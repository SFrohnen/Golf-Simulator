import * as THREE from 'three';
import {GLTFLoader} from 'three/addons/loaders/GLTFLoader.js';
import {RGBELoader} from 'three/addons/loaders/RGBELoader.js';
globalThis.R10Three=THREE;
globalThis.R10ThreeLoaders={GLTFLoader,RGBELoader};
