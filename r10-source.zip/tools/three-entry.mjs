import * as THREE from 'three';
globalThis.R10Three=THREE;
