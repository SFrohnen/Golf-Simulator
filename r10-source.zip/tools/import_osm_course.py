#!/usr/bin/env python3
"""Build a local-metre course pack from OSM Overpass JSON. Strict: no fabricated geometry.
Fetch on a network-enabled computer, or use a previously downloaded raw Overpass JSON.
Only simple closed way polygons are supported in v1; multipolygon relations need manual review.
"""
import argparse, json, math, pathlib, urllib.request, urllib.parse, sys
ROOT=pathlib.Path(__file__).resolve().parents[1]
PROFILES={p['id']:p for p in json.loads((ROOT/'courses/catalog.json').read_text())}
def distance(a,b): return math.hypot(a[0]-b[0],a[1]-b[1])
def inside(p,ring):
    result=False
    for a,b in zip(ring,ring[1:]+ring[:1]):
        if (a[1]>p[1])!=(b[1]>p[1]) and p[0]<(b[0]-a[0])*(p[1]-a[1])/(b[1]-a[1])+a[0]: result=not result
    return result

def download(bbox):
    if len(bbox)!=4 or not (-90<=bbox[0]<bbox[2]<=90 and -180<=bbox[1]<bbox[3]<=180) or max(bbox[2]-bbox[0],bbox[3]-bbox[1])>.15: raise ValueError('Use a small bounding box: south,west,north,east, maximum span 0.15°')
    b=','.join(map(str,bbox)); q=f'[out:json][timeout:60];(way["golf"]({b});way["natural"="water"]({b});way["water"]({b});relation["golf"]({b});relation["natural"="water"]({b}););out geom;'
    req=urllib.request.Request('https://overpass-api.de/api/interpreter',data=urllib.parse.urlencode({'data':q}).encode(),headers={'User-Agent':'PrivateGolfCoursePack/0.7 (manual course geometry import)'})
    with urllib.request.urlopen(req,timeout=90) as r: return json.load(r)

def build(data,profile,refs=None,pars=None,pack_id=None,pack_name=None):
    elements=data.get('elements',[]); ways=[e for e in elements if e.get('type')=='way' and e.get('geometry')]; relations=[e for e in elements if e.get('type')=='relation']; holes=[e for e in ways if e.get('tags',{}).get('golf')=='hole']; byref={}
    for e in holes:
        key=str(e.get('tags',{}).get('ref','')).strip()
        if key: byref.setdefault(key,[]).append(e)
    refs=refs or [str(i) for i in range(1,19)]
    if len(refs)!=18 or len(set(refs))!=18: raise ValueError('Provide 18 unique OSM hole refs in playing order')
    missing=[r for r in refs if len(byref.get(r,[]))!=1]
    if missing: raise ValueError(f'Missing or ambiguous hole refs {missing}; available refs {sorted(byref)}. Select correct area / explicit mapping.')
    if pars is not None and len(pars)!=18: raise ValueError('Provide exactly 18 par values')
    selected=[byref[r][0] for r in refs]; first=selected[0]['geometry'][0]; lat0,lon0=first['lat'],first['lon']; R=6371008.8
    def project(p): return [round(R*math.cos(math.radians(lat0))*math.radians(p['lon']-lon0),2),round(R*math.radians(p['lat']-lat0),2)]
    polygons=[]
    for e in ways:
        tags=e.get('tags',{}); kind=tags.get('golf'); kind={'out_of_bounds':'ob','water_hazard':'water','lateral_water_hazard':'water'}.get(kind,kind)
        if tags.get('natural')=='water' or tags.get('water'): kind='water'
        if kind not in ['fairway','green','bunker','water','ob','rough','tee']: continue
        g=e['geometry']; ring=[project(p) for p in g]
        if len(ring)<4 or distance(ring[0],ring[-1])>.1: continue
        ring.pop(); polygons.append({'type':kind,'ring':ring,'osmId':e['id']})
    result=[]; warnings=[]
    for i,e in enumerate(selected):
        route=[project(p) for p in e['geometry']]; t=e.get('tags',{}); par=(pars or profile.get('par') or [None]*18)[i] if (pars or profile.get('par')) else t.get('par')
        try: par=int(par)
        except (TypeError,ValueError): raise ValueError(f'No verified par for ref {refs[i]}; supply --pars from official scorecard')
        if not 3<=par<=6: raise ValueError('Invalid par')
        start,end=route[0],route[-1]
        green=lambda p:[s for s in polygons if s['type']=='green' and inside(p,s['ring'])]
        g0,g1=green(start),green(end)
        if len(g1)!=1 and len(g0)==1 and not g1: route.reverse();start,end=route[0],route[-1];g1=g0;warnings.append(f'Hole {i+1}: reversed route to match mapped green; review tee.')
        if len(g1)!=1: raise ValueError(f'Hole {i+1} (ref {refs[i]}) endpoint not inside exactly one mapped green; manual review needed. No geometry invented.')
        if not 40<=distance(start,end)<=1000: raise ValueError(f'Implausible hole length {i+1}')
        if not any(s['type']=='tee' and inside(start,s['ring']) for s in polygons): warnings.append(f'Hole {i+1}: tee position from route endpoint, not a verified tee box.')
        xs,ys=zip(*route); loX,hiX=min(xs)-90,max(xs)+90;loY,hiY=min(ys)-90,max(ys)+90
        surfaces=[]
        for s in polygons:
            # Include only the target green as green; other greens are unmapped for putting.
            if s['type']=='green' and s['osmId']!=g1[0]['osmId']: continue
            xx,yy=zip(*s['ring'])
            if max(xx)<loX or min(xx)>hiX or max(yy)<loY or min(yy)>hiY:continue
            if len(s['ring'])>3000: raise ValueError(f'Polygon {s["osmId"]} exceeds v1 complexity; simplify with review')
            surfaces.append(s)
        if not any(s['type']=='fairway' for s in surfaces): warnings.append(f'Hole {i+1}: no nearby fairway polygon.')
        result.append({'number':i+1,'par':par,'tee':start,'pin':end,'route':route,'surfaces':surfaces,'osmHoleId':e['id'],'osmRef':refs[i]})
    if relations: warnings.append(f'{len(relations)} relation(s) not converted; check multipolygon surfaces and hazards manually.')
    warnings.append('Pin positions are OSM route endpoints, not daily pin locations. Tee colours, elevation, trees and out-of-bounds completeness are not validated.')
    return {'version':1,'id':pack_id or profile['id'],'name':pack_name or profile['name'],'kind':'osm','attribution':'© OpenStreetMap contributors, ODbL 1.0 (https://www.openstreetmap.org/copyright). Unreviewed geometry; pin/tee route endpoints.', 'origin':{'lat':lat0,'lon':lon0},'sourceDate':data.get('osm3s',{}).get('timestamp_osm_base'),'reference':profile['reference'],'warnings':warnings,'holes':result}

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--profile',required=True,choices=PROFILES);g=p.add_mutually_exclusive_group(required=True);g.add_argument('--input',type=pathlib.Path);g.add_argument('--bbox',nargs=4,type=float,metavar=('S','W','N','E'));p.add_argument('--refs',help='18 comma-separated exact OSM refs in playing order (required for Weiherhof loop pairing)');p.add_argument('--pars',help='18 comma-separated verified par values');p.add_argument('--id');p.add_argument('--name');p.add_argument('--out',type=pathlib.Path,required=True);a=p.parse_args()
    if a.profile=='weiherhof' and not a.refs: p.error('Choose two nine-hole loops using --refs in playing order; verify actual refs first.')
    try:
        data=json.loads(a.input.read_text()) if a.input else download(a.bbox)
        pack=build(data,PROFILES[a.profile],a.refs.split(',') if a.refs else None,[int(x) for x in a.pars.split(',')] if a.pars else None,a.id,a.name)
        txt=json.dumps(pack,ensure_ascii=False,separators=(',',':'))
        if len(txt.encode())>1024*1024: raise ValueError('Pack exceeds app 1 MB limit; simplify polygons with review')
        a.out.write_text(txt,encoding='utf-8');print(f'Wrote {a.out}; {len(pack["holes"])} holes; REVIEW before use.');print('\n'.join(pack['warnings']))
    except Exception as e: sys.exit('Import failed: '+str(e))
if __name__=='__main__': main()
