#!/usr/bin/env python3
"""Offline enrichment of the validated Trier pack from the user's OSM XML.
Requires shapely 2; no network. Trees use an explicitly approximate footprint.
"""
import sys,json,math,xml.etree.ElementTree as ET
from pathlib import Path
from shapely.geometry import Point,LineString,Polygon,box
from shapely.ops import polygonize,unary_union
from shapely import make_valid

def enrich(xml,pack):
    root=ET.parse(xml).getroot(); origin=pack['origin']; R=6371008.8
    def proj(lat,lon):return (R*math.cos(math.radians(origin['lat']))*math.radians(float(lon)-origin['lon']),R*math.radians(float(lat)-origin['lat']))
    def tags(e):return {t.get('k'):t.get('v') for t in e.findall('tag')}
    nodes={e.get('id'):proj(e.get('lat'),e.get('lon')) for e in root.findall('node')}
    ways={e.get('id'):e for e in root.findall('way')}
    def coords(e):
        refs=[n.get('ref') for n in e.findall('nd')];return [nodes[x] for x in refs] if all(x in nodes for x in refs) else []
    def kind(t):
        if t.get('natural') in ('wood','scrub') or t.get('landuse')=='forest':return 'woodland'
        if t.get('natural')=='water' or t.get('water') or t.get('golf') in ('water_hazard','lateral_water_hazard'):return 'water'
        if t.get('golf')=='out_of_bounds':return 'ob'
    def parts(g):
        if g.geom_type=='Polygon':yield g
        elif hasattr(g,'geoms'):
            for a in g.geoms:yield from parts(a)
    features=[]; relation_members=set(); skipped=[]
    for e in root.findall('relation'):
        t=tags(e);k=kind(t)
        if not k or t.get('type')!='multipolygon':continue
        groups={'outer':[],'inner':[]}; ids=[];ok=True
        for m in e.findall('member'):
            role=m.get('role') or 'outer';wid=m.get('ref')
            if role not in groups or m.get('type')!='way' or wid not in ways:ok=False;break
            p=coords(ways[wid]);
            if len(p)<2:ok=False;break
            groups[role].append(LineString(p));ids.append(wid)
        if not ok:skipped.append(e.get('id'));continue
        from shapely.ops import polygonize_full
        out,cuts,dangles,invalid=polygonize_full(groups['outer']);inn,ic,idg,ii=polygonize_full(groups['inner'])
        if out.is_empty or any(not g.is_empty for g in (cuts,dangles,invalid,ic,idg,ii)):skipped.append(e.get('id'));continue
        geom=unary_union(list(out.geoms)).difference(unary_union(list(inn.geoms)))
        if not geom.is_empty:features.append((k,'relation/'+e.get('id'),geom));relation_members.update(ids)
    for wid,e in ways.items():
        t=tags(e);p=coords(e);k=kind(t)
        if len(p)>=4 and p[0]==p[-1] and k and wid not in relation_members:features.append((k,'way/'+wid,make_valid(Polygon(p))))
        elif len(p)>=2 and t.get('natural')=='tree_row':features.append(('tree_row','way/'+wid,LineString(p).buffer(3,quad_segs=3)))
    for e in root.findall('node'):
        if tags(e).get('natural')=='tree':
            t=tags(e)
            try:r=max(1,min(12,float(t['diameter_crown'])/2))
            except (KeyError,ValueError):r=2.5
            features.append(('tree','node/'+e.get('id'),Point(nodes[e.get('id')]).buffer(r,quad_segs=3)))
    def ring(r):return [[round(x,2),round(y,2)] for x,y in list(r.coords)[:-1]]
    for h in pack['holes']:
        xs,ys=zip(*h['route']); area=box(min(xs)-100,min(ys)-100,max(xs)+100,max(ys)+100)
        # Preserve all fairways, target green, sand and mapped water in the prior pack.
        # Add woodland and tree footprints as OB; use mapped water relations/ways as well.
        surfaces=[s for s in h['surfaces'] if s['type'] not in ('woodland','tree_row','tree')]
        knownwater={str(s.get('osmId')) for s in surfaces if s['type']=='water'}
        for k,ref,geom in features:
            if k=='water' and ref.startswith('way/') and ref.split('/')[1] in knownwater:continue
            if not geom.intersects(area):continue
            for g in parts(geom.intersection(area).simplify(.30,preserve_topology=True)):
                if g.area<1:continue
                ext=ring(g.exterior); holes=[ring(r) for r in g.interiors];
                if len(ext)<3:continue
                surfaces.append({'type':k,'ring':ext,'holes':[r for r in holes if len(r)>=3],'osmRef':ref})
        h['surfaces']=surfaces
    pack['mapRevision']=2
    pack['warnings'].append('Woodland, scrub and mapped tree areas are lost-ball OB under simulator house rules, not official course OB. Tree rows use 3 m half-width; single trees use mapped crown diameter or estimated 2.5 m radius. Only landing locations tested, not airborne collisions. Unmapped terrain remains unknown. Nearby hazards clipped to a 100 m route bounding margin. Missing/incomplete OSM relations: '+(', '.join(skipped) or 'none')+'.')
    pack['attribution']+=' Woodland and tree mapping uses OSM; estimated tree footprints are simulator house rules.'
    return pack
if __name__=='__main__':
    p=enrich(sys.argv[1],json.load(open(sys.argv[2]))); Path(sys.argv[3]).write_text(json.dumps(p,ensure_ascii=False,separators=(',',':')),encoding='utf8')
    print('surfaces',sum(len(h['surfaces']) for h in p['holes']),'max per hole',max(len(h['surfaces']) for h in p['holes']))
