#!/usr/bin/env python3
"""Fetch verified official RLP tile names; fall back to Skadi if unavailable.
Runs in CI or manually. No external network at app runtime. Never generates fake terrain.
"""
import pathlib, sys, tempfile, urllib.request, subprocess, venv, json, time
ROOT=pathlib.Path(__file__).resolve().parents[1]
BASE='https://geobasis-rlp.de/data/dgm1/current/tif/'
NAMES=[f'dgm1_32_{x}_{y}_1_rp_2025.tif' for x in (342,343,344) for y in (5522,5523,5524)]

def fetch(url,path):
    for attempt in range(2):
        try:
            req=urllib.request.Request(url,headers={'User-Agent':'R10PrivateRange/0.7.9 (open terrain import)'})
            with urllib.request.urlopen(req,timeout=25) as f: data=f.read(20*1024*1024+1)
            if len(data)>20*1024*1024 or data[:4] not in (b'II*\x00',b'MM\x00*',b'II+\x00',b'MM\x00+'):
                raise ValueError('Invalid or oversized TIFF response')
            path.write_bytes(data);print('Downloaded',path.name,len(data),flush=True);return
        except Exception as e:
            print('Tile retrieval attempt failed:',url,str(e),flush=True)
            if attempt==1:raise
            time.sleep(1)

def main():
    # A manually prepared pack can be included without any further download.
    from prepare_terrain import ASSET
    from subprocess import run
    report=json.loads(ASSET.read_text().split('=',1)[1].strip().rstrip(';'))
    if any(p.get('id')=='trier' and p.get('terrain') for p in report['packs']):
        print('Trier already has bundled elevation; skipping download');return
    try:
        with tempfile.TemporaryDirectory(prefix='trier-dem-') as tmp:
            d=pathlib.Path(tmp); files=[d/n for n in NAMES]
            for p in files:fetch(BASE+p.name,p)
            py=sys.executable
            try:import rasterio,pyproj
            except ImportError:
                env=d/'venv';venv.EnvBuilder(with_pip=True).create(env);py=str(env/'bin/python')
                run([py,'-m','pip','install','--disable-pip-version-check','--retries','1','--timeout','20','rasterio','pyproj'],check=True,timeout=180)
            run([py,str(ROOT/'tools/prepare_terrain.py'),'--tif',*map(str,files),'--bundle'],check=True,timeout=180)
            print('Official DGM1 terrain bundled successfully',flush=True);return
    except Exception as e:print('Official DGM1 unavailable:',str(e),flush=True)
    # Retain previous coarse source as fallback; emits explicit flat status on failure.
    run([sys.executable,str(ROOT/'tools/prepare_terrain.py'),'--download','--bundle'],check=True)
if __name__=='__main__':main()
