#!/usr/bin/env python3
"""Fetch public OSM geographic data on the connected build runner, never fabricate routes.
A missing network or incomplete map is a reported result, not an invented course.
Raw OSM and pack JSON are retained with the generated asset for provenance / ODbL.
"""
import argparse,json,pathlib,urllib.request,urllib.parse,time
from import_osm_course import PROFILES,build
ENDPOINTS=('https://overpass-api.de/api/interpreter','https://overpass.kumi.systems/api/interpreter')
def query(p):
    b=','.join(map(str,p['bbox']))
    return f'[out:json][timeout:25];(way({p["osmBoundary"]});way["golf"]({b});way["natural"="water"]({b});way["water"]({b});relation["golf"]({b});relation["natural"="water"]({b}););out geom;'
def fetch(p):
    errors=[]
    for endpoint in ENDPOINTS:
        try:
            req=urllib.request.Request(endpoint+'?'+urllib.parse.urlencode({'data':query(p)}),headers={'User-Agent':'PrivateGolfCoursePack/0.7.1 (one-time private build; OSM attribution retained)'})
            with urllib.request.urlopen(req,timeout=35) as r:
                raw=r.read(12*1024*1024+1)
            if len(raw)>12*1024*1024: raise ValueError('Overpass response exceeds limit')
            data=json.loads(raw)
            if data.get('remark'): raise ValueError(str(data['remark'])[:300])
            return data,endpoint
        except Exception as e: errors.append(f'{endpoint}: {e}')
        time.sleep(2)
    raise ValueError(' | '.join(errors))
def convert(data,p):
    elements=data.get('elements',[])
    if not any(e.get('type')=='way' and e.get('id')==p['osmBoundary'] and e.get('tags',{}).get('leisure')=='golf_course' for e in elements): raise ValueError('Expected OSM course boundary not found; review location')
    refs=sorted(str(e.get('tags',{}).get('ref','')) for e in elements if e.get('type')=='way' and e.get('tags',{}).get('golf')=='hole')
    if p['id']=='weiherhof': raise ValueError('Explicit verified A/B/C loop mapping required; found refs: '+', '.join(refs))
    pack=build(data,p,allow_missing_green=(p['id']=='trier'))
    pack['attribution']+=' Geometry automatically checked, not independently surveyed.'
    pack['quality']='provisional' if any(h.get('approximatePuttingTarget') for h in pack['holes']) else 'mapped-unreviewed'
    if len(json.dumps(pack,ensure_ascii=False).encode())>1024*1024: raise ValueError('Pack exceeds 1 MB')
    return pack

def prepare(out,online=False,fixtures=None):
    out.mkdir(parents=True,exist_ok=True); source=out/'osm-source';source.mkdir(exist_ok=True)
    for f in source.glob('*.json'):f.unlink()
    packs=[];status=[]
    for p in PROFILES.values():
        item={'id':p['id'],'name':p['name'],'state':'pending','detail':p.get('mappingNote','')}
        if online or fixtures:
            try:
                data,endpoint=(json.loads((fixtures/(p['id']+'.json')).read_text()),'local fixture') if fixtures else fetch(p)
                item['mappedRoutes']=sum(e.get('type')=='way' and e.get('tags',{}).get('golf')=='hole' for e in data.get('elements',[]));item['sourceDate']=data.get('osm3s',{}).get('timestamp_osm_base')
                (source/(p['id']+'.overpass.json')).write_text(json.dumps(data,separators=(',',':')),encoding='utf-8')
                pack=convert(data,p);pack['sourceEndpoint']=endpoint;packs.append(pack);item.update(state='available',detail=f'18 routes; {sum(h.get("approximatePuttingTarget") is not None for h in pack["holes"])} approximate putting target(s). Review geometry before use.',quality=pack['quality'])
                (source/(p['id']+'.pack.json')).write_text(json.dumps(pack,ensure_ascii=False,separators=(',',':')),encoding='utf-8')
            except Exception as e: item.update(state='unavailable',detail=str(e)[:600])
        status.append(item);print(f'{p["id"]}: {item["state"]}: {item["detail"]}',flush=True)
    report={'packs':packs,'status':status}
    (out/'course-packs.js').write_text('globalThis.R10BundledCourses='+json.dumps(report,ensure_ascii=True,separators=(',',':'))+';\n',encoding='utf-8')
    (source/'report.json').write_text(json.dumps(status,ensure_ascii=False,indent=2),encoding='utf-8')
    (source/'LICENSE.txt').write_text('Map data © OpenStreetMap contributors; Open Database License 1.0. https://www.openstreetmap.org/copyright\nRaw Overpass source and transformed packs are supplied here where retrieved. Official scorecard pars are factual reference values; no club maps or satellite imagery copied.\n',encoding='utf-8')
    return report
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--out',type=pathlib.Path,required=True);ap.add_argument('--online',action='store_true');ap.add_argument('--fixtures',type=pathlib.Path);a=ap.parse_args();prepare(a.out,a.online,a.fixtures)
