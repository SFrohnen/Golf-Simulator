"""Fetch licensed source assets during CI. No asset network requests at app runtime."""
import base64, hashlib, io, json, mimetypes, pathlib, re, sys, time, urllib.request, urllib.parse, zipfile
OUT=pathlib.Path('app/src/main/assets/real-assets.js')
AGENT='R10PrivateRange/0.19 (private offline golf simulator asset build)'
MAX=100*1024*1024

def fetch(url):
    if urllib.parse.urlsplit(url).scheme!='https': raise ValueError('HTTPS required')
    for attempt in range(3):
        try:
            with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':AGENT}),timeout=90) as r:
                data=r.read(MAX+1)
            if not data or len(data)>MAX: raise ValueError('invalid asset size')
            return data
        except Exception:
            if attempt==2: raise
            time.sleep(2**attempt)

def uri(data,mime): return 'data:'+mime+';base64,'+base64.b64encode(data).decode('ascii')
def record(data,url): return {'url':url,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
def checked(info):
    data=fetch(info['url'])
    if info.get('md5') and hashlib.md5(data).hexdigest()!=info['md5'].lower(): raise ValueError('Poly Haven MD5 mismatch')
    return data

def ambient(asset):
    url=f'https://ambientcg.com/get?file={asset}_1K-JPG.zip'; data=fetch(url)
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        names=z.namelist(); out={}
        for key,pattern in [('color','Color'),('normal','NormalGL'),('roughness','Roughness')]:
            found=[n for n in names if re.search(r'_'+pattern+r'\.jpg$',n,re.I)]
            if not found: raise ValueError(f'{asset} missing {pattern}')
            raw=z.read(found[0]); assert raw[:2]==b'\xff\xd8'
            out[key]=uri(raw,'image/jpeg')
    return out,record(data,url)

def files(asset): return json.loads(fetch('https://api.polyhaven.com/files/'+asset))
def model(asset):
    f=files(asset)['gltf']; resolution=next((r for r in ['1k','2k','512','4k'] if r in f),None)
    if not resolution: raise ValueError(f'{asset} has no supported glTF resolution')
    info=f[resolution]['gltf']; raw=checked(info); gltf=json.loads(raw); includes=info.get('include',{}); sources=[record(raw,info['url'])]
    for item in gltf.get('buffers',[])+gltf.get('images',[]):
        name=item.get('uri');
        if not name or name.startswith('data:'): continue
        key=urllib.parse.unquote(name); inc=includes.get(name) or includes.get(key) or includes.get('./'+key)
        if not inc:
            matches=[v for k,v in includes.items() if pathlib.PurePosixPath(urllib.parse.unquote(k)).name==pathlib.PurePosixPath(key).name]
            if len(matches)==1: inc=matches[0]
        if not inc: raise ValueError(f'{asset}: missing include {name}')
        binary=checked(inc); mime=item.get('mimeType') or mimetypes.guess_type(key)[0] or 'application/octet-stream'; item['uri']=uri(binary,mime); sources.append(record(binary,inc['url']))
    # JSON with all external buffers/images embedded: file:// WebViews need no external fetch.
    return gltf,{'resolution':resolution,'files':sources}

def hdr(asset):
    info=files(asset)['hdri']['1k']['hdr']; raw=checked(info)
    if not raw.startswith((b'#?RADIANCE',b'#?RGBE')): raise ValueError('invalid HDR image')
    return uri(raw,'application/octet-stream'),record(raw,info['url'])

def build():
    assets={'materials':{},'models':{},'sources':{},'license':'CC0-1.0'}
    for key,asset in [('fairway','Grass005'),('rough','Grass004'),('sand','Ground052')]:
        assets['materials'][key],assets['sources'][asset]=ambient(asset); print('Downloaded',asset,flush=True)
    for key,asset in [('pine','pine_tree_01'),('broadleaf','tree_small_02'),('grass','grass_bermuda_01')]:
        assets['models'][key],assets['sources'][asset]=model(asset); print('Downloaded',asset,flush=True)
    assets['hdr'],assets['sources']['limpopo_golf_course']=hdr('limpopo_golf_course')
    payload='globalThis.R10RealAssets='+json.dumps(assets,separators=(',',':'))+';\n'
    if len(payload)>90*1024*1024: raise ValueError('Asset pack exceeds 90 MiB; optimize assets before release')
    OUT.write_text(payload); print('PASS real CC0 asset bundle',len(payload),'bytes',flush=True)
if __name__=='__main__': build()
