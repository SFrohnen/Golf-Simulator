"""Fetch licensed source assets during CI. No asset network requests at app runtime."""
import struct, base64, hashlib, io, json, mimetypes, os, pathlib, re, sys, time, urllib.request, urllib.parse, zipfile
OUT=pathlib.Path('app/src/main/assets/real-assets.js')
AGENT='R10PrivateRange/0.24.1 (private offline golf simulator asset build)'
MAX=100*1024*1024

def fetch(url):
    if urllib.parse.urlsplit(url).scheme!='https': raise ValueError('HTTPS required')
    for attempt in range(3):
        try:
            headers={'User-Agent':AGENT}
            # GitHub token is sent only to the GitHub API, never to asset providers.
            if urllib.parse.urlsplit(url).hostname=='api.github.com' and os.environ.get('GH_TOKEN'):
                headers['Authorization']='Bearer '+os.environ['GH_TOKEN']
            with urllib.request.urlopen(urllib.request.Request(url,headers=headers),timeout=90) as r:
                data=r.read(MAX+1)
            if not data or len(data)>MAX: raise ValueError(f'invalid asset size: {url} ({len(data)} bytes read; limit {MAX})')
            return data
        except Exception as exc:
            if attempt==2 or getattr(exc,'code',None) in (401,403,404,429): raise
            time.sleep(2**attempt)

def uri(data,mime): return 'data:'+mime+';base64,'+base64.b64encode(data).decode('ascii')
def record(data,url): return {'url':url,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
def checked(info):
    data=fetch(info['url'])
    if info.get('md5') and hashlib.md5(data).hexdigest()!=info['md5'].lower(): raise ValueError('Poly Haven MD5 mismatch')
    return data

def ambient(asset, fetcher=None):
    url=f'https://ambientcg.com/get?file={asset}_1K-JPG.zip'; data=(fetcher or fetch)(url)
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        names=z.namelist(); out={}
        for key,pattern in [('color','Color'),('normal','NormalGL'),('roughness','Roughness')]:
            found=[n for n in names if re.search(r'_'+pattern+r'\.jpg$',n,re.I)]
            if not found: raise ValueError(f'{asset} missing {pattern}')
            raw=z.read(found[0]); assert raw[:2]==b'\xff\xd8'
            out[key]=uri(raw,'image/jpeg')
    return out,record(data,url)

def files(asset): return json.loads(fetch('https://api.polyhaven.com/files/'+asset))
def model(asset):
    f=files(asset)['gltf']; resolution=next((r for r in ['1k','2k','512','4k'] if r in f),None)
    if not resolution: raise ValueError(f'{asset} has no supported glTF resolution')
    info=f[resolution]['gltf']; raw=checked(info); gltf=json.loads(raw); includes=info.get('include',{}); sources=[record(raw,info['url'])]
    for item in gltf.get('buffers',[])+gltf.get('images',[]):
        name=item.get('uri');
        if not name or name.startswith('data:'): continue
        key=urllib.parse.unquote(name); inc=includes.get(name) or includes.get(key) or includes.get('./'+key)
        if not inc:
            matches=[v for k,v in includes.items() if pathlib.PurePosixPath(urllib.parse.unquote(k)).name==pathlib.PurePosixPath(key).name]
            if len(matches)==1: inc=matches[0]
        if not inc: raise ValueError(f'{asset}: missing include {name}')
        binary=checked(inc); mime=item.get('mimeType') or mimetypes.guess_type(key)[0] or 'application/octet-stream'; item['uri']=uri(binary,mime); sources.append(record(binary,inc['url']))
    # JSON with all external buffers/images embedded: file:// WebViews need no external fetch.
    return gltf,{'resolution':resolution,'files':sources}

# Prefer mobile-ready meshes, not offline-rendering hero assets. Both packs are CC0.
QUAT_REPO='petroulacl/fps-buildings-env-kit'
KENNEY_URL='https://kenney.nl/media/pages/assets/nature-kit/37ac38a37b-1677698939/kenney_nature-kit.zip'
MODEL_BYTES=8*1024*1024
MODEL_TRIANGLES={'pine':24000,'broadleaf':24000,'grass':4000,'cart':24000}

def glb_to_model(raw, kind):
    if len(raw)>MODEL_BYTES or len(raw)<20: raise ValueError(f'{kind}: GLB size outside mobile budget: {len(raw)} bytes')
    magic,version,total=struct.unpack_from('<4sII',raw)
    if magic!=b'glTF' or version!=2 or total!=len(raw): raise ValueError('Invalid GLB header')
    chunks={}; pos=12
    while pos<len(raw):
        if pos+8>len(raw): raise ValueError('Truncated GLB chunk')
        size,tag=struct.unpack_from('<I4s',raw,pos); pos+=8
        if pos+size>len(raw): raise ValueError('Truncated GLB data')
        chunks[tag]=raw[pos:pos+size];pos+=size
    gltf=json.loads(chunks[b'JSON'].rstrip(b'\x00 '))
    if gltf.get('extensionsRequired'): raise ValueError('Unsupported required GLB extensions')
    for i,b in enumerate(gltf.get('buffers',[])):
        if 'uri' in b:
            if not b['uri'].startswith('data:'): raise ValueError('External GLB buffer')
        elif i==0 and b'BIN\x00' in chunks:
            if b['byteLength']>len(chunks[b'BIN\x00']): raise ValueError('Truncated GLB buffer')
            b['uri']=uri(chunks[b'BIN\x00'][:b['byteLength']],'application/octet-stream')
        else: raise ValueError('Missing GLB buffer')
    for image in gltf.get('images',[]):
        if 'uri' in image and not image['uri'].startswith('data:'): raise ValueError('External GLB image')
    accessors=gltf.get('accessors',[]); tris=0
    for mesh in gltf.get('meshes',[]):
        for p in mesh.get('primitives',[]):
            if p.get('mode',4)!=4 or 'POSITION' not in p.get('attributes',{}): raise ValueError('Unsupported mesh primitive')
            tris+=accessors[p.get('indices',p['attributes']['POSITION'])]['count']//3
    if not 0<tris<=MODEL_TRIANGLES[kind]: raise ValueError(f'{kind}: {tris} triangles exceeds mobile budget {MODEL_TRIANGLES[kind]}')
    return gltf,tris

def rank_model(path,kind):
    stem=pathlib.PurePosixPath(path).stem.lower(); n=re.sub(r'[^a-z0-9]','',stem)
    if any(w in n for w in ('dead','snow','stump','autumn','fall','palm','cactus','flower','rock','winter','log','hedge','patch','wheat','dry','cut','tallgrass')): return None
    if kind=='pine':
        if not any(w in n for w in ('pine','fir','conifer','spruce')): return None
        return (0 if 'pine' in n else 1,0 if any(w in n for w in ('default','common','medium','normal')) else 1,len(n),n)
    if kind=='broadleaf':
        if not ('tree' in n or 'oak' in n): return None
        if any(w in n for w in ('pine','fir','conifer','spruce','sapling','bush','birch','willow','cypress')): return None
        return (0 if any(w in n for w in ('oak','common','default','round','maple')) else 1,len(n),n)
    if 'grass' not in n: return None
    return (0 if any(w in n for w in ('short','tuft','common','default')) else 1,len(n),n)

def pick_model(paths,kind,reader,provider):
    candidates=sorted((score,path) for path in paths if path.lower().endswith('.glb') and (score:=rank_model(path,kind)) is not None)
    errors=[]
    for _,path in candidates[:12]:
        try:
            raw,url=reader(path); gltf,tris=glb_to_model(raw,kind)
            source=record(raw,url);source.update({'provider':provider,'asset':path,'triangles':tris,'license':'CC0-1.0'})
            print(f'Downloaded {kind}: {provider} {path} ({len(raw)} bytes, {tris} triangles)',flush=True)
            return gltf,source
        except Exception as exc:
            errors.append(f'{path}: {exc}');print(f'Skipped {kind} candidate {path}: {exc}',flush=True)
    raise ValueError(f'{provider}: no usable {kind} model; {errors}')

def mobile_models(existing=None, provenance=None):
    output=dict(existing or {});sources=dict(provenance or {}); kinds=('pine','broadleaf','grass')
    if all(k in output for k in kinds): return output,sources
    try:
        # Resolve paths and a single commit from GitHub instead of guessing file names.
        head=json.loads(fetch(f'https://api.github.com/repos/{QUAT_REPO}/commits/main'))
        commit=head['sha']; tree=head['commit']['tree']['sha']
        meta=json.loads(fetch(f'https://api.github.com/repos/{QUAT_REPO}/git/trees/{tree}?recursive=1'))
        if meta.get('truncated'): raise ValueError('GitHub tree listing truncated')
        paths=[x['path'] for x in meta['tree'] if x.get('type')=='blob' and x['path'].startswith('environment/vegetation/') and x.get('size',MODEL_BYTES)<=MODEL_BYTES]
        def reader(path):
            url=f'https://raw.githubusercontent.com/{QUAT_REPO}/{commit}/'+urllib.parse.quote(path,safe='/')
            return fetch(url),url
        for kind in kinds:
            if kind in output: continue
            try: output[kind],sources[kind]=pick_model(paths,kind,reader,'Quaternius / Stylized Nature MegaKit')
            except Exception as exc: print(f'Quaternius {kind} unavailable: {exc}',flush=True)
    except Exception as exc: print(f'Quaternius unavailable: {exc}',flush=True)
    if len(output)<len(kinds):
        try:
            raw=fetch(KENNEY_URL)
            if not zipfile.is_zipfile(io.BytesIO(raw)):
                raise ValueError(f'Kenney response is not a ZIP ({len(raw)} bytes)')
            with zipfile.ZipFile(io.BytesIO(raw)) as z:
                paths=[x.filename for x in z.infolist() if x.file_size<=MODEL_BYTES]
                for kind in kinds:
                    if kind in output: continue
                    try: output[kind],sources[kind]=pick_model(paths,kind,lambda path:(z.read(path),KENNEY_URL+'#'+urllib.parse.quote(path)),'Kenney / Nature Kit')
                    except Exception as exc: print(f'Kenney {kind} unavailable: {exc}',flush=True)
        except Exception as exc: print(f'Kenney unavailable: {exc}',flush=True)
    for kind in kinds:
        if kind not in output: print(f'WARNING: {kind} unavailable; using built-in vegetation',flush=True)
    return output,sources

def hdr(asset):
    info=files(asset)['hdri']['1k']['hdr']; raw=checked(info)
    if not raw.startswith((b'#?RADIANCE',b'#?RGBE')): raise ValueError('invalid HDR image')
    return uri(raw,'application/octet-stream'),record(raw,info['url'])

# Optional facility upgrades. A failed provider or unsupported GLB cannot break the existing offline build.
BUNDLED_CART=pathlib.Path(__file__).resolve().parent/'bundled-assets'/'range-cart.glb'
FACILITY_CART_URL='https://tevy.dev/models/golf-cart/v1/lod0.glb'
FACILITY_MATERIALS={'stone':'Bricks099','roof':'RoofingTiles013A','timber':'WoodSiding002'}
def fetch_optional(url):
    if urllib.parse.urlsplit(url).scheme!='https': raise ValueError('HTTPS required')
    limit=12*1024*1024
    with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':AGENT}),timeout=20) as r:
        data=r.read(limit+1)
    if not data or len(data)>limit: raise ValueError('Optional asset exceeds 12 MiB budget')
    return data

def optional_facility(previous=None):
    pack={'materials':{},'models':{},'sources':{}}
    try:
        local=BUNDLED_CART.is_file()
        raw=BUNDLED_CART.read_bytes() if local else fetch_optional(FACILITY_CART_URL)
        gltf,tris=glb_to_model(raw,'cart')
        source='bundled-assets/range-cart.glb' if local else FACILITY_CART_URL
        pack['models']['cart']=gltf; pack['sources']['cart']={**record(raw,source),'triangles':tris,'license':'original project asset' if local else 'CC0-1.0','provider':'Original bundled cart v0.26' if local else 'tevy v1'}
        print('Golf cart packaged:',tris,'triangles; local:',local,flush=True)
    except Exception as exc: print('Optional golf cart unavailable, using original model:',exc,flush=True)
    previous=previous or {}
    for kind,asset in FACILITY_MATERIALS.items():
        if kind in previous.get('materials',{}) and previous.get('sources',{}).get(kind,{}).get('asset')==asset:
            pack['materials'][kind]=previous['materials'][kind];pack['sources'][kind]=previous['sources'][kind];continue
        try:
            maps,source=ambient(asset,fetch_optional)
            if sum(map(len,maps.values()))>12*1024*1024: raise ValueError('Optional material exceeds encoded budget')
            pack['materials'][kind]=maps;pack['sources'][kind]={**source,'license':'CC0-1.0','asset':asset}
            print('Optional facility material downloaded:',asset,flush=True)
        except Exception as exc: print('Optional facility material unavailable:',asset,exc,flush=True)
    return pack

CORE_MATERIALS={'fairway':'Grass005','rough':'Grass004','sand':'Ground052'}
CACHE_SCHEMA=1

def read_cache(path):
    if path is None or not path.is_file(): return {}
    try:
        if path.stat().st_size>95*1024*1024: raise ValueError('cache too large')
        doc=json.loads(path.read_text()); assets=doc['assets']
        payload=json.dumps(assets,separators=(',',':'),sort_keys=True).encode()
        if doc['schema']!=CACHE_SCHEMA or hashlib.sha256(payload).hexdigest()!=doc['sha256']: raise ValueError('cache integrity mismatch')
        if not isinstance(assets,dict): raise ValueError('invalid cache')
        print('Validated asset cache restored',flush=True);return assets
    except Exception as exc: print('Ignoring invalid asset cache:',exc,flush=True);return {}

def save_cache(path,assets):
    if path is None: return
    payload=json.dumps(assets,separators=(',',':'),sort_keys=True).encode()
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps({'schema':CACHE_SCHEMA,'sha256':hashlib.sha256(payload).hexdigest(),'assets':assets},separators=(',',':')));tmp.replace(path)

def build():
    cache_path=pathlib.Path(os.environ['R10_ASSET_CACHE']) if os.environ.get('R10_ASSET_CACHE') else None
    prior=read_cache(cache_path)
    assets={'materials':{},'models':{},'sources':{},'license':'CC0-1.0'}
    for key,asset in CORE_MATERIALS.items():
        if key in prior.get('materials',{}) and asset in prior.get('sources',{}):
            assets['materials'][key]=prior['materials'][key];assets['sources'][asset]=prior['sources'][asset];print('Cached',asset,flush=True)
        else:
            assets['materials'][key],assets['sources'][asset]=ambient(asset);print('Downloaded',asset,flush=True)
    existing={k:v for k,v in prior.get('models',{}).items() if k in ('pine','broadleaf','grass') and k in prior.get('sources',{})}
    assets['models'], vegetation_sources=mobile_models(existing,{k:prior['sources'][k] for k in existing})
    assets['sources'].update(vegetation_sources)
    if prior.get('hdr') and 'limpopo_golf_course' in prior.get('sources',{}):
        assets['hdr']=prior['hdr'];assets['sources']['limpopo_golf_course']=prior['sources']['limpopo_golf_course'];print('Cached HDRI',flush=True)
    else:
        try: assets['hdr'],assets['sources']['limpopo_golf_course']=hdr('limpopo_golf_course')
        except Exception as exc: print('WARNING: HDRI unavailable; using built-in lighting:',exc,flush=True)
    # Preserve optional materials in the validated cache, but always read the shipped model anew.
    assets['facility']=optional_facility(prior.get('facility'))
    # Cache only facility materials; the versioned cart is always read from source.
    save_cache(cache_path,{**assets,'facility':{'materials':assets['facility']['materials'],'sources':{k:v for k,v in assets['facility']['sources'].items() if k in FACILITY_MATERIALS}}})
    missing=[k for k in ('pine','broadleaf','grass') if k not in assets['models']]+([] if assets.get('hdr') else ['HDRI'])
    assets['missing']=missing
    payload='globalThis.R10RealAssets='+json.dumps(assets,separators=(',',':'))+';\n'
    if len(payload)>90*1024*1024:
        assets['facility']['materials']={};assets['facility']['sources']={k:v for k,v in assets['facility']['sources'].items() if k=='cart'};print('Optional facility materials omitted: overall bundle budget',flush=True)
        payload='globalThis.R10RealAssets='+json.dumps(assets,separators=(',',':'))+';\n'
    if len(payload)>90*1024*1024: raise ValueError('Asset pack exceeds 90 MiB; optimize assets before release')
    OUT.write_text(payload); print('PASS CC0 asset bundle',len(payload),'bytes; missing optional vegetation/HDRI:',missing,flush=True)
if __name__=='__main__': build()
