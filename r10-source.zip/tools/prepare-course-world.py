#!/usr/bin/env python3
"""Offline world builder. Shapely 2.1+. Existing OSM and licensed bundled aerials;
manual traces are approximate, not an official survey. No network at runtime."""
import ast,json,math
from pathlib import Path
from collections import defaultdict
from shapely import constrained_delaunay_triangles, make_valid
from shapely.geometry import Polygon,LineString,box
from shapely.ops import unary_union
from shapely.strtree import STRtree
ROOT=Path(__file__).resolve().parents[1]; A=ROOT/'app/src/main/assets'
def read(n):return json.loads((A/n).read_text().split('=',1)[1].strip().rstrip(';'))
P=read('course-packs.js')['packs']; aerial=read('aerial.js'); canopy=read('canopy.js')
traces=next(ast.literal_eval(n.value) for n in ast.parse((ROOT/'tools/extend_canopy.py').read_text()).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='TRACES' for t in n.targets))
# Coordinates on the inspected 900x900 Trier, 1200x900 Kikuoka, 1200x600 Weiherhof aerials.
HAZARDS={
 'trier':{'bunker':[[(640,331),(645,329),(650,331),(655,332),(655,336),(649,338),(644,336)],[(380,203),(386,202),(390,205),(390,210),(395,213),(393,218),(385,218),(376,215),(377,209)],[(141,638),(146,635),(149,638),(148,644),(141,645),(137,642)],[(566,524),(573,519),(577,521),(575,527),(568,531),(564,528)],[(719,464),(728,463),(730,467),(723,470),(714,470),(713,467)]], 'water':[[(417,397),(436,393),(457,386),(469,388),(475,401),(474,413),(453,420),(432,426),(412,425),(405,416)]]},
 'kikuoka':{'bunker':[[(875,211),(880,205),(882,199),(886,201),(886,206),(892,207),(889,211),(882,216),(879,222),(875,220)],[(905,302),(910,297),(915,300),(917,305),(912,310),(907,313),(903,309)],[(950,264),(953,258),(959,252),(964,253),(965,258),(959,261),(958,267),(951,270)],[(1109,342),(1113,336),(1120,336),(1122,340),(1117,344),(1118,348),(1113,350),(1108,347)],[(735,575),(739,573),(744,579),(742,584),(737,585),(734,581)],[(196,504),(201,502),(206,505),(206,510),(201,512),(196,511)]], 'water':[[(749,389),(758,388),(764,393),(765,402),(760,409),(751,408),(746,401)]]},
 'weiherhof':{'bunker':[[(750,235),(755,232),(760,234),(761,239),(756,241),(751,239)],[(917,371),(923,369),(926,372),(924,379),(918,384),(913,381)],[(1069,405),(1075,406),(1080,411),(1079,419),(1074,420),(1071,413)]], 'water':[[(1096,322),(1105,323),(1111,329),(1108,341),(1102,349),(1100,364),(1088,374),(1077,377),(1062,372),(1064,361),(1076,350),(1076,339),(1084,329)]]}}
# Approximate manual traces on 320px crops of 200px original aerial windows centred on each pin.
GREEN_CROPS={
 'trier:18':[(121,148),(132,130),(151,119),(173,122),(188,132),(198,148),(209,161),(214,182),(204,199),(185,213),(163,219),(146,213),(132,201),(127,182),(119,169)],
 'A2':[(102,155),(119,142),(144,137),(173,137),(199,142),(213,151),(216,166),(203,177),(176,182),(147,182),(122,177),(106,169)],
 'A3':[(114,124),(132,113),(154,113),(173,126),(181,146),(188,165),(188,184),(177,200),(159,209),(141,202),(126,187),(115,168),(108,148)],
 'A5':[(128,137),(151,132),(173,137),(194,148),(207,162),(213,178),(200,187),(182,186),(161,178),(145,167),(130,156)],
 'A7':[(115,145),(132,133),(151,129),(174,132),(191,141),(202,153),(202,166),(189,179),(170,185),(147,177),(126,165),(115,157)],
 'B6':[(124,151),(140,138),(161,136),(182,141),(200,150),(210,162),(203,175),(185,186),(161,187),(143,178),(128,168)],
 'C6':[(116,166),(131,150),(149,140),(173,135),(197,128),(214,135),(217,147),(204,160),(183,174),(160,184),(139,186),(122,177)],
 'C9':[(119,147),(133,133),(152,132),(174,137),(186,151),(186,171),(174,184),(153,190),(134,183),(119,169)]}
BUILDINGS={'trier':[[(660,436),(682,426),(690,436),(670,446)]], 'kikuoka':[[(430,386),(448,379),(456,390),(468,377),(480,389),(459,409),(448,421),(437,412)]], 'weiherhof':[[(544,249),(600,242),(604,259),(547,269)]]}
PATHS={'trier':[[(590,348),(605,378),(625,411),(634,449),(646,486),(656,514)]], 'kikuoka':[[(383,352),(396,376),(415,399),(429,420),(454,441),(485,450),(517,446),(552,420)],[(1014,51),(1040,84),(1071,115),(1099,149),(1102,192),(1095,226),(1102,257),(1116,293)]], 'weiherhof':[[(635,244),(651,220),(672,191),(690,165),(707,129),(727,99)]]}
def polys(g):
 if g.is_empty:return
 if g.geom_type=='Polygon':yield g
 elif hasattr(g,'geoms'):
  for x in g.geoms:yield from polys(x)
def valid(s):return make_valid(Polygon(s['ring'],s.get('holes',[])))
def ring(r):return [[round(x,2),round(y,2)] for x,y in list(r.coords)[:-1]]
def feat(g,t,source):return [dict(type=t,ring=ring(p.exterior),holes=[ring(r) for r in p.interiors],source=source) for p in polys(g) if p.area>1]
def pix(k,w,h,p):
 m=aerial[k];return (m['x']+p[0]*m['w']/w,-m['y']-p[1]*m['h']/h)
def convert(p,a,b):
 R=6371008.8; lat=a['lat']+math.degrees(p[1]/R);lon=a['lon']+math.degrees(p[0]/(R*math.cos(math.radians(a['lat']))));return [R*math.cos(math.radians(b['lat']))*math.radians(lon-b['lon']),R*math.radians(lat-b['lat'])]
def tr(s,a,b):return {**s,'ring':[convert(p,a,b) for p in s['ring']],'holes':[[convert(p,a,b) for p in r] for r in s.get('holes',[])]}
def union(xs):return unary_union(xs) if xs else Polygon()
worlds={}; report={}
for c in P:
 k=c['id']; family=k.split('-')[0]; related=[p for p in P if p['id'].split('-')[0]==family]; by=defaultdict(list); seen=set(); routes=[]
 for p in related:
  for i,h in enumerate(p['holes']):
   routes.append([convert(q,p['origin'],c['origin']) for q in h['route']])
   for s in h['surfaces']+canopy[p['id']][i]:
    ss=tr(s,p['origin'],c['origin']); key=(ss['type'],tuple((round(x,1),round(y,1)) for x,y in ss['ring']))
    if key in seen:continue
    seen.add(key);by[ss['type']].extend(polys(valid(ss)))
 merged={t:union(v) for t,v in by.items()}; green_additions=[]; green_seen=set()
 for p in related:
  for h in p['holes']:
   ref=h.get('loopRef',p['id']+':'+str(h['number']))
   if ref not in GREEN_CROPS or ref in green_seen:continue
   green_seen.add(ref); m=aerial[p['id']]; W,H=(2304,2304) if family=='trier' else (3072,1536)
   x=(h['pin'][0]-m['x'])/m['w']*W; y=(-m['y']-h['pin'][1])/m['h']*H
   g=make_valid(Polygon([convert(pix(p['id'],W,H,(int(x-100)+qx/1.6,int(y-100)+qy/1.6)),p['origin'],c['origin']) for qx,qy in GREEN_CROPS[ref]]))
   merged['green']=union([merged.get('green',Polygon()),g]);green_additions.extend(feat(g,'green','Approximate manual aerial green outline '+ref))
 protect=union([merged.get(t,Polygon()).buffer(2) for t in ['fairway','green','tee','water','bunker']]+[LineString(r).buffer(5) for r in routes]);
 hgt={'trier':1200,'kikuoka':900,'weiherhof':600}[family]; forest=union([make_valid(Polygon([pix(k,1200,hgt,q) for q in r])) for r in traces[family]])
 merged['woodland']=union([merged.get('woodland',Polygon()),forest]).difference(protect).simplify(.7,preserve_topology=True)
 additions=[]; w=900 if family=='trier' else 1200; h=900 if family=='trier' else hgt
 for t,entries in HAZARDS[family].items():
  for r in entries:
   g=make_valid(Polygon([pix(k,w,h,q) for q in r])); existing=merged.get(t,Polygon())
   if g.intersection(existing.buffer(2)).area/g.area>.20 or g.intersection(union([merged.get('green',Polygon()),merged.get('tee',Polygon())]).buffer(2)).area>g.area*.08:continue
   merged[t]=union([existing,g]); additions.extend(feat(g,t,'Approximate manual trace from bundled aerial imagery'))
 merged['woodland']=merged['woodland'].difference(union([merged.get(t,Polygon()).buffer(1) for t in ['water','bunker','green','tee','fairway']]))
 features=[]
 for t,g in merged.items():features.extend(feat(g.simplify(.3,preserve_topology=True),t,'Existing mapped geometry + approximate aerial interpretation'))
 buildings=[f for r in BUILDINGS[family] for f in feat(make_valid(Polygon([pix(k,w,h,q) for q in r])),'building','Approximate aerial footprint')]
 paths=union([LineString([pix(k,w,h,q) for q in r]).buffer(1.5,cap_style=2,join_style=1) for r in PATHS[family]])
 xmin,ymin,xmax,ymax=union([LineString(r) for r in routes]).bounds; step=20; tile=120
 x0=math.floor((xmin-180)/tile)*tile;y0=math.floor((ymin-180)/tile)*tile;x1=math.ceil((xmax+180)/tile)*tile;y1=math.ceil((ymax+180)/tile)*tile
 area=box(x0,y0,x1,y1); water=list(polys(merged.get('water',Polygon()).intersection(area))); bunker=merged.get('bunker',Polygon()).intersection(area)
 regions=[]; covered=Polygon()
 def add(g,kind,idx=-1):
  global covered
  g=g.intersection(area).difference(covered)
  if not g.is_empty:regions.append((g,kind,idx));covered=union([covered,g])
 for i,g in enumerate(water):add(g,'water',i)
 core=bunker.buffer(-2.4);add(core,'sandcore');add(bunker,'sand')
 for t in ['green','tee','fairway']:add(merged.get(t,Polygon()),t)
 add(paths,'path');add(merged['woodland'],'woodland');add(area,'rough')
 index=STRtree([p[0] for p in regions]); tiles={}; count=0
 for y in range(y0,y1,step):
  for x in range(x0,x1,step):
   cell=box(x,y,x+step,y+step); hits=index.query(cell,predicate='intersects'); out=tiles.setdefault(f'{x//tile},{y//tile}',{})
   for tri in [Polygon([(x,y),(x+step,y),(x+step,y+step)]),Polygon([(x,y),(x+step,y+step),(x,y+step)])]:
    for i in hits:
     geo,kind,idx=regions[int(i)]; q=tri.intersection(geo)
     for p in polys(q):
      if p.area<.0001:continue
      for tt in constrained_delaunay_triangles(p).geoms:
       if tt.area<.0001:continue
       key=kind+(':'+str(idx) if kind=='water' else ''); buf=out.setdefault(key,[])
       for xx,yy in list(tt.exterior.coords)[:-1]:buf.extend([round(xx,2),round(yy,2)])
       count+=1
 worlds[k]={'step':step,'tile':tile,'bounds':[x0,y0,x1,y1],'tiles':tiles,'features':features,'water':[ring(p.exterior) for p in water],'buildings':buildings,'bunkerCore':feat(core,'bunker','Estimated visual core'),'additions':additions,'greenAdditions':green_additions,'origin':c['origin']}
 report[k]={'holes':len(c['holes']),'surfacePolygons':len(features),'denseWoodlandAreaM2':round(merged['woodland'].area),'newHazards':len(additions),'newGreenOutlines':len(green_additions),'waterBodies':len(water),'tiles':len(tiles),'trianglesFullWorld':count,'dem':c.get('terrain',{}).get('source','not bundled; existing CI importer required')}
 print(k,report[k],flush=True)
(A/'course-world-data.js').write_text('globalThis.R10CourseWorldData='+json.dumps(worlds,separators=(',',':'))+';\n')
(ROOT/'courses/world-audit.json').write_text(json.dumps(report,indent=2)+'\n')
