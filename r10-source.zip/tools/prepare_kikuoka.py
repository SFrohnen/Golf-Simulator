from pathlib import Path
import sys,json,xml.etree.ElementTree as ET,re,math
import argparse
parser=argparse.ArgumentParser(description='Rebuild Kikuoka from an OSM map XML and Mapzen Skadi N49E006.hgt.gz.')
parser.add_argument('osm',type=Path)
parser.add_argument('hgt',type=Path)
args=parser.parse_args()
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'tools'))
from import_osm_course import build
from prepare_terrain import ATTR,publish,make_grid,skadi_sample
E=ET.parse(args.osm)
nodes={n.get('id'):{k:float(n.get(k)) for k in ('lat','lon')} for n in E.findall('node')}
# EPSG:4326 WMS left/top 6.299,49.600; right/bottom 6.327,49.586; 1400 x 1080 px.
def gps(x,y): return dict(lon=6.299+x/50000,lat=49.600-y*0.014/1080)
def coords(s):return [gps(*map(int,p.split(','))) for p in s.split()]
els=[]
for w in E.findall('way'):
 tags={t.get('k'):t.get('v') for t in w.findall('tag')}
 if not(tags.get('golf') or tags.get('natural')=='water' or tags.get('water')):continue
 els.append(dict(type='way',id=int(w.get('id')),tags=tags,geometry=[nodes[n.get('ref')] for n in w.findall('nd')]))
def feature(kind,geom,ref=None):
 tags={'golf':kind}
 if ref: tags['ref']=str(ref)
 else: geom=geom+[geom[0]]
 els.append(dict(type='way',id=-len(els)-1,tags=tags,geometry=geom))
# Green centre and perimeter traced against ACT ortho. First green already mapped.
greens=[
(1173,155,'1161,153 1166,145 1174,145 1178,149 1186,152 1184,157 1173,161 1165,167 1160,164'),
(1281,197,'1267,190 1272,184 1278,184 1281,193 1289,196 1300,196 1305,202 1300,209 1288,207 1284,202 1273,199'),
(1049,408,'1037,409 1042,401 1053,400 1062,398 1064,404 1061,412 1056,416 1045,416'),
(854,667,'845,664 853,658 861,652 867,655 866,665 862,675 850,677 843,673'),
(1169,513,'1158,512 1164,505 1173,499 1180,501 1179,509 1174,519 1161,525 1156,522'),
(1328,415,'1312,417 1318,409 1322,404 1332,405 1342,411 1350,418 1346,424 1333,424 1323,419'),
(1092,469,'1077,473 1082,462 1090,462 1099,457 1106,458 1105,467 1098,477 1086,479 1078,478'),
(778,546,'767,549 772,540 783,537 789,532 791,536 786,546 783,556 774,558 766,557'),
(501,546,'487,549 487,540 492,535 497,537 500,542 510,543 515,549 511,553 503,551 494,551'),
(229,608,'215,615 217,606 225,601 234,597 239,599 238,608 230,615 220,620 215,620'),
(77,658,'62,661 66,653 73,650 82,650 91,652 89,657 83,662 81,669 73,669 68,665 62,666'),
(432,515,'420,518 425,512 429,503 435,505 444,503 445,511 441,522 436,525 428,521 421,523'),
(581,741,'571,735 575,731 581,735 587,732 594,735 593,740 588,745 583,753 575,753 570,747'),
(578,914,'568,906 576,905 582,899 587,901 589,910 585,918 580,927 572,927 569,921'),
(795,730,'784,728 787,722 794,719 801,723 811,725 814,728 810,738 804,740 799,735 793,735 787,735'),
(635,930,'624,929 628,924 635,924 641,919 645,923 646,931 641,941 634,939 628,942 623,940'),
(638,565,'628,566 629,557 635,550 641,549 644,555 643,565 638,574 632,578 626,571')]
routes=['1186,135','1265,248 1190,310 1126,342','1014,500 948,575 899,620','894,697 1012,614 1106,552','1212,468','1286,360 1225,389 1150,427','1009,453 925,478 840,515','577,594','435,458 359,502 280,563','169,641','140,679 244,667 326,622 379,565','456,578 506,617 547,658','540,729 524,816 535,867','634,898 666,830 714,763','826,755 754,814 702,872','598,849 618,787 650,739 628,655']
for i,((x,y,outline),route) in enumerate(zip(greens,['']+routes),2):
 feature('green',coords(outline))
 if i>2:feature('hole',coords(route)+[gps(x,y)],i)
# Mown landing areas, simplified where the cut changes between orthophotos.
fairways=[
'1005,296 1017,282 1036,280 1058,256 1086,215 1104,189 1124,177 1155,159 1146,176 1123,193 1102,227 1081,263 1061,289 1036,299 1014,309',
'1069,392 1086,364 1108,349 1132,341 1154,316 1179,301 1205,300 1210,306 1192,321 1162,341 1143,361 1119,371 1100,390 1074,404 1062,407',
'875,651 874,637 899,614 922,595 941,566 963,538 980,534 985,543 979,559 964,577 953,600 930,617 906,631 886,652',
'956,646 973,628 1003,612 1028,582 1060,566 1083,552 1108,527 1137,522 1148,515 1157,517 1146,537 1123,550 1102,574 1078,587 1050,600 1025,625 1000,637 970,654 957,655',
'801,527 807,511 830,495 850,491 864,479 875,483 871,494 891,487 916,477 940,471 948,478 938,489 912,497 886,509 864,510 839,525 813,533',
'242,592 245,578 272,563 285,543 310,528 326,509 344,503 350,513 339,532 316,551 306,573 279,584 260,598 244,603',
'213,673 223,658 259,646 282,628 300,623 319,607 331,586 359,572 371,549 394,536 418,521 416,535 399,548 385,567 377,590 359,602 338,618 327,639 299,650 272,665 243,676',
'503,619 514,622 533,634 545,647 559,651 568,672 577,697 585,714 586,728 574,725 561,707 553,681 540,672 528,647',
'522,777 531,773 538,782 535,804 541,826 538,850 545,867 554,888 570,900 566,908 550,904 533,888 520,870 519,846 515,830 518,810',
'654,912 661,890 673,875 683,851 707,833 723,815 752,803 772,789 779,798 773,811 748,830 730,852 705,870 687,891 670,906',
'606,844 609,815 617,789 628,766 637,746 635,722 623,698 616,667 611,646 615,624 621,605 632,591 642,591 643,605 633,629 635,654 646,686 652,716 663,736 658,757 643,780 627,803 616,836']
for s in fairways:feature('fairway',coords(s))
feature('water',coords('985,288 1002,268 1018,278 1000,299'))
profile=next(p for p in json.loads((root/'courses/catalog.json').read_text()) if p['id']=='kikuoka')
pack=build({'elements':els},profile)
for h in pack['holes']:
 if h['osmHoleId']<0:h.pop('osmHoleId');h.pop('osmRef')
 for surf in h['surfaces']:
  if surf.get('osmId',0)<0:surf.pop('osmId');surf['source']='ACT orthophoto interpretation'
pack['warnings']=['Fixed simulator tees and green centres. Mown surface boundaries are approximate, especially where turf cuts have changed. Unmapped hazards and trees can be absent.']
pack['attribution']='Map data © OpenStreetMap contributors (ODbL 1.0). Additional geometry interpreted from Luxembourg ACT national orthophotos 2021, 2023 and 2025 (BD-L-ORTHO, CC0, geoportail.lu). Hole order: Kikuoka Country Club / 2024 EGA championship course plan.'
sample,_=skadi_sample(args.hgt.read_bytes())
grid=make_grid(pack,sample,30,'Mapzen Skadi / 30 m simulator grid',ATTR)
pack=publish(pack,grid,root/'courses/bundled/kikuoka.json')
for h in pack['holes']: print(h['number'],round(sum(math.dist(a,b) for a,b in zip(h['route'],h['route'][1:]))))
asset=root/'app/src/main/assets/course-packs.js';prefix='globalThis.R10BundledCourses='
data=json.loads(asset.read_text().strip()[len(prefix):-1]);data['packs']=[p for p in data['packs'] if p['id']!='kikuoka']+[pack]
next(p for p in data['status'] if 'Kikuoka' in p['name']).update(state='available',detail='18 holes, par 72. Offline elevation and aerially interpreted greens.')
asset.write_text(prefix+json.dumps(data,separators=(',',':'))+';\n')
