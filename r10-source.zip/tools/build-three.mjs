import {build} from 'esbuild';
import {copyFileSync} from 'node:fs';
await build({entryPoints:['tools/three-entry.mjs'],bundle:true,format:'iife',minify:true,target:'chrome90',outfile:'app/src/main/assets/three-runtime.js',legalComments:'inline'});
copyFileSync('node_modules/three/LICENSE','app/src/main/assets/three-license.txt');
