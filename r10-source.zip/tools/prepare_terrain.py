#!/usr/bin/env python3
"""Build a compact Trier height grid from an actual DEM, never synthetic data.
Optional GeoTIFF input needs rasterio/pyproj; build-time Skadi fallback uses stdlib.
"""
import argparse, gzip, math, struct, json, pathlib, urllib.request, datetime
ROOT=pathlib.Path(__file__).resolve().parents[1]
BASE=ROOT/'courses/bundled/trier.json'
ASSET=ROOT/'app/src/main/assets/course-packs.js'
URL='https://s3.amazonaws.com/elevation-tiles-prod/skadi/N49/N49E006.hgt.gz'
URLS=[URL,'https://elevation-tiles-prod.s3.amazonaws.com/skadi/N49/N49E006.hgt.gz']
ATTR='Mapzen / Tilezen Terrain Tiles on AWS; Europe terrain data produced using Copernicus data and information funded by the European Union – EU-DEM layers; SRTM data courtesy of the U.S. Geological Survey. https://github.com/tilezen/joerd/blob/master/docs/attribution.md'
R=6371008.8

def make_grid(c,sample,step,source,attr):
    points=[p for h in c['holes'] for p in [*h['route'],*(q for s in h['surfaces'] for q in s['ring'])]]
    x0=math.floor((min(p[0] for p in points)-450)/step)*step;y0=math.floor((min(p[1] for p in points)-450)/step)*step
    nx=math.ceil((max(p[0] for p in points)+450-x0)/step)+1;ny=math.ceil((max(p[1] for p in points)+450-y0)/step)+1
    lat0,lon0=c['origin']['lat'],c['origin']['lon']; factor=180/math.pi/R
    values=[]
    for j in range(ny):
        for i in range(nx):
            lat=lat0+(y0+j*step)*factor;lon=lon0+(x0+i*step)*factor/math.cos(math.radians(lat0));v=float(sample(lat,lon))
            if not math.isfinite(v) or not -50<v<1000:raise ValueError('Missing or implausible Trier DEM sample')
            values.append(round(v,1))
    if max(values)-min(values)<5:raise ValueError('Terrain unexpectedly flat')
    return dict(version=1,x0=x0,y0=y0,step=step,nx=nx,ny=ny,values=values,source=source,attribution=attr)

def skadi_sample(blob):
    # Protect against corrupted / oversized gzip. HGT north-to-south rows, signed big endian.
    import io
    with gzip.GzipFile(fileobj=io.BytesIO(blob)) as f: raw=f.read(2*3601**2+1)
    n=math.isqrt(len(raw)//2)
    if n not in (1201,3601) or len(raw)!=2*n*n:raise ValueError('Unexpected HGT size')
    def sample(lat,lon):
        x=(lon-6)*(n-1);y=(50-lat)*(n-1)
        if not 0<=x<n-1 or not 0<=y<n-1:raise ValueError('Outside N49E006 tile')
        i,j=int(x),int(y);a,b=x-i,y-j
        q=[struct.unpack_from('>h',raw,2*(row*n+col))[0] for row,col in [(j,i),(j,i+1),(j+1,i),(j+1,i+1)]]
        if -32768 in q:raise ValueError('HGT void')
        return (1-b)*((1-a)*q[0]+a*q[1])+b*((1-a)*q[2]+a*q[3])
    return sample,n

def geotiff_sample(paths):
    import rasterio
    from pyproj import Transformer
    import numpy as np
    rasters=[]
    for p in paths:
        ds=rasterio.open(p)
        if not ds.crs:raise ValueError('GeoTIFF missing CRS')
        rasters.append((ds,Transformer.from_crs('EPSG:4326',ds.crs,always_xy=True),ds.read(1,masked=True)))
    def sample(lat,lon):
        for ds,trans,a in rasters:
            x,y=trans.transform(lon,lat);col,row=(~ds.transform)*(x,y);i,j=int(math.floor(col)),int(math.floor(row))
            if 0<=i<ds.width and 0<=j<ds.height and not np.ma.is_masked(a[j,i]):return float(a[j,i])
        raise ValueError(f'No DEM coverage at {lat:.6f},{lon:.6f}')
    return sample

def publish(c,grid,out):
    c=dict(c,terrain=grid,mapRevision=max(3,c.get('mapRevision',0)+1));c['attribution']+=' Elevation: '+grid['attribution']
    text=json.dumps(c,ensure_ascii=False,separators=(',',':'))
    if len(text.encode())>1024*1024:raise ValueError('Terrain course pack exceeds 1 MB')
    out.write_text(text,encoding='utf8');return c

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--download',action='store_true');ap.add_argument('--hgt',type=pathlib.Path);ap.add_argument('--tif',type=pathlib.Path,nargs='+');ap.add_argument('--out',type=pathlib.Path,default=ROOT/'courses/bundled/trier-terrain.json');ap.add_argument('--bundle',action='store_true');ap.add_argument('--data-year',default=str(datetime.date.today().year));a=ap.parse_args()
    c=json.loads(BASE.read_text());
    try:
        if a.tif:
            g=make_grid(c,geotiff_sample(a.tif),10,'RLP DGM1 (1 m source, 10 m game grid)','© GeoBasis-DE / LVermGeoRP '+a.data_year+', dl-de/by-2-0, www.lvermgeo.rlp.de [Daten bearbeitet]; https://www.govdata.de/dl-de/by-2-0')
        elif a.hgt or a.download:
            if a.hgt:blob=a.hgt.read_bytes()
            else:
                last=None
                for url in URLS:
                    try:
                        with urllib.request.urlopen(url,timeout=25) as f:blob=f.read(32*1024*1024+1)
                        if len(blob)>32*1024*1024:raise ValueError('DEM download exceeds limit')
                        break
                    except Exception as exc:last=exc;print('Coarse DEM download failed:',url,str(exc))
                else:raise ValueError('All coarse DEM endpoints failed: '+str(last))
            sample,n=skadi_sample(blob);g=make_grid(c,sample,30 if n==3601 else 90,'Mapzen Skadi DEM, coarse (~30–90 m source), not survey DGM1',ATTR)
        else:raise ValueError('Provide --tif, --hgt, or --download')
        c=publish(c,g,a.out)
        if a.bundle:
            report=json.loads(ASSET.read_text().split('=',1)[1].strip().rstrip(';'));report['packs']=[c if p['id']=='trier' else p for p in report['packs']]
            for s in report['status']:
                if s['id']=='trier':s['detail']+=' · Terrain: '+g['source']
            ASSET.write_text('globalThis.R10BundledCourses='+json.dumps(report,ensure_ascii=True,separators=(',',':'))+';\n')
        print(f'Trier terrain ready: {g["nx"]}×{g["ny"]}, {min(g["values"])}–{max(g["values"])} m, {g["source"]}')
    except Exception as e:
        print('Trier terrain unavailable: '+str(e))
        if a.download and a.bundle:
            report=json.loads(ASSET.read_text().split('=',1)[1].strip().rstrip(';'))
            for item in report['status']:
                if item['id']=='trier':item['detail']+=' · Elevation download failed; flat fallback. '+str(e)[:180]
            ASSET.write_text('globalThis.R10BundledCourses='+json.dumps(report,ensure_ascii=True,separators=(',',':'))+';\n')
            return # preserve existing flat course; UI explicitly labels it
        raise
if __name__=='__main__':main()
