"""Generate original, self-contained mobile golf cart GLB. Requires trimesh/numpy only for regeneration, not CI."""
from pathlib import Path
import numpy as np
import trimesh as tm
from trimesh.visual.material import PBRMaterial
from trimesh.visual import TextureVisuals

scene=tm.Scene()
materials={}
for name,c,rough,metal in [('paint',(0.84,0.87,0.80,1),.32,.12),('rubber',(.055,.06,.055,1),.93,0),('rim',(.55,.57,.57,1),.36,.65),('seat',(.60,.48,.32,1),.83,0),('trim',(.13,.15,.14,1),.55,.05),('roof',(.87,.85,.76,1),.76,0),('glass',(.48,.65,.72,.35),.14,0),('light',(.96,.91,.69,1),.24,.1),('red',(.52,.045,.028,1),.28,0),('bag',(.14,.25,.20,1),.85,0),('bag2',(.41,.17,.09,1),.85,0)]:
    materials[name]=PBRMaterial(name=name,baseColorFactor=c,roughnessFactor=rough,metallicFactor=metal,alphaMode='BLEND' if name=='glass' else 'OPAQUE',doubleSided=name=='glass')
parts={k:[] for k in materials}
def add(mesh,mat,pos=None):
    if pos is not None: mesh.apply_translation(pos)
    parts[mat].append(mesh)
def box(pos,size,mat): add(tm.creation.box(extents=size),mat,pos)
def ell(pos,size,mat,sub=2):
    m=tm.creation.icosphere(subdivisions=sub);m.apply_scale(np.array(size)/2);add(m,mat,pos)
def rod(a,b,r,mat,n=12):
    a,b=np.array(a),np.array(b);d=b-a;m=tm.creation.cylinder(radius=r,height=np.linalg.norm(d),sections=n);m.apply_transform(tm.geometry.align_vectors([0,0,1],d));add(m,mat,(a+b)/2)
def rounded(pos,size,r,mat):
    # Convex hull of eight small spheres produces smooth rounded upholstery/body panels.
    size=np.array(size);core=np.maximum(0,size/2-r);v=tm.creation.icosphere(subdivisions=1).vertices*r
    cloud=np.vstack([v+core*np.array([a,b,c]) for a in (-1,1) for b in (-1,1) for c in (-1,1)])
    add(tm.convex.convex_hull(cloud),mat,pos)
# Length along Z, width along X, vertical Y; nominal 1.30 × 2.10 × 2.75 m.
rounded((0,.43,0),(1.28,.24,2.5),.09,'trim')
rounded((0,.64,.74),(1.31,.48,1.08),.20,'paint')
rounded((0,.78,.78),(1.18,.20,.93),.09,'paint')
rounded((0,.65,-.78),(1.30,.42,.90),.16,'paint')
box((0,.55,-.08),(1.12,.06,.80),'rubber')
for x in (-.59,.59):
    rounded((x,.53,-.05),(.13,.14,.95),.06,'trim')
    for z in (-.87,.87):
        # Wide rubber wheels, recessed alloy hub, five spokes and tread strips.
        rod((x-.12,.29,z),(x+.12,.29,z),.29,'rubber',32)
        outer=x+np.sign(x)*.124
        rod((outer,.29,z),(outer+np.sign(x)*.014,.29,z),.166,'trim',24)
        rod((outer,.29,z),(outer+np.sign(x)*.025,.29,z),.115,'rim',24)
        for i in range(5):
            a=i*2*np.pi/5;rod((outer+np.sign(x)*.027,.29,z),(outer+np.sign(x)*.027,.29+.135*np.cos(a),z+.135*np.sin(a)),.017,'rim',8)
        for i in range(28):
            a=i*2*np.pi/28;rod((x-.095,.29+.284*np.cos(a),z+.284*np.sin(a)),(x+.095,.29+.284*np.cos(a+.025),z+.284*np.sin(a+.025)),.010,'trim',6)
# Seats and backrests, two separate cushions with seams.
for x in (-.30,.30):
    rounded((x,.85,-.43),(.57,.18,.61),.085,'seat')
    rounded((x,1.13,-.74),(.56,.48,.16),.075,'seat')
    rod((x-.22,.945,-.42),(x+.22,.945,-.42),.008,'trim',8)
for x in (-.62,.62):
    rod((x,.90,-.65),(x,1.09,-.42),.025,'trim');rod((x,1.09,-.42),(x,1.09,-.10),.025,'trim')
    for z in (-.79,.73):rod((x,.70,z),(x*.95,2.00,z),.035,'trim')
rounded((0,2.02,-.03),(1.48,.14,2.10),.065,'roof')
# Windscreen, dash and steering wheel.
box((0,1.47,.735),(1.17,.78,.018),'glass');rod((-.60,1.10,.75),(.60,1.10,.75),.027,'trim');rod((-.60,1.50,.75),(.60,1.50,.75),.018,'trim')
rounded((0,1.01,.46),(1.19,.16,.27),.06,'trim');rod((-.32,1.02,.42),(-.32,1.24,.22),.027,'trim')
for i in range(24):
    a=i*2*np.pi/24;b=(i+1)*2*np.pi/24
    rod((-.32+.135*np.cos(a),1.24+.115*np.sin(a),.22+.07*np.sin(a)),(-.32+.135*np.cos(b),1.24+.115*np.sin(b),.22+.07*np.sin(b)),.016,'rubber',8)
for x in (-.43,.43):
    rounded((x,.80,1.25),(.27,.15,.055),.025,'light');rounded((x,.73,-1.23),(.18,.12,.05),.022,'red')
for i in range(7):box(((i-3)*.082,.57,1.272),(.045,.09,.035),'trim')
rod((-.55,.43,1.29),(.55,.43,1.29),.055,'trim');rod((-.55,.43,-1.29),(.55,.43,-1.29),.055,'trim')
# Rear golf bags and visible individual clubs.
for x,mat in [(-.34,'bag'),(.34,'bag2')]:
    rod((x,.62,-1.03),(x,1.35,-1.10),.16,mat,24);rod((x,1.32,-1.10),(x,1.38,-1.10),.17,'trim',24)
    rounded((x,.95,-1.22),(.23,.37,.11),.04,mat)
    for i in range(5):
        dx=(i%3-1)*.083;z=-1.10+(i//3-.5)*.10;top=1.55+i*.07
        rod((x+dx,1.30,z),(x+dx,top,z-.04),.009,'rim',8);rounded((x+dx+.045,top,z-.04),(.13,.043,.065),.02,'trim')
for name,meshes in parts.items():
    if meshes:
        m=tm.util.concatenate(meshes);m.visual=TextureVisuals(material=materials[name]);scene.add_geometry(m,geom_name=name,node_name=name)
path=Path(__file__).resolve().parent/'bundled-assets'/'range-cart.glb';path.parent.mkdir(exist_ok=True);path.write_bytes(scene.export(file_type='glb',include_normals=True));print(path, sum(len(m.faces) for m in scene.geometry.values()),'triangles',scene.bounds)
