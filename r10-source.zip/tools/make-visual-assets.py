"""Original tileable procedural materials. Requires numpy and Pillow only to regenerate.
Runtime consumes bundled WebP data URIs; no internet or third-party assets required."""
import numpy as np, base64, json, io
from PIL import Image
from pathlib import Path
N=512
rng=np.random.default_rng(180)
y,x=np.mgrid[:N,:N]
def noise(k):
    a=rng.random((k,k)); u=x*k/N; v=y*k/N; i=u.astype(int); j=v.astype(int); f=u-i; g=v-j; f=f*f*(3-2*f);g=g*g*(3-2*g)
    return (a[j%k,i%k]*(1-f)+a[j%k,(i+1)%k]*f)*(1-g)+(a[(j+1)%k,i%k]*(1-f)+a[(j+1)%k,(i+1)%k]*f)*g
out={}
for kind in ['rough','fairway','green','tee','sand','bark','crown','water']:
    coarse=noise(7)-.5; med=noise(32)-.5; fine=noise(128)-.5; grain=rng.random((N,N))-.5
    if kind in ['rough','fairway','green','tee']:
        blade=np.sin((x+2*np.sin(y*2*np.pi*7/N))*2*np.pi*91/N)*.5
        strength={'rough':1.25,'fairway':.9,'green':.55,'tee':.7}[kind]
        lum=218+strength*(coarse*55+med*47+fine*43+grain*35+blade*24)
        rgb=np.stack([lum+med*12,lum+3,lum-10+coarse*16],-1)
    elif kind=='sand':
        lum=232+coarse*28+med*18+fine*36+grain*33;rgb=np.stack([lum+5,lum,lum-10],-1)
    elif kind=='bark':
        ridge=np.sin((x+noise(8)*14)*2*np.pi*33/N);lum=184+ridge*32+med*53+fine*30+grain*18;rgb=np.stack([lum+12,lum,lum-15],-1)
    elif kind=='crown':
        leaves=noise(64)-.5;lum=206+coarse*65+med*58+leaves*85+grain*28;rgb=np.stack([lum-9,lum+5,lum-22],-1)
    else:
        ripple=np.sin((y+noise(8)*25)*2*np.pi*22/N);lum=220+ripple*13+med*20;rgb=np.stack([lum-5,lum,lum+8],-1)
    img=Image.fromarray(np.uint8(np.clip(rgb,0,255)));buf=io.BytesIO();img.save(buf,format='WEBP',quality=88);out[kind]='data:image/webp;base64,'+base64.b64encode(buf.getvalue()).decode()
Path('app/src/main/assets/visual-assets.js').write_text('/* Original procedural surface assets; see tools/make-visual-assets.py. */\nglobalThis.R10VisualAssets='+json.dumps(out,separators=(',',':'))+';\n')
