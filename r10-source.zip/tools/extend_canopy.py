"""Conservative manual digitization of major continuous canopy from the bundled licensed aerials.
Vertices in 1200px-wide review previews (Trier 1200x1200, Kikuoka 1200x900,
Weiherhof 1200x600). Not a boundary survey or official golf OB. No remote fetch.
Run against original v0.14 canopy.js, or rerun safely (old extended polygons replaced).
Requires shapely. Preserves prior mapping; clips newly interpreted forest away from
mapped playable surfaces and water and associates it with nearby hole corridors.
"""
from pathlib import Path
import json
from shapely.geometry import Polygon,LineString,Point
from shapely.ops import unary_union
from shapely.validation import make_valid
ROOT=Path(__file__).resolve().parents[1]/'app/src/main/assets'

def read(f): return json.loads((ROOT/f).read_text().split('=',1)[1].rstrip(';\n'))
# Major obvious continuous woodland; avoid sparse individual trees and uncertain scrub.
TRACES={
 'kikuoka':[
  [(480,321),(490,282),(523,251),(568,237),(609,225),(657,206),(695,181),(735,143),(758,115),(792,103),(819,113),(851,134),(869,157),(862,191),(840,202),(817,228),(791,245),(752,260),(720,272),(689,293),(662,316),(631,351),(602,381),(568,394),(526,377),(501,353)],
  [(1022,0),(1200,0),(1200,346),(1178,320),(1155,283),(1134,245),(1110,198),(1086,162),(1061,128),(1035,99),(1012,77),(992,51),(983,22)],
  [(0,0),(128,0),(182,33),(180,75),(158,113),(123,141),(105,176),(80,213),(65,248),(45,294),(68,349),(68,395),(54,446),(32,500),(46,544),(28,586),(0,607)],
  [(0,622),(49,621),(100,641),(153,652),(219,644),(269,632),(316,609),(354,587),(383,584),(404,605),(410,642),(399,694),(390,743),(374,786),(363,825),(317,860),(273,885),(231,900),(124,900),(117,864),(104,814),(94,762),(74,713),(44,692),(0,682)],
  [(1200,373),(1200,900),(769,900),(806,860),(840,820),(877,780),(911,744),(949,699),(987,655),(1023,610),(1066,561),(1103,518),(1138,472),(1170,426)],
  [(799,364),(810,349),(823,344),(838,351),(841,366),(831,381),(816,389),(802,381)],
  [(601,624),(606,604),(624,587),(641,592),(649,613),(638,632),(620,639)],
 ],
 'weiherhof':[
  [(0,0),(108,0),(116,33),(89,55),(73,77),(58,121),(53,162),(40,201),(22,232),(0,242)],
  [(0,259),(20,272),(43,302),(70,330),(100,338),(132,356),(161,373),(190,395),(220,417),(255,421),(294,414),(331,404),(361,380),(388,353),(411,331),(439,316),(478,315),(523,324),(555,340),(598,356),(632,374),(671,383),(713,377),(743,354),(769,344),(812,343),(849,356),(877,373),(891,392),(878,412),(855,435),(824,461),(809,487),(806,514),(823,539),(838,556),(838,600),(0,600)],
  [(649,172),(680,153),(708,138),(731,133),(742,148),(721,166),(712,185),(724,207),(711,229),(695,251),(674,271),(654,266),(646,245),(650,223),(640,204)],
  [(351,200),(374,183),(393,178),(417,185),(445,199),(465,212),(459,228),(435,239),(409,232),(382,228),(359,218)],
  [(287,36),(309,15),(335,16),(356,34),(363,55),(348,66),(323,64),(303,53)],
  [(692,46),(706,28),(725,24),(745,37),(758,50),(750,62),(724,65),(704,57)],
  [(1109,325),(1128,320),(1153,333),(1170,357),(1168,377),(1153,391),(1127,396),(1116,380),(1109,354)],
  [(991,115),(1014,101),(1044,102),(1064,115),(1072,133),(1060,157),(1036,159),(1006,147),(991,133)],
 ],
 'trier':[
  [(0,562),(27,577),(41,609),(60,649),(75,697),(91,750),(109,804),(120,864),(134,924),(139,978),(145,1035),(148,1101),(145,1170),(100,1200),(0,1200)],
  [(1200,674),(1200,1200),(1091,1200),(1055,1166),(1041,1129),(1002,1090),(956,1052),(924,1016),(899,982),(864,960),(838,930),(806,912),(773,900),(737,908),(754,867),(791,832),(824,803),(853,779),(887,752),(923,729),(970,710),(1017,698),(1063,686),(1105,666),(1153,665)],
  [(151,1131),(181,1126),(218,1131),(253,1129),(284,1120),(326,1104),(364,1092),(394,1080),(428,1071),(446,1081),(414,1104),(372,1118),(333,1139),(292,1157),(244,1173),(201,1181),(160,1180)],
  [(383,845),(401,827),(425,832),(450,852),(462,875),(458,898),(443,916),(422,926),(399,919),(386,895)],
  [(440,697),(456,688),(481,683),(512,689),(535,706),(529,723),(506,738),(482,735),(458,723)],
  [(617,368),(642,353),(661,360),(682,382),(697,402),(698,422),(677,433),(651,423),(633,406),(619,391)],
  [(215,42),(239,42),(272,58),(309,77),(343,94),(365,112),(363,139),(343,132),(312,110),(282,94),(255,82),(228,78),(216,62)],
  [(379,119),(410,131),(453,154),(496,174),(543,197),(581,214),(620,230),(626,246),(607,246),(567,235),(519,228),(476,220),(430,208),(395,190),(380,166)],
 ]
}

def polygons(g):
 if g.is_empty:return
 if g.geom_type=='Polygon':yield g
 elif hasattr(g,'geoms'):
  for x in g.geoms:yield from polygons(x)

def valid(p):return make_valid(p) if not p.is_valid else p

def shape(s):return valid(Polygon(s['ring'],s.get('holes',[])))

def coords(r):return [[round(x,1),round(y,1)] for x,y in list(r.coords)[:-1]]

aerial=read('aerial.js'); canopy=read('canopy.js'); packs=read('course-packs.js')['packs']
report={}
for course in packs:
 k=course['id']; kind=k.split('-')[0]; m=aerial[k]; hgt={'trier':1200,'kikuoka':900,'weiherhof':600}[kind]
 world=lambda p:(m['x']+p[0]*m['w']/1200,-m['y']-p[1]*m['h']/hgt)
 trace=unary_union([valid(Polygon([world(p) for p in ring])) for ring in TRACES[kind]])
 playable=[]
 for h in course['holes']:
  playable.extend(shape(s).buffer(2) for s in h['surfaces'] if s['type'] in ['fairway','green','tee','water','bunker'])
  playable.extend([Point(h['tee']).buffer(8),Point(h['pin']).buffer(8)])
 trace=trace.difference(unary_union(playable)).simplify(.8,preserve_topology=True)
 new=0;area=0
 for i,h in enumerate(course['holes']):
  prior=[s for s in canopy[k][i] if s.get('source')!='Extended aerial canopy / simulator OB']
  old=unary_union([shape(s) for s in prior]+[shape(s) for s in h['surfaces'] if s['type'] in ['woodland','tree_row','tree','ob']])
  # Retain full forest blocks in the playing corridor, not only small edge strips.
  corridor=LineString(h['route']).buffer(180)
  missing=trace.intersection(corridor).difference(old).simplify(.6,preserve_topology=True)
  extra=[]
  for poly in polygons(missing):
   if poly.area<80:continue
   if poly.contains(Point(h['tee'])) or poly.contains(Point(h['pin'])):continue
   ring=coords(poly.exterior);holes=[coords(r) for r in poly.interiors if Polygon(r).area>=5]
   if len(ring)<3 or len(ring)>3000 or len(holes)>100:continue
   extra.append({'type':'woodland','source':'Extended aerial canopy / simulator OB','ring':ring,'holes':holes})
   new+=1;area+=poly.area
  canopy[k][i]=prior+extra
  assert len(h['surfaces'])+len(canopy[k][i])<=300
 report[k]={'new_hole_polygons':new,'sum_hole_polygon_area_m2':round(area),'note':'Areas overlap between holes; not a course-wide unique total.'}
(ROOT/'canopy.js').write_text('globalThis.R10Canopy='+json.dumps(canopy,separators=(',',':'))+';\n')
print(json.dumps(report,indent=2))
