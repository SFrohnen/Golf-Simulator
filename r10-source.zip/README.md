## v0.4.2 — Swing delivery analysis

Main Range metrics now include Garmin-reported club path and face angle, derived face-to-path, and attack angle. Positive raw angles point right of target; left-handed labels reverse open/closed and in/out. Missing data is unavailable, not inferred from ball flight. Face-to-path is used as a qualitative delivery cross-check (2° heuristic), not an additional aerodynamic input. Session and Analytics show signed per-club means. Existing CSV fields retained. Flight model unchanged.

## v0.4.1 — Live session usability

- Range now has a persistent active practice session and a New session button (does not delete history). Live club-colored dispersion circles appear after three valid shots per club, with auto-scaled plot and separate real/demo data. Analytics remains available across history.
- Correct any shot’s club directly in Range or History; quick last-shot selector. Club averages and circles update immediately. CSV preserves session IDs and historical club corrections. Older imports without session IDs remain in History rather than mixing into a new session.
- Latest shot shows estimated shape (push/pull/straight with fade/slice/draw/hook), handedness, bold carry/offline/launch, and total, peak, spin, spin axis, ball speed, club head speed and smash factor above flight diagnostics. Shape uses initial heading and modeled bearing change; heuristic 1.5° straight and 5° severe curvature thresholds, not a measured classification.
- Offline is shown as L/R/C; mean absolute offline plus counts of left, right and center for the current club and all-history club analytics. Missing values excluded. Smash factor = ball speed / club speed; missing/zero club speed omitted.
- Removed standalone rollout display and finish dispersion; total distance still uses the previous provisional ground model because total remains requested.
- Carry flight engine unchanged. Protocol, flight, history, reference, club/session/shape and mocked-DOM UI tests pass. Browser smoke test timed out in this environment; Android build and actual device visual validation pending.

# R10 Private Range · Android 0.4.0-alpha

Private, offline-first Android driving range for a **Garmin Approach R10**. All app data stays on the phone. No remote account, SDK subscription, or `INTERNET` permission.

> **Development status:** The user confirmed physical R10 shot registration in v0.2. The new v0.3 aerodynamic model passes synthetic tests; its carry accuracy is not yet validated on hardware. This source archive is not an APK.

## Package 2 — Club analytics (v0.4.0)

- Select the actual 12-club bag in Range before each shot. Colors remain consistent in Range, Analytics and History.
- Analytics plots every eligible shot using the same scale on both axes. Circles are centered on each club's mean landing/finish position and enclose all displayed points (not confidence intervals). Switch between landing and finish and filter clubs. Demo shots are excluded unless enabled.
- Per-club means include carry, rollout, total, absolute lateral deviation at landing and finish, spin and apex. Missing values are excluded from each mean; metric sample counts appear if different from club count. All decimal shot metrics display one decimal place; CSV retains full precision.
- Historical club labels from before v0.4 are unverified because the selected club was sometimes wrong. Confirm/correct each shot in History; the original club is preserved. Only confirmed, current-model shots are included in club analytics. Reimporting the original backup does not duplicate a corrected shot.
- Rollout is a provisional flat-ground estimate using landing speed, angle, spin and selected ground firmness (soft/medium/firm). Total is carry plus rollout; finish position uses terminal flight heading when available, otherwise landing bearing. No terrain/slope/check-back or validated rollout calibration. Changing firmness recomputes these estimates for all eligible shots; CSV includes the selected surface and basis.
- The v0.3.2 carry engine and Bluetooth transport are unchanged. Carry is provisionally calibrated, not independently validated. Back up CSV before updating, then import if needed and recalculate history. Package 3 practice and coaching modes are still pending.

Run `node tests/club-analytics.test.js` plus the existing protocol, flight, history and calibration tests. The source ZIP is not an APK. Mobile UI and physical R10 testing are still needed.

## Package 1 — Accuracy and physics

See `CHANGELOG.md` for scope and limitations. Run `bash tests/run-tests.sh` and `node tests/flight.test.js` locally or build via GitHub Actions (workflow included). Export your existing shots from History before installing the update; if Android refuses the update due to different signing keys, do not uninstall until the export is saved.

To replay the existing shots offline: copy the CSV export to the project folder; fill in `shot_time` in `validation/reference-shots.csv` from the exact corresponding shot in the export (optionally add shot ID). Do not guess the pairing. Then run `node validation/replay.js exported-shots.csv validation/reference-shots.csv 15 0 > comparison.csv` (replace temperature and altitude with matching reference conditions). Unmatched shots are replayed without scoring. Existing readings alone cannot establish the new model's accuracy. The model uses generic coefficients guided by published golf ball aerodynamics, not fitted to a specific ball: https://www.mdpi.com/2504-3900/2/6/238 .

The following v0.2 notes describe the original transport implementation.

## What changed in v0.2

* Discover an `Approach R10` by BLE name; request Android Bluetooth bond if necessary; use native GATT connect.
* Discover the Garmin MultiLink GATT service, enable notifications, write to the correct pair of characteristics.
* Queue serialized GATT writes (using ATT-safe 20-byte values and explicit timeouts).
* Send MultiLink service-1 registration and handle its 16-byte response.
* Assemble notification fragments; COBS decode; verify CRC16/ARC; parse GFDI standard/compressed message headers.
* Complete the documented GFDI 5024/5050 handshake; ACK optional FIT messages without persisting device identity.
* Subscribe to shot-data alerts, request radar wake-up, decode status transitions and shots from protobuf messages.
* Extract launch speed/angle/direction, spin/spin axis, club speed/face/path/attack, shot id, and spin provenance; ignore duplicate retransmissions for 60 s.
* Send decoded real-shot measurements to the in-app range UI, while **labeling carry and lateral distance as unvalidated estimates**.
* Keep demo shots completely separate and labeled `DEMO`.
* Export the extended shot fields to CSV. Raw BLE payloads / device IDs are not exported.
* Include repeatable pure-Java tests for the protocol phases.

### Known limitations

* The phone-to-R10 path and Android `MainActivity.java` have not been exercised with hardware or compiled into an APK in this environment. Testing will likely reveal firmware-dependent edge cases.
* Protobuf fragmentation is handled for single-frame shot messages only; multi-part reassembly is not implemented.
* No automatic reconnect yet. Use **R10 Connect → Scan** after a disconnect.
* Swing without a ball is recognized in diagnostics but not imported as a ball-flight shot.
* The R10 reports **launch** data; v0.3 carry and landing are modeled by the experimental aerodynamic integrator. Rollout is not yet modeled.
* The selected club is assigned by the user in the app; the R10 doesn't automatically identify your club.
* No real golf-course environment yet. Driving range first.

## On-phone test plan

1. Charge and power on the R10. Close Garmin Golf and any other apps connected to it.
2. In Android settings, pair **Approach R10** over Bluetooth, if it is not already paired. (The app also asks Android to bond if needed.)
3. Install the generated debug APK using the build method below. Open the app and allow **Nearby devices** when requested.
4. Open **R10 Connect** → **Scan for R10**. Confirm progress through:
   * `Found Approach R10`
   * `Connected. Discovering R10 GATT services`
   * `Subscribing to R10 MultiLink notifications`
   * `Registering R10 MultiLink`
   * `GFDI handshake: ...`
   * `Handshake complete. Subscribing to shot data`
   * `Subscribed. Waking R10 radar`
   * `R10 radar: Armed — ready` or `R10 already awake — ready for shots`
5. Set your selected club on **Range**, hit a ball, and check for `Live shot #… received` in diagnostics and a new `R10`-labelled row in the range/history.
6. If it stalls, take a screenshot of the **connection diagnostics text** and share it, preferably without any Bluetooth MAC addresses or other private identifiers. The app deliberately does not expose binary packet captures.

If it does not find the device: ensure Garmin Golf is fully disconnected, turn R10 off/on, pair via Android Bluetooth settings, grant Nearby devices, then scan again. A hardware test will determine whether Android's no-location BLE scanning flag needs changing on your phone.

## APK build without a local IDE

The ZIP contains a complete Gradle source project, **not an APK**. To compile using GitHub's hosted build computers:

1. Create a **private** GitHub repository; upload the ZIP's **contents** into its root.
2. On GitHub, open **Actions → Build Android APK → Run workflow** (or push to `main`).
3. Wait for the build to finish; download the `r10-private-range-debug-apk` artifact and extract its `app-debug.apk`.
4. Open that APK on your Android phone and follow Android's prompts to allow installation from the app used to open it.

Alternatively, open the project in Android Studio with Android SDK 35 / JDK 17 / Gradle 8.9 and choose **Build APK(s)**. Neither method needs a Play Store listing.

## Run protocol regression tests without Android SDK

On a machine with a JDK:

```bash
bash tests/run-tests.sh
```

Tests simulate a full session: MultiLink registration → GFDI 5024/5050 → protobuf subscribe → wake response → decoded launch shot → duplicate suppression, also exercising COBS, CRC, split BLE notifications and corruption handling. These tests **do not constitute a hardware test**.

## Source code

* `app/src/main/java/com/privategolf/r10range/MainActivity.java` — Android BLE permissions, bond/connect, serialized writes, local WebView bridge, offline CSV export.
* `app/src/main/java/com/privategolf/r10range/R10Protocol.java` — pure Java Garmin MultiLink/GFDI/protobuf protocol driver.
* `app/src/main/assets/index.html` — offline range UI and practice history.
* `tests/R10ProtocolTest.java` — regression tests.
* `.github/workflows/android-apk.yml` — hosted build of debug APK.

## Interoperability references

This independent interoperability implementation uses publicly documented protocol behavior and original Java code. Useful technical references:

* [10over: Wire Protocol Reference](https://github.com/divotmaker/10over/blob/main/docs/WIRE.md)
* [10over: Connection Lifecycle and Message Sequencing](https://github.com/divotmaker/10over/blob/main/docs/SEQUENCE.md)
* [10over: R10 device library](https://docs.rs/crate/tenover/latest)
* [Flighthook: Garmin R10](https://github.com/divotmaker/flighthook/blob/main/docs/devices/garmin-r10.md)

No first-party Garmin code or authentication bypass is included. This project is not associated with Garmin.

### Restore a CSV backup (v0.3.1)
Keep the original CSV outside the app. In History, choose Import CSV and select your exported file using Android Files. Legacy rows with complete inputs are recalculated using current temperature/altitude; their original carry is saved as previousCarry. Rows lacking required data keep their original carry. Repeated imports skip matching shots. Import merges rather than clears history; files must be UTF-8 CSV from this app and fit the 1,000-shot limit. Use the original CSV for reference matching and keep a separate backup. This source update has local parser/flight/protocol tests, not a verified APK or device test.

### v0.3.2 physics calibration and history replay
Default conditions are 20°C / 200 m. The model is tuned to seven confirmed Awesome Golf shot pairs (one probable pair is excluded). This is a calibration result, not independent validation. Back up your CSV before updating. In Range, check atmosphere; in History, import your backup if needed and tap Recalculate history. Original carry and raw data are retained; the previous model carry is stored separately when the model changes. Export a new CSV for comparison.

Offline commands:
```sh
node validation/calibrate.js
node validation/replay.js validation/calibration-shots.csv validation/reference-shots.csv 20 200
node tests/reference-replay.test.js
```
The calibration coefficients are engineering approximations informed by the general dependence of golf-ball drag/lift on spin and speed (see https://www.mdpi.com/2504-3900/2/6/238). They are not measured ball-specific coefficients. Use fresh reference shots to check generalization, especially wedges, low launch and different speeds.

### v0.5.0 practice modes
Open **Practice** and choose Random Numbers, Target Practice or Club Gapping. Choose live R10 or demo, configure the session and tap Start practice. Confirm the club before each attempt; the button changes to Ready. In demo mode use Demo practice shot; in live mode hit the ball once the R10 is ready. A new target or next club is selected automatically after a scored attempt. Unarmed shots are retained as ordinary history, not scored. Changing tabs disarms the next shot. Correct the recorded club in the practice shot list or History. Gapping advances when the required count for each chosen club is satisfied. To stop early, End practice; review results before New practice. Older sessions appear below the setup/results screen. A CSV export retains practice metadata and can restore practice result archives after a reinstall; in-progress setup is device-local. Existing 1000-shot cap applies. Target scores are based on modeled carry landing coordinates and configurable target distances (not rollout), and are provisional until independent flight validation. For gapping, SD is population SD; consistency labels and overlap bands are descriptive heuristics, not confidence intervals. The optimized flight engine and Bluetooth implementation are unchanged from v0.4.2. All automated tests pass; Android build and on-device UI validation remain necessary.

### v0.6.0 — Integrated Personal Golf Coach

Use the global **Personal Golf Coach** selector below the app header: Off hides feedback in all modes, Brief shows a priority plus a drill, and Detailed includes the underlying evidence and your historical comparison. Take a Range shot or confirm a club and complete a scored attempt in any Practice mode. Feedback appears below the shot metrics. Demo shots are explicitly marked and cannot contaminate real-shot history comparisons. Correcting a club assignment recalculates feedback from the corrected data. For personalized comparisons, confirm at least five prior shots of the same club with compatible flight model, environmental settings, source and target context. Current/prior session trends require at least five comparable offline measurements in each group. Prior carry can reflect different swing intents, especially wedges; use the suggestions as experiments rather than diagnoses. Spin and flight can be estimated, and delivered angles are not a video-based swing analysis. The coach works completely offline. No additional CSV columns are required. Course simulation will reuse the coach module in a future release.

Run `node tests/coach.test.js` and `node tests/ui-smoke.test.js` in addition to the prior regression tests. All automated tests pass in the development environment; a real Android APK/device test is outstanding. The calibrated flight.js and native Bluetooth implementation are unchanged. Back up CSV before installing; replace the existing repository's source ZIP and build the latest main commit with the existing workflow.

## v0.7.0: course simulation alpha

Open **Course**, choose Practice Valley (fictional), number of holes, front/back start (for <=9), format, human count, number of bot opponents/teams, bot difficulty and live R10/demo source. In stroke play each golfer plays their own ball. In scramble choose between both team shots; solo scramble supplies a bot partner. Tap the map to aim; confirm club/current player before each human shot. Bots use a simplified independent distance/dispersion model. Auto-putting estimates 0–3 strokes; manual putting accepts 1–10 once on a mapped green. Water and mapped OB use a simplified +1/replay rule. No terrain, wind, tree collision or surface-dependent carry/roll yet. Landings use carry only. There is a 16+ stroke pickup safeguard. The scorecard is gross strokes, not WHS or official rules. Second players' shots are kept out of personal history. One current round is saved locally; export its scorecard before ending or reinstalling. This export is not a round-state restore file.

### Real course data

Trier (Ensch), Kikuoka and assumed Weiherhof near Losheim are listed in `courses/catalog.json`, **not bundled as playable real courses**. Geometry access failed in the build environment. Do not rename the fictional course to any actual course. See `courses/README.md` for the strict open-data import path. JSON packs are imported using the Android file picker in Course → Import course JSON. Existing application ID is unchanged. Replace the root ZIP in the existing GitHub main workflow; retain CSV backups.
