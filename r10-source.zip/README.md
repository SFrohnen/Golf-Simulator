## v0.20.0-alpha — Natural practice landscape

- Hybrid Driving Range and range-based practice: seven staggered target greens (50–350 m), sand pockets with collars, two physical numbered distance boards per station, variable fairway edges and mowing bands, graded decorative outer rough banks, dense irregular multi-row forest belts and short foreground grass blades. The active target retains its exact position, rings and flag. The hitting reference plane is unchanged; decorative bunkers/banks are not new physical hazards or collision terrain.
- Uses the existing bundled alpha-cutout oak/pine atlas for mid/distant range trees and existing solid 3D models nearby. No new photographic tree model downloads or new licenses; no changes to mapped course scenery. The atlas is image-based foliage, not a high-poly 3D tree asset. The existing photographic materials are more visible through bounded neutral detail and low bump amplitudes, preserving green colors and the dark tee mat. Range-only sunlight/exposure are slightly reduced.
- Classic restores v0.18 geometry, materials, lighting and sky; Experimental retains the v0.19.2 experiment. Hybrid real-course rendering remains as in v0.19.2. The previous terrain rules, physics, course elevation, scoring and Garmin R10 connectivity are unchanged. Sculpted physical bunker geometry, advanced water reflections and newly sourced photorealistic foliage models are deferred.
- Existing ZIP-based Ubuntu 24.04 workflow remains compatible; upload as r10-source.zip. CI adds checks for the actual range atlas/material path and course isolation, plus a ninth screenshot (Hybrid range aerial). The local 27 test suites passed; npm registry access is unavailable here, so actual browser rendering, screenshot thresholds, Android build and device performance still require verification in CI/on-device.

## v0.19.2-alpha — Rendering repair

- Classic restores v0.18 surface textures, terrain RGB, trees, sky and lighting. Hybrid (default) keeps those colors and blends bounded photographic luminance detail into the existing surface textures; tee mat stays untouched, imported roughness/normal maps are not applied. Experimental enables imported vegetation with width/height normalization and low-strength HDRI environment lighting (never the HDRI landscape background). Presets persist and are shared across range, practice and course.
- Range/practice full-screen maps request immersive Android system bars; Back exits the map. On-device behavior requires verification.
- CI captures Classic, Hybrid and Experimental scenes plus the v0.18 baseline, and tests material restoration and coarse pixel difference bounds. The Trier screenshot fixture now uses the actual elevation-enabled embedded pack (10 m grid), not the old flat JSON.
- Existing v0.19+ Ubuntu 24.04 workflow remains compatible; replace only r10-source.zip. The source pack has placeholders for the runtime and imported assets, generated during CI. All local regression suites pass; actual asset downloads, browser screenshots, visual thresholds and Android build/device checks are pending CI.

## v0.19.1 — Mobile vegetation build hotfix

Replaces the oversized Poly Haven vegetation with bounded CC0 game-ready GLBs from Quaternius (Kenney Nature Kit fallback). These assets are stylized, not photorealistic. Retains ambientCG photographic terrain and Poly Haven HDRI. Validates geometry/size and logs selected source; existing v0.19+ workflow remains compatible. Provider downloads and device performance still require CI/device validation.

# v0.19.0-alpha — Realistic asset integration

- Adds an automated build-time CC0 asset importer: ambientCG Grass005, Grass004 and Ground052 photographic 1K JPG albedo, OpenGL normal and roughness maps; Poly Haven Pine Tree 01, Tree Small 02, Grass Bermuda 01 glTF models and Limpopo Golf Course 1K HDRI. The source ZIP intentionally contains a placeholder; GitHub downloads the real assets during `npm run build:three`. A failed download or missing map fails the build. Source URLs, SHA-256 digests and license credits are included in the generated asset pack. Provider downloads and the real rendering test were not executable locally.
- Imported model geometry uses instancing, height normalization, mapped tree locations, quality-dependent triangle/count budgets and nearest-tree selection. Other trees retain the v0.18 procedural geometry. Imported grass tufts are sampled on playable turf/rough in front of the camera when rebuilding the scene; no change to collision or shot physics. Imported surface maps retain approximate mowing-stripe contrast, and HDRI provides photographic sky and environmental light. The water material uses environmental highlights, not planar reflections. No new wind animation, independent Ultra quality tier, geometry decimation or true bunker excavation.
- Asset status distinguishes Real assets, Loading assets, Partial asset fallback and Procedural assets. Existing legacy renderer fallback remains. Offline at runtime; no cloud connection needed to display the downloaded assets.
- Use the normal ZIP upload on the existing Three.js/Ubuntu 24.04 workflow. Existing `npm run build:three` automatically performs the new importer and its unit tests. Optional `android-apk-v019.yml` also checks the real asset bundle inside the APK and uploads v0.18/v0.19 rendered comparison screenshots. Browser test requires actual maps, all three models, HDRI and imported geometry in the scene; screenshot appearance and mobile performance remain unverified.
- 27 local suites passed (22 JavaScript, 4 Python including new mocked importer tests, 1 Java protocol runner). Android compilation, real asset download, real WebGL browser test, and on-device performance remain pending CI/device validation.

# v0.18.0-alpha — Immersive Three.js graphics

- Eight original 512×512 tileable offline WebP materials: rough, fairway, green, tee, sand, bark, crown and water. Surface classes and texture scales are separated; sand, bark, canopy and water gain bump detail. No third-party photographic assets were downloaded. The generator is included under `tools/make-visual-assets.py`.
- Replace Three.js crossed-tree cards with instanced volumetric broadleaf crowns, trunks and branches, and layered conifers. Distribute woodland trees across mapped patches with a quality-dependent budget, reject new woodland trunks in mapped playable surfaces. These are representative visuals, not measured individual trees. Gameplay canopy/OB rules remain unchanged.
- World-space sky shader with clouds, sun and haze; directional and hemisphere lighting, tone mapping, and soft shadows at medium/high quality. Low disables shadows and simplifies trees. More natural tee camera (1.85 m), smoother terrain normals and finer high-quality base mesh. No new elevation source or physical bunker excavation; water is textured/specular, not true reflective water. Preserve existing HUD, flight, shot recording, course maps, scoring and BLE.
- Existing `r10-source.zip` workflow still works if already updated for Three.js and pinned to Ubuntu 24.04. The optional external `android-apk-v018.yml` adds a graphics screenshot artifact. The bundled workflow is for a repository containing the expanded source.
- Existing 26 local suites passed (22 JavaScript, 3 Python, 1 Java protocol runner). The pinned Three.js dependency and Android build were unavailable locally. GitHub CI performs the real WebGL test and generates new and v0.17 screenshots (range and Trier hole 1) in `visual-previews/`. Visual comparison, phone FPS and APK verification are pending CI/device execution.

# v0.16.0-alpha release

Build with the included GitHub Actions Android APK workflow. Open Driving range or a virtual Course round in landscape for the new graphical HUD. Swipe the bottom metrics strip horizontally to see additional values. Range Options / Course HUD select Playing or Technical; choices persist. Choose Auto camera to start at the ball, follow the flight, hold the landing, and return to the next shot. Manual camera and replay controls remain. Course score is relative to par for completed holes, and strokes are for the current hole. Estimated metrics are marked; all existing physics and data are retained.

This is a source-only alpha; no Android SDK/Gradle or physical R10 is available for validation here. JavaScript (including mocked UI and renderer), Python geometry/import and Java wire-protocol tests were run. Actual WebView graphics, layout and performance require device testing; browser navigation was blocked in this environment. See CHANGELOG.md for scope and remaining polish.

# v0.15.0-alpha release

See CHANGELOG.md for changes. The existing GitHub Actions Android build workflow is included. This source release was regression-tested with JavaScript, Python and Java protocol tests; Android compilation, live Bluetooth and native weather/file-picker operation were not verified in this environment. Handicap values are provisional, simulated rounds are separate from real records, and imported differentials must be supplied most recent first. Woodland additions are aerial-derived simulator boundaries, not official OB.

# v0.9.6-alpha — Fixed-distance auto-putting

The selected ball’s resting distance on the green determines automatic putts: up to 2 m adds one, over 2 m through 15 m adds two, and over 15 m adds three. Hole-outs add zero. Manual putting remains available. Saved scores are preserved and future shots in resumed rounds use these rules.

# v0.9.1-alpha — Ball and landing inspection

On Course, Ball opens a close terrain-level inspection of the current lie. Landing frames the last shot's first contact and finish on the current hole (or its impact point after a tree strike). Drag to move over the ground, pinch or use + / − to change distance. Show score returns to hole review. Follow ball tracks through rollout and holds the endpoint. Range and Practice also have Ball and Landing controls in the play map. The app's Android launcher, startup artwork and Clubhouse button use the custom gold golfer icon.

# v0.9.0-alpha — Clubhouse and hole results

Clubhouse opens with Course, Tour career, Driving range and Practice games. A saved course session resumes directly. Select a course by its opening-hole illustration, then choose round length, shot source and scoring options. The score card appears over the course once the finishing trajectory completes. It shows each team's hole result, strokes, recorded putts when available, and running score relative to par. Next tee advances the round.

Clubhouse photography: https://images.unsplash.com/photo-1535131749006-b7f58c99034b (bundled for offline play). Course previews use each installed pack's geometry.

# v0.8.5-alpha — Fullscreen round sessions

Casual and Career rounds keep the Android game view open through Green, replay, hole transitions and the final scorecard. Android Back dismisses an open replay, details or exit prompt. Reopening the app restores the saved round. To leave, choose End round and confirm.

# v0.8.4-alpha — Full-screen play and handicap putting

Course, Range and active Practice sessions open to the play map. The on-map controls include zoom, club, mode-appropriate shot controls and menu. On Course use Green for a top-down inspection, Full hole to reset the frame, and Next tee after reviewing the finish. Pin distance and elevation change are screen-fixed. The result reports carry, rollout, straight-line shot distance, elevation change, remaining distance and awarded automatic putts. Imported courses without heights show elevation unavailable. Flat training ranges report zero elevation change.

In Course setup choose Auto-putts and Scratch, 10 HCP (default), 20 HCP or 30+ HCP. Expand Auto-putt probabilities for the complete table. Distance is measured at rest. The selected ball draws once, scoring one, two or three putts. A simulated hole-out requires no putts. Unfinished rounds from older versions use the HCP 10 default for future auto-putts.

The HCP 10 one- and three-putt probabilities use the HCP 10 comparison columns in Shot Scope's Pro Data Report Example, table “Where putts are won and lost”: https://shotscope.com/wp-content/uploads/2026/11/The-Pro-Data-Report-Example.pdf . Two-putt probability is the remainder under the three-putt cap. For the other handicaps the fixed bins are simulator estimates guided by amateur make rates (https://mygolfspy.com/news-opinion/putting-make-percentage-by-handicap-full-chart-are-you-above-or-below-average/) and Shot Scope's aggregate putts per green (How to Improve With Data, figure 22). The 30+ profile extrapolates beyond the published 25-handicap benchmarks. Short-distance make rates from all attempts can differ from first-putt rates.

# v0.8.3-alpha — Terrain-aware course rollout

Full shots and chips in Course mode now use a modeled bounce and rollout. Carry marks first contact. The shot result shows rollout distance and the finishing lie. The 2D map marks the ground track in white. Use Follow ball in 3D or Round details → Replay last shot to watch through the finish, even after the hole changes.

The existing range rollout estimate provides the flat fairway baseline. Course mode adjusts for surface resistance and local terrain gradient. Greens run faster, rough slows the ball, and unmapped ground uses a default resistance. Bunker entry stops the ball; water and OB trigger the existing replay penalty. Putting begins when the ball finishes on a green or approximate target. The bounce and turf parameters are estimates. The Trier DEM resolves broad slopes at 10 m spacing. Recorded rounds keep previous placements; subsequent shots use the updated model.

# v0.8.2-alpha — Offline tour career

In Course, choose Career tournament, select a course, round length, difficulty and shot source, then start. One human plays normal stroke play with the existing putting options and coach. Seven named rivals post simulated scores at round completion. All bundled and imported courses can host events. Each season has three regular tournaments and a double-points Championship Final. The highest season points total wins. Ties share rank and points. Rivals target approximately +5, even par, −4 and −9 respectively over 18 holes at Easy, Medium, Hard and Expert, with event variation and proportional targets on shorter rounds.

Progress is stored on this device separately for each difficulty and for Demo and live R10. Incomplete events can resume after reopening the app. Ending an incomplete event forfeits its progress. Achievements recognize a first finish, a birdie or better, a tournament win and a season title. Trier elevation remains bundled offline.

# v0.7.10-alpha — Trier elevation included offline

The Android asset includes the official Rheinland-Pfalz DGM1 elevation grid for all 18 Trier holes. Builds use the checked-in asset. Start a new Trier round to see uphill and downhill metres from your current lie to your aim point and the pin. Saved rounds keep their original course snapshot.

The 211 × 232 grid uses 10 m spacing, sampled from nine official 1 m DGM1 tiles (2025 filenames) in ETRS89 / UTM zone 32N, covering tile eastings 342–344 and northings 5522–5524. The grid includes the surrounding terrain. Small green contours can fall between samples. See course attribution in the app.

# v0.7.8-alpha — Terrain-ready course simulation

**Real elevation raster not bundled yet.** The development environment could not resolve the elevation-data host. The existing Trier geometry remains bundled, and its flat fallback is labeled. On a fresh CI build, `prepareTrierTerrain` attempts to download the public Mapzen/Tilezen Skadi N49E006 HGT tile from AWS and samples its actual elevations, approximately 30–90 m source spacing depending on tile format. This is a coarse DEM, not survey-grade DGM1; elevations may include surface effects. Success bundles the compact terrain-aware course; failure leaves a playable flat map and reports the error in the Course setup. Build-time retrieval has not been verified on GitHub. No internet required when playing.

The app supports official RLP DGM1 GeoTIFF inputs, from https://geoshop.rlp.de/opendata-dgm1.html (DL-DE/BY-2.0). Download coverage of approximately 6.802–6.834 E, 49.832–49.855 N (WGS84); in ETRS89/UTM32, safely cover E 341900–344300, N 5522200–5524900 m. All mapped features plus 450 m buffer included. For high-resolution import run `python tools/prepare_terrain.py --tif tile1.tif tile2.tif ... --data-year 2026 --out trier-terrain.json` with rasterio, numpy and pyproj installed; specify the actual data retrieval year. To bundle instead, use `--bundle --out courses/bundled/trier-terrain.json` as well. The converter samples at 10 m for mobile performance, validates coverage and size, and appends the source attribution. For direct coarse import, download https://s3.amazonaws.com/elevation-tiles-prod/skadi/N49/N49E006.hgt.gz and run `python tools/prepare_terrain.py --hgt N49E006.hgt.gz --out trier-terrain.json`. Import the resulting course JSON using the app. If network retrieval is unsuccessful, upload downloaded DEM files in ChatGPT for conversion. No synthetic terrain is shipped as Trier.

Terrain-aware rendering uses tessellated base/surface geometry with bilinear sampling, elevated vegetation and pins, ground ray picking and camera placement. Surface meshes remain approximate, especially on coarse DEM and software renderer. Course shots integrate until the trajectory intersects the terrain, allowing both longer downhill shots and shorter uphill shots. Collision heights are relative to local terrain; tree heights are still estimated. Bot flights approximate parabolas. Course scoring still uses landing position only; no sloped-ground rollout, exact water levels, or DEM-based tree heights. Range and practice retain the same aerodynamic coefficients and flat flight behavior. No CSV recalculation needed. Elevation difference to pin displayed during the round. Start a **new round** to use the upgraded course pack.

Tests: all existing JS/Java/Python tests passed, plus synthetic terrain interpolation, uphill/downhill, ground picking, tree collision, and HGT import tests. Tests use synthetic fixtures, not real Trier elevation. Android build, live DEM retrieval, actual terrain visual accuracy and device performance remain pending.

# Latest release v0.7.6-alpha — 3D visual upgrade

Use the usual ZIP replacement in GitHub main and build the latest commit. Retain a CSV backup. In Range or Practice select 3D, Medium quality, Tee View and Full Screen; play a demo shot, Replay and cycle cameras. Try Low/High quality if needed. Visual-only bounce and rollout show the existing estimated resting position; they do not change flight or scoring. The offline sky, grass, foliage and lighting are procedural/stylized. Course mode is still 2D. Android/GPU performance requires device validation. No need to recalculate history for this visual-only release.

# Latest release v0.7.4-alpha

Use the existing ZIP-replacement workflow: back up CSV, replace `r10-source.zip` on main, run a **new** workflow on the latest commit, install APK. Restore CSV if required, then History → Recalculate history (20°C, 200 m for reference comparison). Previous carry and prior model carry retained. Do not treat calibration results as fresh independent validation. Courses remain bundled as in v0.7.3. Native Bluetooth recovery and cue tone must be tested on hardware. See CHANGELOG and `validation/beta-reference.csv`, `validation/beta-replay-results.csv`, and `validation/fit-beta.js` for fit data and results.

# v0.7.3-alpha — Course tree collisions

Use the usual ZIP replacement/build process. Start a new round for testing. Trees now obstruct shots in three dimensions using provisional canopy/trunk sizes and flat terrain. On impact the orange flight trace ends at a red TREE HIT marker, the notice shows distance and height, and the house rule applies +1 penalty and replay. Low shots can pass below the canopy if they miss the trunk; shots above the estimated canopy or around its footprint are unaffected. Bots use approximate parabolic trajectories. The flight model is unchanged. Trier hole 10 fairway bunker geometry is still pending verification; no invented bunker. Hole 8 or 12 has mapped water for penalty testing.

## v0.4.2 — Swing delivery analysis

Main Range metrics now include Garmin-reported club path and face angle, derived face-to-path, and attack angle. Positive raw angles point right of target; left-handed labels reverse open/closed and in/out. Missing data is unavailable, not inferred from ball flight. Face-to-path is used as a qualitative delivery cross-check (2° heuristic), not an additional aerodynamic input. Session and Analytics show signed per-club means. Existing CSV fields retained. Flight model unchanged.

## v0.4.1 — Live session usability

- Range now has a persistent active practice session and a New session button (does not delete history). Live club-colored dispersion circles appear after three valid shots per club, with auto-scaled plot and separate real/demo data. Analytics remains available across history.
- Correct any shot’s club directly in Range or History; quick last-shot selector. Club averages and circles update immediately. CSV preserves session IDs and historical club corrections. Older imports without session IDs remain in History rather than mixing into a new session.
- Latest shot shows estimated shape (push/pull/straight with fade/slice/draw/hook), handedness, bold carry/offline/launch, and total, peak, spin, spin axis, ball speed, club head speed and smash factor above flight diagnostics. Shape uses initial heading and modeled bearing change; heuristic 1.5° straight and 5° severe curvature thresholds, not a measured classification.
- Offline is shown as L/R/C; mean absolute offline plus counts of left, right and center for the current club and all-history club analytics. Missing values excluded. Smash factor = ball speed / club speed; missing/zero club speed omitted.
- Removed standalone rollout display and finish dispersion; total distance still uses the previous provisional ground model because total remains requested.
- Carry flight engine unchanged. Protocol, flight, history, reference, club/session/shape and mocked-DOM UI tests pass. Browser smoke test timed out in this environment; Android build and actual device visual validation pending.

# R10 Private Range · Android 0.4.0-alpha

Private, offline-first Android driving range for a **Garmin Approach R10**. All app data stays on the phone. No remote account, SDK subscription, or `INTERNET` permission.

> **Development status:** The user confirmed physical R10 shot registration in v0.2. The new v0.3 aerodynamic model passes synthetic tests; its carry accuracy is not yet validated on hardware. This source archive is not an APK.

## Package 2 — Club analytics (v0.4.0)

- Select the actual 12-club bag in Range before each shot. Colors remain consistent in Range, Analytics and History.
- Analytics plots every eligible shot using the same scale on both axes. Circles are centered on each club's mean landing/finish position and enclose all displayed points (not confidence intervals). Switch between landing and finish and filter clubs. Demo shots are excluded unless enabled.
- Per-club means include carry, rollout, total, absolute lateral deviation at landing and finish, spin and apex. Missing values are excluded from each mean; metric sample counts appear if different from club count. All decimal shot metrics display one decimal place; CSV retains full precision.
- Historical club labels from before v0.4 are unverified because the selected club was sometimes wrong. Confirm/correct each shot in History; the original club is preserved. Only confirmed, current-model shots are included in club analytics. Reimporting the original backup does not duplicate a corrected shot.
- Rollout is a provisional flat-ground estimate using landing speed, angle, spin and selected ground firmness (soft/medium/firm). Total is carry plus rollout; finish position uses terminal flight heading when available, otherwise landing bearing. No terrain/slope/check-back or validated rollout calibration. Changing firmness recomputes these estimates for all eligible shots; CSV includes the selected surface and basis.
- The v0.3.2 carry engine and Bluetooth transport are unchanged. Carry is provisionally calibrated, not independently validated. Back up CSV before updating, then import if needed and recalculate history. Package 3 practice and coaching modes are still pending.

Run `node tests/club-analytics.test.js` plus the existing protocol, flight, history and calibration tests. The source ZIP is not an APK. Mobile UI and physical R10 testing are still needed.

## Package 1 — Accuracy and physics

See `CHANGELOG.md` for scope and limitations. Run `bash tests/run-tests.sh` and `node tests/flight.test.js` locally or build via GitHub Actions (workflow included). Export your existing shots from History before installing the update; if Android refuses the update due to different signing keys, do not uninstall until the export is saved.

To replay the existing shots offline: copy the CSV export to the project folder; fill in `shot_time` in `validation/reference-shots.csv` from the exact corresponding shot in the export (optionally add shot ID). Do not guess the pairing. Then run `node validation/replay.js exported-shots.csv validation/reference-shots.csv 15 0 > comparison.csv` (replace temperature and altitude with matching reference conditions). Unmatched shots are replayed without scoring. Existing readings alone cannot establish the new model's accuracy. The model uses generic coefficients guided by published golf ball aerodynamics, not fitted to a specific ball: https://www.mdpi.com/2504-3900/2/6/238 .

The following v0.2 notes describe the original transport implementation.

## What changed in v0.2

* Discover an `Approach R10` by BLE name; request Android Bluetooth bond if necessary; use native GATT connect.
* Discover the Garmin MultiLink GATT service, enable notifications, write to the correct pair of characteristics.
* Queue serialized GATT writes (using ATT-safe 20-byte values and explicit timeouts).
* Send MultiLink service-1 registration and handle its 16-byte response.
* Assemble notification fragments; COBS decode; verify CRC16/ARC; parse GFDI standard/compressed message headers.
* Complete the documented GFDI 5024/5050 handshake; ACK optional FIT messages without persisting device identity.
* Subscribe to shot-data alerts, request radar wake-up, decode status transitions and shots from protobuf messages.
* Extract launch speed/angle/direction, spin/spin axis, club speed/face/path/attack, shot id, and spin provenance; ignore duplicate retransmissions for 60 s.
* Send decoded real-shot measurements to the in-app range UI, while **labeling carry and lateral distance as unvalidated estimates**.
* Keep demo shots completely separate and labeled `DEMO`.
* Export the extended shot fields to CSV. Raw BLE payloads / device IDs are not exported.
* Include repeatable pure-Java tests for the protocol phases.

### Known limitations

* The phone-to-R10 path and Android `MainActivity.java` have not been exercised with hardware or compiled into an APK in this environment. Testing will likely reveal firmware-dependent edge cases.
* Protobuf fragmentation is handled for single-frame shot messages only; multi-part reassembly is not implemented.
* No automatic reconnect yet. Use **R10 Connect → Scan** after a disconnect.
* Swing without a ball is recognized in diagnostics but not imported as a ball-flight shot.
* The R10 reports **launch** data; v0.3 carry and landing are modeled by the experimental aerodynamic integrator. Rollout is not yet modeled.
* The selected club is assigned by the user in the app; the R10 doesn't automatically identify your club.
* No real golf-course environment yet. Driving range first.

## On-phone test plan

1. Charge and power on the R10. Close Garmin Golf and any other apps connected to it.
2. In Android settings, pair **Approach R10** over Bluetooth, if it is not already paired. (The app also asks Android to bond if needed.)
3. Install the generated debug APK using the build method below. Open the app and allow **Nearby devices** when requested.
4. Open **R10 Connect** → **Scan for R10**. Confirm progress through:
   * `Found Approach R10`
   * `Connected. Discovering R10 GATT services`
   * `Subscribing to R10 MultiLink notifications`
   * `Registering R10 MultiLink`
   * `GFDI handshake: ...`
   * `Handshake complete. Subscribing to shot data`
   * `Subscribed. Waking R10 radar`
   * `R10 radar: Armed — ready` or `R10 already awake — ready for shots`
5. Set your selected club on **Range**, hit a ball, and check for `Live shot #… received` in diagnostics and a new `R10`-labelled row in the range/history.
6. If it stalls, take a screenshot of the **connection diagnostics text** and share it, preferably without any Bluetooth MAC addresses or other private identifiers. The app deliberately does not expose binary packet captures.

If it does not find the device: ensure Garmin Golf is fully disconnected, turn R10 off/on, pair via Android Bluetooth settings, grant Nearby devices, then scan again. A hardware test will determine whether Android's no-location BLE scanning flag needs changing on your phone.

## APK build without a local IDE

The ZIP contains a complete Gradle source project, **not an APK**. To compile using GitHub's hosted build computers:

1. Create a **private** GitHub repository; upload the ZIP's **contents** into its root.
2. On GitHub, open **Actions → Build Android APK → Run workflow** (or push to `main`).
3. Wait for the build to finish; download the `r10-private-range-debug-apk` artifact and extract its `app-debug.apk`.
4. Open that APK on your Android phone and follow Android's prompts to allow installation from the app used to open it.

Alternatively, open the project in Android Studio with Android SDK 35 / JDK 17 / Gradle 8.9 and choose **Build APK(s)**. Neither method needs a Play Store listing.

## Run protocol regression tests without Android SDK

On a machine with a JDK:

```bash
bash tests/run-tests.sh
```

Tests simulate a full session: MultiLink registration → GFDI 5024/5050 → protobuf subscribe → wake response → decoded launch shot → duplicate suppression, also exercising COBS, CRC, split BLE notifications and corruption handling. These tests **do not constitute a hardware test**.

## Source code

* `app/src/main/java/com/privategolf/r10range/MainActivity.java` — Android BLE permissions, bond/connect, serialized writes, local WebView bridge, offline CSV export.
* `app/src/main/java/com/privategolf/r10range/R10Protocol.java` — pure Java Garmin MultiLink/GFDI/protobuf protocol driver.
* `app/src/main/assets/index.html` — offline range UI and practice history.
* `tests/R10ProtocolTest.java` — regression tests.
* `.github/workflows/android-apk.yml` — hosted build of debug APK.

## Interoperability references

This independent interoperability implementation uses publicly documented protocol behavior and original Java code. Useful technical references:

* [10over: Wire Protocol Reference](https://github.com/divotmaker/10over/blob/main/docs/WIRE.md)
* [10over: Connection Lifecycle and Message Sequencing](https://github.com/divotmaker/10over/blob/main/docs/SEQUENCE.md)
* [10over: R10 device library](https://docs.rs/crate/tenover/latest)
* [Flighthook: Garmin R10](https://github.com/divotmaker/flighthook/blob/main/docs/devices/garmin-r10.md)

No first-party Garmin code or authentication bypass is included. This project is not associated with Garmin.

### Restore a CSV backup (v0.3.1)
Keep the original CSV outside the app. In History, choose Import CSV and select your exported file using Android Files. Legacy rows with complete inputs are recalculated using current temperature/altitude; their original carry is saved as previousCarry. Rows lacking required data keep their original carry. Repeated imports skip matching shots. Import merges rather than clears history; files must be UTF-8 CSV from this app and fit the 1,000-shot limit. Use the original CSV for reference matching and keep a separate backup. This source update has local parser/flight/protocol tests, not a verified APK or device test.

### v0.3.2 physics calibration and history replay
Default conditions are 20°C / 200 m. The model is tuned to seven confirmed Awesome Golf shot pairs (one probable pair is excluded). This is a calibration result, not independent validation. Back up your CSV before updating. In Range, check atmosphere; in History, import your backup if needed and tap Recalculate history. Original carry and raw data are retained; the previous model carry is stored separately when the model changes. Export a new CSV for comparison.

Offline commands:
```sh
node validation/calibrate.js
node validation/replay.js validation/calibration-shots.csv validation/reference-shots.csv 20 200
node tests/reference-replay.test.js
```
The calibration coefficients are engineering approximations informed by the general dependence of golf-ball drag/lift on spin and speed (see https://www.mdpi.com/2504-3900/2/6/238). They are not measured ball-specific coefficients. Use fresh reference shots to check generalization, especially wedges, low launch and different speeds.

### v0.5.0 practice modes
Open **Practice** and choose Random Numbers, Target Practice or Club Gapping. Choose live R10 or demo, configure the session and tap Start practice. Confirm the club before each attempt; the button changes to Ready. In demo mode use Demo practice shot; in live mode hit the ball once the R10 is ready. A new target or next club is selected automatically after a scored attempt. Unarmed shots are retained as ordinary history, not scored. Changing tabs disarms the next shot. Correct the recorded club in the practice shot list or History. Gapping advances when the required count for each chosen club is satisfied. To stop early, End practice; review results before New practice. Older sessions appear below the setup/results screen. A CSV export retains practice metadata and can restore practice result archives after a reinstall; in-progress setup is device-local. Existing 1000-shot cap applies. Target scores are based on modeled carry landing coordinates and configurable target distances (not rollout), and are provisional until independent flight validation. For gapping, SD is population SD; consistency labels and overlap bands are descriptive heuristics, not confidence intervals. The optimized flight engine and Bluetooth implementation are unchanged from v0.4.2. All automated tests pass; Android build and on-device UI validation remain necessary.

### v0.6.0 — Integrated Personal Golf Coach

Use the global **Personal Golf Coach** selector below the app header: Off hides feedback in all modes, Brief shows a priority plus a drill, and Detailed includes the underlying evidence and your historical comparison. Take a Range shot or confirm a club and complete a scored attempt in any Practice mode. Feedback appears below the shot metrics. Demo shots are explicitly marked and cannot contaminate real-shot history comparisons. Correcting a club assignment recalculates feedback from the corrected data. For personalized comparisons, confirm at least five prior shots of the same club with compatible flight model, environmental settings, source and target context. Current/prior session trends require at least five comparable offline measurements in each group. Prior carry can reflect different swing intents, especially wedges; use the suggestions as experiments rather than diagnoses. Spin and flight can be estimated, and delivered angles are not a video-based swing analysis. The coach works completely offline. No additional CSV columns are required. Course simulation will reuse the coach module in a future release.

Run `node tests/coach.test.js` and `node tests/ui-smoke.test.js` in addition to the prior regression tests. All automated tests pass in the development environment; a real Android APK/device test is outstanding. The calibrated flight.js and native Bluetooth implementation are unchanged. Back up CSV before installing; replace the existing repository's source ZIP and build the latest main commit with the existing workflow.

## v0.7.0: course simulation alpha

Open **Course**, choose Practice Valley (fictional), number of holes, front/back start (for <=9), format, human count, number of bot opponents/teams, bot difficulty and live R10/demo source. In stroke play each golfer plays their own ball. In scramble choose between both team shots; solo scramble supplies a bot partner. Tap the map to aim; confirm club/current player before each human shot. Bots use a simplified independent distance/dispersion model. Auto-putting estimates 0–3 strokes; manual putting accepts 1–10 once on a mapped green. Water and mapped OB use a simplified +1/replay rule. No terrain, wind, tree collision or surface-dependent carry/roll yet. Landings use carry only. There is a 16+ stroke pickup safeguard. The scorecard is gross strokes, not WHS or official rules. Second players' shots are kept out of personal history. One current round is saved locally; export its scorecard before ending or reinstalling. This export is not a round-state restore file.

### Real course data

Trier (Ensch), Kikuoka and assumed Weiherhof near Losheim are listed in `courses/catalog.json`, **not bundled as playable real courses**. Geometry access failed in the build environment. Do not rename the fictional course to any actual course. See `courses/README.md` for the strict open-data import path. JSON packs are imported using the Android file picker in Course → Import course JSON. Existing application ID is unchanged. Replace the root ZIP in the existing GitHub main workflow; retain CSV backups.

## v0.7.1 — Real course data acquisition
Use the usual `r10-source.zip` replacement and a new GitHub build on `main`. The Gradle `prepareR10CourseAssets` task invokes Python 3 on the GitHub runner, retrieves the three scoped OSM extracts and writes `course-packs.js` plus `osm-source/report.json`, raw source and successful transformed packs into generated APK assets. No workflow replacement is needed. Check the task log for each course status. After installation, open **Course**; only successful packs appear in the selector, with a status report for every attempted course. Practice Valley remains explicitly fictional. The APK is usable offline after build. A network failure or incomplete/ambiguous geometry is not treated as successful acquisition. The app and GitHub artifact still build when an individual course is unavailable. Local offline builds show pending unless the acquisition script is run with `--online` separately; `R10_SKIP_COURSE_FETCH=1` skips acquisition on GitHub.

Trier is the first candidate, not a guaranteed playable pack: OpenYardage's public inventory reports 18 routes but one unmapped green; this alpha permits a gameplay-only 10 m putting target around at most one mapped route endpoint (not an actual green polygon). Review all geometry before treating it as realistic. Kikuoka and Weiherhof likely need substantial additional mapping; Weiherhof needs a verified loop combination. Source URL failures, stale OSM tags, missing geometry and invalid routes are reported. No licensed aerial tiles or terrain are bundled, and none of the three real courses has been live imported or independently validated by the developer. See `courses/README.md`.

## v0.7.2: offline Trier and map controls
Replace `r10-source.zip` in your existing repository, commit to main, build the latest commit and install the APK. The Android build no longer downloads geographic data. Trier is packaged inside the app, so no separate import is required. To see the revised map, start a new round; ongoing rounds retain their original geometry.

During a round the map fills the display above the bottom navigation. Tap to aim, drag to pan, pinch to zoom or use +/−, then Full hole to restore the route overview. The bottom overlay includes club selection/ready, current turn, target distance and scramble/putting controls. Round details includes the coach, last shot, scorecard, attribution and end-round control. The map legend distinguishes mapped hazards and unknown ground. Under the simulator house rule, mapped woodland, scrub, tree rows and individual trees count as OB when the ball lands in them (one penalty stroke and replay; not official OB). Tree footprints are approximate; no airborne collision detection yet. Some hazards may be missing in OSM, and hole 18's green is still an approximate gameplay target.

Course setup → Export selected course JSON saves a single course through the native Android picker. Keep these files and CSV exports externally; local storage may be lost on uninstall or a clean installation. Older imported Trier revisions remain backed up but the bundled newer revision takes precedence for new rounds. The enriched pack is also in `courses/bundled/trier.json`. Source and licensing: `courses/source/`. Kikuoka and Weiherhof are not bundled. Career mode remains backlog. Android APK and physical-device testing are pending.

### v0.7.5 optional 3D range
Select **3D** from the View selector on Range or an active Practice screen. The choice is shared across these modes; choose **2D** to restore the original map. Camera choices: Tee view, Aerial, Follow ball. New modeled shots animate along their existing time-stamped flight points; Replay runs the last trajectory again. Older shots without trajectory points show landing dots only. Graphics quality controls tree detail and render pixel ratio. Distance markers and the target rings use meter-scale coordinates. Course rounds continue to use the existing 2D map.

Full screen expands the renderer within the app and includes camera/replay controls. Rotate the phone to landscape for a wider view; exit full screen to change clubs or confirm a Random Numbers attempt. No additional dependencies, downloads, network permissions or GitHub workflow changes are required. The renderer prefers WebGL 2 and falls back to projected Canvas 3D; if rendering fails, the original 2D view is restored. The mode indicator shows which renderer is active. Visuals are intentionally low-poly/procedural and flat; terrain, realistic textures, 3D Trier geometry and animated vegetation are future work.

Test: use Demo shot in Range, switch cameras, replay, rotate, change quality, and repeat in each practice mode. Verify the 2D toggle and that shots/metrics remain identical. For GPU or Android problems, report phone model, mode/status and screenshot. Automated Java/JS/Python tests pass, including `node tests/range3d.test.js`; browser software-renderer UI tests pass, actual GPU and Android hardware remain unverified. Keep CSV/course backups before installing.

### v0.7.7: 3D course view
Select Course, Trier, a round length and start. Switch between 3D course and 2D map using the view selector. Ball view follows the current player position and aim; Aerial frames the hole; Follow ball follows the recorded human shot during animation. Tap ground to change aim, or use 2D for precise positioning. Confirm the club to record the next shot as before. Replay works for the last human shot on the current hole; bots resolve immediately. Geometry is OSM-derived and not surveyed. Terrain is flat and vegetation stylized, not actual elevations. The mapped bunker omission on hole 10 and approximate putting target on hole 18 are unchanged. No changes to scoring or physics.

### 0.7.9 official Trier elevation recovery
CI invokes `tools/fetch_trier_terrain.py`. Nine verified tile filenames are in `courses/trier-dgm1-sources.json`. The downloader uses a temporary Python virtual environment for rasterio/pyproj if needed and tries Skadi if official retrieval/conversion fails. Inspect `prepareTrierTerrain` build output for the selected source and any errors. If both fail the app remains explicitly flat; no synthetic heights are substituted.

Manual recovery: download all nine official `.tif` files listed in the manifest, then run `python tools/prepare_terrain.py --tif /path/to/tiles/*.tif --out /path/to/trier-terrain.json` in an environment with rasterio and pyproj. Import the resulting JSON through Course → Import course JSON. Use `--bundle` to embed the same pack in the source tree for subsequent releases. Start a new round after updating. DGM1 source is 1 m; the app grid is sampled every 10 m. The aim and pin readouts show signed elevation differences from the current ball position, not absolute height above sea level, and explicitly flag unavailable data.

## v0.17.0-alpha — experimental Three.js renderer

This release preserves the v0.16 shot engine, HUD, course geometry, scoring, BLE protocol and stored data. The Three.js layer consumes the same scene geometry, camera and trajectories and draws into a separate canvas. If it cannot initialize or loses the context, the original renderer takes over. The range/course view status identifies the actual renderer. Grass/sand maps are deterministic procedural textures; the existing tree atlas is mapped onto crossed cards. High graphics enables a local directional shadow map. The existing sky image remains the backdrop; this is not a fully new photorealistic course asset set.

### Build

GitHub Actions installs pinned Three.js 0.180.0, esbuild and Playwright dependencies, creates the local classic-script bundle and copies the Three.js MIT license before Android compilation. It also runs a real headless WebGL smoke test. There is no runtime CDN or internet dependency. For manual builds from source, run `npm install --no-audit --no-fund` then `npm run build:three` before Gradle. The source archive intentionally contains a placeholder for the generated runtime; opening it without the build step uses the legacy renderer. A package lock is not included because the dependency registry was inaccessible in the authoring environment.

### Validation status

26 existing and new local JavaScript/Python/Java suites passed, including all Trier hole geometry conversion. The real Three.js dependency could not be downloaded locally, so the actual WebGL smoke test, APK compilation and device performance/appearance remain unverified. The CI smoke test is an additional build gate; its results must not be inferred from the local adapter tests.
