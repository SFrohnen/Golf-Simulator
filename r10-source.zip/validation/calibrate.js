// Development-only bounded grid fit. Excludes probable matches; no automatic live calibration.
const fs=require('node:fs');const path=require('node:path');const H=require('../app/src/main/assets/history-import');const F=require('../app/src/main/assets/flight');
const rows=H.parse(fs.readFileSync(path.join(__dirname,'calibration-shots.csv'),'utf8'));
const refs=fs.readFileSync(path.join(__dirname,'reference-shots.csv'),'utf8').trim().split(/\r?\n/).slice(1).map(s=>s.split(','));
const data=refs.filter(r=>r[7]==='CONFIRMED').map(r=>({shot:rows.find(s=>s.shotId===r[5]&&s.time===r[6]),reference:Number(r[2])}));
if(data.some(r=>!r.shot))throw Error('Missing matched raw shot');
const settings={temperatureC:20,altitudeM:200,dt:.025};const candidates=[];
for(const baseDrag of [.16,.18,.20,.22,.24])for(const spinDrag of [.12,.22,.32,.42,.52])for(const liftScale of [1.5,1.65,1.8,1.95,2.1]){
 const coeff={baseDrag,spinDrag,liftScale};const err=data.map(r=>F.simulateWithCoefficients(r.shot,settings,coeff).carry-r.reference);
 const penalty=4*((baseDrag-.22)/.06)**2+4*((spinDrag-.12)/.4)**2+4*((liftScale-1.5)/.6)**2;candidates.push({coeff,err,penalty});
}
const indices=data.map((_,i)=>i);const loss=(c,ix)=>ix.reduce((sum,i)=>sum+c.err[i]**2,0)/ix.length+c.penalty;const select=ix=>candidates.reduce((a,b)=>loss(a,ix)<loss(b,ix)?a:b);
const best=select(indices);const held=indices.map(i=>{const c=select(indices.filter(j=>j!==i));return {shotId:data[i].shot.shotId,coeff:c.coeff,error:c.err[i]};});const mae=a=>a.reduce((sum,e)=>sum+Math.abs(e),0)/a.length;
console.log(JSON.stringify({selected:best.coeff,fitMAE:mae(best.err),leaveOneOutMAE:mae(held.map(r=>r.error)),held},null,2));
