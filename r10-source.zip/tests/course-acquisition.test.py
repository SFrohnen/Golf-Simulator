import pathlib,sys,tempfile,json,unittest,math
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'tools'))
import prepare_course_packs as m

def fixture(profile,missing=()):
    baseLat,baseLon=49.83,6.80
    elements=[{'type':'way','id':profile['osmBoundary'],'tags':{'leisure':'golf_course'},'geometry':[]}]
    def way(i,tags,pts):return {'type':'way','id':i,'tags':tags,'geometry':[{'lat':lat,'lon':lon} for lon,lat in pts]}
    for i,length in enumerate(profile.get('referenceLengths',[250]*18),1):
        lon=baseLon+i*.001; lat=baseLat; end=lat+math.degrees(length/6371008.8)
        elements.append(way(i,{'golf':'hole','ref':str(i)},[(lon,lat),(lon,end)]))
        if i not in missing: elements.append(way(100+i,{'golf':'green'},[(lon-.00012,end-.0001),(lon+.00012,end-.0001),(lon+.00012,end+.0001),(lon-.00012,end+.0001),(lon-.00012,end-.0001)]))
    return {'elements':elements,'osm3s':{'timestamp_osm_base':'2026-11-24T00:00:00Z'}}
class Test(unittest.TestCase):
    def test_tier(self):
        p=m.PROFILES['trier'];c=m.convert(fixture(p,(18,)),p);self.assertEqual(c['holes'][17]['approximatePuttingTarget'],10);self.assertFalse(any(s['type']=='green' for s in c['holes'][17]['surfaces']));self.assertEqual(c['quality'],'provisional');self.assertEqual(sum(h['par'] for h in c['holes']),72)
        with self.assertRaisesRegex(ValueError,'endpoint'):m.convert(fixture(p,(17,18)),p)
        d=fixture(p);d['elements'].pop(0)
        with self.assertRaisesRegex(ValueError,'boundary'):m.convert(d,p)
    def test_reports(self):
        with tempfile.TemporaryDirectory() as temp:
            root=pathlib.Path(temp);fixtures=root/'fixtures';fixtures.mkdir();out=root/'out';p=m.PROFILES['trier'];(fixtures/'trier.json').write_text(json.dumps(fixture(p,(18,))))
            (fixtures/'kikuoka.json').write_text(json.dumps({'elements':fixture(m.PROFILES['kikuoka'])['elements'][:5]}))
            (fixtures/'weiherhof.json').write_text(json.dumps(fixture(m.PROFILES['weiherhof'])))
            r=m.prepare(out,fixtures=fixtures);self.assertEqual(len(r['packs']),1);self.assertEqual([i['state'] for i in r['status']],['available','unavailable','unavailable']);self.assertTrue((out/'osm-source/trier.overpass.json').exists());self.assertTrue((out/'osm-source/trier.pack.json').exists());self.assertIn('R10BundledCourses', (out/'course-packs.js').read_text());self.assertEqual(m.prepare(out)['packs'],[]);self.assertFalse((out/'osm-source/trier.pack.json').exists())
if __name__=='__main__':unittest.main()
