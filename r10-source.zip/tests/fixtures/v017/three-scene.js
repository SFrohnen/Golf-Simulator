/* Three.js presentation adapter. No changes to shots, terrain data or scoring. */
(function(root){'use strict';
const xyz=(x,y,z)=>[-x,y,z]; // Legacy camera is left-handed; reflect east to match Three's right-handed camera.
const srgb=v=>{v=Math.max(0,Math.min(1,v));return v<=.04045?v/12.92:Math.pow((v+.055)/1.055,2.4);};
function bucket(){return {position:[],color:[],uv:[]};}
function vertex(b,p,c,uv=[0,0]){b.position.push(...xyz(...p));b.color.push(...c.map(srgb));b.uv.push(...uv);}
function classify(mat){return mat===-2?'sand':mat===-1?'grass':mat===1?'solid':'solid';}
function convert(geo){
 const out={grass:bucket(),sand:bucket(),water:bucket(),solid:bucket(),leaves:bucket()},a=geo.tris;
 for(let i=0;i<a.length;){let mat=a[i+6];
  if(mat < -9){ // A legacy tree card encodes width, UV, species and tone in six vertices.
   const width=-mat-10;
   for(const angle of [Math.PI/4,-Math.PI/4]) for(let j=0;j<6;j++){
    const k=i+j*7,u=a[k+3],v=a[k+4],s=Math.floor(a[k+5]),tone=.92+(a[k+5]-s)*.16;
    vertex(out.leaves,[a[k]+(u-.5)*width*Math.cos(angle),a[k+1],a[k+2]+(u-.5)*width*Math.sin(angle)],[tone,tone,tone],[(u*.996+.002+s)*.5,v*.4995+.5005]);
   }i+=42;continue;
  }
  // Water triangles use the existing blue palette; solid decorative geometry stays separate.
  const kind=mat===1&&a[i+3]<.3&&a[i+4]>.35&&a[i+5]>.52?'water':classify(mat),b=out[kind];
  for(let j=0;j<3;j++){const k=i+j*7;vertex(b,a.slice(k,k+3),a.slice(k+3,k+6),[a[k]/1.8,a[k+2]/1.8]);}i+=21;
 }
 return out;
}
function convertLinear(a){const b=bucket();for(let i=0;i<a.length;i+=7)vertex(b,a.slice(i,i+3),a.slice(i+3,i+6));return b;}
function textureData(kind,n=128){const a=new Uint8Array(n*n*4),r=(x,y)=>{const f=Math.sin(x*127.1+y*311.7)*43758.5453;return f-Math.floor(f);};for(let y=0;y<n;y++)for(let x=0;x<n;x++){const v=r(x,y),coarse=r(Math.floor(x/8),Math.floor(y/8)),blade=r(x,Math.floor(y/3));let l=kind==='sand'?194+49*v+12*coarse:158+37*v+28*blade+27*coarse;let i=(y*n+x)*4;for(let k=0;k<3;k++)a[i+k]=Math.round(l);a[i+3]=255;}return a;}
class SceneRenderer{
 constructor(original,owner,T=root.R10Three){this.T=T;this.owner=owner;this.original=original;this.canvas=root.document.createElement('canvas');this.canvas.className='threeSceneCanvas';this.canvas.setAttribute('aria-hidden','true');this.canvas.style.pointerEvents='none';this.canvas.style.position='absolute';this.canvas.style.inset='0';this.canvas.style.width='100%';this.canvas.style.height='100%';original.parentNode.insertBefore(this.canvas,original);try{
  this.renderer=new T.WebGLRenderer({canvas:this.canvas,alpha:true,antialias:true,powerPreference:'high-performance'});this.renderer.setClearColor(0,0);this.renderer.outputColorSpace=T.SRGBColorSpace;this.renderer.toneMapping=T.ACESFilmicToneMapping;this.renderer.toneMappingExposure=1.32;
  this.scene=new T.Scene();this.scene.fog=new T.Fog(0xaec8c2,120,800);this.camera=new T.PerspectiveCamera(60,1,.15,1800);this.static=new T.Group();this.dynamic=new T.Group();this.scene.add(this.static,this.dynamic);
  this.scene.add(new T.HemisphereLight(0xe5f3ff,0x78914b,2.1));this.sun=new T.DirectionalLight(0xffefd4,2.6);this.sun.position.set(75,105,-50);this.scene.add(this.sun,this.sun.target);this.sun.castShadow=true;this.sun.shadow.mapSize.set(1024,1024);Object.assign(this.sun.shadow.camera,{left:-100,right:100,top:100,bottom:-100,near:1,far:350});this.sun.shadow.normalBias=.16;this.sun.shadow.bias=-.0003;this.renderer.shadowMap.type=T.PCFSoftShadowMap;this.renderer.shadowMap.autoUpdate=false;
  this.textures={};for(const kind of ['grass','sand']){const tex=new T.DataTexture(textureData(kind),128,128,T.RGBAFormat);tex.colorSpace=T.SRGBColorSpace;tex.wrapS=tex.wrapT=T.RepeatWrapping;tex.magFilter=T.LinearFilter;tex.minFilter=T.LinearMipmapLinearFilter;tex.generateMipmaps=true;tex.anisotropy=Math.min(4,this.renderer.capabilities.getMaxAnisotropy());tex.needsUpdate=true;this.textures[kind]=tex;}
  this.materials={grass:new T.MeshStandardMaterial({vertexColors:true,map:this.textures.grass,roughness:1,side:T.DoubleSide}),sand:new T.MeshStandardMaterial({vertexColors:true,map:this.textures.sand,roughness:1,side:T.DoubleSide}),water:new T.MeshStandardMaterial({vertexColors:true,roughness:.25,metalness:.18,side:T.DoubleSide}),solid:new T.MeshStandardMaterial({vertexColors:true,roughness:.9,side:T.DoubleSide}),leaves:new T.MeshStandardMaterial({vertexColors:true,side:T.DoubleSide,alphaTest:.42,roughness:1}),overlay:new T.MeshBasicMaterial({vertexColors:true,side:T.DoubleSide,polygonOffset:true,polygonOffsetFactor:-1,polygonOffsetUnits:-1}),line:new T.LineBasicMaterial({vertexColors:true})};
  this.foliageReady=false;if(root.R10FoliageImage)new T.TextureLoader().load(root.R10FoliageImage,tex=>{if(this.disposed){tex.dispose();return;}tex.colorSpace=T.SRGBColorSpace;this.textures.leaves=tex;this.materials.leaves.map=tex;this.materials.leaves.needsUpdate=true;this.foliageReady=true;this.key=null;if(owner.lastData&&original.isConnected)owner.draw(owner.lastData,root.performance.now());},undefined,()=>{});
  this.canvas.addEventListener('webglcontextlost',e=>{e.preventDefault();this.lost=true;});original.style.opacity='0';
 }catch(e){this.dispose();throw e;}}
 meshGeometry(b,normals=true){const T=this.T,g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(b.position,3));g.setAttribute('color',new T.Float32BufferAttribute(b.color,3));g.setAttribute('uv',new T.Float32BufferAttribute(b.uv,2));if(normals)g.computeVertexNormals();return g;}
 clear(group){for(const obj of group.children.slice()){group.remove(obj);obj.geometry?.dispose();if(obj.userData.ownMaterial)obj.material.dispose();}}
 addTriangles(group,geo,isDynamic){const T=this.T;for(const [kind,b] of Object.entries(convert(geo))){if(!b.position.length)continue;const material=isDynamic&&kind==='solid'?this.materials.overlay:this.materials[kind],mesh=new T.Mesh(this.meshGeometry(b),material);mesh.receiveShadow=!isDynamic&&kind!=='leaves';mesh.castShadow=!isDynamic&&(kind==='leaves'||kind==='solid');group.add(mesh);}}
 addLines(group,arr){if(!arr.length)return;group.add(new this.T.LineSegments(this.meshGeometry(convertLinear(arr),false),this.materials.line));}
 addDots(group,arr,ratio){const T=this.T; // Fixed pixel-size circular points, matching the existing HUD marker sizes.
  if(!arr.length)return;const b=convertLinear(arr),g=this.meshGeometry(b,false),sizes=[];for(let i=6;i<arr.length;i+=7)sizes.push(arr[i]*ratio);g.setAttribute('size',new T.Float32BufferAttribute(sizes,1));const m=new T.ShaderMaterial({vertexShader:'attribute float size; attribute vec3 color; varying vec3 col; void main(){col=color;gl_PointSize=size;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',fragmentShader:'varying vec3 col; void main(){float d=length(gl_PointCoord-.5);if(d>.5)discard;gl_FragColor=vec4(col,1.); #include <colorspace_fragment>\n}'.replace('; #include',';\n#include')});const p=new T.Points(g,m);p.userData.ownMaterial=true;group.add(p);}
 draw({key,ground,dynamic,cam,quality,w,h,ratio}){if(this.lost)throw Error('Three.js GPU context lost');const r=this.renderer; if(this.w!==w||this.h!==h){r.setSize(w,h,false);this.w=w;this.h=h;}
  const shadows=quality==='high';r.shadowMap.enabled=shadows;this.camera.aspect=w/h;this.camera.updateProjectionMatrix();this.camera.position.set(...xyz(...cam.eye));this.camera.up.set(...xyz(...cam.u));this.camera.lookAt(...xyz(...cam.at));
  const fullKey=key+'/'+this.foliageReady;if(this.key!==fullKey){this.clear(this.static);const geo=ground(this.foliageReady);this.addTriangles(this.static,geo,false);this.addLines(this.static,geo.lines);this.key=fullKey;r.shadowMap.needsUpdate=true;}
  const center=[-cam.eye[0],0,cam.eye[2]];if(shadows&&(!this.shadowCenter||Math.hypot(center[0]-this.shadowCenter[0],center[2]-this.shadowCenter[2])>45)){this.shadowCenter=center;this.sun.position.set(center[0]+75,105+cam.eye[1]*.12,center[2]-50);this.sun.target.position.set(...center);this.sun.shadow.camera.updateProjectionMatrix();r.shadowMap.needsUpdate=true;}
  this.clear(this.dynamic);this.addTriangles(this.dynamic,dynamic,true);this.addLines(this.dynamic,dynamic.lines);this.addDots(this.dynamic,dynamic.dots,ratio);r.render(this.scene,this.camera);}
 dispose(){this.disposed=true;if(this.static)this.clear(this.static);if(this.dynamic)this.clear(this.dynamic);for(const m of Object.values(this.materials||{}))m.dispose();for(const t of Object.values(this.textures||{}))t.dispose();this.renderer?.dispose();this.renderer?.forceContextLoss();this.canvas?.remove();if(this.original?.style)this.original.style.opacity='';}
}
const api={SceneRenderer,xyz,srgb,convert,convertLinear,textureData};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.R10ThreeScene=api;
})(typeof globalThis!=='undefined'?globalThis:this);
