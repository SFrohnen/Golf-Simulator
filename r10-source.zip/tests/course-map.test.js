const assert=require('node:assert/strict'),M=require('../app/src/main/assets/course-map.js'),E=require('../app/src/main/assets/course.js'),fs=require('fs');
const v=M.fit([[0,0],[0,400]],400,700,100,140),p=[50,200],screen=M.project(v,p);const close=(a,b)=>assert(Math.hypot(a[0]-b[0],a[1]-b[1])<1e-8);close(M.unproject(v,screen),p);const z=M.zoom(v,2,screen,v.k);close(M.project(z,p),screen);const pan=M.pan(z,22,-11);close(M.project(pan,p),[screen[0]+22,screen[1]-11]);assert.equal(M.zoom(v,100,screen,v.k).k,v.k*10);
const c=E.validate(require('../courses/bundled/trier.json'));assert.equal(c.holes.length,18);assert.equal(c.mapRevision,2);assert(fs.statSync('courses/bundled/trier.json').size<1024*1024);for(const h of c.holes){assert.notEqual(E.lie(h,h.tee),'ob');assert.equal(E.lie(h,h.pin),'holed');}
const ring=[[0,0],[20,0],[20,20],[0,20]],hole={pin:[100,100],surfaces:[{type:'woodland',ring,holes:[[[5,5],[15,5],[15,15],[5,15]]]}]};assert.equal(E.lie(hole,[2,2]),'ob');assert.equal(E.lie(hole,[10,10]),'unmapped');for(const type of ['tree','tree_row','woodland','water','bunker']){hole.surfaces=[{type,ring}];assert.equal(E.lie(hole,[10,10]),type==='water'||type==='bunker'?type:'ob');}
const r=E.create(c,{holes:3,side:'front',humans:1,bots:0,difficulty:'easy',format:'stroke',source:'DEMO',putting:'auto'});const a=E.active(r);let sample;for(const s of a.hole.surfaces.filter(s=>s.type==='woodland')){const xx=s.ring.map(p=>p[0]),yy=s.ring.map(p=>p[1]);for(let x=Math.min(...xx)+.5;x<Math.max(...xx)&&!sample;x+=2)for(let y=Math.min(...yy)+.5;y<Math.max(...yy)&&!sample;y+=2){if(E.lie(a.hole,[x,y])==='ob')sample=[x,y];}if(sample)break;}assert(sample);const d=E.dist(a.state.pos,sample),before=a.state.pos.slice();const e=E.shoot(r,sample,{downrange:d,offline:0});assert.equal(e.penalty,1);assert.equal(e.surface,'ob');assert.deepEqual(r.states[0].pos,before);assert.equal(r.states[0].strokes,2);console.log('PASS projection/zoom/pan, real Trier validation and woodland landing penalty, polygon cutouts');
const box=(x0,y0,x1,y1)=>[[x0,y0],[x1,y0],[x1,y1],[x0,y1]];
const fairway={type:'fairway',ring:box(-15,-10,11,100),holes:[box(-8,20,-6,40)]};
const wider={type:'fairway',ring:box(10,0,18,60)};
const testHole={surfaces:[fairway,wider]};
assert.deepEqual(M.fairwayRoom(testHole,[0,0],[0,30]),{left:6,right:18});
assert.deepEqual(M.fairwayRoom(testHole,[0,70],[0,30]),{left:18,right:6});
assert.equal(M.fairwayRoom(testHole,[0,0],[30,30]),null);
assert.equal(M.fairwayRoom(testHole,[0,0],[0,0]),null);
