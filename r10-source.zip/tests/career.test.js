const assert=require('node:assert/strict');
const tour=require('../app/src/main/assets/career.js');
function round(history,id,difficulty='expert',holes=18){
    return {id,done:true,career:tour.stage(history),course:{name:'Imported test course'},
        config:{difficulty},numbers:Array.from({length:holes},(_,i)=>i+1),
        scorecards:Array.from({length:holes},()=>({par:4,scores:[3]}))};
}
let history=[];
for(let i=0;i<4;i++){
    const r=round(history,'event-'+i);
    assert.equal(tour.record(history,{...r,done:false}),history);
    history=tour.record(history,r);
    assert.equal(tour.record(history,r),history);
    const result=history.at(-1);
    assert.equal(result.results.length,8);
    assert.equal(result.results[0].points,i===3?1000:500);
    assert.equal(result.results[0].name,'You');
}
assert.equal(tour.stage(history).season,2);
assert.equal(tour.standings(history,1)[0].points,2500);
assert.equal(tour.standings(history,2)[0].points,0);
assert(tour.achievements(history).includes('Season champion'));
for(const difficulty of Object.keys(tour.targets)){
    const r=round([],difficulty,difficulty);
    const field=tour.record([],r)[0].results.filter(p=>p.name!=='You');
    assert(Math.abs(field[0].strokes-72-tour.targets[difficulty])<=2);
    r.scorecards[0].scores[0]+=field[0].strokes-54;
    const tied=tour.record([],r)[0].results.filter(p=>p.place===1);
    assert(tied.length>=2 && tied.every(p=>p.points===500));
}
console.log('PASS season rollover, double points, standings, achievements, ties and difficulty targets');
