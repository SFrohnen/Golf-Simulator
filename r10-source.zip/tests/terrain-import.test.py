import sys,pathlib,json,gzip,struct,tempfile
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'tools'))
from prepare_terrain import make_grid,skadi_sample,publish,BASE
c=json.loads(BASE.read_text())
n=1201
# synthetic sloped source, correctly formatted HGT, NOT course elevation.
raw=b''.join(struct.pack('>h',j//2+40)*n for j in range(n)); sample,n2=skadi_sample(gzip.compress(raw));assert n2==n
assert 100<sample(49.84,6.82)<200
# Fixture with sufficient range over our course bounding box
q=make_grid(c,lambda lat,lon:300+(lat-49.84)*10000,10,'synthetic fixture','test only')
assert q['nx']*q['ny']==len(q['values']);assert max(q['values'])-min(q['values'])>10
with tempfile.TemporaryDirectory() as tmp:
 p=pathlib.Path(tmp)/'out.json';a=publish(c,q,p);assert a['mapRevision']==3 and p.stat().st_size<1024*1024
try:make_grid(c,lambda lat,lon:float('nan'),10,'x','x');raise AssertionError('expected failure')
except ValueError:pass
print('PASS HGT decode, terrain grid georeferencing, size limit, missing data rejection')
