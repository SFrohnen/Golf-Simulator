const fs=require('fs'),vm=require('vm'),assert=require('node:assert/strict');
const path=process.cwd()+'/app/src/main/assets/';const html=fs.readFileSync(path+'index.html','utf8');const ids=[...html.matchAll(/\bid="([^"]+)"/g)].map(x=>x[1]);assert.equal(new Set(ids).size,ids.length);
let arcs=[];const ctx=new Proxy({measureText:t=>({width:String(t).length*6}),createLinearGradient:()=>({addColorStop(){}}),arc(...args){arcs.push(args)}},{get:(o,k)=>k in o?o[k]:()=>{}});const make=id=>({id,value:({temp:'20',alt:'200',surface:'medium',hand:'right',club:'7 Iron',practiceMode:'random',practiceSource:'DEMO',practiceMin:'40',practiceMax:'150',practiceStep:'5',practiceLimit:'3',practiceDistance:'100',practicePerClub:'3',practiceClub:'7 Iron'})[id]||'',valueAsNumber:({temp:20,alt:200})[id],checked:false,innerHTML:'',textContent:'',classList:{toggle(){}},querySelectorAll(){return [{dataset:{practiceClub:'7 Iron'}},{dataset:{practiceClub:'8 Iron'}}]},addEventListener(k,v){this['on'+k]=v},getBoundingClientRect(){return {width:400,height:350}},getContext(){return ctx}});const els=Object.fromEntries(ids.map(id=>[id,make(id)]));const storage={};const navButtons=['range','practice','analytics','history','connect','course'].map(tab=>({dataset:{tab},classList:{toggle(){}}}));const sandbox={console,document:{getElementById(id){assert(els[id],id);return els[id]},querySelectorAll(){return navButtons}},localStorage:{getItem:k=>storage[k]||null,setItem:(k,v)=>storage[k]=v,removeItem:k=>delete storage[k]},performance:{now:()=>1000},requestAnimationFrame(){},confirm:()=>true,devicePixelRatio:1,addEventListener(){}};sandbox.window=sandbox;vm.createContext(sandbox);for(const f of ['game-hud.js','flight.js','range3d.js','history-import.js','club-analytics.js','practice.js','coach.js','course.js','caddie.js','round-stats.js','course-packs.js','canopy.js','tee-cards.js','aerial.js','course-map.js','course-world-data.js','course-world.js','course3d.js','career.js','course-ui.js'])vm.runInContext(fs.readFileSync(path+f,'utf8'),sandbox);vm.runInContext(html.match(/<script>\s*([\s\S]*?)<\/script>/)[1],sandbox);assert.equal(els.rangeView.value,'3d'); els.rangeView.value='2d'; els.rangeView.onchange();const raw={source:'R10',ballSpeed:48,clubSpeed:34,launch:20,direction:3,spin:6500,spinAxis:10,face:2,path:4,attack:-3.5};els.enterGame.onclick();els.playRange.onclick();const spoken=[];
assert.equal(els.voiceCoach.checked,true);
sandbox.R10Native={speakCoach:line=>spoken.push(line),stopCoachVoice(){}};
els.voiceCoach.checked=true;
els.voiceCoach.onchange();
assert.equal(JSON.parse(storage['r10-private-range-analytics-v1']).voiceCoach,true);
assert.deepEqual(spoken.splice(0),['Voice coaching on.']);
for(let i=0;i<3;i++)sandbox.receiveR10Shot({...raw,shotId:i,direction:i+2});assert.equal(els.sessionCount.textContent,'3 session shots');assert(els.rangeGameHud.innerHTML.includes('Carry'));assert(els.rangeGameHud.innerHTML.includes('Target miss'));assert(els.rangeGameHud.innerHTML.includes('gameMetricNumber'));assert(els.rangeCoach.innerHTML.includes('Personal Golf Coach'));assert(!els.rangeCoach.innerHTML.includes('Why / personal baseline'));assert(els.latestCorrection.innerHTML.includes('Correct last shot club'));assert(els.sessionSummary.innerHTML.includes('3 shots'));assert(els.extraMetrics.innerHTML.includes('Smash factor'));assert(els.shapeLabel.textContent.length>0);assert(els.extraMetrics.innerHTML.includes('Club path'));assert(els.extraMetrics.innerHTML.includes('Clubface angle'));assert(els.extraMetrics.innerHTML.includes('Face-to-path'));assert(els.extraMetrics.innerHTML.includes('in-to-out'));assert(els.extraMetrics.innerHTML.includes('closed'));assert(els.shapeDetail.textContent.includes('Draw / hook tendency'));assert(els.sessionSummary.innerHTML.includes('Face-to-path'));assert(arcs.some(a=>a[2]>=5));els.latestCorrection.onchange({target:{matches:()=>true,value:'8 Iron',dataset:{shotIndex:'0'}}});assert(els.recentShots.innerHTML.includes('8 Iron'));assert(els.sessionSummary.innerHTML.includes('2 shots'));els.newSession.onclick();assert.equal(els.sessionCount.textContent,'0 session shots');assert.equal(JSON.parse(storage['r10-private-range-shots-v1']).length,3);console.log('PASS: mocked DOM Range startup, 3 shots, metrics, club correction, session reset and persistence');

assert.equal(spoken.splice(0).length,3);navButtons[1].onclick();els.practiceStart.onclick();assert(els.practiceGoal.textContent.includes('m'));for(let i=0;i<3;i++){els.practiceArm.onclick();els.practiceDemo.onclick();}assert.equal(els.practiceGoal.textContent,'Practice complete');assert(els.practiceCoach.innerHTML.includes('Personal Golf Coach'));assert(els.practiceCoach.innerHTML.includes('simulated'));let stored=JSON.parse(storage['r10-private-range-shots-v1']);assert.equal(stored.filter(x=>x.practiceMode==='random').length,3);assert(stored.filter(x=>x.practiceMode==='random').every(x=>x.source==='DEMO'&&Number.isFinite(x.practiceTarget)));els.practiceNew.onclick();els.practiceMode.value='gapping';els.practiceStart.onclick();assert.equal(els.practiceGoal.textContent,'8 Iron');els.practiceClub.value='7 Iron';els.practiceClub.onchange();assert.equal(els.practiceGoal.textContent,'7 Iron');for(let i=0;i<6;i++){els.practiceDemo.onclick();} assert.equal(els.practiceGoal.textContent,'Practice complete');assert(els.practiceCoach.innerHTML.includes('Personal Golf Coach'));assert(els.practiceCoach.innerHTML.includes('simulated'));console.log('PASS practice UI demo random and gapping');
assert.equal(spoken.splice(0).length,9);els.practiceNew.onclick();els.practiceMode.value='target';els.practiceSource.value='R10';els.practiceStart.onclick();assert.equal(els.practiceGoal.textContent,'100.0 m');sandbox.receiveR10Shot({...raw,shotId:200});stored=JSON.parse(storage['r10-private-range-shots-v1']);assert(!stored[0].practiceId);assert.equal(spoken.length,0);els.practiceArm.onclick();sandbox.receiveR10Shot({...raw,shotId:201});stored=JSON.parse(storage['r10-private-range-shots-v1']);assert.equal(stored[0].practiceMode,'target');assert.equal(stored[0].practiceTarget,100);assert.equal(els.practiceProgress.textContent,'1 / 3 attempts');navButtons[0].onclick();navButtons[1].onclick();sandbox.receiveR10Shot({...raw,shotId:202});stored=JSON.parse(storage['r10-private-range-shots-v1']);assert.equal(stored[0].practiceMode,'target');assert.equal(els.practiceProgress.textContent,'2 / 3 attempts');assert(els.practiceResults.innerHTML.includes('Within radius'));assert(els.practiceCoach.innerHTML.includes('on demand'));assert.equal(spoken.splice(0).length,2);console.log('PASS target once-confirmed live capture, resume, and accuracy rings');

assert(els.practiceCoach.innerHTML.includes('Personal Golf Coach'));els.coachMode.value='off';els.coachMode.onchange();assert.equal(els.practiceCoach.innerHTML,'');assert.equal(els.rangeCoach.innerHTML,'');els.coachMode.value='detailed';els.coachMode.onchange();assert(els.practiceCoach.innerHTML.includes('Why / personal baseline'));assert.equal(JSON.parse(storage['r10-private-range-analytics-v1']).coachMode,'detailed');console.log('PASS global coach setting and practice feedback');
// Round captures are separate from personal history; coach remains integrated.
Object.assign(els.courseHoles,{value:'3'});els.courseSide.value='back';els.courseFormat.value='scramble';els.courseHumans.value='2';els.courseBots.value='0';els.courseDifficulty.value='medium';els.courseSource.value='R10';els.coursePutting.value='auto';navButtons[5].onclick();els.courseSelect.value='demo';els.courseStart.onclick();assert(els.courseHole.textContent.includes('Hole 10'));assert(els.courseTurn.textContent.includes('Player 1'));let before=JSON.parse(storage['r10-private-range-shots-v1']).length;sandbox.receiveR10Shot({...raw,source:'DEMO',shotId:301});assert(els.courseStatus.textContent.includes('not counted'));assert.equal(spoken.length,0);sandbox.receiveR10Shot({...raw,shotId:302});assert(els.courseTurn.textContent.includes('Player 2'));assert(els.courseCoach.innerHTML.includes('Personal Golf Coach'));assert(els.courseHud.innerHTML.includes('To pin'));assert(els.courseHud.innerHTML.includes('Round'));sandbox.receiveR10Shot({...raw,shotId:303});assert(els.courseChoices.innerHTML.includes('Ball 2'));els.courseChoices.onclick({target:{dataset:{choice:'0'}}});assert(els.courseTurn.textContent.includes('Player 1'));assert.equal(JSON.parse(storage['r10-private-range-shots-v1']).length,before);let rr=JSON.parse(storage['r10-course-round-v1']);els.courseReplay.onclick();els.courseDetailsToggle.onclick();els.courseDetailsClose.onclick();assert.equal(spoken.length,2);assert.equal(els.courseVoiceCoach.checked,true);els.courseVoiceCoach.checked=false;els.courseVoiceCoach.onchange();assert.equal(els.voiceCoach.checked,false);assert.equal(JSON.parse(storage['r10-private-range-analytics-v1']).voiceCoach,false);assert.match(els.courseHole.textContent,/Hole 10/);assert.equal(rr.log.length,2);assert.equal(spoken.length,2);assert.doesNotMatch(spoken[0],/metres|Carry [0-9]|drill/i);assert.equal(rr.states[0].strokes,1);els.coachMode.value='off';els.coachMode.onchange();assert.equal(els.courseCoach.innerHTML,'');els.courseEnd.onclick();els.keepPlaying.onclick();assert(storage['r10-course-round-v1']);els.courseEnd.onclick();els.confirmEnd.onclick();assert.equal(JSON.parse(storage['r10-course-round-v1']||'null'),null);console.log('PASS course live capture, two-human scramble, coaching, scoring and independent history');

// Bundle available without network, stale imported Trier does not override the bundled elevation pack.
assert(els.courseSelect.innerHTML.includes('Golf Club Trier'));sandbox.importR10Course(fs.readFileSync('courses/source/trier-base.json','utf8'));assert.equal(els.courseSelect.value,'trier');els.courseFormat.value='stroke';els.courseHumans.value='1';els.courseStart.onclick();rr=JSON.parse(storage['r10-course-round-v1']);assert.equal(rr.course.mapRevision,4);assert.match(els.aimReading.textContent,/◎ .* m [↑↓]/);assert.equal(rr.course.terrain.step,10);sandbox.R10Native={exportCourse:(name,data)=>{assert.equal(name,'trier-course.json');assert.equal(JSON.parse(data).mapRevision,4);}};els.courseZoomReset.onclick();els.courseZoomIn.onclick();els.courseZoomOut.onclick();els.courseDetailsToggle.onclick();els.courseDetailsClose.onclick();els.courseEnd.onclick();els.confirmEnd.onclick();els.courseSelect.value='trier';els.coursePackExport.onclick();console.log('PASS bundled Trier, stale import precedence, map draw and zoom controls, JSON export');

// Complete a career event using the same controls as a demo golfer.
els.courseMode.value='career';els.courseSource.value='DEMO';els.courseDifficulty.value='easy';
els.courseSelect.value='demo';els.courseHoles.value='3';els.courseSide.value='front';
els.courseMode.onchange();els.courseStart.onclick();
assert.match(els.courseTitle.textContent,/Season Opener/);
let reviewed=0;
for(let n=0;n<90 && !JSON.parse(storage['r10-course-round-v1']).done;n++){
    if(JSON.parse(storage['r10-course-round-v1']).reviewHole){assert.match(els.scoreMomentContent.innerHTML,/stroke/);assert.match(els.scoreMomentContent.innerHTML,/Round/);assert.equal(els.courseResultHud.textContent,'');els.courseContinue.onclick();reviewed++;continue;}
    els.courseArm.onclick();els.courseDemo.onclick();
}
assert.equal(reviewed,3);assert.match(els.careerBoard.innerHTML,/First finish/);
assert.equal(JSON.parse(storage['r10-tour-v1-DEMO-easy']).length,1);
els.courseEnd.onclick();els.confirmEnd.onclick();assert.match(els.careerPreview.textContent,/Tour Invitational/);
els.courseSource.value='R10';els.courseSource.onchange();
assert.match(els.careerPreview.textContent,/Season Opener/);
console.log('PASS career demo tournament completion, standings and separate live progression');

// Exercise the user-facing JSON importer and the course through a demo shot.
sandbox.importR10Course(fs.readFileSync('courses/bundled/kikuoka.json','utf8'));
assert.equal(els.courseSelect.value,'kikuoka');
assert.ok(JSON.parse(storage['r10-course-packs-v1']).some(c=>c.id==='kikuoka'));
els.courseMode.value='casual'; els.courseMode.onchange();
els.courseSource.value='DEMO'; els.courseSide.value='front';
els.courseStart.onclick(); els.courseArm.onclick(); els.courseDemo.onclick();
const kikuokaRound=JSON.parse(storage['r10-course-round-v1']);
assert.equal(kikuokaRound.course.id,'kikuoka');
assert.match(els.aimReading.textContent,/◎ .* m/);
assert.equal(kikuokaRound.course.holes.reduce((sum,h)=>sum+h.par,0),72);
console.log('PASS Kikuoka JSON import, persistence and demo round');

assert.equal(spoken.length,2);
console.log('PASS voice feedback counts for Range, Practice, Course, unarmed shots and muted demos');
els.courseEnd.onclick();els.confirmEnd.onclick();
navButtons[0].onclick();
els.coachMode.value='brief';els.coachMode.onchange();
sandbox.receiveR10Shot({...raw,shotId:700});
els.smartStart.onclick();
// Resume the unfinished regular practice before starting a new suggestion.
if(!JSON.parse(storage['r10-private-range-practice-v1']).drill){
 els.practiceEnd.onclick();navButtons[0].onclick();els.smartStart.onclick();
}
const smart=JSON.parse(storage['r10-private-range-practice-v1']);
assert.equal(smart.config.limit,5);assert.equal(smart.config.source,'R10');
assert(els.smartInstructions.textContent.length>10);els.practiceArm.onclick();
for(let i=0;i<5;i++)sandbox.receiveR10Shot({...raw,shotId:701+i});
assert.equal(els.practiceGoal.textContent,'Practice complete');
assert.match(els.smartInstructions.textContent,/baseline|this drill/);
console.log('PASS smart drill starts, preserves current practice, scores five shots and displays results');

// A clip only becomes replayable after the native recorder finalizes the file.
navButtons[0].onclick();
const accepted=[],discarded=[],replays=[];
sandbox.R10Native={openSwingCamera(){},acceptSwingShot:key=>accepted.push(key),
 discardSwing:key=>discarded.push(key),replaySwing:(key,metrics)=>replays.push({key,metrics})};
const videoShot=(id,key)=>sandbox.receiveR10Shot({...raw,shotId:id,swingTake:key});
const savedShots=()=>JSON.parse(storage['r10-private-range-shots-v1']);
videoShot(801,'first');videoShot(802,'first');
assert.deepEqual(accepted,['first']);
assert(!savedShots().some(s=>s.swingVideo));
sandbox.finishSwingVideo('first',true);
assert.equal(savedShots().find(s=>s.swingVideo==='first').shotId,801);
els.rangeFilmReplay.onclick();
assert.equal(replays[0].key,'first');assert.match(replays[0].metrics,/#801/);
videoShot(803,'cancelled');sandbox.finishSwingVideo('cancelled',false);
assert(!savedShots().some(s=>s.swingVideo==='cancelled'));
navButtons[1].onclick();els.practiceNew.onclick();
els.practiceMode.value='target';els.practiceSource.value='R10';els.practiceStart.onclick();
videoShot(804,'second');assert(!accepted.includes('second'));
els.practiceArm.onclick();videoShot(805,'second');sandbox.finishSwingVideo('second',true);
els.practiceFilmReplay.onclick();
assert.equal(replays[1].key,'second');assert.match(replays[1].metrics,/#805/);
sandbox.finishSwingVideo('missing-shot',true);assert.deepEqual(discarded,['missing-shot']);
console.log('PASS swing video pairs once, skips unconfirmed practice, discards failed clips and replays exact shot readings');

els.playProgress.onclick();
els.progressClub.value='7 Iron';els.progressClub.onchange();
assert.match(els.progressReport.innerHTML,/Typical carry/);
els.progressSource.value='DEMO';els.progressSource.onchange();
els.progressClub.value='Driver';els.progressClub.onchange();
assert.match(els.progressReport.innerHTML,/No qualifying demo/);
console.log('PASS clubhouse progress and source/club selectors');

els.playCaddie.onclick();els.outStart.onclick();
assert.match(els.caddieCall.textContent,/m to target/);assert.equal(els.caddieAccept.disabled,true); // tee preview, no ball marked yet
const pack=sandbox.R10BundledCourses.packs.find(c=>c.id==='weiherhof');
const origin=pack.origin,pin=pack.holes[0].pin;
function fakeFix(x,y){
 sandbox.R10Native.caddieLocation=token=>sandbox.caddieFix(token,origin.lat+y/111195.08,origin.lon+x/(111195.08*Math.cos(origin.lat*Math.PI/180)),4,'');
 els.caddieGps.onclick();
}
navButtons[0].onclick();els.club.value='7 Iron';
for(let i=0;i<7;i++)sandbox.receiveR10Shot({...raw,shotId:900+i});
const carry=savedShots()[0].downrange;
els.playCaddie.onclick();fakeFix(pin[0],pin[1]-carry);
assert.equal(els.caddieAccept.disabled,false);els.caddieAccept.onclick();
assert(JSON.parse(storage['r10-outdoor-caddie-v1']).pending);
const beforeCount=savedShots().length;
fakeFix(pin[0],pin[1]);
assert.equal(savedShots().length,beforeCount);assert.equal(JSON.parse(storage['r10-outdoor-caddie-v1']).log.length,1);
assert.match(els.caddieLast.textContent,/total/);
console.log('PASS outdoor GPS, confirmed club and aim, measured finish and separate outdoor history');

for(const id of ['kikuoka','trier']){
 const c=sandbox.R10BundledCourses.packs.find(p=>p.id===id);
 els.outSetup.onclick();els.caddiePack.value=id;els.caddiePack.onchange();els.outStart.onclick();
 assert.match(els.caddieHole.innerHTML,/Hole 18/);
 els.caddieHole.value='18';els.caddieHole.onchange();
 const p=c.holes[17].pin;
 function fix(x,y){
   sandbox.R10Native.caddieLocation=t=>sandbox.caddieFix(t,c.origin.lat+y/111195.08,c.origin.lon+x/(111195.08*Math.cos(c.origin.lat*Math.PI/180)),4,'');
   els.caddieGps.onclick();
 }
 fix(p[0],p[1]-carry);assert.equal(els.caddieAccept.disabled,false);
 els.caddieAccept.onclick();fix(p[0],p[1]);
 const last=JSON.parse(storage['r10-outdoor-caddie-v1']).log.at(-1);
 assert.equal(last.course,id);assert.equal(last.holeRef,'Hole 18');
 assert.match(els.caddieCall.textContent,/No supported/);
}
console.log('PASS Kikuoka and Trier outdoor fix, approach, course switch and finished shot');

navButtons[0].onclick();
els.club.value='Pitching Wedge';els.club.onchange();
els.rangeLength.value='half';sandbox.receiveR10Shot({...raw,shotId:1044});
assert.equal(savedShots()[0].swingLength,'half');
els.openBag.onclick();assert.match(els.bagDistances.innerHTML,/Wedge matrix/);
assert.match(els.bagDistances.innerHTML,/Pitching Wedge/);
assert.match(els.courseClub.innerHTML,/7 Iron · [0-9]+ m/);
assert(!els.practiceModes.innerHTML.includes('Club Gapping'));

els.playCaddie.onclick();
els.outSetup.onclick();
els.caddiePack.value='trier';els.caddiePack.onchange();
els.outTee.value='Blue';els.outCount.value='9';els.outCount.onchange();
els.outSide.value='back';els.outStart.onclick();
assert.equal(els.caddieHole.value,'10');assert.equal(els.outPrev.disabled,true);
assert.match(els.caddieHole.innerHTML,/1\/9 · Hole 10/);
assert.match(els.outTeeDist.textContent,/Blue · \d+ m/);
els.outNext.onclick();assert.equal(els.caddieHole.value,'11');
els.caddieHole.value='18';els.caddieHole.onchange();assert.equal(els.outNext.disabled,true);
els.outSetup.onclick();els.outCount.value='18';els.outStart.onclick();
assert.equal(els.caddieHole.value,'1');assert.equal(els.outTeeDist.textContent,'Blue · 322 m');
console.log('PASS outdoor back nine, tee-specific distance, hole jump and full round reset');
