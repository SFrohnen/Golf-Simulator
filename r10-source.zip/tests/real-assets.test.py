import unittest, importlib.util, io, zipfile, json, hashlib, struct, base64
from pathlib import Path
from unittest.mock import patch
spec=importlib.util.spec_from_file_location('real_assets',Path('tools/fetch-real-assets.py')); m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class TestImporter(unittest.TestCase):
 def test_material_maps(self):
  b=io.BytesIO()
  with zipfile.ZipFile(b,'w') as z:
   for name in ['Color','NormalGL','Roughness']: z.writestr('Grass005_1K-JPG_'+name+'.jpg',b'\xff\xd8'+name.encode())
  with patch.object(m,'fetch',return_value=b.getvalue()):
   maps,rec=m.ambient('Grass005');self.assertEqual(set(maps),{'color','normal','roughness'});self.assertEqual(rec['sha256'],hashlib.sha256(b.getvalue()).hexdigest());self.assertTrue(all(x.startswith('data:image/jpeg;base64,') for x in maps.values()))
 def test_model_embeds_dependencies(self):
  gltf=json.dumps({'asset':{'version':'2.0'},'buffers':[{'uri':'mesh.bin','byteLength':3}],'images':[{'uri':'textures/leaf.png'}]}).encode()
  data={'https://test/model':gltf,'https://test/bin':b'abc','https://test/tex':b'xyz'}
  def rec(url):return {'url':url,'md5':hashlib.md5(data[url]).hexdigest()}
  info=rec('https://test/model');info['include']={'mesh.bin':rec('https://test/bin'),'textures/leaf.png':rec('https://test/tex')}
  with patch.object(m,'files',return_value={'gltf':{'1k':{'gltf':info}}}),patch.object(m,'fetch',side_effect=lambda url:data[url]):
   model,source=m.model('test');self.assertTrue(model['buffers'][0]['uri'].startswith('data:application/octet-stream;base64,'));self.assertTrue(model['images'][0]['uri'].startswith('data:image/png;base64,'));self.assertEqual(len(source['files']),3)
 def test_missing_or_wrong_hash_fails(self):
  with patch.object(m,'fetch',return_value=b'bad'):
   with self.assertRaises(ValueError):m.checked({'url':'https://test/file','md5':'0'*32})
def sample_glb(count=3):
 data=b'\x00'*36
 doc={'asset':{'version':'2.0'},'buffers':[{'byteLength':len(data)}],'bufferViews':[{'buffer':0,'byteOffset':0,'byteLength':len(data)}],'accessors':[{'bufferView':0,'componentType':5126,'count':count,'type':'VEC3'}],'meshes':[{'primitives':[{'attributes':{'POSITION':0}}]}],'nodes':[{'mesh':0}],'scenes':[{'nodes':[0]}],'scene':0}
 raw=json.dumps(doc).encode();raw+=b' '*(-len(raw)%4)
 return struct.pack('<4sII',b'glTF',2,12+8+len(raw)+8+len(data))+struct.pack('<I4s',len(raw),b'JSON')+raw+struct.pack('<I4s',len(data),b'BIN\x00')+data
class TestMobileImporter(unittest.TestCase):
 def test_glb_embeds_buffers_and_counts_triangles(self):
  model,tris=m.glb_to_model(sample_glb(),'pine');self.assertEqual(tris,1);self.assertEqual(base64.b64decode(model['buffers'][0]['uri'].split(',')[1]),b'\x00'*36)
 def test_rejects_oversized_geometry_and_invalid_glb(self):
  with self.assertRaisesRegex(ValueError,'mobile budget'):m.glb_to_model(sample_glb(75000),'pine')
  with self.assertRaises(ValueError):m.glb_to_model(b'not a model','grass')
 def test_mobile_primary_source_commit_pinned(self):
  paths=['environment/vegetation/Pine_Common.glb','environment/vegetation/Tree_Common.glb','environment/vegetation/Grass_Short.glb']
  def fetch(url):
   if '/commits/' in url:return json.dumps({'sha':'c'*40,'commit':{'tree':{'sha':'a'*40}}}).encode()
   if '/git/trees/' in url:return json.dumps({'tree':[{'type':'blob','path':p,'size':500} for p in paths]}).encode()
   self.assertIn('/'+'c'*40+'/',url);return sample_glb()
  with patch.object(m,'fetch',side_effect=fetch):models,sources=m.mobile_models()
  self.assertEqual(set(models),{'pine','broadleaf','grass'});self.assertTrue(all('Quaternius' in x['provider'] for x in sources.values()))
 def test_alternate_source_when_primary_unreachable(self):
  data=io.BytesIO()
  with zipfile.ZipFile(data,'w') as z:
   for name in ['tree_pineDefaultA','tree_default','grass']:z.writestr('Models/GLB format/'+name+'.glb',sample_glb())
  def fetch(url):
   if url==m.KENNEY_URL:return data.getvalue()
   raise OSError('simulated primary failure')
  with patch.object(m,'fetch',side_effect=fetch):models,sources=m.mobile_models()
  self.assertEqual(set(models),{'pine','broadleaf','grass'});self.assertTrue(all('Kenney' in x['provider'] for x in sources.values()))
if __name__=='__main__':unittest.main()
