import unittest, importlib.util, io, zipfile, json, hashlib
from pathlib import Path
from unittest.mock import patch
spec=importlib.util.spec_from_file_location('real_assets',Path('tools/fetch-real-assets.py')); m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class TestImporter(unittest.TestCase):
 def test_material_maps(self):
  b=io.BytesIO()
  with zipfile.ZipFile(b,'w') as z:
   for name in ['Color','NormalGL','Roughness']: z.writestr('Grass005_1K-JPG_'+name+'.jpg',b'\xff\xd8'+name.encode())
  with patch.object(m,'fetch',return_value=b.getvalue()):
   maps,rec=m.ambient('Grass005');self.assertEqual(set(maps),{'color','normal','roughness'});self.assertEqual(rec['sha256'],hashlib.sha256(b.getvalue()).hexdigest());self.assertTrue(all(x.startswith('data:image/jpeg;base64,') for x in maps.values()))
 def test_model_embeds_dependencies(self):
  gltf=json.dumps({'asset':{'version':'2.0'},'buffers':[{'uri':'mesh.bin','byteLength':3}],'images':[{'uri':'textures/leaf.png'}]}).encode()
  data={'https://test/model':gltf,'https://test/bin':b'abc','https://test/tex':b'xyz'}
  def rec(url):return {'url':url,'md5':hashlib.md5(data[url]).hexdigest()}
  info=rec('https://test/model');info['include']={'mesh.bin':rec('https://test/bin'),'textures/leaf.png':rec('https://test/tex')}
  with patch.object(m,'files',return_value={'gltf':{'1k':{'gltf':info}}}),patch.object(m,'fetch',side_effect=lambda url:data[url]):
   model,source=m.model('test');self.assertTrue(model['buffers'][0]['uri'].startswith('data:application/octet-stream;base64,'));self.assertTrue(model['images'][0]['uri'].startswith('data:image/png;base64,'));self.assertEqual(len(source['files']),3)
 def test_missing_or_wrong_hash_fails(self):
  with patch.object(m,'fetch',return_value=b'bad'):
   with self.assertRaises(ValueError):m.checked({'url':'https://test/file','md5':'0'*32})
if __name__=='__main__':unittest.main()
