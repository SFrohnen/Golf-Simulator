const assert=require('node:assert/strict');
const C=require('../app/src/main/assets/caddie'),E=require('../app/src/main/assets/course');
const rectangle=(type,x,y,w,h)=>({type,ring:[[x,y],[x+w,y],[x+w,y+h],[x,y+h]]});
const hole={pin:[0,140],tee:[0,0],surfaces:[rectangle('green',-12,131,24,20),rectangle('water',-100,100,200,22)]};
const shot={club:'7 Iron',source:'R10',clubConfirmed:true,carry:140,downrange:140,offline:6,model:'v'};
const shots=Array.from({length:6},()=>({...shot}));
const groups=C.clubSamples([...shots,{...shot,source:'DEMO'},{...shot,practiceId:'p'}],'v');
assert.equal(groups.get('7 Iron').length,6);
const r=C.recommend(hole,[0,0],groups);
assert.equal(r.club,'7 Iron');assert(r.target[0]<0);assert.equal(r.on,6);assert.equal(r.clearance.cleared,6);
assert.equal(C.recommend(hole,[0,0],C.clubSamples(shots.slice(0,4),'v')),null);
assert.equal(C.recommend(hole,[0,-350],groups),null);
assert.deepEqual(C.project({lat:49,lon:6},49,6),[0,0]);
assert.deepEqual(C.recommend(hole,[0,0],groups,false,'',[4,140]).target,[4,140]);
require('../app/src/main/assets/course-packs.js');
for(const course of globalThis.R10BundledCourses.packs){
 for(const h of course.holes){
   const ball=[h.pin[0],h.pin[1]-140],result=C.recommend({...h,terrain:course.terrain},ball,groups,true);
   assert(result,h.loopRef);assert(Number.isFinite(result.delta));assert.equal(result.pattern.length,6);
 }
}
console.log('PASS approach selection, miss direction, hazard clearance, insufficient data, manual aim, and all five shipped course packs');

const wedge={...shot,club:'Pitching Wedge',swingLength:'half',carry:60,downrange:60};
const partial=C.clubSamples([...Array(5).fill(wedge),{...wedge,mishit:true},{...wedge,swingLength:'full'}],'v');
assert.equal(partial.get('Pitching Wedge · Half').length,5);
assert.equal(C.recommend(hole,[0,80],partial).club,'Pitching Wedge · Half');
