import importlib.util, pathlib, unittest
p=pathlib.Path(__file__).resolve().parents[1]/'tools/import_osm_course.py'
spec=importlib.util.spec_from_file_location('importer',p); m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
def geo(lon,lat): return {'lat':lat,'lon':lon}
def way(i,tags,coords): return {'type':'way','id':i,'tags':tags,'geometry':[geo(*q) for q in coords]}
def data():
    result=[]
    for i in range(18):
        lon=6+i*.001; a=(lon,49.0);b=(lon,49.002)
        result.extend([way(i+1,{'golf':'hole','ref':str(i+1),'par':'4'},[a,b]),way(100+i,{'golf':'green'},[(lon-.00015,49.0019),(lon+.00015,49.0019),(lon+.00015,49.0021),(lon-.00015,49.0021),(lon-.00015,49.0019)])])
    return {'elements':result}
class Test(unittest.TestCase):
    def test_projection(self):
        d=m.build(data(),m.PROFILES['kikuoka']);self.assertEqual(len(d['holes']),18);self.assertEqual(d['holes'][0]['tee'],[0,0]);self.assertAlmostEqual(d['holes'][0]['pin'][1],222.39,places=1);self.assertEqual(d['kind'],'osm');self.assertIn('OpenStreetMap',d['attribution']);self.assertEqual(len([x for x in d['holes'][0]['surfaces'] if x['type']=='green']),1)
    def test_fail_closed(self):
        d=data();d['elements'].pop(1)
        with self.assertRaisesRegex(ValueError,'endpoint'):m.build(d,m.PROFILES['kikuoka'])
        with self.assertRaisesRegex(ValueError,'Missing'):m.build({'elements':[]},m.PROFILES['trier'])
        with self.assertRaisesRegex(ValueError,'exactly 18'):m.build(data(),m.PROFILES['trier'],pars=[4])
if __name__=='__main__': unittest.main()
