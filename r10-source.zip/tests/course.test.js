const assert=require('node:assert/strict'),E=require('../app/src/main/assets/course.js');const c=E.demo();assert.equal(c.holes.length,18);assert.equal(c.kind,'fictional');for(const n of [3,6,9,12,15,18]){assert.equal(E.holeNumbers(n,'front').length,n);assert.equal(E.holeNumbers(n,'back')[0],n<=9?10:1);}assert.deepEqual(E.holeNumbers(3,'back'),[10,11,12]);assert.deepEqual(E.landing([0,0],[0,10],20,5),[5,20]);assert.deepEqual(E.landing([0,0],[10,0],20,5),[20,-5]);assert.throws(()=>E.validate({...c,holes:c.holes.slice(1)}));assert.throws(()=>E.validate({...c,holes:[...c.holes.slice(0,17),c.holes[0]]}));
const opts={holes:3,side:'back',humans:2,bots:1,difficulty:'medium',format:'stroke',source:'DEMO',putting:'manual'};let r=E.create(c,opts);assert.equal(E.hole(r).number,10);assert.equal(r.teams.length,3);const hitPin=()=>{const a=E.active(r);return E.shoot(r,a.hole.pin,{downrange:E.dist(a.state.pos,a.hole.pin),offline:0});};hitPin();assert.equal(r.turn,1);hitPin();assert.equal(r.turn,2);hitPin();assert.equal(r.index,1);assert.deepEqual(r.scorecards[0].scores,[1,1,1]);
r=E.create(c,{...opts,format:'scramble',bots:0});assert.equal(r.teams[0].members.length,2);const a=E.active(r);const start=a.state.pos.slice();E.shoot(r,a.hole.pin,{downrange:30,offline:10});assert.deepEqual(a.state.pos,start);assert.equal(a.state.strokes,0);assert.equal(E.active(r).player.id,'p1');hitPin();assert.equal(E.best(r),1);E.choose(r,1);assert.equal(r.scorecards[0].scores[0],1);assert.equal(r.index,1);
r=E.create(c,{...opts,format:'scramble',humans:1,bots:2});assert.equal(r.teams[0].members[1].bot,true);assert.equal(r.teams[2].members.length,2);
r=E.create(c,{...opts,humans:1,bots:0,side:'front'});let h=E.hole(r);E.shoot(r,h.pin,{downrange:E.dist(h.tee,h.pin)-5,offline:0});assert(E.active(r).state.awaitPutt);E.finishPutt(r,2);assert.equal(r.scorecards[0].scores[0],3);
// A mapped hazard causes one penalty and replay; scramble can choose a safe partner ball.
r=E.create(c,{...opts,humans:1,bots:0,side:'front'});h=E.hole(r);h.surfaces.unshift({type:'water',ring:[[-5,10],[5,10],[5,30],[-5,30]]});E.shoot(r,[0,100],{downrange:20,offline:0});assert.deepEqual(E.active(r).state.pos,h.tee);assert.equal(E.active(r).state.strokes,2);
// Simulate full bot rounds using deterministic pseudo-random values. Verify progress, scores and completion.
let seed=9;const rng=()=>((seed=(seed*1664525+1013904223)>>>0)/4294967296);for(const difficulty of Object.keys(E.difficulties)){r=E.create(E.demo(),{...opts,holes:18,format:'scramble',humans:1,bots:2,putting:'auto',difficulty});let count=0;while(!r.done&&count++<3000){const x=E.active(r);if(x.state.candidates.length===x.team.members.length){E.choose(r,E.best(r));continue;}if(x.player.bot)E.botShot(r,rng);else hitPin();}assert(r.done);assert.equal(r.scorecards.length,18);assert(r.scorecards.every(x=>x.scores.length===3));}console.log('PASS course round lengths, direction, stroke play, scramble, putting, water and all bot levels');
// An unmapped green is not a geographic polygon; only an explicit 10 m gameplay target.
{
 const E=require('../app/src/main/assets/course.js');const c=E.demo();c.kind='osm';c.id='fixture-osm';c.holes[0].surfaces=c.holes[0].surfaces.filter(s=>s.type!=='green');c.holes[0].approximatePuttingTarget=10;const h=E.validate(c).holes[0];assert.equal(E.lie(h,[h.pin[0],h.pin[1]+4]),'approximate target');assert.notEqual(E.lie(h,[h.pin[0],h.pin[1]+11]),'approximate target');const r=E.create(c,{holes:3,side:'front',humans:1,bots:0,format:'stroke',difficulty:'easy',source:'DEMO',putting:'manual'});const d=E.dist(h.tee,h.pin);E.shoot(r,h.pin,{downrange:d-4,offline:0});assert.equal(E.active(r).state.awaitPutt,true);E.finishPutt(r,2);assert.equal(r.scorecards[0].scores[0],3);
}
console.log('PASS explicit unmapped green gameplay target and putting');

// Exercise the scoring entry point, including unfinished rounds from the handicap release.
for(const [distance,expected] of [[0,0],[1.999,1],[2,1],[2.001,2],[8.4,2],[15,2],[15.001,3]]){
    const course=E.demo(),h=course.holes[0];
    h.tee=[0,0];h.pin=[0,100];h.route=[h.tee,h.pin];
    h.surfaces=[{type:'green',ring:[[-25,75],[25,75],[25,125],[-25,125]]}];
    const round=E.create(course,{...opts,side:'front',humans:1,bots:0,putting:'auto',reviewHoles:true});
    round.config.puttProfile='30+';
    const restored=JSON.parse(JSON.stringify(round));
    const entry=E.shoot(restored,h.pin,{downrange:100-distance,offline:0});
    assert.equal(entry.putts,expected);assert.equal(restored.states[0].last.putts,expected);
    assert.deepEqual(restored.scorecards[0].scores,[1+expected]);
    E.continueHole(restored);E.continueHole(restored);
    assert.equal(restored.index,1);assert.equal(restored.scorecards.length,1);
}
console.log('PASS distance-based auto-putts, exact cutoffs, hole-out and resume');
