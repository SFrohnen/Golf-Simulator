const assert=require('node:assert/strict'),R=require('../app/src/main/assets/range3d.js'),S=require('../app/src/main/assets/three-scene.js');
const g=R.geometry();g.quad([0,0,0],[1,0,0],[1,0,1],[0,0,1],[.3,.5,.2],-1);g.tri([0,0,0],[1,0,0],[0,0,1],[.86,.75,.49],-2);g.tri([0,0,0],[1,0,0],[0,0,1],[.17,.47,.64],1);R.foliageCard(g,10,20,12,8,42,3);const b=S.convert(g);assert.equal(b.grass.position.length,18);assert.equal(b.sand.position.length,9);assert.equal(b.water.position.length,9);assert.equal(b.leaves.position.length,36);assert.equal(Math.min(...b.leaves.position.filter((_,i)=>i%3===1)),3);assert.equal(Math.max(...b.leaves.position.filter((_,i)=>i%3===1)),15);assert.equal(b.trees.length,1);assert.equal(b.trees[0].height,12);assert.equal(b.trees[0].base,3);assert(b.leaves.uv.every(v=>v>=0&&v<=1));assert(b.grass.position.includes(-1));assert(Math.abs(S.srgb(.5)-.214041)<.00001);assert.deepEqual(S.xyz(1,2,3),[-1,2,3]);const t=S.textureData('grass'),s=S.textureData('sand');assert.equal(t.length,128*128*4);assert.notDeepEqual(t,s);assert.deepEqual(t,S.textureData('grass'));assert(t.every((v,i)=>i%4!==3||v===255));
// Check full range geometry and mapped Trier hole meshes for finite geometry and UVs.
const range=S.convert(R.ground({depth:250,half:45},'medium',true));assert(range.fairway.position.length>100&&range.rough.position.length>100);assert(range.leaves.position.length>100);for(const b of Object.values(range))assert(b.position.every(Number.isFinite)&&b.color.every(Number.isFinite)&&b.uv.every(Number.isFinite));
const C=require('../app/src/main/assets/course3d.js'),E=require('../app/src/main/assets/course.js'),fs=require('fs');const trier=E.validate(JSON.parse(fs.readFileSync('courses/bundled/trier.json','utf8')));for(const hole of trier.holes){const groups=S.convert(C.sceneGround(hole,'low',true));assert(groups.rough.position.length>0&&groups.fairway.position.length>0);for(const b of Object.values(groups))assert(b.position.every(Number.isFinite)&&b.color.every(Number.isFinite)&&b.uv.every(Number.isFinite));}
console.log('PASS Three.js adapter: coordinate reflection, material separation, crossed foliage UVs and deterministic texture data');

for(const t of range.trees){assert(t.height>0&&t.width>0&&Number.isFinite(t.seed));}
require('../app/src/main/assets/visual-assets.js');const assets=globalThis.R10VisualAssets;assert.equal(Object.keys(assets).length,8);for(const v of Object.values(assets)){assert(v.startsWith('data:image/webp;base64,'));const raw=Buffer.from(v.split(',')[1],'base64');assert(raw.length>1000&&raw.subarray(8,12).toString()==='WEBP');}assert.equal(new Set(Object.values(assets)).size,8);
console.log('PASS v0.18 surface separation, eight offline assets and volumetric tree placements');
const Real=require('../app/src/main/assets/real-scene.js');assert.equal(Real.treeLimit(50000,'high'),13);assert.equal(Real.treeLimit(50000,'low'),2);const near=[{x:5,z:1,species:1},{x:20,z:1,species:1},{x:2,z:1,species:0},{x:300,z:0,species:1}];assert.deepEqual(Real.selectTrees(near,{x:0,z:0},'pine',1,'high'),[near[0]]);assert.deepEqual(Real.selectTrees(near,{x:0,z:0},'broadleaf',3,'low'),[near[2]]);console.log('PASS real asset model selection and triangle-budget limits');
assert.equal(S.resolvePreset(undefined),'hybrid');assert.equal(S.resolvePreset('classic'),'classic');assert.equal(S.resolvePreset('experimental'),'experimental');assert.equal(Real.detailFactor(0,100),.86);assert.equal(Real.detailFactor(100,100),1);assert.equal(Real.detailFactor(255,100),1.14);assert(!require('fs').readFileSync('app/src/main/assets/three-scene.js','utf8').includes('b.color[i]=b.color[i+1]'));console.log('PASS v0.19.2 bounded photographic detail and preserved terrain RGB');
const mk=()=>({map:{id:'baseline'},bumpMap:null,bumpScale:0,normalMap:null,roughnessMap:null,roughness:1,metalness:0,userData:{},normalScale:{set(){}}});const mats=Object.fromEntries(['fairway','green','tee','rough','grass','sand','water'].map(k=>[k,mk()]));const owner={T:{},materials:mats,scene:{},sky:{visible:true},sun:{intensity:2.85}};const r=new Real.RealScene(owner,{},{});r.materials={fairway:{},rough:{},sand:{}};r.detail=()=>({id:'photoDetail'});r.hdr={};r.apply('hybrid');assert.equal(mats.tee.map.id,'baseline');assert.equal(mats.fairway.map.id,'photoDetail');assert.equal(mats.rough.roughness,1);assert.equal(owner.scene.environment,null);assert(owner.sky.visible);r.apply('experimental');assert.equal(owner.scene.environment,r.hdr);assert.equal(owner.scene.background,null);r.apply('classic');assert.equal(mats.fairway.map.id,'baseline');assert.equal(mats.rough.userData.photo,undefined);assert.equal(owner.scene.environment,null);assert.equal(owner.sun.intensity,2.85);assert(owner.sky.visible);require('../app/src/main/assets/course-packs.js');assert(globalThis.R10BundledCourses.packs.find(p=>p.id==='trier').terrain.step===10);console.log('PASS Classic/Hybrid/Experimental isolation, material restoration, tee protection, bundled DEM');
// Natural range is separate from the old generator, deterministic, finite and bounded.
for(const q of ['low','medium','high']){
 const e={depth:250,half:45},g=R.naturalGround(e,q,true),c=S.convert(g);
 assert(g.naturalRange);assert(!R.ground(e,q,true).naturalRange);assert.deepEqual(g.tris,R.naturalGround(e,q,true).tris);assert(g.tris.length/21<44000);
 assert(c.trees.length>100);assert(c.trees.some(t=>t.base>.5));assert(c.sand.position.length/9>=400);assert(c.tee.position.length>0);assert(c.green.position.length>0);assert(c.leaves.position.length>0);
 for(const b of Object.values(c))assert(b.position.every(Number.isFinite)&&b.color.every(Number.isFinite)&&b.uv.every(Number.isFinite));
 // Visual terrain now has gentle relief, but the tee remains flat and target distances stay fixed.
 for(let i=0;i<c.fairway.position.length;i+=3){const [x,y,z]=c.fairway.position.slice(i,i+3);assert(Math.abs(y-R.rangeHeight(-x,z))<1e-8);}
 assert.equal(R.rangeHeight(0,0),0);
 assert(c.trees.every(t=>t.height>0&&t.width>0));
}
assert.equal(Real.detailFactor(100,100,true),1);assert.equal(Real.detailFactor(0,100,true),.72);assert.equal(Real.detailFactor(255,100,true),1.28);
owner.owner={lastData:{}};r.apply('hybrid');assert.equal(mats.fairway.bumpScale,.010);assert.equal(mats.rough.bumpScale,.018);assert.equal(mats.tee.map.id,'baseline');r.apply('classic');assert.equal(mats.fairway.bumpScale,0);owner.owner.lastData={scene:{}};r.apply('hybrid');assert.equal(mats.fairway.bumpScale,0);assert.equal(owner.scene.environment,null);
const oldRange=require('./fixtures/v018/range3d.js');assert.deepEqual(R.ground({depth:175,half:45},'high',true).tris,oldRange.ground({depth:175,half:45},'high',true).tris);
console.log('PASS v0.20 natural range layout, geometry budgets, elevated visual fairway, bounded detail, isolated presets and Classic baseline');

// v0.21: menu/geometry target alignment, fixed distances and independent hazards.
assert.deepEqual(R.rangeTargets,[42,65,97,128,150,183,212,248,271,303,337]);
assert(new Set(R.rangeTargets.slice(1).map((z,i)=>z-R.rangeTargets[i])).size>=5);
const menu=fs.readFileSync('app/src/main/assets/index.html','utf8').match(/<div id="rangeTargetOptions">(.*?)<\/div>/s)[1];
assert.deepEqual([...menu.matchAll(/data-metres="(\d+)"/g)].map(m=>+m[1]),R.rangeTargets);
for(const q of ['low','medium','high']){const g=R.naturalGround({depth:175,half:45},q,true),c=S.convert(g);assert.equal(g.facility.carts,2);assert.equal(g.facility.clubhouse,1);assert.equal(g.facility.ponds.length,2);assert.equal(g.facility.bunkers.length,8);assert(c.water.position.length/9>=128);assert(g.facility.targets.every(t=>Math.abs(t.x)<t.r));assert(c.trees.every(t=>R.rangePonds.every(([x,z,rx,rz])=>((-t.x-x)/(rx+4))**2+((t.z-z)/(rz+4))**2>=1)));assert(c.solid.position.length/9>1000);assert(g.tris.length/21<44000);for(const target of R.rangeTargets){let flag=false;for(let i=0;i<g.lines.length;i+=14){if(g.lines[i]===0&&g.lines[i+2]===target&&g.lines[i+7]===0&&g.lines[i+9]===target&&Math.abs(g.lines[i+8]-(2.8+R.rangeHeight(0,target)))<1e-8)flag=true;}assert(flag,'missing centreline flag at '+target);}}
const classicBefore=require('./fixtures/v018/range3d.js');assert.deepEqual(R.ground({depth:250,half:45},'high',true).tris,classicBefore.ground({depth:250,half:45},'high',true).tris);
console.log('PASS v0.21 fixed irregular targets, matching selector, ponds, props, tree exclusion and preserved Classic geometry');
// v0.22: exact water plane, mirrored view maths, isolated UV/material buckets, prop texture determinism and fitted aerial camera.
assert.deepEqual(S.mirrorPoint([3,5,7],.05),[3,-4.9,7]);assert.deepEqual(S.mirrorPoint([3,.048,7]),[3,.048,7]);
for(const q of ['low','medium','high']){const g=R.naturalGround({depth:175,half:45},q,true),c=S.convert(g);for(const k of ['stone','roof','timber','window','windscreen','path','metal'])assert(c[k].position.length>0&&c[k].uv.every(Number.isFinite),k);for(let i=1;i<c.water.position.length;i+=3)assert.equal(c.water.position[i],.048);assert(g.tris.length/21<44000);}
for(const k of ['stone','roof','timber','path']){const a=S.propTextureData(k);assert.equal(a.length,128*128*4);assert.deepEqual(a,S.propTextureData(k));assert(a.every((v,i)=>i%4!==3||v===255));}assert.notDeepEqual(S.propTextureData('stone'),S.propTextureData('roof'));
for(const aspect of [16/9,9/16,4/3]){const cam=R.facilityCamera({depth:175,half:45},aspect);for(const x of [-92,92])for(const z of [-12,355]){const p=R.project([x,0,z],cam,aspect);assert(Math.abs(p.x)<.95&&Math.abs(p.y)<.95&&p.z>0);}if(aspect>=1.3)assert(cam.eye[1]<300);}
console.log('PASS v0.22 planar pond reflection geometry, mirrored camera math, prop material UVs, texture determinism, aerial framing and geometry budget');

// v0.23: matched, non-overlapping annular meshes and adaptive depth precision.
{
 const outer=[12,9,.1],inner=[9,6,.15],g=R.geometry(),n=40;
 R.surfaceRing(g,4,20,outer,inner,[.3,.5,.2],23,-5,n);
 assert.equal(g.tris.length/21,2*n);
 // Each vertex of the inner rim must coincide exactly with a vertex of the filling disc.
 const disc=R.geometry();R.surfaceRing(disc,4,20,inner,null,[.4,.6,.2],23,-4,n);
 const points=geo=>Array.from({length:geo.tris.length/7},(_,i)=>geo.tris.slice(i*7,i*7+3).join('/'));
 const rim=new Set(points(g));for(const point of points(disc)){if(point!=='4/0.15/20')assert(rim.has(point));}
 assert(!rim.has('4/0.15/20'));assert.equal(disc.tris.length/21,n);
 assert.equal(S.rangeNearPlane(1.85),1);assert.equal(S.rangeNearPlane(250),42);assert(S.rangeNearPlane(120)>20);
 // At 300 m depth, the theoretical 16-bit depth step must be smaller than the water/ground gap.
 const near=S.rangeNearPlane(250),far=1800,z=300;assert(z*z*(far-near)/(near*far*65535)<.048);
}
console.log('PASS v0.23 matched surface rings, adaptive depth precision and shared water plane');

// v0.24: metric visual relief, level pond water, terrain-aware picking, ball geometry metadata.
{
 const relief=R.rangeTargets.map(z=>R.rangeHeight(0,z));assert(Math.min(...relief)<-4&&Math.max(...relief)>5&&Math.max(...relief)<6);assert.equal(R.rangeHeight(0,0),0);assert.equal(R.rangeHeight(-33,34),0);assert(R.rangeElevationLabel(150).includes('+5.4 m'));
 const camera=R.camera([0,30,125],[0,R.rangeHeight(0,150),150]),pick=R.rangeGroundPick(camera,0,0,1.6);assert(Math.abs(pick[1]-150)<.001);
 assert.equal(R.BALL_RADIUS,.021335);assert.equal(S.BALL_RADIUS,R.BALL_RADIUS);
 const tex=S.dimpleTextureData();assert.equal(tex.length,512*256*4);assert(new Set(tex).size>100);assert(tex.every((v,i)=>i%4!==3||v===255));assert.equal(tex,S.dimpleTextureData());
 const e={depth:175,half:45},dyn=R.dynamic(e,[],150,[],{},[],null,false,null,false,null,true),displayed=S.ballOverlay(dyn);assert.equal(dyn.golfBalls.length,1);assert.equal(dyn.golfBalls[0].position[1],.04+R.BALL_RADIUS);assert.equal(displayed.dots.length,0);assert.equal(displayed.tris.length,dyn.legacyBallShadow);
 const g=R.naturalGround(e,'medium',true,true);assert(g.externalCart);assert(g.tris.length<R.naturalGround(e,'medium',true,false).tris.length);assert.equal(g.facility.carts,2);
 const h={...trier.holes[0],terrain:trier.terrain},scene=C.make({hole:h,key:'test',position:h.tee,aim:h.route[1],states:[{pos:h.tee,candidates:[]}]});const ball=scene.dynamic([],null,false);assert.equal(ball.golfBalls.length,1);assert(Math.abs(ball.golfBalls[0].position[1]-ball.golfBalls[0].ground-R.BALL_RADIUS)<1e-9);
}
// Test sampled patch clearance against the actual tessellated ground, not just the height formula.
for(const quality of ['low','medium','high']){
 const g=R.naturalGround({depth:175,half:45},quality,true),arr=g.tris,cell=8,index=new Map(),key=(x,z)=>Math.floor(x/cell)+'/'+Math.floor(z/cell);
 for(let i=42;i<g.terrainTriangles*21;i+=21){const xs=[arr[i],arr[i+7],arr[i+14]],zs=[arr[i+2],arr[i+9],arr[i+16]];for(let x=Math.floor(Math.min(...xs)/cell);x<=Math.floor(Math.max(...xs)/cell);x++)for(let z=Math.floor(Math.min(...zs)/cell);z<=Math.floor(Math.max(...zs)/cell);z++){const k=x+'/'+z;if(!index.has(k))index.set(k,[]);index.get(k).push(i);}}
 const height=(x,z)=>{let h=-Infinity;for(const i of index.get(key(x,z))||[]){const ax=arr[i],az=arr[i+2],bx=arr[i+7]-ax,bz=arr[i+9]-az,cx=arr[i+14]-ax,cz=arr[i+16]-az,dx=x-ax,dz=z-az,det=bx*cz-bz*cx;if(Math.abs(det)<1e-9)continue;const u=(dx*cz-dz*cx)/det,v=(bx*dz-bz*dx)/det;if(u>=-1e-7&&v>=-1e-7&&u+v<=1.0000001)h=Math.max(h,arr[i+1]*(1-u-v)+arr[i+8]*u+arr[i+15]*v);}return h;};
 let checked=0;for(let i=g.terrainTriangles*21;i<arr.length;i+=21){const kind=arr[i+6];if(![-4,-2,2,-5].includes(kind))continue;for(const weights of [[1/3,1/3,1/3],[.6,.2,.2],[.2,.6,.2],[.2,.2,.6]]){const p=[0,1,2].map(k=>weights.reduce((n,w,j)=>n+w*arr[i+j*7+k],0)),base=height(p[0],p[2]);if(!Number.isFinite(base))continue;assert(base-p[1]<.001,`${quality}: terrain intersects patch ${kind} at ${p}`);checked++;}}
 assert(checked>1000);
}
console.log('PASS v0.24 metric landscape, level ponds, ground picking, ball scale/dimples, course ball and sampled patch clearance');

// v0.25: stronger relief, detailed linear normals and continuous contact alpha.
{
 const relief=R.rangeTargets.map(z=>R.rangeHeight(0,z));assert(Math.max(...relief)-Math.min(...relief)>10);
 const normals=S.dimpleNormalData();assert.equal(normals.length,1024*512*4);assert.equal(normals,S.dimpleNormalData());let tilted=0;for(let i=0;i<normals.length;i+=4){assert(normals[i+3]===255&&normals[i+2]>=128);if(Math.abs(normals[i]-128)>35||Math.abs(normals[i+1]-128)>35)tilted++;}assert(tilted>30000);
 const color=S.ballColorData();assert.equal(color.length,512*256*4);assert(color.some(v=>v<245));const shadow=S.ballContactData();assert.equal(shadow[3],0);assert(shadow[(32*64+32)*4+3]>245);assert(shadow[(32*64+50)*4+3]<shadow[(32*64+40)*4+3]);assert.equal(S.teeFiberData().length,256*256*4);
 const g=R.naturalGround({depth:175,half:45},'high',true);assert.equal(g.tris[1],-15);assert(g.tris.length/21<44000);
}
console.log('PASS v0.25 stronger relief, dimple normals/color, shadow falloff, tee fibers and geometry budget');
// v0.26 continuous curve and unchanged ball/height contract.
const path=R.smoothPath([[-33,27],[-28,19],[-21,15],[-12,10],[-7,4]]);
assert.deepEqual(path[0],[-33,27]);assert.deepEqual(path.at(-1),[-7,4]);assert(path.length>30);assert(path.every(p=>p.every(Number.isFinite)));for(let i=1;i<path.length;i++)assert(Math.hypot(path[i][0]-path[i-1][0],path[i][1]-path[i-1][1])<1.2);
console.log('PASS v0.26 continuous curved cart paths and preserved terrain/ball constraints');

// v0.27: each target has its own radial contour, a shared green/lie profile and terrain-clipped mesh.
{
 const profiles=new Set();
 for(const t of R.rangeGreens){const patch=R.greenPatch(t.x,t.z,t.r),coords=[];for(let i=0;i<patch.tris.length;i+=21){const x=patch.tris[i],z=patch.tris[i+2];coords.push(Math.hypot((x-t.x)/(t.r+1.2),(z-t.z)/(t.r*.79+1.2)).toFixed(4));}profiles.add(coords.slice(0,64).join('/'));assert(R.rangeSurfaceOffset(0,t.z)>.025,'flag must remain inside green/collar');assert(Math.abs(R.rangeSurfaceOffset(t.x,t.z)-.14)<1e-9);}
 assert.equal(profiles.size,11);assert.equal(R.rangeSurfaceOffset(0,0),.04);assert.equal(R.rangeSurfaceOffset(0,10),0);
 for(const q of ['low','medium','high']){const g=R.naturalGround({depth:175,half:45},q,true);assert.equal(g.facility.bays,3);assert(g.facility.shrubs>=15&&g.facility.shrubs<=42);assert(g.facility.roughClumps>20);assert(g.tris.length/21<44000);assert(g.tris.every(Number.isFinite));}
}
console.log('PASS v0.27 individual green contours, shared visual lie profile, three bays, bounded natural vegetation and unchanged target positions');

// v0.28 shot budget: do not downgrade static geometry or change shot timing.
for(const q of ['low','medium','high']){
 const idle=S.rangeFramePolicy(q,false),active=S.rangeFramePolicy(q,true);
 assert.equal(active.reflection,false);assert.equal(active.idleWater,false);assert.equal(active.shadowRecentre,false);
 assert.equal(active.ratioCap,q==='low'?1:1.5);assert.equal(idle.ratioCap,q==='high'?2:q==='medium'?1.5:1);
 assert.equal(idle.reflection,q!=='low');assert.equal(idle.idleWater,q==='high');assert.equal(idle.shadowRecentre,true);
}
console.log('PASS v0.28 Low/Medium/High motion rendering policy');
