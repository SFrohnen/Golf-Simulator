const assert = require('node:assert/strict');
const engine = require('../app/src/main/assets/course.js');
require('../app/src/main/assets/course-packs.js');
for (const [id, pair, par] of [['weiherhof','AB',71], ['weiherhof-ac','AC',71], ['weiherhof-bc','BC',72]]) {
    const course = engine.validate(globalThis.R10BundledCourses.packs.find(p => p.id === id));
    assert.deepEqual(course, require('../courses/bundled/' + id + '.json'));
    assert.equal(course.holes.reduce((n,h) => n + h.par, 0), par);
    for (const [i,h] of course.holes.entries()) {
        assert.equal(h.loopRef, pair[Math.floor(i / 9)] + (1 + i % 9));
        for (const p of h.route) assert.ok(Number.isFinite(engine.height({...h, terrain:course.terrain}, p)));
        assert.ok(h.approximatePuttingTarget === 10 || h.surfaces.some(s => s.type === 'green'));
    }
}
