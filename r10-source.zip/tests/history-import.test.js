const assert=require('node:assert/strict');const H=require('../app/src/main/assets/history-import');const F=require('../app/src/main/assets/flight');
const header='time,shotId,club,source,ballSpeed,launch,direction,spin,spinAxis,spinSource,clubSpeed,face,path,attack,carry,carryBasis,offline';
const first='2026-11-24T07:00:00Z,10,7 Iron,R10,42,20,2,6500,3,MEASURED,32,1,-2,0,174,SIMULATED,6';
const second='2026-11-24T07:01:00Z,11,"7 Iron",R10,42,20,2,6500,,MEASURED,,,,,139,SIMULATED,4';
const text='\uFEFF'+header+'\r\n'+first+'\r\n'+second+'\r\n';
const r=H.merge(text,[],F.simulate,{temperatureC:15,altitudeM:0});assert.equal(r.added,2);assert.equal(r.recalculated,1);assert.equal(r.legacy,1);assert.equal(r.shots[0].carry,139);assert.equal(r.shots[1].previousCarry,174);assert.equal(r.shots[1].model,F.VERSION);assert.equal(r.shots[1].faceToPath,3);assert.equal(H.merge(text,r.shots,F.simulate,{}).duplicates,2);assert.throws(()=>H.parse('not,a,backup'));assert.throws(()=>H.parse(header+'\n'+first+',extra'));assert.throws(()=>H.parse(header+'\n'+first.replace(',174,',',bad,')));console.log('History import tests passed');
