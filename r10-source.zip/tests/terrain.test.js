const assert=require('node:assert/strict'),E=require('../app/src/main/assets/course.js'),F=require('../app/src/main/assets/flight.js'),C=require('../app/src/main/assets/course3d.js'),R=require('../app/src/main/assets/range3d.js');
// Synthetic fixture only: a +/- 10% gradient, not geographic Trier data.
function grid(slope){let t={version:1,x0:-500,y0:-500,step:20,nx:76,ny:76,source:'Synthetic fixture',attribution:'Test only',values:[]};for(let j=0;j<t.ny;j++)for(let i=0;i<t.nx;i++)t.values.push(300+slope*(t.y0+j*t.step));return t;}
const c=E.demo(),h=c.holes[0],from=[0,0],aim=[0,300],input={ballSpeed:48,launch:20,direction:0,spin:6500,spinAxis:0};
const flat=F.simulate(input),up={...h,terrain:grid(.1)},down={...h,terrain:grid(-.1)};assert.equal(E.height(up,[5,55]),305.5);assert.equal(E.height(down,[5,55]),294.5);
const u=F.simulate(input,{groundAt:E.groundAt(up,from,aim)}),d=F.simulate(input,{groundAt:E.groundAt(down,from,aim)});assert(u.carry<flat.carry&&flat.carry<d.carry);for(const [t,f] of [[up,u],[down,d]]){let p=f.points.at(-1);assert(Math.abs(p.z-E.groundAt(t,from,aim)(p.x,p.y))<1e-7);}
assert.deepEqual(F.simulate(input,{groundAt:null}),flat);
const obstacle={...up,surfaces:[{type:'tree',ring:[[-3,47],[3,47],[3,53],[-3,53]]}]};let shot=E.traceFlight(obstacle,from,aim,[{x:0,y:0,z:0},{x:40,y:0,z:14},{x:60,y:0,z:14},{x:100,y:0,z:10}]);assert.equal(shot.impact.type,'tree');assert(shot.impact.height>3&&shot.impact.height<12);
const g=C.sceneGround(up,'medium');assert(g.tris.every(Number.isFinite));assert(g.tris.some((v,i)=>i%7===1&&v>10));const scene=C.make({hole:up,key:'up',position:from,aim,states:[{pos:from,candidates:[]}]});const cam=scene.camera('aerial',null,1.6,false),pick=C.groundPick(cam,0,0,1.6,up);assert(pick&&pick.every(Number.isFinite));let pts=C.shotPoints(up,{hole:up.number,from,aim},u.points);assert(Math.abs(pts.at(-1).z-u.points.at(-1).z)<1e-6);c.terrain=grid(.1);E.validate(c);const r=E.create(c,{holes:3,side:'front',humans:1,bots:0,format:'stroke',difficulty:'medium',source:'DEMO',putting:'auto'});assert(E.hole(r).terrain);assert.throws(()=>E.validate({...c,terrain:{...c.terrain,values:[1]}}));console.log('PASS terrain interpolation, uphill/downhill, flat regression, tree clearance, raised mesh, aiming and validation',flat.carry.toFixed(1),u.carry.toFixed(1),d.carry.toFixed(1));
assert.equal(E.aimLabel(up,[0,0],[0,100]),'100.0 m · +10.0 m ↑');
assert.equal(E.aimLabel(down,[0,0],[0,100]),'100.0 m · −10.0 m ↓');
assert.equal(E.aimLabel(up,[0,100],[100,100]),'100.0 m · 0.0 m level');
assert.equal(E.aimLabel(h,[0,0],[0,100]),'100.0 m · elevation unavailable');
assert.equal(E.elevationDelta(up,[0,0],[5000,0]),null);
assert.equal(E.elevationDelta(up,[0,20],[0,100]),8);
assert(scene.labels(false).some(x=>x[1].includes('+30.0 m ↑')));
console.log('PASS dynamic aim delta, uphill/downhill/level, unavailable and 3D labels');
