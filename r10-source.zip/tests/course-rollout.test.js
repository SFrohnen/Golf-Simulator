const assert=require('node:assert/strict');
const E=require('../app/src/main/assets/course.js'), C=require('../app/src/main/assets/course3d.js');
const F=require('../app/src/main/assets/flight.js');
const opts={holes:3,side:'front',humans:1,bots:0,difficulty:'easy',format:'stroke',source:'DEMO',putting:'manual'};
const shot={downrange:40,offline:0,carry:40,spin:3000,landingSpeed:32,landingAngle:26};
const points=[{x:0,y:0,z:0,t:0},{x:37,y:0,z:1.5,t:2},{x:40,y:0,z:0,t:2.1}];
const strip=(type,start,end)=>({type,ring:[[-50,start],[50,start],[50,end],[-50,end]]});
function play(slope,surfaces,pin){
    const c=E.demo(),h=c.holes[0];h.surfaces=surfaces;
    if(pin){h.pin=pin;h.route[h.route.length-1]=pin;}
    c.terrain={version:1,x0:-100,y0:-100,step:10,nx:21,ny:61,values:[],source:'fixture',attribution:'fixture'};
    for(let y=0;y<61;y++)for(let x=0;x<21;x++)c.terrain.values.push(150+slope*(10*y-100));
    const r=E.create(c,opts),e=E.shoot(r,[0,100],shot,points);
    return {r,e};
}
const fair=[strip('fairway',0,500)],flat=play(0,fair).e,up=play(.1,fair).e,down=play(-.1,fair).e;
assert(up.rollout<flat.rollout && down.rollout>flat.rollout);
assert(play(0,[strip('rough',0,500)]).e.rollout<flat.rollout);
for(const kind of ['water','bunker','ob']){
    const {e,r}=play(0,[strip(kind,43,45),...fair]);
    assert.equal(e.surface,kind);assert(e.pos[1]>=43&&e.pos[1]<=45);
    assert.equal(e.penalty,kind==='bunker'?0:1);
    assert.deepEqual(r.states[0].pos,e.penalty?e.from:e.pos);
}
const green=play(0,[strip('green',38,43),strip('rough',43,200)],[0,70]);
assert.equal(green.e.surface,'rough');assert(!green.r.states[0].awaitPutt);
assert.deepEqual(flat.carryPos,[0,40]);assert(flat.groundPath.some(p=>p.z>0));assert.equal(flat.groundPath.at(-1).z,0);
require('../app/src/main/assets/course-packs.js');
const trier=globalThis.R10BundledCourses.packs.find(p=>p.id==='trier'),round=E.create(trier,opts);
const h=E.hole(round),aim=E.defaultAim(round),flight=F.simulate({ballSpeed:36,launch:22,spin:5100,spinAxis:0,direction:0},{groundAt:E.groundAt(h,h.tee,aim)});
const e=E.shoot(round,aim,{...shot,...flight},flight.points);
assert(e.rollout>0);const replay=C.shotPoints(h,e,flight.points),end=replay.at(-1);
assert(end.t>flight.flightTime);assert(Math.abs(end.x-(e.pos[1]-h.tee[1]))<1e-8);
assert(Math.abs(end.y-(e.pos[0]-h.tee[0]))<1e-8);assert(Math.abs(end.z-(E.height(h,e.pos)-E.height(h,h.tee)))<1e-8);
assert(replay.every((p,i)=>!i||p.t>replay[i-1].t));
console.log('PASS course lie, hazard penalties, slopes, bounce and Trier replay endpoint',e.shot.carry.toFixed(1),e.rollout.toFixed(1),e.surface);
