const assert=require('node:assert/strict');
const A=require('../app/src/main/assets/club-analytics'), F=require('../app/src/main/assets/flight'), H=require('../app/src/main/assets/history-import');
assert.deepEqual(A.CLUBS.map(c=>c.name),['60° Wedge','56° Wedge','52° Wedge','Pitching Wedge','9 Iron','8 Iron','7 Iron','6 Iron','5 Iron','5 Wood','7 Wood','Driver']);
assert.equal(new Set(A.CLUBS.map(c=>c.color)).size,12);
const raw={ballSpeed:48,launch:20,direction:0,spin:6500,spinAxis:0};const flight=F.simulate(raw);const shot={...raw,...flight,source:'R10',club:'7 Iron',clubConfirmed:true,spinSource:'ESTIMATED'};
const a={...shot,offline:-10,downrange:140,carry:Math.hypot(140,10)},b={...shot,offline:10,downrange:150,carry:Math.hypot(150,10),spin:undefined,apex:undefined};
const demo={...a,source:'DEMO'},unknown={...a,clubConfirmed:false},old={...a,model:'legacy'};
const s=A.summarize([a,b,demo,unknown,old],F.VERSION).find(c=>c.name==='7 Iron');assert.equal(s.count,2);assert.equal(s.offline.value,10);assert.equal(s.spin.n,1);assert.equal(s.apex.n,1);assert.equal(s.rollout.n,1);assert.equal(A.summarize([a,demo],F.VERSION,'medium',true).find(c=>c.name==='7 Iron').count,2);
const g=A.groups([a,b],F.VERSION,'medium',false).find(c=>c.name==='7 Iron');assert.deepEqual(g.center,{x:0,y:145});assert.equal(g.radius,Math.hypot(10,5));
const soft=A.rollout(shot,'soft'),medium=A.rollout(shot),firm=A.rollout(shot,'firm');assert(soft.rollout<medium.rollout&&medium.rollout<firm.rollout);assert.equal(medium.total,shot.carry+medium.rollout);assert(Math.abs(Math.hypot(medium.finalDownrange-shot.downrange,medium.finalOffline-shot.offline)-medium.rollout)<1e-8);assert.equal(A.rollout({...shot,landingAngle:null}),null);assert.equal(A.rollout(shot,'invalid'),null);
const csv='time,shotId,club,source,ballSpeed,launch,carry,clubConfirmed,originalClub\n2026-11-24T10:00:00Z,42,Driver,R10,48,20,174,false,Driver';const initial=H.merge(csv,[],null,{}).shots;const corrected=[{...initial[0],club:'7 Iron',clubConfirmed:true}];assert.equal(H.merge(csv,corrected,null,{}).duplicates,1);assert.equal(H.parse(csv)[0].clubConfirmed,false);assert.equal(H.parse(csv.replace('false','true'))[0].clubConfirmed,true);
console.log('Club analytics tests passed');

{
 const analytics=require('../app/src/main/assets/club-analytics.js');
 const shot={club:'7 Iron',source:'R10',clubConfirmed:true,model:'v',sessionId:'s1',time:'2026-01-01T12:00:00Z',carry:130,offline:4};
 const group=Array.from({length:5},(_,i)=>({...shot,carry:130+i}));
 const data=[...group,{...shot,sessionId:'s2',carry:180,offline:0,time:'2026-01-02T12:00:00Z'},
   {...shot,sessionId:'',offline:null},{...shot,source:'DEMO',carry:300},{...shot,practiceId:'p1'},
   {...shot,model:'old'},{...shot,mishit:true},{...shot,clubConfirmed:false}];
 const report=analytics.clubProgress(data,shot.club,'R10','range','v');
 assert.equal(report.total.count,7);assert.equal(report.total.median,132);assert.equal(report.total.offline.n,6);
 assert.deepEqual(report.total.sides,{L:0,R:5,C:1});assert.equal(report.longest.carry,180);
 assert.equal(report.best.count,5);assert.equal(report.sessions[0].count,1);assert.equal(report.ungrouped,1);
 assert.equal(analytics.clubProgress(data,shot.club,'DEMO','range','v').total.count,1);
 assert.equal(analytics.clubProgress(data,shot.club,'R10','practice','v').total.count,1);
 assert.equal(analytics.clubProgress([],shot.club,'R10','range','v').best,null);
}

{
 const pw={club:'Pitching Wedge',carry:95,model:'v',source:'R10',clubConfirmed:true};
 for(const club of ['Pitching Wedge','52° Wedge','56° Wedge','60° Wedge']){
   const shot={...pw,club};
   const data=[shot,{...shot,swingLength:'half',carry:40},{...shot,swingLength:'half',carry:50},
    {...shot,swingLength:'half',mishit:true},{...shot,swingLength:'threeQuarter',carry:72},
    {...shot,source:'DEMO'},{...shot,practiceId:'a'},{...shot,captureMode:'practice'}];
   const profiles=A.bagProfiles(data,'v').filter(p=>p.club===club);
   assert.deepEqual(profiles.map(p=>[p.length,p.n,p.avg]),[['full',1,95],['threeQuarter',1,72],['half',2,45]]);
   assert.equal(profiles[2].sd,5);
 }
}
