package com.privategolf.r10range;

import android.Manifest;
import android.app.AlertDialog;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.view.ViewGroup;
import android.widget.*;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.video.*;
import androidx.camera.view.PreviewView;
import com.google.common.util.concurrent.ListenableFuture;
import java.io.File;
import java.util.UUID;

/** All camera state and callbacks are serialized on the activity's main thread. */
final class SwingVideo {
    static final int PERMISSION = 45;
    private final MainActivity host;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final File directory;
    private Take active;
    private boolean awaitingPermission;
    private static final int MATCH_PARENT = ViewGroup.LayoutParams.MATCH_PARENT;

    private static final class Take {
        String key = UUID.randomUUID().toString();
        AlertDialog dialog;
        TextView status;
        Button start;
        PreviewView preview;
        ProcessCameraProvider provider;
        VideoCapture<Recorder> capture;
        Recording recording;
        File file;
        boolean running, paired, cancelled;
    }

    SwingVideo(MainActivity host) {
        this.host = host;
        directory = new File(host.getFilesDir(), "swing-video");
    }

    void open() {
        if (active != null || awaitingPermission || host.isFinishing() || host.isDestroyed()) return;
        if (host.checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            awaitingPermission = true;
            host.requestPermissions(new String[]{Manifest.permission.CAMERA}, PERMISSION);
            return;
        }
        Take t = new Take();
        active = t;
        LinearLayout content = new LinearLayout(host);
        content.setOrientation(LinearLayout.VERTICAL);
        t.preview = new PreviewView(host);
        t.preview.setImplementationMode(PreviewView.ImplementationMode.COMPATIBLE);
        content.addView(t.preview, MATCH_PARENT, Math.max(120,host.getResources().getDisplayMetrics().heightPixels/2));
        t.status = new TextView(host);
        t.status.setText("Frame your full swing face-on, then tap Record.");
        content.addView(t.status);
        t.dialog = new AlertDialog.Builder(host).setTitle("Swing camera").setView(content)
            .setPositiveButton("Record", null).setNegativeButton("Cancel", (d,w)->cancel(t)).create();
        t.dialog.setOnCancelListener(d->cancel(t));
        t.dialog.show();
        t.start = t.dialog.getButton(AlertDialog.BUTTON_POSITIVE);
        t.start.setEnabled(false);
        t.start.setOnClickListener(v->start(t));
        ListenableFuture<ProcessCameraProvider> future = ProcessCameraProvider.getInstance(host);
        future.addListener(()->{
            if (active != t) return;
            try {
                t.provider = future.get();
                CameraSelector lens = t.provider.hasCamera(CameraSelector.DEFAULT_FRONT_CAMERA)
                    ? CameraSelector.DEFAULT_FRONT_CAMERA : CameraSelector.DEFAULT_BACK_CAMERA;
                Preview preview = new Preview.Builder().build();
                preview.setSurfaceProvider(t.preview.getSurfaceProvider());
                Recorder recorder = new Recorder.Builder().setQualitySelector(QualitySelector.from(Quality.HD,
                    FallbackStrategy.lowerQualityOrHigherThan(Quality.HD))).build();
                t.capture = VideoCapture.withOutput(recorder);
                t.provider.bindToLifecycle(host,lens,preview,t.capture);
                t.start.setEnabled(true);
            } catch (Exception e) { fail(t,"Camera unavailable. Check camera access and try again."); }
        },host::runOnUiThread);
    }

    void permissionResult(boolean allowed) {
        if (!awaitingPermission) return;
        awaitingPermission = false;
        if (allowed) open(); else notice("Allow camera access to record your swing.");
    }

    private void start(Take t) {
        if (active != t || t.recording != null) return;
        t.start.setEnabled(false);
        try {
            if (!directory.isDirectory() && !directory.mkdirs()) throw new IllegalStateException();
            t.file = new File(directory,t.key+".mp4");
            FileOutputOptions out = new FileOutputOptions.Builder(t.file).setDurationLimitMillis(60000).build();
            t.recording = t.capture.getOutput().prepareRecording(host,out)
                .start(host::runOnUiThread,event->{
                    if (event instanceof VideoRecordEvent.Start && active == t && !t.cancelled) {
                        t.running = true;
                        t.status.setText("Recording · hit one ball. Your R10 shot will finish the clip.");
                    } else if (event instanceof VideoRecordEvent.Finalize) {
                        VideoRecordEvent.Finalize end = (VideoRecordEvent.Finalize)event;
                        boolean usable = !t.cancelled && t.paired && (!end.hasError() ||
                            end.getError()==VideoRecordEvent.Finalize.ERROR_DURATION_LIMIT_REACHED) && t.file.length()>0;
                        close(t);
                        if (!usable) {
                            t.file.delete();
                            if (!t.cancelled) notice(t.paired?"Recording failed.":"No accepted R10 shot during recording.");
                        }
                        host.videoFinished(t.key,usable);
                    }
                });
        } catch (RuntimeException e) { fail(t,"Recording could not start."); }
    }

    String recordingKey() {
        return active!=null && active.running && !active.paired && !active.cancelled ? active.key : null;
    }
    void accept(String key) {
        Take t=active;
        if (t==null || !key.equals(recordingKey())) return;
        t.paired=true;
        t.status.setText("Shot received · saving swing…");
        handler.postDelayed(()->{if(active==t && !t.cancelled && t.recording!=null)t.recording.stop();},900);
    }
    void pause() { if(active!=null)cancel(active); }
    private void cancel(Take t) {
        if(active!=t)return;
        t.cancelled=true;
        if(t.recording!=null)t.recording.stop(); else close(t);
    }
    private void close(Take t) {
        if(active!=t)return;
        active=null;
        if(t.provider!=null)t.provider.unbindAll();
        if(t.dialog.isShowing())t.dialog.dismiss();
    }
    private void fail(Take t,String message) {
        close(t);
        if(t.file!=null)t.file.delete();
        notice(message);
    }
    private File file(String key) {
        try {
            if(key!=null && UUID.fromString(key).toString().equals(key))return new File(directory,key+".mp4");
        } catch(IllegalArgumentException ignored) {}
        return null;
    }
    void discard(String key) { File f=file(key);if(f!=null)f.delete(); }
    void play(String key,String readings) {
        File f=file(key);
        if(f==null || !f.isFile()) { notice("This recording is unavailable."); return; }
        LinearLayout layout=new LinearLayout(host);
        layout.setOrientation(LinearLayout.VERTICAL);
        TextView metrics=new TextView(host);metrics.setText(readings);layout.addView(metrics);
        VideoView video=new VideoView(host);
        layout.addView(video,MATCH_PARENT,host.getResources().getDisplayMetrics().heightPixels/2);
        AlertDialog dialog=new AlertDialog.Builder(host).setTitle("Swing replay").setView(layout)
            .setPositiveButton("Close",null).create();
        dialog.setOnDismissListener(d->video.stopPlayback());
        dialog.show();
        MediaController controls=new MediaController(host);
        video.setMediaController(controls);
        controls.setAnchorView(video);
        video.setOnErrorListener((p,w,e)->{notice("Unable to play this clip.");return true;});
        video.setVideoURI(Uri.fromFile(f));
        video.start();
    }
    private void notice(String message) { Toast.makeText(host,message,Toast.LENGTH_LONG).show(); }
}
