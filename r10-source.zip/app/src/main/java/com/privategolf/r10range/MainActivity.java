package com.privategolf.r10range;

import android.Manifest;
import androidx.activity.ComponentActivity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.BluetoothStatusCodes;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;
import android.speech.tts.TextToSpeech;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebChromeClient;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONObject;
import java.io.OutputStream;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.UUID;

/** Native offline Android shell. BLE operations are serialized on the UI thread. */
public final class MainActivity extends ComponentActivity {
    private SwingVideo swingVideo;
    private static final int BT_PERMS_REQUEST = 41;
    private static final int SAVE_CSV_REQUEST = 42;
    private static final int IMPORT_CSV_REQUEST = 43;
    private static final int IMPORT_COURSE_REQUEST = 44;
    private static final UUID MULTILINK = UUID.fromString("6a4e2800-667b-11e3-949a-0800200c9a66");
    private static final UUID CHAR_NOTIFY_AND_REGISTER = UUID.fromString("6a4e2810-667b-11e3-949a-0800200c9a66");
    private static final UUID CHAR_WRITE = UUID.fromString("6a4e2820-667b-11e3-949a-0800200c9a66");
    private static final UUID CCCD = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ArrayDeque<BleWrite> writes = new ArrayDeque<>();
    private WebView web;
    private BluetoothAdapter adapter;
    private BluetoothLeScanner scanner;
    private BluetoothGatt gatt;
    private BluetoothGattCharacteristic notifyAndRegister;
    private BluetoothGattCharacteristic writeCharacteristic;
    private BluetoothDevice awaitingBond;
    private R10Protocol protocol;
    private boolean scanning, writeBusy, closed;
    private Runnable stopScanTask, writeTimeout, reconnectTask, connectTimeout;
    private BluetoothDevice lastDevice;
    private int reconnectAttempts;
    private android.media.ToneGenerator cueTone;
    private final java.util.LinkedHashMap<String,Long> recentShots = new java.util.LinkedHashMap<>();
    private String pendingCsv;
    private String pendingExportLabel = "CSV";
    private boolean bondReceiverRegistered;

    private static final class BleWrite {
        final BluetoothGattCharacteristic target;
        final byte[] data;
        BleWrite(BluetoothGattCharacteristic target, byte[] data) { this.target=target;this.data=data; }
    }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        swingVideo = new SwingVideo(this);
        getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(0xff081625);
        getWindow().setNavigationBarColor(0xff081625);
        BluetoothManager manager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        adapter = manager == null ? null : manager.getAdapter();
        web = new WebView(this);
        web.setBackgroundColor(0xff081625);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) { return true; }
        });
        // Our JS interface is only exposed to the local APK asset, never remote pages.
        web.addJavascriptInterface(new Bridge(), "R10Native");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
        IntentFilter bondFilter = new IntentFilter(BluetoothDevice.ACTION_BOND_STATE_CHANGED);
        registerReceiver(bondReceiver, bondFilter);
        bondReceiverRegistered = true;
    }

    private void emit(String type, String message) {
        mainHandler.post(() -> {
            if (web != null) web.evaluateJavascript("window.nativeEvent(" + JSONObject.quote(type) + "," + JSONObject.quote(message) + ")", null);
        });
    }
    private void liveShot(R10Protocol.Shot shot) {
        try {
            JSONObject data = new JSONObject();
            data.put("source", "R10");
            data.put("shotId", shot.shotId);
            data.put("practice", shot.practice);
            data.put("ballSpeed", shot.speedMps); // m/s
            data.put("launch", shot.verticalDeg); // degrees
            data.put("direction", shot.horizontalDeg); // degrees
            data.put("spin", shot.spinRpm); // rpm
            data.put("spinAxis", shot.spinAxisDeg);
            data.put("spinSource", new String[]{"ESTIMATED", "FLIGHT_MODEL", "UNCLASSIFIED", "MEASURED"}[Math.max(0, Math.min(3, shot.spinSource))]);
            if (shot.hasClub) {
                data.put("clubSpeed", shot.clubSpeedMps);
                data.put("face", shot.faceDeg);
                data.put("path", shot.pathDeg);
                data.put("attack", shot.attackDeg);
            }
            // The R10 does not report carry/total; HTML estimates those separately.
            mainHandler.post(() -> {
                String key = shot.shotId + ":" + shot.speedMps + ":" + shot.verticalDeg + ":" + shot.horizontalDeg + ":" + shot.spinRpm;
                long now = android.os.SystemClock.elapsedRealtime();
                recentShots.entrySet().removeIf(e -> now - e.getValue() > 120000);
                if (shot.shotId > 0 && recentShots.containsKey(key)) { emit("log", "Duplicate shot suppressed after reconnect: " + shot.shotId); return; }
                if (shot.shotId > 0) recentShots.put(key, now);
                String keyForVideo = swingVideo.recordingKey();
                if (keyForVideo != null) {
                    try { data.put("swingTake", keyForVideo); } catch (org.json.JSONException ignored) {}
                }
                if (web != null) web.evaluateJavascript("window.receiveR10Shot(" + data.toString() + ")", null);
            });
        } catch (Exception ignored) { emit("log", "Shot JSON conversion failed"); }
    }

    private boolean roundFullscreen;

    private void applyRoundFullscreen() {
        android.view.View decor = getWindow().getDecorView();
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            android.view.WindowInsetsController bars = getWindow().getInsetsController();
            if (bars == null) return;
            if (roundFullscreen) {
                bars.setSystemBarsBehavior(android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                bars.hide(android.view.WindowInsets.Type.systemBars());
            } else {
                bars.show(android.view.WindowInsets.Type.systemBars());
            }
        } else {
            decor.setSystemUiVisibility(roundFullscreen
                ? android.view.View.SYSTEM_UI_FLAG_FULLSCREEN | android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                : android.view.View.SYSTEM_UI_FLAG_VISIBLE);
        }
    }

    @Override public void onWindowFocusChanged(boolean focused) {
        super.onWindowFocusChanged(focused);
        if (focused && roundFullscreen) applyRoundFullscreen();
    }

    @Override public void onBackPressed() {
        if (roundFullscreen) {
            web.evaluateJavascript("window.roundBack && window.roundBack()", null);
        } else {
            super.onBackPressed();
        }
    }

    private TextToSpeech coachSpeech;
    private boolean speechReady, foreground;
    private String pendingSpeech;
    private void sayCoach(String line) {
        if (!foreground || isFinishing() || isDestroyed() || line == null || line.isEmpty()) return;
        pendingSpeech = line;
        if (speechReady) {
            playPendingSpeech();
        } else if (coachSpeech == null) {
            coachSpeech = new TextToSpeech(this, status -> mainHandler.post(() -> {
                if (coachSpeech == null || isDestroyed()) return;
                speechReady = status == TextToSpeech.SUCCESS
                    && coachSpeech.setLanguage(java.util.Locale.US) >= TextToSpeech.LANG_AVAILABLE;
                if (speechReady) playPendingSpeech();
                else {
                    if (foreground && pendingSpeech != null)
                        Toast.makeText(this, "Voice coaching needs an English text-to-speech voice.", Toast.LENGTH_LONG).show();
                    pendingSpeech = null;
                    coachSpeech.shutdown();
                    coachSpeech = null;
                }
            }));
        }
    }
    private void playPendingSpeech() {
        if (!foreground || pendingSpeech == null) return;
        if (coachSpeech.speak(pendingSpeech, TextToSpeech.QUEUE_FLUSH, null, "golf-coach") == TextToSpeech.ERROR)
            Toast.makeText(this, "Voice coaching could not play audio.", Toast.LENGTH_SHORT).show();
        pendingSpeech = null;
    }
    private void silenceCoach() {
        pendingSpeech = null;
        if (speechReady) coachSpeech.stop();
    }
    @Override protected void onResume() {
        super.onResume();
        foreground = true;
    }
    @Override protected void onPause() {
        foreground = false;
        swingVideo.pause();
        silenceCoach();
        if(caddieListener!=null)finishFix(locationToken,null,"Location interrupted. Retry when ready.");
        super.onPause();
    }
    void videoFinished(String key, boolean saved) {
        if (web != null) web.evaluateJavascript("window.finishSwingVideo("+JSONObject.quote(key)+","+saved+")",null);
    }
        private static final int CADDIE_LOCATION = 46;
    private int locationToken;
    private android.location.LocationListener caddieListener;
    private Runnable locationTimeout;
    private void stopCaddieFix() {
        if (locationTimeout!=null) mainHandler.removeCallbacks(locationTimeout);
        if (caddieListener!=null) {
            android.location.LocationManager lm=(android.location.LocationManager)getSystemService(LOCATION_SERVICE);
            if(lm!=null)lm.removeUpdates(caddieListener);
            caddieListener=null;
        }
    }
    private void finishFix(int token,android.location.Location loc,String error) {
        if(token!=locationToken)return;
        stopCaddieFix();
        String args=loc==null?"0,0,0":loc.getLatitude()+","+loc.getLongitude()+","+loc.getAccuracy();
        if(web!=null)web.evaluateJavascript("window.caddieFix("+token+","+args+","+JSONObject.quote(error)+")",null);
    }
    private void requestFix(int token) {
        stopCaddieFix();
        locationToken=token;
        if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},CADDIE_LOCATION);
            return;
        }
        android.location.LocationManager lm=(android.location.LocationManager)getSystemService(LOCATION_SERVICE);
        try {
            if(lm==null||!lm.isProviderEnabled(android.location.LocationManager.GPS_PROVIDER)){
                finishFix(token,null,"GPS is off. Enable location or mark the ball on the map.");return;
            }
            caddieListener=new android.location.LocationListener(){
                public void onLocationChanged(android.location.Location loc){
                    long age=android.os.SystemClock.elapsedRealtimeNanos()-loc.getElapsedRealtimeNanos();
                    if(age>=0 && age<15000000000L && loc.hasAccuracy() && loc.getAccuracy()<=40)finishFix(token,loc,"");
                }
                public void onProviderDisabled(String provider){finishFix(token,null,"GPS is off.");}
                public void onProviderEnabled(String provider){}
                public void onStatusChanged(String provider,int status,Bundle extras){}
            };
            lm.requestLocationUpdates(android.location.LocationManager.GPS_PROVIDER,500,0,caddieListener,Looper.getMainLooper());
            locationTimeout=()->finishFix(token,null,"No precise GPS fix. Retry outdoors or mark the ball on the map.");
            mainHandler.postDelayed(locationTimeout,25000);
        }catch(RuntimeException e){finishFix(token,null,"GPS unavailable. Mark the ball on the map.");}
    }

    public final class Bridge {
        @JavascriptInterface public void caddieLocation(int token){runOnUiThread(()->requestFix(token));}

        @JavascriptInterface public void openSwingCamera() { runOnUiThread(()->swingVideo.open()); }
        @JavascriptInterface public void acceptSwingShot(String key) { runOnUiThread(()->swingVideo.accept(key)); }
        @JavascriptInterface public void discardSwing(String key) { runOnUiThread(()->swingVideo.discard(key)); }
        @JavascriptInterface public void replaySwing(String key,String metrics) { runOnUiThread(()->swingVideo.play(key,metrics)); }

        @JavascriptInterface public void speakCoach(String line) { runOnUiThread(() -> sayCoach(line)); }
        @JavascriptInterface public void stopCoachVoice() { runOnUiThread(() -> silenceCoach()); }
        @JavascriptInterface public void setRoundFullscreen(boolean active) {
            runOnUiThread(() -> {
                roundFullscreen = active;
                applyRoundFullscreen();
            });
        }

        @JavascriptInterface public void scan() { runOnUiThread(() -> beginScan()); }
        @JavascriptInterface public void disconnect() { runOnUiThread(() -> closeBle()); }
        @JavascriptInterface public void clubCue() { runOnUiThread(() -> { try { if (cueTone == null) cueTone = new android.media.ToneGenerator(android.media.AudioManager.STREAM_MUSIC, 85); cueTone.startTone(android.media.ToneGenerator.TONE_PROP_ACK, 350); } catch (Exception ignored) {} }); }
        @JavascriptInterface public void importCsv() {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                startActivityForResult(i, IMPORT_CSV_REQUEST);
            });
        }
        @JavascriptInterface public void importCourse() {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                startActivityForResult(i, IMPORT_COURSE_REQUEST);
            });
        }
        @JavascriptInterface public void exportCourse(String filename, String json) {
            runOnUiThread(() -> {
                pendingCsv = json;
                pendingExportLabel = "Course JSON";
                Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("application/json");
                i.putExtra(Intent.EXTRA_TITLE, filename.replaceAll("[^A-Za-z0-9_.-]", "_"));
                startActivityForResult(i, SAVE_CSV_REQUEST);
            });
        }
        @JavascriptInterface public void exportCsv(String filename, String csv) {
            runOnUiThread(() -> {
                pendingCsv = csv;
                pendingExportLabel = "CSV";
                Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("text/csv");
                i.putExtra(Intent.EXTRA_TITLE, filename.replaceAll("[^A-Za-z0-9_.-]", "_"));
                startActivityForResult(i, SAVE_CSV_REQUEST);
            });
        }
    }

    private boolean allowed(String name) { return Build.VERSION.SDK_INT < 23 || checkSelfPermission(name) == PackageManager.PERMISSION_GRANTED; }
    private void beginScan() {
        if (adapter == null) { emit("status", "Bluetooth not available on this device"); return; }
        if (Build.VERSION.SDK_INT >= 31 && (!allowed(Manifest.permission.BLUETOOTH_SCAN) || !allowed(Manifest.permission.BLUETOOTH_CONNECT))) {
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT}, BT_PERMS_REQUEST); return;
        }
        if (Build.VERSION.SDK_INT < 31 && !allowed(Manifest.permission.ACCESS_FINE_LOCATION)) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, BT_PERMS_REQUEST); return;
        }
        if (!adapter.isEnabled()) { emit("status", "Turn on Android Bluetooth, then scan again"); return; }
        closeBle();
        closed = false; reconnectAttempts=0; lastDevice=null;
        try {
            scanner = adapter.getBluetoothLeScanner();
            if (scanner == null) { emit("status", "BLE scanner unavailable"); return; }
            scanning = true;
            scanner.startScan(scanCallback);
            emit("status", "Scanning for Approach R10 (15 seconds)...");
            stopScanTask = () -> {
                if (!scanning) return;
                stopScan();
                emit("status", "R10 not found. Turn off Garmin Golf and pair the R10 in Android Bluetooth settings.");
            };
            mainHandler.postDelayed(stopScanTask, 15000);
        } catch (Exception e) { scanning = false; emit("status", "BLE scan error: " + e.getMessage()); }
    }

    private final ScanCallback scanCallback = new ScanCallback() {
        @Override public void onScanResult(int callbackType, ScanResult result) {
            BluetoothDevice device = result.getDevice();
            String name = result.getScanRecord() == null ? null : result.getScanRecord().getDeviceName();
            try { if (name == null) name = device.getName(); }
            catch (SecurityException ignored) {}
            // Exact R10 name preferred; Garmin vendor alone is not enough (many Garmin devices advertise).
            if (name == null || !name.toLowerCase(java.util.Locale.ROOT).contains("approach r10")) return;
            final String foundName = name;
            mainHandler.post(() -> {
                if (!scanning) return;
                stopScan();
                emit("status", "Found " + foundName + ". Checking Bluetooth pairing...");
                connectOrBond(device);
            });
        }
        @Override public void onScanFailed(int code) {
            mainHandler.post(() -> {stopScan(); emit("status", "BLE scan failed (" + code + ")");});
        }
    };
    private void stopScan() {
        if (stopScanTask != null) mainHandler.removeCallbacks(stopScanTask);
        if (!scanning) return;
        scanning = false;
        try { if (scanner != null) scanner.stopScan(scanCallback); } catch (Exception ignored) {}
    }
    private void connectOrBond(BluetoothDevice device) {
        try {
            if (device.getBondState() == BluetoothDevice.BOND_BONDED) { connect(device); return; }
            awaitingBond = device;
            if (device.getBondState() == BluetoothDevice.BOND_BONDING || device.createBond()) {
                emit("status", "Bluetooth pairing requested. Accept Android's pairing prompt.");
            } else emit("status", "Pair the R10 in Android Bluetooth settings, then scan again.");
        } catch (Exception e) { emit("status", "BLE pairing error: " + e.getMessage()); }
    }
    private final BroadcastReceiver bondReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (!BluetoothDevice.ACTION_BOND_STATE_CHANGED.equals(intent.getAction())) return;
            BluetoothDevice device;
            if (Build.VERSION.SDK_INT >= 33) device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice.class);
            else { @SuppressWarnings("deprecation") BluetoothDevice old = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE); device = old; }
            if (device == null || awaitingBond == null || !device.getAddress().equals(awaitingBond.getAddress())) return;
            int state = intent.getIntExtra(BluetoothDevice.EXTRA_BOND_STATE, BluetoothDevice.ERROR);
            if (state == BluetoothDevice.BOND_BONDED) {
                awaitingBond = null;
                emit("log", "R10 Bluetooth bond established");
                connect(device);
            } else if (state == BluetoothDevice.BOND_NONE) {
                awaitingBond = null;
                emit("status", "Pairing did not complete. Pair using Android Bluetooth settings and retry.");
            }
        }
    };

    private void connect(BluetoothDevice device) {
        if (closed) return;
        lastDevice=device;
        try {
            emit("status", "Connecting to R10 via Bluetooth LE...");
            gatt = device.connectGatt(this, false, gattCallback, BluetoothDevice.TRANSPORT_LE);
            if (gatt==null) { retryConnection("GATT connection could not start"); return; }
            connectTimeout=() -> retryConnection("R10 initialization timed out");
            mainHandler.postDelayed(connectTimeout, 25000);
        } catch (Exception e) { retryConnection("GATT connection error: " + e.getMessage()); }
    }

    private void retryConnection(String reason) {
        closeGattOnly();
        if (closed || lastDevice == null) return;
        if (reconnectTask != null) mainHandler.removeCallbacks(reconnectTask);
        if (reconnectAttempts >= 5) { emit("status", "R10 disconnected: automatic retries exhausted. Scan to reconnect. " + reason); return; }
        int delay=Math.min(15000, 1500*(1<<reconnectAttempts)); reconnectAttempts++;
        emit("status", "R10 disconnected: " + reason + ". Automatic retry " + reconnectAttempts + "/5 in " + delay/1000.0 + " s.");
        reconnectTask=() -> { reconnectTask=null; if (!closed && lastDevice!=null) connect(lastDevice); };
        mainHandler.postDelayed(reconnectTask, delay);
    }
    private final BluetoothGattCallback gattCallback = new BluetoothGattCallback() {
        @Override public void onConnectionStateChange(BluetoothGatt g, int status, int state) {
            mainHandler.post(() -> {
                if (g != gatt || closed) return;
                if (status == BluetoothGatt.GATT_SUCCESS && state == BluetoothProfile.STATE_CONNECTED) {
                    emit("status", "Connected. Discovering R10 GATT services...");
                    try { if (!g.discoverServices()) retryConnection("Service discovery could not start"); }
                    catch (Exception e) { retryConnection("Service discovery failed: " + e.getMessage()); }
                } else if (state == BluetoothProfile.STATE_DISCONNECTED || status != BluetoothGatt.GATT_SUCCESS) {
                    retryConnection("GATT " + status);
                }
            });
        }
        @Override public void onServicesDiscovered(BluetoothGatt g, int status) {
            mainHandler.post(() -> {
                if (closed || g != gatt) return;
                if (status != BluetoothGatt.GATT_SUCCESS) { emit("status", "Service discovery error " + status); return; }
                BluetoothGattService service = g.getService(MULTILINK);
                if (service == null) { emit("status", "R10 MultiLink BLE service not found"); return; }
                notifyAndRegister = service.getCharacteristic(CHAR_NOTIFY_AND_REGISTER);
                writeCharacteristic = service.getCharacteristic(CHAR_WRITE);
                if (notifyAndRegister == null || writeCharacteristic == null) {
                    emit("status", "R10 MultiLink characteristics missing"); return;
                }
                BluetoothGattDescriptor descriptor = notifyAndRegister.getDescriptor(CCCD);
                if (descriptor == null || !g.setCharacteristicNotification(notifyAndRegister, true)) {
                    emit("status", "Cannot subscribe to R10 BLE notifications"); return;
                }
                try {
                    boolean ok;
                    if (Build.VERSION.SDK_INT >= 33) ok = g.writeDescriptor(descriptor, BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE) == BluetoothStatusCodes.SUCCESS;
                    else {
                        descriptor.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                        ok = g.writeDescriptor(descriptor);
                    }
                    if (!ok) emit("status", "R10 notification subscription failed to start");
                    else emit("status", "Subscribing to R10 MultiLink notifications...");
                } catch (Exception e) { emit("status", "Notification subscription error: " + e.getMessage()); }
            });
        }
        @Override public void onDescriptorWrite(BluetoothGatt g, BluetoothGattDescriptor descriptor, int status) {
            mainHandler.post(() -> {
                if (closed || g != gatt || !CCCD.equals(descriptor.getUuid())) return;
                if (status != BluetoothGatt.GATT_SUCCESS) { emit("status", "R10 notification enable failed (" + status + ")"); return; }
                protocol = new R10Protocol(new R10Protocol.Events() {
                    @Override public void write(boolean register, byte[] chunk) { queueWrite(register, chunk); }
                    @Override public void phase(String name) { emit("status", name); if (name.contains("ready for shots") || name.contains("R10 awake") || name.contains("radar: armed")) { reconnectAttempts=0; if (connectTimeout!=null) mainHandler.removeCallbacks(connectTimeout); } }
                    @Override public void log(String message) { emit("log", message); }
                    @Override public void shot(R10Protocol.Shot s) { liveShot(s); }
                });
                protocol.start();
            });
        }
        @Override public void onCharacteristicWrite(BluetoothGatt g, BluetoothGattCharacteristic characteristic, int status) {
            mainHandler.post(() -> {
                if (closed || g != gatt) return;
                writeBusy = false;
                if (writeTimeout != null) mainHandler.removeCallbacks(writeTimeout);
                if (status != BluetoothGatt.GATT_SUCCESS) {
                    retryConnection("R10 BLE write failed (" + status + ")"); return;
                }
                drainWrites();
            });
        }
        @Override public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic characteristic, byte[] value) {
            if (!CHAR_NOTIFY_AND_REGISTER.equals(characteristic.getUuid())) return;
            byte[] copy = value == null ? null : value.clone();
            mainHandler.post(() -> { if (!closed && g == gatt && protocol != null) protocol.notification(copy); });
        }
        @SuppressWarnings("deprecation")
        @Override public void onCharacteristicChanged(BluetoothGatt g, BluetoothGattCharacteristic characteristic) {
            if (Build.VERSION.SDK_INT >= 33 || !CHAR_NOTIFY_AND_REGISTER.equals(characteristic.getUuid())) return;
            byte[] value = characteristic.getValue();
            byte[] copy = value == null ? null : value.clone();
            mainHandler.post(() -> { if (!closed && g == gatt && protocol != null) protocol.notification(copy); });
        }
    };

    private void queueWrite(boolean register, byte[] chunk) {
        BluetoothGattCharacteristic ch = register ? notifyAndRegister : writeCharacteristic;
        if (gatt == null || ch == null) { emit("log", "Write ignored: GATT not ready"); return; }
        writes.addLast(new BleWrite(ch, chunk));
        drainWrites();
    }
    private void drainWrites() {
        if (writeBusy || writes.isEmpty() || gatt == null || closed) return;
        BleWrite next = writes.removeFirst();
        try {
            next.target.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT);
            boolean ok;
            if (Build.VERSION.SDK_INT >= 33) {
                ok = gatt.writeCharacteristic(next.target, next.data, BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT) == BluetoothStatusCodes.SUCCESS;
            } else {
                next.target.setValue(next.data);
                ok = gatt.writeCharacteristic(next.target);
            }
            if (!ok) {
                retryConnection("BLE write could not start"); return;
            }
            writeBusy = true;
            writeTimeout = () -> {
                if (writeBusy) {
                    writeBusy = false;
                    writes.clear();
                    retryConnection("Bluetooth write timed out");
                }
            };
            mainHandler.postDelayed(writeTimeout, 6000);
        } catch (Exception e) {
            writes.clear(); writeBusy = false;
            retryConnection("BLE write error: " + e.getMessage());
        }
    }
    private void closeGattOnly() {
        if (connectTimeout != null) mainHandler.removeCallbacks(connectTimeout);
        if (writeTimeout != null) mainHandler.removeCallbacks(writeTimeout);
        writes.clear(); writeBusy=false; protocol=null;
        notifyAndRegister=null; writeCharacteristic=null;
        BluetoothGatt current = gatt; gatt = null;
        if (current != null) try { current.disconnect(); current.close(); } catch (Exception ignored) {}
    }
    private void closeBle() {
        stopScan(); awaitingBond = null;
        closed=true;
        if (reconnectTask!=null) mainHandler.removeCallbacks(reconnectTask);
        reconnectTask=null; lastDevice=null;
        closeGattOnly();
        emit("status", "Not connected — demo mode available");
    }
    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grants) {
        super.onRequestPermissionsResult(requestCode, permissions, grants);
        if(requestCode==CADDIE_LOCATION){
            if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED)requestFix(locationToken);
            else finishFix(locationToken,null,"Precise location was not granted. Mark the ball on the map.");
            return;
        }
        if(requestCode==SwingVideo.PERMISSION){
            swingVideo.permissionResult(grants.length>0 && grants[0]==PackageManager.PERMISSION_GRANTED);
            return;
        }
        if (requestCode == BT_PERMS_REQUEST) {
            boolean granted = grants.length > 0;
            for (int value: grants) if (value != PackageManager.PERMISSION_GRANTED) granted=false;
            if (granted) beginScan();
            else emit("status", "Nearby devices permission is needed for R10 access");
        }
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == IMPORT_CSV_REQUEST && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri == null) return;
            new Thread(() -> {
                try (InputStream in = getContentResolver().openInputStream(uri); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                    if (in == null) throw new java.io.IOException("Unable to open CSV");
                    byte[] buffer = new byte[8192]; int n;
                    while ((n = in.read(buffer)) != -1) {
                        if (out.size() + n > 2 * 1024 * 1024) throw new java.io.IOException("CSV exceeds 2 MB");
                        out.write(buffer, 0, n);
                    }
                    String csv = new String(out.toByteArray(), StandardCharsets.UTF_8);
                    runOnUiThread(() -> { if (web != null) web.evaluateJavascript("window.importR10Csv(" + JSONObject.quote(csv) + ")", null); });
                } catch (Exception e) { runOnUiThread(() -> Toast.makeText(this, "CSV import failed: " + e.getMessage(), Toast.LENGTH_LONG).show()); }
            }).start();
        }
        if (requestCode == IMPORT_COURSE_REQUEST && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri == null) return;
            new Thread(() -> {
                try (InputStream in = getContentResolver().openInputStream(uri); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                    if (in == null) throw new java.io.IOException("Unable to open course pack");
                    byte[] buffer = new byte[8192]; int n;
                    while ((n = in.read(buffer)) != -1) {
                        if (out.size() + n > 1024 * 1024) throw new java.io.IOException("Course pack exceeds 1 MB");
                        out.write(buffer, 0, n);
                    }
                    String json = new String(out.toByteArray(), StandardCharsets.UTF_8);
                    runOnUiThread(() -> { if (web != null) web.evaluateJavascript("window.importR10Course(" + JSONObject.quote(json) + ")", null); });
                } catch (Exception e) { runOnUiThread(() -> Toast.makeText(this, "Course import failed: " + e.getMessage(), Toast.LENGTH_LONG).show()); }
            }).start();
        }
        if (requestCode == SAVE_CSV_REQUEST && resultCode == RESULT_OK && data != null && pendingCsv != null) {
            Uri uri = data.getData();
            try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                if (out != null) out.write(pendingCsv.getBytes(StandardCharsets.UTF_8));
                Toast.makeText(this, pendingExportLabel + " exported", Toast.LENGTH_SHORT).show();
            } catch (Exception e) { Toast.makeText(this, pendingExportLabel + " export failed", Toast.LENGTH_LONG).show(); }
            pendingCsv = null;
        }
    }
    @Override protected void onDestroy() {
        closeBle();
        if(cueTone!=null){cueTone.release();cueTone=null;}
        if (bondReceiverRegistered) { unregisterReceiver(bondReceiver); bondReceiverRegistered=false; }
        if (web != null) { web.removeJavascriptInterface("R10Native"); web.destroy(); web=null; }
        if (coachSpeech != null) { coachSpeech.shutdown(); coachSpeech = null; speechReady = false; }
        super.onDestroy();
    }
}
