/* Offline tour. The same field posts a score against par for each completed round. */
(function(root) {
'use strict';
const opponents = ['Nora Stein','Elias Weber','Mara Klein','Leon Vidal','Ada Rossi','Theo Braun','Lina Meyer'];
const events = ['Season Opener','Tour Invitational','Players Cup','Championship Final'];
const targets = {easy:5, medium:0, hard:-4, expert:-9};
const points = [500,350,250,180,150,120,100,80];
const player = 'You';
function stage(history) {
    const season = Math.floor(history.length / events.length) + 1;
    const index = history.length % events.length;
    return {season,index,name:events[index],final:index===events.length-1};
}
function ranked(rows, metric, descending=false) {
    rows.sort((a,b)=>(descending?-1:1)*(a[metric]-b[metric]) || a.name.localeCompare(b.name));
    let place=1;
    return rows.map((row,i)=>{
        if(i && rows[i-1][metric]!==row[metric]) place=i+1;
        return {...row,place};
    });
}
function record(history,round) {
    if(!round.done || !round.career || history.some(r=>r.id===round.id)) return history;
    const event=stage(history);
    if(event.season!==round.career.season || event.index!==round.career.index) throw Error('This career event was already played.');
    const cards=round.scorecards, holes=cards.length;
    if(holes!==round.numbers.length || !holes) throw Error('Incomplete tournament scorecard.');
    const par=cards.reduce((s,h)=>s+h.par,0);
    const score=cards.reduce((s,h)=>s+h.scores[0],0);
    const difficulty=round.config.difficulty;
    // Deterministic form keeps the field stable across retries, with different leaders each event.
    const seed=event.season*101+event.index*19;
    const rows=opponents.map((name,i)=>{
        const form=Math.sin(seed*1.3+i*7.1)*2.5;
        return {name,offset:i*1.45+form};
    });
    const best=Math.min(...rows.map(r=>r.offset));
    const target=targets[difficulty]+Math.round(Math.sin(seed)*1.5);
    const field=rows.map(r=>({name:r.name,strokes:par+Math.round((target+r.offset-best)*holes/18)}));
    field.push({name:player,strokes:score});
    const results=ranked(field,'strokes').map(r=>({...r,points:points[r.place-1]*(event.final?2:1)}));
    return [...history,{id:round.id,...event,course:round.course.name,holes,par,results,
        birdie:cards.some(h=>h.scores[0]<=h.par-1)}];
}
function standings(history,season) {
    const totals=new Map([player,...opponents].map(name=>[name,0]));
    for(const event of history.filter(e=>e.season===season))
        for(const row of event.results) totals.set(row.name,totals.get(row.name)+row.points);
    return ranked(Array.from(totals,([name,points])=>({name,points})),'points',true);
}
function achievements(history) {
    const won=e=>e.results.find(r=>r.name===player).place===1;
    const trophy=e=>e.final && standings(history,e.season).find(r=>r.name===player).place===1;
    return [[history.length,'First finish'],[history.some(e=>e.birdie),'First birdie or better'],
        [history.some(won),'Tournament winner'],[history.some(trophy),'Season champion']]
        .filter(([earned])=>earned).map(([,label])=>label);
}
const api={events,targets,stage,record,standings,achievements};
if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.R10Career=api;
})(globalThis);
