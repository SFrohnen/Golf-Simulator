/* Offline approach recommendations use actual pairs of downrange and lateral readings. */
(function(root){
'use strict';
const E=typeof module==='object'?require('./course.js'):root.R10Course;
const A=typeof module==='object'?require('./club-analytics.js'):root.ClubAnalytics;
function project(origin,lat,lon){
 const m=6371008.8*Math.PI/180;
 return [(lon-origin.lon)*m*Math.cos(origin.lat*Math.PI/180),(lat-origin.lat)*m];
}
const F=typeof module==='object'?require('./flight.js'):root.GolfFlight;
const adjustedCache=new WeakMap(), genericCache=new Map();
function conditionKey(w){return Math.round(Number(w.temperatureC??20)*10)/10+'/'+Math.round(Number(w.altitudeM??200)/5)*5;}
function adjusted(s,w){const key=conditionKey(w),cached=adjustedCache.get(s);if(cached?.key===key)return cached.row;let row=s;try{row={...s,...F.simulate(s,w)};}catch(e){}adjustedCache.set(s,{key,row});return row;}
function clubSamples(shots,version,weather){
 const groups=new Map();
 for(const s of A.bagRows(shots,version)){
   if(!A.finite(s.downrange)||!A.finite(s.offline)||s.downrange<=0)continue;
   const key=A.profileKey(s.club,s.swingLength);
   if(!groups.has(key))groups.set(key,[]);
   const rows=groups.get(key);
   if(rows.length<30){rows.push(weather?adjusted(s,weather):s);}
 }
 return groups;
}
function recommend(h,ball,groups,safer=false,selected='',custom=null){
 const distance=E.dist(ball,custom||h.pin);
 if(distance<5||distance>260)return null;
 const approx=h.approximatePuttingTarget===10;
 const targets=[];
 for(const x of [-10,-5,0,5,10])for(const y of [-10,-5,0,5,10]){
   const p=[h.pin[0]+x,h.pin[1]+y];
   if(['green','holed','approximate target'].includes(E.lie(h,p))&&E.dist(ball,p)>1)targets.push(p);
 }
 if(custom)targets.splice(0,targets.length,custom);
 let best=null;
 for(const [club,ss] of groups){
   if(ss.length<5||(selected&&selected!==club))continue;
   const meanCarry=ss.reduce((n,s)=>n+Number(s.downrange),0)/ss.length;
   if(!selected&&Math.abs(meanCarry-distance)>Math.max(28,distance*.25))continue;
   for(const target of targets){
     let cost=0,hazards=0,on=0;
     const delta=E.elevationDelta(h,ball,target);
     const pattern=[];
     for(const s of ss){
       // Estimate the altered carry using the modeled descent angle at landing.
       const slope=A.finite(s.landingAngle)&&s.landingAngle>=20&&s.landingAngle<=80?Math.tan(s.landingAngle*Math.PI/180):null;
       const forward=Number(s.downrange)-(slope&&delta!==null?delta/slope:0);
       const land=E.landing(ball,target,forward,Number(s.offline)),lie=E.lie(h,land);
       pattern.push(land);
       const hazard=['water','ob','bunker'].includes(lie);
       if(hazard)hazards++;
       const green=['green','holed','approximate target'].includes(lie);
       if(green)on++;
       cost+=E.dist(land,custom||h.pin)+(green?0:safer?22:12)+(hazard?(lie==='bunker'?24:50)*(safer?3:1):0);
     }
     cost=cost/ss.length+.015*E.dist(target,h.pin);
     if(!best||cost<best.cost)best={club,target,cost,hazards,on,n:ss.length,approx,delta,pattern};
   }
 }
 if(best){
   const targetDistance=E.dist(ball,best.target);
   let edge=0,type='';
   // Sample the aim line every metre. A carry past this edge is a depth check only.
   for(let d=1;d<targetDistance;d++){
     const lie=E.lie(h,E.landing(ball,best.target,d,0));
     if(lie==='water'||lie==='bunker'){edge=d;type=lie;}
   }
   if(edge){
     const ux=(best.target[0]-ball[0])/targetDistance,uy=(best.target[1]-ball[1])/targetDistance;
     best.clearance={type,edge,cleared:best.pattern.filter(p=>(p[0]-ball[0])*ux+(p[1]-ball[1])*uy>edge).length};
   }
 }
 return best;
}
// General course management. Compare carry endpoints on mapped surfaces; no claim of official hazard probability.
function plan(h,ball,groups,safer=true,selected='',custom=null,weather={}){
 const pin=h.pin,d=E.dist(ball,pin);if(d<2)return null;
 const usable=new Map([...groups].filter(([k,v])=>v.length>=5));
 // A generic pattern is explicitly distinguished from personal history.
 const estimatedKeys=new Set();
 for(const c of A.CLUBS){if(usable.has(c.name))continue;try{const [ballSpeed,launch,spin]=c.base;const key=c.name+'/'+conditionKey(weather);let f=genericCache.get(key);if(!f){f=F.simulate({ballSpeed,launch,spin,direction:0,spinAxis:0},weather);if(genericCache.size>240)genericCache.clear();genericCache.set(key,f);}usable.set(c.name,[-1,0,1].flatMap(x=>[-1,0,1].map(y=>({...f,downrange:f.downrange*(1+x*.09),offline:f.downrange*y*.065}))));estimatedKeys.add(c.name);}catch(e){}}
 const aims=custom?[custom]:[pin,...(h.route||[]).filter(p=>E.dist(ball,p)>15&&E.dist(p,pin)<d-5)];
 let best=null;
 for(const [club,ss] of usable){if(selected&&selected!==club)continue;const avg=ss.reduce((n,s)=>n+Number(s.downrange),0)/ss.length;
  for(const base of aims){const len=E.dist(ball,base);if(len<1)continue;const u=[(base[0]-ball[0])/len,(base[1]-ball[1])/len];const center=custom?base:E.landing(ball,base,Math.min(avg,len),0);
   for(const offset of custom?[0]:[-8,0,8]){const target=[center[0]+u[1]*offset,center[1]-u[0]*offset];if(E.dist(ball,target)<1)continue;const delta=E.elevationDelta(h,ball,target);let cost=0,hazards=0,on=0,safe=0;const pattern=[];
    for(const s of ss){const slope=A.finite(s.landingAngle)&&s.landingAngle>=20&&s.landingAngle<=80?Math.tan(s.landingAngle*Math.PI/180):null;const land=E.landing(ball,target,Math.max(0,Number(s.downrange)-(slope&&delta!==null?delta/slope:0)),Number(s.offline));pattern.push(land);const lie=E.lie(h,land),green=['green','holed','approximate target'].includes(lie),hazard=['water','ob','bunker'].includes(lie);if(green)on++;if(green||lie==='fairway')safe++;if(hazard)hazards++;cost+=E.dist(land,custom||pin)+(green||lie==='fairway'?0:15)+(hazard?(lie==='bunker'?35:100)*(safer?2:1):0);}
    cost=cost/ss.length+(estimatedKeys.has(club)?8:0);if(!best||cost<best.cost)best={club,target,cost,hazards,on,safe,n:ss.length,delta,pattern,estimated:estimatedKeys.has(club)};
   }
  }
 }
 return best;
}
function dispersionRings(points){if(points.length<3)return [];const n=points.length,center=points.reduce((a,p)=>[a[0]+p[0]/n,a[1]+p[1]/n],[0,0]),d=points.map(p=>E.dist(p,center)).sort((a,b)=>a-b);return [.5,.8].map(f=>({center,radius:d[Math.ceil(f*n)-1],fraction:f}));}
const api={project,clubSamples,recommend,plan,dispersionRings};
if(typeof module==='object')module.exports=api;else root.R10Caddie=api;
})(globalThis);
