/* Offline approach recommendations use actual pairs of downrange and lateral readings. */
(function(root){
'use strict';
const E=typeof module==='object'?require('./course.js'):root.R10Course;
const A=typeof module==='object'?require('./club-analytics.js'):root.ClubAnalytics;
function project(origin,lat,lon){
 const m=6371008.8*Math.PI/180;
 return [(lon-origin.lon)*m*Math.cos(origin.lat*Math.PI/180),(lat-origin.lat)*m];
}
function clubSamples(shots,version){
 const groups=new Map();
 for(const s of A.bagRows(shots,version)){
   if(!A.finite(s.downrange)||!A.finite(s.offline)||s.downrange<=0)continue;
   const key=A.profileKey(s.club,s.swingLength);
   if(!groups.has(key))groups.set(key,[]);
   const rows=groups.get(key);
   if(rows.length<30)rows.push(s);
 }
 return groups;
}
function recommend(h,ball,groups,safer=false,selected='',custom=null){
 const distance=E.dist(ball,custom||h.pin);
 if(distance<5||distance>260)return null;
 const approx=h.approximatePuttingTarget===10;
 const targets=[];
 for(const x of [-10,-5,0,5,10])for(const y of [-10,-5,0,5,10]){
   const p=[h.pin[0]+x,h.pin[1]+y];
   if(['green','holed','approximate target'].includes(E.lie(h,p))&&E.dist(ball,p)>1)targets.push(p);
 }
 if(custom)targets.splice(0,targets.length,custom);
 let best=null;
 for(const [club,ss] of groups){
   if(ss.length<5||(selected&&selected!==club))continue;
   const meanCarry=ss.reduce((n,s)=>n+Number(s.downrange),0)/ss.length;
   if(!selected&&Math.abs(meanCarry-distance)>Math.max(28,distance*.25))continue;
   for(const target of targets){
     let cost=0,hazards=0,on=0;
     const delta=E.elevationDelta(h,ball,target);
     const pattern=[];
     for(const s of ss){
       // Estimate the altered carry using the modeled descent angle at landing.
       const slope=A.finite(s.landingAngle)&&s.landingAngle>=20&&s.landingAngle<=80?Math.tan(s.landingAngle*Math.PI/180):null;
       const forward=Number(s.downrange)-(slope&&delta!==null?delta/slope:0);
       const land=E.landing(ball,target,forward,Number(s.offline)),lie=E.lie(h,land);
       pattern.push(land);
       const hazard=['water','ob','bunker'].includes(lie);
       if(hazard)hazards++;
       const green=['green','holed','approximate target'].includes(lie);
       if(green)on++;
       cost+=E.dist(land,custom||h.pin)+(green?0:safer?22:12)+(hazard?(lie==='bunker'?24:50)*(safer?3:1):0);
     }
     cost=cost/ss.length+.015*E.dist(target,h.pin);
     if(!best||cost<best.cost)best={club,target,cost,hazards,on,n:ss.length,approx,delta,pattern};
   }
 }
 if(best){
   const targetDistance=E.dist(ball,best.target);
   let edge=0,type='';
   // Sample the aim line every metre. A carry past this edge is a depth check only.
   for(let d=1;d<targetDistance;d++){
     const lie=E.lie(h,E.landing(ball,best.target,d,0));
     if(lie==='water'||lie==='bunker'){edge=d;type=lie;}
   }
   if(edge){
     const ux=(best.target[0]-ball[0])/targetDistance,uy=(best.target[1]-ball[1])/targetDistance;
     best.clearance={type,edge,cleared:best.pattern.filter(p=>(p[0]-ball[0])*ux+(p[1]-ball[1])*uy>edge).length};
   }
 }
 return best;
}
const api={project,clubSamples,recommend};
if(typeof module==='object')module.exports=api;else root.R10Caddie=api;
})(globalThis);
