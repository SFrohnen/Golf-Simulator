/* Three.js presentation adapter. No changes to shots, terrain data or scoring. */
(function(root){'use strict';
const xyz=(x,y,z)=>[-x,y,z]; // Legacy camera is left-handed; reflect east to match Three's right-handed camera.
const srgb=v=>{v=Math.max(0,Math.min(1,v));return v<=.04045?v/12.92:Math.pow((v+.055)/1.055,2.4);};
function bucket(){return {position:[],color:[],uv:[]};}
function vertex(b,p,c,uv=[0,0]){b.position.push(...xyz(...p));b.color.push(...c.map(srgb));b.uv.push(...uv);}
function classify(mat){return ({'-1':'grass','-2':'sand','-3':'fairway','-4':'green','-5':'rough','-6':'tee',2:'water',3:'stone',4:'roof',5:'timber',6:'window',7:'windscreen',8:'path',9:'metal'})[mat]||'solid';}
const surfaceKinds=['grass','fairway','green','rough','tee','sand','water'];
const propKinds=['stone','roof','timber','window','windscreen','path','metal'];
const rand=(v)=>{const n=Math.sin(v*127.1+311.7)*43758.5453;return n-Math.floor(n);};
function convert(geo){
 const out=Object.fromEntries([...surfaceKinds,...propKinds,'solid','leaves'].map(k=>[k,bucket()])),a=geo.tris;
 Object.defineProperty(out,'trees',{value:[],enumerable:false});
 for(let i=0;i<a.length;){let mat=a[i+6];
  if(mat < -9){ // A legacy tree card encodes width, UV, species and tone in six vertices.
   const width=-mat-10;
   out.trees.push({x:-a[i],z:a[i+2],base:a[i+1],height:a[i+15]-a[i+1],width,species:Math.floor(a[i+5]),seed:a[i]*17+a[i+2]*31+a[i+5]*91});
   for(const angle of [Math.PI/4,-Math.PI/4]) for(let j=0;j<6;j++){
    const k=i+j*7,u=a[k+3],v=a[k+4],s=Math.floor(a[k+5]),tone=.92+(a[k+5]-s)*.16;
    vertex(out.leaves,[a[k]+(u-.5)*width*Math.cos(angle),a[k+1],a[k+2]+(u-.5)*width*Math.sin(angle)],[tone,tone,tone],[(u*.996+.002+s)*.5,v*.4995+.5005]);
   }i+=42;continue;
  }
  // Water triangles use the existing blue palette; solid decorative geometry stays separate.
  const kind=mat===1&&a[i+3]<.3&&a[i+4]>.35&&a[i+5]>.52?'water':classify(mat),b=out[kind];
  const winding=(a[i+7]-a[i])*(a[i+16]-a[i+2])-(a[i+9]-a[i+2])*(a[i+14]-a[i]);
  const indices=surfaceKinds.includes(kind)&&winding<0?[0,2,1]:[0,1,2];
  const dx=a[i+7]-a[i],dy=a[i+8]-a[i+1],dz=a[i+9]-a[i+2],ex=a[i+14]-a[i],ey=a[i+15]-a[i+1],ez=a[i+16]-a[i+2],nx=Math.abs(dy*ez-dz*ey),ny=Math.abs(dz*ex-dx*ez),nz=Math.abs(dx*ey-dy*ex);
  for(const j of indices){const k=i+j*7;let uv=[a[k]/(kind==='green'?1.1:kind==='rough'?3.5:2.5),a[k+2]/(kind==='green'?1.1:kind==='rough'?3.5:2.5)];if(propKinds.includes(kind)){const scale=kind==='path'?2:kind==='roof'?1.2:kind==='stone'?1.5:.85;uv=ny>=nx&&ny>=nz?[a[k]/scale,a[k+2]/scale]:nx>nz?[a[k+2]/scale,a[k+1]/scale]:[a[k]/scale,a[k+1]/scale];}vertex(b,a.slice(k,k+3),a.slice(k+3,k+6),uv);}i+=21;
 }
 return out;
}
function convertLinear(a){const b=bucket();for(let i=0;i<a.length;i+=7)vertex(b,a.slice(i,i+3),a.slice(i+3,i+6));return b;}
function textureData(kind,n=128){const a=new Uint8Array(n*n*4),r=(x,y)=>{const f=Math.sin(x*127.1+y*311.7)*43758.5453;return f-Math.floor(f);};for(let y=0;y<n;y++)for(let x=0;x<n;x++){const v=r(x,y),coarse=r(Math.floor(x/8),Math.floor(y/8)),blade=r(x,Math.floor(y/3));let l=kind==='sand'?194+49*v+12*coarse:158+37*v+28*blade+27*coarse;let i=(y*n+x)*4;for(let k=0;k<3;k++)a[i+k]=Math.round(l);a[i+3]=255;}return a;}
function propTextureData(kind,n=128){const a=new Uint8Array(n*n*4);for(let y=0;y<n;y++)for(let x=0;x<n;x++){const u=x/n,v=y/n,noise=rand(x+y*n),row=Math.floor(v*5),stagger=(row%2)*.5,brick=(u*4+stagger)%1,joint=(v*5)%1;let l=224+noise*27;
 if(kind==='stone')l=(joint<.045||brick<.035)?150:212+22*rand(row*17+Math.floor(u*4+stagger))+noise*17;
 if(kind==='roof'){const q=(u*8+(row%2)*.5)%1;l=(joint<.07?150:198+42*Math.sin(q*Math.PI))+noise*12;}
 if(kind==='timber')l=205+21*Math.sin(u*125+2*Math.sin(v*11))+noise*24;
 if(kind==='path')l=181+64*noise+10*rand(Math.floor(x/3)+Math.floor(y/3)*51);
 const k=(x+y*n)*4;for(let j=0;j<3;j++)a[k+j]=Math.round(Math.max(0,Math.min(255,l)));a[k+3]=255;}return a;}
// A planar mirror camera and projective texture matrix, shared by the two coplanar ponds.
const WATER_Y=.048;
function mirrorPoint(p,y=WATER_Y){return [p[0],2*y-p[1],p[2]];}
// Range-only near plane: improves depth resolution at long distances without changing camera framing.
// Range-only frame policy: preserve scene geometry and flight timing while reducing GPU work.
function rangeFramePolicy(quality,moving){return {ratioCap:quality==='low'?1:quality==='high'?(moving?1.5:2):1.5,reflection:quality!=='low'&&!moving,idleWater:quality==='high'&&!moving,shadowRecentre:!moving};}
function rangeNearPlane(eyeHeight){return Math.max(1,Math.min(42,Math.max(0,eyeHeight)*.18));}
function makeRangeWater(T){return new T.ShaderMaterial({side:T.DoubleSide,polygonOffset:true,polygonOffsetFactor:-1,polygonOffsetUnits:-2,uniforms:{reflection:{value:null},reflectionMatrix:{value:new T.Matrix4()},time:{value:0},hasReflection:{value:0}},vertexShader:`varying vec3 waterWorld;varying vec4 reflectionPos;uniform mat4 reflectionMatrix;void main(){vec4 world=modelMatrix*vec4(position,1.);waterWorld=world.xyz;reflectionPos=reflectionMatrix*world;gl_Position=projectionMatrix*viewMatrix*world;}`,fragmentShader:`varying vec3 waterWorld;varying vec4 reflectionPos;uniform sampler2D reflection;uniform float time;uniform float hasReflection;
 // Two irregular ponds share a plane but retain a gradual shallow-water color at their banks.
 float bankRatio(vec2 p,vec2 center,vec2 radii,float seed){vec2 q=(p-center)/radii;float angle=atan(q.y,q.x);return length(q)/(1.+.10*sin(angle*3.+seed)+.045*sin(angle*5.-seed));}
 void main(){vec2 p=waterWorld.xz;float t=time*.65;
 float a=sin(dot(p,vec2(1.73,.91))+t)+.44*sin(dot(p,vec2(-.71,3.14))-t*1.17)+.22*sin(dot(p,vec2(4.12,1.31))+t*.78);
 float b=sin(dot(p,vec2(-1.19,1.58))-t*.83)+.37*cos(dot(p,vec2(2.77,.45))+t*1.24)+.25*cos(dot(p,vec2(.55,3.62))-t*.58);
 float detail=1.-smoothstep(.15,1.5,length(fwidth(p)));vec3 n=normalize(vec3(.022*a*detail,1.,.025*b*detail));
 vec3 view=normalize(cameraPosition-waterWorld);float fresnel=.12+.80*pow(1.-clamp(dot(view,n),0.,1.),4.);
 vec2 uv=reflectionPos.xy/max(.001,reflectionPos.w)*.5+.5;uv+=vec2(a,b)*.0028*detail;
 float inside=step(0.,uv.x)*step(uv.x,1.)*step(0.,uv.y)*step(uv.y,1.)*step(.001,reflectionPos.w);
 vec3 sky=vec3(.24,.36,.43);vec3 reflected=mix(sky,texture2D(reflection,clamp(uv,.002,.998)).rgb,hasReflection*inside);
 vec2 original=vec2(-p.x,p.y);float radius=min(bankRatio(original,vec2(36.,51.),vec2(14.,20.),51.),bankRatio(original,vec2(-53.,199.),vec2(19.,27.),199.));
 float shallows=smoothstep(.70+.035*a,.98+.025*b,radius);vec3 deep=vec3(.029,.095,.080);vec3 shallow=vec3(.12,.185,.105);vec3 water=mix(deep,shallow,shallows)*(1.+.025*a+.018*b);
 vec3 color=mix(water,reflected,fresnel);vec3 halfDir=normalize(view+normalize(vec3(.65,.69,-.42)));color+=vec3(.70,.62,.44)*pow(max(0.,dot(n,halfDir)),170.)*.35;
 float fog=1.-exp(-pow(length(cameraPosition-waterWorld)*.001,2.));color=mix(color,vec3(.36,.48,.49),fog*.30);gl_FragColor=vec4(color,1.);
 #include <tonemapping_fragment>
 #include <colorspace_fragment>
 }`});}
// Isotropic spherical dimple height field. Fibonacci placement avoids a latitude/longitude grid.
const BALL_RADIUS=.021335;
let cachedDimples;
function dimpleTextureData(w=512,h=256){if(w===512&&h===256&&cachedDimples)return cachedDimples;const a=new Uint8Array(w*h*4),centres=[],n=336,cosR=Math.cos(.083),golden=Math.PI*(3-Math.sqrt(5));
 for(let i=0;i<n;i++){const y=1-2*(i+.5)/n,r=Math.sqrt(1-y*y),t=i*golden;centres.push([r*Math.cos(t),y,r*Math.sin(t)]);}
 const angles=Array.from({length:w},(_,x)=>[(Math.cos((x+.5)/w*2*Math.PI)),Math.sin((x+.5)/w*2*Math.PI)]);
 for(let y=0;y<h;y++){const t=(y+.5)/h*Math.PI,yy=Math.cos(t),r=Math.sin(t);const row=centres.filter(c=>yy*c[1]+r*Math.hypot(c[0],c[2])>=cosR);for(let x=0;x<w;x++){const xx=r*angles[x][0],zz=r*angles[x][1];let d=cosR;for(const c of row)d=Math.max(d,xx*c[0]+yy*c[1]+zz*c[2]);const k=Math.min(1,Math.max(0,(d-cosR)/(1-cosR))),v=Math.round(235-185*k*k*(3-2*k)),j=(y*w+x)*4;a[j]=a[j+1]=a[j+2]=v;a[j+3]=255;}}
 if(w===512&&h===256)cachedDimples=a;return a;
}
// Tangent-space normals from the spherical dimple profile. Texture samples are linear, not sRGB.
let cachedBallNormals,cachedBallContact;
function dimpleNormalData(w=1024,h=512){if(w===1024&&h===512&&cachedBallNormals)return cachedBallNormals;const src=dimpleTextureData(w,h),out=new Uint8Array(w*h*4),depth=.00062;
 const value=(x,y)=>src[(Math.max(0,Math.min(h-1,y))*w+(x+w)%w)*4]/185;
 for(let y=0;y<h;y++){const arcU=BALL_RADIUS*2*Math.PI/w*Math.max(.06,Math.sin((y+.5)*Math.PI/h)),arcV=BALL_RADIUS*Math.PI/h;for(let x=0;x<w;x++){const dx=depth*(value(x+1,y)-value(x-1,y))/(2*arcU),dy=depth*(value(x,y+1)-value(x,y-1))/(2*arcV),l=Math.hypot(dx,dy,1),i=(y*w+x)*4;out[i]=Math.round(127.5*(1-dx/l));out[i+1]=Math.round(127.5*(1-dy/l));out[i+2]=Math.round(127.5*(1+1/l));out[i+3]=255;}}
 if(w===1024&&h===512)cachedBallNormals=out;return out;
}
function ballColorData(){const a=dimpleTextureData(),out=new Uint8Array(a.length);for(let i=0;i<a.length;i+=4){const v=Math.round(255-20*(235-a[i])/185);out[i]=out[i+1]=out[i+2]=v;out[i+3]=255;}return out;}
function teeFiberData(n=256){const a=new Uint8Array(n*n*4);for(let y=0;y<n;y++)for(let x=0;x<n;x++){const r=rand(x*17+y*73),blade=rand(x*73+Math.floor(y/4)*127),v=Math.round(120+75*blade+55*r),i=(y*n+x)*4;a[i]=v;a[i+1]=Math.min(255,v+16);a[i+2]=Math.max(0,v-15);a[i+3]=255;}return a;}
function ballContactData(n=64){if(n===64&&cachedBallContact)return cachedBallContact;const a=new Uint8Array(n*n*4);for(let y=0;y<n;y++)for(let x=0;x<n;x++){const r=Math.hypot((x+.5-n/2)/(n/2),(y+.5-n/2)/(n/2)),i=(y*n+x)*4;a[i]=a[i+1]=a[i+2]=255;a[i+3]=Math.round(255*Math.max(0,1-r*r)**2.8);}if(n===64)cachedBallContact=a;return a;}
function ballOverlay(geo){const skip=new Set([...(geo.legacyBallDots||[]),...(geo.golfBalls||[]).map(b=>b.dot)]),dots=[];for(let i=0;i<geo.dots.length;i+=7)if(!skip.has(i))dots.push(...geo.dots.slice(i,i+7));return {...geo,tris:geo.legacyBallShadow!=null?geo.tris.slice(0,geo.legacyBallShadow):geo.tris,dots};}
function rangeTerrainMaterial(mat,aerial=false,kind='rough'){const m=mat.clone();if(aerial)m.bumpScale=0;else m.bumpScale*=.65;
 m.onBeforeCompile=shader=>{shader.vertexShader=shader.vertexShader.replace('#include <common>','#include <common>\nvarying vec2 r10Ground;').replace('#include <begin_vertex>','#include <begin_vertex>\nr10Ground=position.xz;');shader.fragmentShader=shader.fragmentShader.replace('#include <common>',`#include <common>
 varying vec2 r10Ground;
 float r10Hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
 float r10Noise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(r10Hash(i),r10Hash(i+vec2(1.,0.)),f.x),mix(r10Hash(i+vec2(0.,1.)),r10Hash(i+vec2(1.,1.)),f.x),f.y);}`);
 shader.fragmentShader=shader.fragmentShader.replace('#include <map_fragment>',`
 #ifdef USE_MAP
 vec2 uv2=vec2(vMapUv.x*.49+vMapUv.y*.37,-vMapUv.x*.37+vMapUv.y*.49)+vec2(.31,.73);
 vec3 tex1=texture2D(map,vMapUv).rgb;vec3 tex2=texture2D(map,uv2).rgb;
 // Cross-fade two independent sample directions; suppress repeated fine texture in distant views.
 float r10Footprint=length(fwidth(r10Ground));float r10Visibility=1.-smoothstep(.025,.32,r10Footprint);
 float r10Blend=.16+.68*r10Noise(r10Ground*.055);vec3 r10Detail=mix(tex1,tex2,r10Blend);
 diffuseColor.rgb*=mix(vec3(.76),r10Detail,.08+.92*r10Visibility);
 #endif
 diffuseColor.rgb*=.90+.12*r10Noise(r10Ground*.029)+.075*r10Noise(r10Ground*.11);
 diffuseColor.rgb*=mix(vec3(1.07,.94,.98),vec3(1.02,1.02,1.08),r10Noise(r10Ground*.018));
 ${kind==='sand'?`diffuseColor.rgb*=mix(vec3(.90,.89,.86),vec3(1.04,1.02,.98),r10Noise(r10Ground*.72));`:''}
 ${kind==='fairway'?`float r10StripeCoord=(r10Ground.y+2.6*sin(r10Ground.x*.072)+1.7*sin(r10Ground.y*.021+r10Ground.x*.033))*.255;float r10Stripe=sin(r10StripeCoord);float r10StripeAA=max(.09,fwidth(r10StripeCoord));diffuseColor.rgb*=mix(.98,1.02,smoothstep(-r10StripeAA,r10StripeAA,r10Stripe));`:''}`);};m.customProgramCacheKey=()=> 'r10-range-terrain-v030-'+kind;return m;}
class SceneRenderer{
 constructor(original,owner,T=root.R10Three){this.T=T;this.owner=owner;this.original=original;this.canvas=root.document.createElement('canvas');this.canvas.className='threeSceneCanvas';this.canvas.setAttribute('aria-hidden','true');this.canvas.style.pointerEvents='none';this.canvas.style.position='absolute';this.canvas.style.inset='0';this.canvas.style.width='100%';this.canvas.style.height='100%';original.parentNode.insertBefore(this.canvas,original);try{
  this.renderer=new T.WebGLRenderer({canvas:this.canvas,alpha:true,antialias:true,powerPreference:'high-performance'});this.renderer.setClearColor(0,0);this.renderer.outputColorSpace=T.SRGBColorSpace;this.renderer.toneMapping=T.ACESFilmicToneMapping;this.renderer.toneMappingExposure=1.08;
  this.scene=new T.Scene();this.scene.fog=new T.FogExp2(0xb6c9ce,.0032);this.camera=new T.PerspectiveCamera(60,1,.15,1800);this.static=new T.Group();this.dynamic=new T.Group();this.scene.add(this.static,this.dynamic);
  this.hemisphere=new T.HemisphereLight(0xc7e2ff,0x66774a,1.55);this.scene.add(this.hemisphere);this.sun=new T.DirectionalLight(0xffe8bb,2.85);this.sun.position.set(85,85,-55);this.scene.add(this.sun,this.sun.target);this.sun.castShadow=true;this.sun.shadow.mapSize.set(1024,1024);Object.assign(this.sun.shadow.camera,{left:-85,right:85,top:85,bottom:-85,near:1,far:340});this.sun.shadow.normalBias=.12;this.sun.shadow.bias=-.0004;this.renderer.shadowMap.type=T.PCFSoftShadowMap;this.renderer.shadowMap.autoUpdate=false;
  this.sky=this.makeSky();this.scene.add(this.sky);
  this.textures={};this.materials={};this.assetsReady=false;this.pendingAssets=0;
  const lit=(opts={})=>new T.MeshStandardMaterial({roughness:1,side:T.DoubleSide,...opts});
  for(const kind of surfaceKinds){this.materials[kind]=lit({vertexColors:true,roughness:kind==='water'?.19:1,metalness:kind==='water'?.12:0});}
  this.materials.solid=lit({vertexColors:true,roughness:.9});
  for(const kind of propKinds){const m=lit({vertexColors:true,roughness:kind==='window'||kind==='windscreen'?.24:kind==='metal'?.38:.92,metalness:kind==='metal'?.18:0});if(kind==='windscreen'){m.transparent=true;m.opacity=.38;m.depthWrite=false;}if(['stone','roof','timber','path'].includes(kind)){const tex=new T.DataTexture(propTextureData(kind),128,128,T.RGBAFormat);tex.colorSpace=T.SRGBColorSpace;tex.wrapS=tex.wrapT=T.RepeatWrapping;tex.magFilter=T.LinearFilter;tex.minFilter=T.LinearMipmapLinearFilter;tex.generateMipmaps=true;tex.needsUpdate=true;this.textures['prop-'+kind]=tex;m.map=tex;m.bumpMap=tex;m.bumpScale=kind==='stone'?.028:kind==='roof'?.025:.009;}this.materials[kind]=m;}
  this.rangeWater=makeRangeWater(T);this.reflectionTarget=null;this.reflectionCamera=new T.PerspectiveCamera();this.waterKey=null;this.materials.bark=lit({side:T.FrontSide});this.materials.crown=lit({side:T.FrontSide});
  this.materials.overlay=new T.MeshBasicMaterial({vertexColors:true,side:T.DoubleSide,polygonOffset:true,polygonOffsetFactor:-1,polygonOffsetUnits:-1});this.materials.line=new T.LineBasicMaterial({vertexColors:true});
  const assets=root.R10VisualAssets||{};const mappings={rough:['rough','grass'],fairway:['fairway'],green:['green'],tee:['tee'],sand:['sand'],bark:['bark'],crown:['crown'],water:['water']};
  for(const [kind,targets] of Object.entries(mappings)){if(!assets[kind])continue;this.pendingAssets++;new T.TextureLoader().load(assets[kind],tex=>{if(this.disposed){tex.dispose();return;}tex.colorSpace=T.SRGBColorSpace;tex.wrapS=tex.wrapT=T.RepeatWrapping;tex.magFilter=T.LinearFilter;tex.minFilter=T.LinearMipmapLinearFilter;tex.anisotropy=Math.min(8,this.renderer.capabilities.getMaxAnisotropy());this.textures[kind]=tex;for(const k of targets){const m=this.materials[k];m.map=tex;if(['sand','bark','water','crown'].includes(k)){m.bumpMap=tex;m.bumpScale=k==='water'?.08:k==='sand'?.025:k==='bark'?.07:.035;}m.needsUpdate=true;this.real?.rememberBaseline(k,m);}this.pendingAssets--;this.assetsReady=this.pendingAssets===0&&!this.assetError;if(this.assetsReady){this.real?.apply(this.preset);this.key=null;}if(this.assetsReady&&owner.lastData&&original.isConnected)owner.draw(owner.lastData,root.performance.now());},undefined,()=>{this.pendingAssets--;this.assetError=kind;});}
  // Existing alpha-cutout foliage atlas: reuse detailed foliage in the new range only.
  if(root.R10FoliageImage){new T.TextureLoader().load(root.R10FoliageImage,tex=>{if(this.disposed){tex.dispose();return;}tex.colorSpace=T.SRGBColorSpace;tex.anisotropy=Math.min(4,this.renderer.capabilities.getMaxAnisotropy());this.textures.foliage=tex;this.materials.foliage=new T.MeshStandardMaterial({map:tex,vertexColors:true,side:T.DoubleSide,alphaTest:.52,roughness:1,metalness:0});this.key=null;if(owner.lastData&&original.isConnected)owner.draw(owner.lastData,root.performance.now());},undefined,()=>{this.foliageError=true;});}
  this.canvas.addEventListener('webglcontextlost',e=>{e.preventDefault();this.lost=true;});original.style.opacity='0';if(root.R10RealAssets&&root.R10ThreeLoaders&&root.R10RealScene){this.real=new root.R10RealScene.RealScene(this,root.R10RealAssets,root.R10ThreeLoaders);this.real.load().catch(e=>{this.real.errors.push(String(e));this.real.complete=true;});}
 }catch(e){this.dispose();throw e;}}
 makeSky(){const T=this.T,m=new T.ShaderMaterial({side:T.BackSide,depthWrite:false,fog:false,toneMapped:false,uniforms:{rangeStyle:{value:0}},vertexShader:`varying vec3 vDir;void main(){vDir=position;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}`,fragmentShader:`varying vec3 vDir;uniform float rangeStyle;
 float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
 float noise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(hash(i),hash(i+vec2(1.,0.)),f.x),mix(hash(i+vec2(0.,1.)),hash(i+vec2(1.,1.)),f.x),f.y);}
 void main(){vec3 d=normalize(vDir);float h=max(0.,d.y);vec3 col=mix(vec3(.68,.79,.84),vec3(.085,.35,.66),pow(h,.57));vec2 p=d.xz/(.22+h)*2.5;float n=.53*noise(p)+.28*noise(p*2.03)+.13*noise(p*4.1)+.06*noise(p*8.2);float cloud=smoothstep(.49,.68,n)*smoothstep(.025,.17,h);col=mix(col,vec3(.90,.93,.96),cloud*.93);if(rangeStyle>.5){vec3 blue=mix(vec3(.68,.77,.83),vec3(.085,.31,.60),pow(h,.57));float layered=n+.035*noise(p*14.3);float detail=smoothstep(.47,.70,layered)*smoothstep(.025,.19,h);col=mix(blue,mix(vec3(.72,.77,.82),vec3(.98,.98,1.),smoothstep(.53,.72,layered)),detail*.96);}float sun=max(0.,dot(d,normalize(vec3(.65,.69,-.42))));col+=vec3(.18,.12,.045)*pow(sun,18.);col=mix(col,vec3(1.,.91,.67),smoothstep(.9993,.9998,sun));gl_FragColor=vec4(col,1.);
 #include <colorspace_fragment>
 }`});const mesh=new T.Mesh(new T.SphereGeometry(1200,32,16),m);mesh.frustumCulled=false;mesh.renderOrder=-100;return mesh;}
 addRangeForest(group,trees,quality){
  if(this.rangeAerial){this.addForest(group,trees,quality==='low'?'low':'medium');return;}
  if(!this.materials.foliage){this.addForest(group,trees,quality==='low'?'low':'medium');return;}
  // Preserve volumetric silhouettes near the tee; atlas cards fill the middle and distant forest.
  const T=this.T,near=[],b=bucket(),limit=quality==='low'?30:58;
  for(const t of trees){if(Math.hypot(t.x-this.camera.position.x,t.z-this.camera.position.z)<limit){near.push(t);continue;}
   const tone=.83+.17*rand(t.seed),species=t.species===1?1:0;
   for(const angle of [Math.PI/4,-Math.PI/4])for(const [u,v] of [[0,0],[1,0],[1,1],[0,0],[1,1],[0,1]]){
    const dx=(u-.5)*t.width;vertex(b,[-t.x+dx*Math.cos(angle),t.base+v*t.height,t.z+dx*Math.sin(angle)],[tone,tone,tone],[(u*.996+.002+species)*.5,v*.4995+.5005]);
   }
  }
  this.addForest(group,near,quality==='low'?'low':'medium');
  if(b.position.length){const mesh=new T.Mesh(this.meshGeometry(b,true),this.materials.foliage);mesh.userData.rangeFoliage=true;mesh.receiveShadow=true;mesh.castShadow=quality!=='low';group.add(mesh);}
 }
 addForest(group,trees,quality){if(!trees.length)return;if(this.preset==='experimental'&&this.real)trees=this.real.trees(group,trees,quality,this.camera.position);if(!trees.length)return;const T=this.T,high=quality==='high',low=quality==='low',branches=[],crowns=[],pines=[];
  function part(list,x,y,z,sx,sy,sz,color,seed,angle=0){list.push({x,y,z,sx,sy,sz,color,seed,angle});}
  for(const t of trees){const h=t.height,w=Math.max(.7,t.width*.46),x=t.x,z=t.z,y=t.base,k=t.seed,needle=t.species===1;const bark=new T.Color(0x786344).multiplyScalar(.8+.35*rand(k));part(branches,x,y+h*.28,z,Math.max(.10,h*.022),h*.56,Math.max(.10,h*.022),bark,k);
   const hue=this.rangeStyle?(needle?[0x355b39,0x48613a]:[0x506f38,0x637e40,0x436735,0x747e42])[Math.floor(rand(k+57)*(needle?2:4))]:(needle?0x3c6238:0x557f35);const color=new T.Color(hue).multiplyScalar(.78+.40*rand(k+6));if(needle){for(let j=0;j<(low?3:5);j++){const n=low?3:5,f=j/(n-1),r=w*(.94-f*.68);part(pines,x,y+h*(.36+f*.43),z,r,h*(.42-f*.15),r,color.clone().multiplyScalar(.83+f*.20),k+j);}}
   else{part(crowns,x,y+h*.71,z,w*.77,h*.29,w*.76,color,k);const n=low?3:high?9:6;for(let j=0;j<n;j++){const a=j*2.399+k,rad=w*(.42+.17*rand(k+j+9)),yy=h*(.59+.19*rand(k+j+17)),rr=w*(.38+.15*rand(k+j+31));const cx=x+Math.cos(a)*rad,cz=z+Math.sin(a)*rad;part(crowns,cx,y+yy,cz,rr,h*(.16+.08*rand(k+j+3)),rr*.92,color.clone().multiplyScalar(.80+.36*rand(k+j+41)),k+j,a);if(!low&&j<3){const from=new T.Vector3(x,y+h*.28,z),to=new T.Vector3(cx,y+yy*.92,cz),mid=from.clone().lerp(to,.5),v=to.clone().sub(from),q=new T.Quaternion().setFromUnitVectors(new T.Vector3(0,1,0),v.clone().normalize());branches.push({x:mid.x,y:mid.y,z:mid.z,sx:h*.011,sy:v.length(),sz:h*.011,color:bark,quaternion:q});}}}
  }
  const canopy=new T.SphereGeometry(1,high?14:10,high?10:7),pos=canopy.attributes.position;for(let i=0;i<pos.count;i++){const x=pos.getX(i),y=pos.getY(i),z=pos.getZ(i),s=1+.105*Math.sin(x*13+y*8)*Math.cos(z*11-y*7)+.06*Math.sin(x*21+z*15);pos.setXYZ(i,x*s,y*s,z*s);}canopy.computeVertexNormals();
  const batches=[[branches,new T.CylinderGeometry(.47,1,1,low?5:8),this.materials.bark],[crowns,canopy,this.materials.crown],[pines,new T.ConeGeometry(1,1,high?12:8,3),this.materials.crown]];
  const dummy=new T.Object3D();for(const [parts,geo,mat] of batches){if(!parts.length){geo.dispose();continue;}const mesh=new T.InstancedMesh(geo,mat,parts.length);for(let i=0;i<parts.length;i++){const p=parts[i];dummy.position.set(p.x,p.y,p.z);dummy.scale.set(p.sx,p.sy,p.sz);dummy.quaternion.identity();if(p.quaternion)dummy.quaternion.copy(p.quaternion);else dummy.rotation.y=p.angle||0;dummy.updateMatrix();mesh.setMatrixAt(i,dummy.matrix);mesh.setColorAt(i,p.color);}mesh.instanceMatrix.needsUpdate=true;mesh.instanceColor.needsUpdate=true;mesh.castShadow=true;mesh.receiveShadow=true;mesh.computeBoundingSphere();group.add(mesh);}
 }
 meshGeometry(b,normals=true){const T=this.T,g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(b.position,3));g.setAttribute('color',new T.Float32BufferAttribute(b.color,3));g.setAttribute('uv',new T.Float32BufferAttribute(b.uv,2));if(normals){g.computeVertexNormals();const n=g.attributes.normal;if(normals==='terrain'){const sum=new Map(),keys=[];for(let i=0;i<n.count;i++){const p=g.attributes.position,k=[p.getX(i),p.getY(i),p.getZ(i)].map(x=>Math.round(x*1000)).join('/');keys.push(k);const sign=n.getY(i)<0?-1:1,v=sum.get(k)||[0,0,0];v[0]+=n.getX(i)*sign;v[1]+=n.getY(i)*sign;v[2]+=n.getZ(i)*sign;sum.set(k,v);}for(let i=0;i<n.count;i++){const v=sum.get(keys[i]),l=Math.hypot(...v)||1;n.setXYZ(i,v[0]/l,v[1]/l,v[2]/l);}}}return g;}
 clear(group){for(const obj of group.children.slice()){group.remove(obj);if(!obj.userData.sharedGeometry)obj.geometry?.dispose();if(obj.isInstancedMesh)obj.dispose();if(obj.userData.ownMaterial)obj.material.dispose();}}
 addTriangles(group,geo,isDynamic,quality='medium'){const T=this.T,converted=convert(geo);for(const [kind,b] of Object.entries(converted)){if(!b.position.length||kind==='leaves')continue;let material=isDynamic&&kind==='solid'?this.materials.overlay:this.materials[kind];const rangeSurface=!isDynamic&&geo.naturalRange;let owned=false;if(rangeSurface&&['fairway','grass','rough','green','sand'].includes(kind)){material=rangeTerrainMaterial(material,this.rangeAerial,kind);owned=true;}if(rangeSurface&&kind==='tee'){material=material.clone();owned=true;if(!this.textures.teeFibers){const t=new T.DataTexture(teeFiberData(),256,256,T.RGBAFormat);t.colorSpace=T.SRGBColorSpace;t.wrapS=t.wrapT=T.RepeatWrapping;t.repeat.set(9,9);t.magFilter=T.LinearFilter;t.minFilter=T.LinearMipmapLinearFilter;t.generateMipmaps=true;t.needsUpdate=true;this.textures.teeFibers=t;}material.map=this.textures.teeFibers;material.bumpMap=this.textures.teeFibers;material.bumpScale=.0014;}if(rangeSurface&&kind==='water'){material=this.rangeWater;}const mesh=new T.Mesh(this.meshGeometry(b,surfaceKinds.includes(kind)?'terrain':true),material);if(owned)mesh.userData.ownMaterial=true;if(rangeSurface&&kind==='water')mesh.userData.rangeWater=true;if(rangeSurface&&propKinds.includes(kind))mesh.userData.facilityProp=kind;mesh.receiveShadow=!isDynamic;mesh.castShadow=!isDynamic&&(kind==='solid'||propKinds.includes(kind)&&kind!=='path'&&kind!=='windscreen');if(!isDynamic&&['fairway','rough','tee','grass'].includes(kind))mesh.userData.grassSurface=kind==='grass'?'rough':kind;group.add(mesh);}if(!isDynamic){if(geo.naturalRange){this.addRangeForest(group,converted.trees,quality);if(geo.externalCart)this.real?.addFacilityCarts(group,quality);}else this.addForest(group,converted.trees,quality);group.updateMatrixWorld(true);if(this.preset==='experimental')this.real?.grass(group,quality,this.camera.position);}}
 addLines(group,arr){if(!arr.length)return;group.add(new this.T.LineSegments(this.meshGeometry(convertLinear(arr),false),this.materials.line));}
 addGolfBalls(group,balls,quality){const T=this.T;if(!balls?.length)return;if(!this.materials.golfBall){const make=(data,w,h)=>{const t=new T.DataTexture(data,w,h,T.RGBAFormat);t.wrapS=T.RepeatWrapping;t.wrapT=T.ClampToEdgeWrapping;t.magFilter=T.LinearFilter;t.minFilter=T.LinearMipmapLinearFilter;t.generateMipmaps=true;t.needsUpdate=true;return t;};const tex=make(dimpleNormalData(),1024,512),contact=make(ballContactData(),64,64),color=make(ballColorData(),512,256);color.colorSpace=T.SRGBColorSpace;this.textures.ballColor=color;this.textures.ballDimples=tex;this.textures.ballContact=contact;this.materials.golfBall=new T.MeshStandardMaterial({color:0xf5f5ef,roughness:.47,metalness:0,map:color,normalMap:tex,normalScale:new T.Vector2(1.35,1.35)});this.materials.ballContact=new T.MeshBasicMaterial({color:0x10180d,map:contact,transparent:true,opacity:.83,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-1,polygonOffsetUnits:-1});}
  this.ballGeometryCache ||= {};const sphereKey=quality==='low'?'low':'detail';const sphere=this.ballGeometryCache[sphereKey] ||= new T.SphereGeometry(BALL_RADIUS,quality==='low'?24:64,quality==='low'?16:40);const contactGeometry=this.ballGeometryCache.contact ||= new T.PlaneGeometry(BALL_RADIUS*4.8,BALL_RADIUS*3.9);const placed=[];for(const b of balls){if(b.hidden||placed.some(p=>Math.hypot(...p.map((v,i)=>v-b.position[i]))<BALL_RADIUS))continue;placed.push(b.position);const m=new T.Mesh(sphere,this.materials.golfBall);m.position.set(...xyz(...b.position));m.userData.sharedGeometry=true;m.userData.golfBall=true;m.userData.radiusMetres=BALL_RADIUS;m.receiveShadow=true;group.add(m);if(b.ground!=null){const shadow=new T.Mesh(contactGeometry,this.materials.ballContact);shadow.rotation.x=-Math.PI/2;shadow.position.set(-b.position[0]+.006,b.ground+.0006,b.position[2]+.003);shadow.userData.sharedGeometry=true;shadow.userData.ballContact=true;group.add(shadow);}}
 }
 addDots(group,arr,ratio){const T=this.T; // Fixed pixel-size circular points, matching the existing HUD marker sizes.
  if(!arr.length)return;const b=convertLinear(arr),g=this.meshGeometry(b,false),sizes=[];for(let i=6;i<arr.length;i+=7)sizes.push(arr[i]*ratio);g.setAttribute('size',new T.Float32BufferAttribute(sizes,1));const m=new T.ShaderMaterial({vertexShader:'attribute float size; attribute vec3 color; varying vec3 col; void main(){col=color;gl_PointSize=size;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',fragmentShader:'varying vec3 col; void main(){float d=length(gl_PointCoord-.5);if(d>.5)discard;gl_FragColor=vec4(col,1.); #include <colorspace_fragment>\n}'.replace('; #include',';\n#include')});const p=new T.Points(g,m);p.userData.ownMaterial=true;group.add(p);}
 updateReflection(cam,quality,w,h){const T=this.T,r=this.renderer,water=this.static.children.filter(o=>o.userData.rangeWater);if(!water.length)return;const uniforms=this.rangeWater.uniforms;
  if(quality==='low'||cam.eye[1]<=WATER_Y){uniforms.hasReflection.value=0;this.waterKey=null;return;}
  const max=quality==='high'?768:384,scale=Math.min(1,max/Math.max(w,h)),rw=Math.max(64,Math.round(w*scale)),rh=Math.max(64,Math.round(h*scale));
  if(!this.reflectionTarget){this.reflectionTarget=new T.WebGLRenderTarget(rw,rh,{depthBuffer:true});}else if(this.reflectionTarget.width!==rw||this.reflectionTarget.height!==rh){this.reflectionTarget.setSize(rw,rh);this.waterKey=null;}
  const key=[this.key,...cam.eye,...cam.at,w,h,quality].map(v=>typeof v==='number'?v.toFixed(3):v).join('/');if(this.waterKey===key)return;
  const c=this.reflectionCamera;c.copy(this.camera,false);c.position.set(...mirrorPoint(xyz(...cam.eye)));const up=xyz(...cam.u);c.up.set(up[0],-up[1],up[2]);c.lookAt(...mirrorPoint(xyz(...cam.at)));c.updateMatrixWorld(true);uniforms.reflectionMatrix.value.multiplyMatrices(c.projectionMatrix,c.matrixWorldInverse);
  const target=r.getRenderTarget(),clip=r.clippingPlanes,shadow=r.shadowMap.needsUpdate,sky=this.sky.position.clone(),dynamic=this.dynamic.visible;for(const mesh of water)mesh.visible=false;this.dynamic.visible=false;
  try{r.clippingPlanes=[new T.Plane(new T.Vector3(0,1,0),-WATER_Y)];r.shadowMap.needsUpdate=false;this.sky.position.copy(c.position);r.setRenderTarget(this.reflectionTarget);r.clear();r.render(this.scene,c);uniforms.reflection.value=this.reflectionTarget.texture;uniforms.hasReflection.value=1;this.waterKey=key;this.reflectionPasses=(this.reflectionPasses||0)+1;}
  finally{r.setRenderTarget(target);r.clippingPlanes=clip;r.shadowMap.needsUpdate=shadow;this.sky.position.copy(sky);this.dynamic.visible=dynamic;for(const mesh of water)mesh.visible=true;}
 }
 pauseWater(){if(this.waterRAF!=null){root.cancelAnimationFrame?.(this.waterRAF);this.waterRAF=null;}}
 animateWater(){if(this.waterRAF!=null||!root.requestAnimationFrame)return;const tick=t=>{this.waterRAF=null;if(this.disposed||this.lost||!this.naturalRange||this.waterQuality!=='high'||!this.canvas.isConnected||!this.canvas.getClientRects().length||root.document.hidden)return;if(t-(this.waterFrame||0)>=100){this.waterFrame=t;this.rangeWater.uniforms.time.value=t*.001;this.renderer.render(this.scene,this.camera);}this.waterRAF=root.requestAnimationFrame(tick);};this.waterRAF=root.requestAnimationFrame(tick);}
 draw({key,ground,dynamic,cam,quality,w,h,ratio,moving=false}){if(this.lost)throw Error('Three.js GPU context lost');const r=this.renderer; if(this.w!==w||this.h!==h){r.setSize(w,h,false);this.w=w;this.h=h;}
  const shadows=quality!=='low';r.shadowMap.enabled=shadows;this.camera.aspect=w/h;this.camera.updateProjectionMatrix();this.camera.position.set(...xyz(...cam.eye));this.camera.up.set(...xyz(...cam.u));this.camera.lookAt(...xyz(...cam.at));this.sky.position.copy(this.camera.position);
  const preset=resolvePreset(this.owner.lastData?.preset||root.R10GraphicsPreset),rangeStyle=preset==='hybrid'&&!this.owner.lastData?.scene;if(this.preset!==preset||this.rangeStyle!==rangeStyle){this.preset=preset;this.rangeStyle=rangeStyle;this.real?.apply(preset);this.key=null;this.shadowCenter=null;}const policy=rangeFramePolicy(quality,rangeStyle&&moving);if(rangeStyle&&moving)this.pauseWater();const aerial=rangeStyle&&(moving&&this.key&&typeof this.rangeAerial==='boolean'?this.rangeAerial:cam.eye[1]>35);this.camera.near=rangeStyle?rangeNearPlane(cam.eye[1]):.15;this.camera.updateProjectionMatrix();if(aerial!==this.rangeAerial)this.shadowCenter=null;this.rangeAerial=aerial;const fullKey=key+'/'+preset+(this.rangeAerial?'/aerial':'');if(this.key!==fullKey){this.clear(this.static);const geo=ground(true,preset);this.addTriangles(this.static,geo,false,quality);this.addLines(this.static,geo.lines);this.naturalRange=!!geo.naturalRange;this.key=fullKey;this.waterKey=null;r.shadowMap.needsUpdate=true;}
  const shadowType=this.naturalRange?this.T.PCFShadowMap:this.T.PCFSoftShadowMap;if(r.shadowMap.type!==shadowType){r.shadowMap.type=shadowType;r.shadowMap.needsUpdate=true;this.scene.traverse(o=>{for(const m of (Array.isArray(o.material)?o.material:o.material?[o.material]:[]))m.needsUpdate=true;});for(const m of Object.values(this.materials))m.needsUpdate=true;}this.sun.shadow.radius=this.naturalRange?2.0:1;this.sun.shadow.intensity=this.naturalRange?.80:1;
  this.sky.material.uniforms.rangeStyle.value=this.naturalRange?1:0;this.scene.fog.density=this.naturalRange?(this.rangeAerial?.00058:.00175):.0032;this.sun.intensity=2.85;this.hemisphere.intensity=this.naturalRange?1.43:1.55;r.toneMappingExposure=this.naturalRange?1.025:1.08;this.sun.shadow.normalBias=this.naturalRange?.095:.12;const shadowSpan=this.naturalRange?(this.rangeAerial?235:82):85;Object.assign(this.sun.shadow.camera,{left:-shadowSpan,right:shadowSpan,top:shadowSpan,bottom:-shadowSpan});const center=this.rangeAerial?[-cam.at[0],0,cam.at[2]]:[-cam.eye[0],0,cam.eye[2]];if(shadows&&(!this.shadowCenter||(!this.naturalRange||policy.shadowRecentre)&&Math.hypot(center[0]-this.shadowCenter[0],center[2]-this.shadowCenter[2])>45)){this.shadowCenter=center;if(this.naturalRange){const scale=this.rangeAerial?3.1:1;this.sun.position.set(center[0]+100*scale,78*scale,center[2]-64*scale);}else this.sun.position.set(center[0]+85,(this.rangeAerial?190:85)+cam.eye[1]*.12,center[2]-55);this.sun.target.position.set(...center);this.sun.shadow.camera.far=this.naturalRange&&this.rangeAerial?850:this.rangeAerial?720:340;this.sun.shadow.camera.updateProjectionMatrix();r.shadowMap.needsUpdate=true;}
  this.clear(this.dynamic);const displayed=preset==='classic'?dynamic:ballOverlay(dynamic);this.addTriangles(this.dynamic,displayed,true);this.addLines(this.dynamic,displayed.lines);this.addDots(this.dynamic,displayed.dots,ratio);if(preset!=='classic')this.addGolfBalls(this.dynamic,dynamic.golfBalls,quality);if(this.naturalRange){this.waterQuality=quality;this.rangeWater.uniforms.time.value=(root.performance?.now()||0)*.001;if(policy.reflection)this.updateReflection(cam,quality,w,h);else{this.rangeWater.uniforms.hasReflection.value=0;this.waterKey=null;}}else this.pauseWater();r.render(this.scene,this.camera);if(this.naturalRange&&policy.idleWater)this.animateWater();else this.pauseWater();}
 dispose(){this.disposed=true;this.pauseWater();this.reflectionTarget?.dispose();this.rangeWater?.dispose();if(this.static)this.clear(this.static);if(this.dynamic)this.clear(this.dynamic);for(const g of Object.values(this.ballGeometryCache||{}))g.dispose();this.real?.dispose();this.sky?.geometry.dispose();this.sky?.material.dispose();for(const m of Object.values(this.materials||{}))m.dispose();for(const t of Object.values(this.textures||{}))t.dispose();this.renderer?.dispose();this.renderer?.forceContextLoss();this.canvas?.remove();if(this.original?.style)this.original.style.opacity='';}
}
function resolvePreset(p){return ['classic','hybrid','experimental'].includes(p)?p:'hybrid';}
const api={rangeFramePolicy,BALL_RADIUS,dimpleTextureData,dimpleNormalData,ballContactData,ballColorData,teeFiberData,ballOverlay,rangeNearPlane,propTextureData,mirrorPoint,resolvePreset,SceneRenderer,xyz,srgb,convert,convertLinear,textureData};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.R10ThreeScene=api;
})(typeof globalThis!=='undefined'?globalThis:this);
