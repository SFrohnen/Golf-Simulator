/* Three.js presentation adapter. No changes to shots, terrain data or scoring. */
(function(root){'use strict';
const xyz=(x,y,z)=>[-x,y,z]; // Legacy camera is left-handed; reflect east to match Three's right-handed camera.
const srgb=v=>{v=Math.max(0,Math.min(1,v));return v<=.04045?v/12.92:Math.pow((v+.055)/1.055,2.4);};
function bucket(){return {position:[],color:[],uv:[]};}
function vertex(b,p,c,uv=[0,0]){b.position.push(...xyz(...p));b.color.push(...c.map(srgb));b.uv.push(...uv);}
function classify(mat){return ({'-1':'grass','-2':'sand','-3':'fairway','-4':'green','-5':'rough','-6':'tee',2:'water',3:'stone',4:'roof',5:'timber',6:'window',7:'windscreen',8:'path',9:'metal'})[mat]||'solid';}
const surfaceKinds=['grass','fairway','green','rough','tee','sand','water'];
const propKinds=['stone','roof','timber','window','windscreen','path','metal'];
const rand=(v)=>{const n=Math.sin(v*127.1+311.7)*43758.5453;return n-Math.floor(n);};
function convert(geo){
 const out=Object.fromEntries([...surfaceKinds,...propKinds,'solid','leaves'].map(k=>[k,bucket()])),a=geo.tris;
 Object.defineProperty(out,'trees',{value:[],enumerable:false});
 for(let i=0;i<a.length;){let mat=a[i+6];
  if(mat < -9){ // A legacy tree card encodes width, UV, species and tone in six vertices.
   const width=-mat-10;
   out.trees.push({x:-a[i],z:a[i+2],base:a[i+1],height:a[i+15]-a[i+1],width,species:Math.floor(a[i+5]),seed:a[i]*17+a[i+2]*31+a[i+5]*91});
   for(const angle of [Math.PI/4,-Math.PI/4]) for(let j=0;j<6;j++){
    const k=i+j*7,u=a[k+3],v=a[k+4],s=Math.floor(a[k+5]),tone=.92+(a[k+5]-s)*.16;
    vertex(out.leaves,[a[k]+(u-.5)*width*Math.cos(angle),a[k+1],a[k+2]+(u-.5)*width*Math.sin(angle)],[tone,tone,tone],[(u*.996+.002+s)*.5,v*.4995+.5005]);
   }i+=42;continue;
  }
  // Water triangles use the existing blue palette; solid decorative geometry stays separate.
  const kind=mat===1&&a[i+3]<.3&&a[i+4]>.35&&a[i+5]>.52?'water':classify(mat),b=out[kind];
  const winding=(a[i+7]-a[i])*(a[i+16]-a[i+2])-(a[i+9]-a[i+2])*(a[i+14]-a[i]);
  const indices=surfaceKinds.includes(kind)&&winding<0?[0,2,1]:[0,1,2];
  const dx=a[i+7]-a[i],dy=a[i+8]-a[i+1],dz=a[i+9]-a[i+2],ex=a[i+14]-a[i],ey=a[i+15]-a[i+1],ez=a[i+16]-a[i+2],nx=Math.abs(dy*ez-dz*ey),ny=Math.abs(dz*ex-dx*ez),nz=Math.abs(dx*ey-dy*ex);
  for(const j of indices){const k=i+j*7;let uv=[a[k]/(kind==='green'?1.1:kind==='rough'?3.5:2.5),a[k+2]/(kind==='green'?1.1:kind==='rough'?3.5:2.5)];if(propKinds.includes(kind)){const scale=kind==='path'?2:kind==='roof'?1.2:kind==='stone'?1.5:.85;uv=ny>=nx&&ny>=nz?[a[k]/scale,a[k+2]/scale]:nx>nz?[a[k+2]/scale,a[k+1]/scale]:[a[k]/scale,a[k+1]/scale];}vertex(b,a.slice(k,k+3),a.slice(k+3,k+6),uv);}i+=21;
 }
 return out;
}
function convertLinear(a){const b=bucket();for(let i=0;i<a.length;i+=7)vertex(b,a.slice(i,i+3),a.slice(i+3,i+6));return b;}
function textureData(kind,n=128){const a=new Uint8Array(n*n*4),r=(x,y)=>{const f=Math.sin(x*127.1+y*311.7)*43758.5453;return f-Math.floor(f);};for(let y=0;y<n;y++)for(let x=0;x<n;x++){const v=r(x,y),coarse=r(Math.floor(x/8),Math.floor(y/8)),blade=r(x,Math.floor(y/3));let l=kind==='sand'?194+49*v+12*coarse:158+37*v+28*blade+27*coarse;let i=(y*n+x)*4;for(let k=0;k<3;k++)a[i+k]=Math.round(l);a[i+3]=255;}return a;}
function propTextureData(kind,n=128){const a=new Uint8Array(n*n*4);for(let y=0;y<n;y++)for(let x=0;x<n;x++){const u=x/n,v=y/n,noise=rand(x+y*n),row=Math.floor(v*5),stagger=(row%2)*.5,brick=(u*4+stagger)%1,joint=(v*5)%1;let l=224+noise*27;
 if(kind==='stone')l=(joint<.045||brick<.035)?150:212+22*rand(row*17+Math.floor(u*4+stagger))+noise*17;
 if(kind==='roof'){const q=(u*8+(row%2)*.5)%1;l=(joint<.07?150:198+42*Math.sin(q*Math.PI))+noise*12;}
 if(kind==='timber')l=205+21*Math.sin(u*125+2*Math.sin(v*11))+noise*24;
 if(kind==='path')l=181+64*noise+10*rand(Math.floor(x/3)+Math.floor(y/3)*51);
 const k=(x+y*n)*4;for(let j=0;j<3;j++)a[k+j]=Math.round(Math.max(0,Math.min(255,l)));a[k+3]=255;}return a;}
// A planar mirror camera and projective texture matrix, shared by the two coplanar ponds.
const WATER_Y=.048;
function mirrorPoint(p,y=WATER_Y){return [p[0],2*y-p[1],p[2]];}
function makeRangeWater(T){return new T.ShaderMaterial({side:T.DoubleSide,uniforms:{reflection:{value:null},reflectionMatrix:{value:new T.Matrix4()},time:{value:0},hasReflection:{value:0}},vertexShader:`varying vec3 waterWorld;varying vec4 reflectionPos;uniform mat4 reflectionMatrix;void main(){vec4 world=modelMatrix*vec4(position,1.);waterWorld=world.xyz;reflectionPos=reflectionMatrix*world;gl_Position=projectionMatrix*viewMatrix*world;}`,fragmentShader:`varying vec3 waterWorld;varying vec4 reflectionPos;uniform sampler2D reflection;uniform float time;uniform float hasReflection;
 void main(){vec2 p=waterWorld.xz;float a=sin(p.x*2.3+p.y*1.7+time*1.35),b=cos(p.x*.73-p.y*2.8-time*.92);vec3 n=normalize(vec3(.036*a,1.,.046*b));vec3 view=normalize(cameraPosition-waterWorld);float fresnel=.20+.70*pow(1.-clamp(dot(view,n),0.,1.),4.);vec2 uv=reflectionPos.xy/max(.001,reflectionPos.w)*.5+.5;uv+=vec2(a,b)*.006;vec3 sky=vec3(.28,.42,.50);vec3 reflected=mix(sky,texture2D(reflection,clamp(uv,.002,.998)).rgb,hasReflection);vec3 water=vec3(.045,.14,.115)*(1.+.12*a+.06*b);vec3 color=mix(water,reflected,fresnel);vec3 halfDir=normalize(view+normalize(vec3(.65,.69,-.42)));color+=vec3(.65,.55,.34)*pow(max(0.,dot(n,halfDir)),110.)*.5;float fog=1.-exp(-pow(length(cameraPosition-waterWorld)*.001,2.));color=mix(color,vec3(.36,.48,.49),fog*.40);gl_FragColor=vec4(color,1.);
 #include <tonemapping_fragment>
 #include <colorspace_fragment>
 }`});}
function rangeTerrainMaterial(mat){const m=mat.clone();m.onBeforeCompile=shader=>{shader.vertexShader=shader.vertexShader.replace('#include <common>','#include <common>\nvarying vec2 r10Ground;').replace('#include <begin_vertex>','#include <begin_vertex>\nr10Ground=position.xz;');shader.fragmentShader=shader.fragmentShader.replace('#include <common>',`#include <common>
 varying vec2 r10Ground;
 float r10Hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
 float r10Noise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(r10Hash(i),r10Hash(i+vec2(1.,0.)),f.x),mix(r10Hash(i+vec2(0.,1.)),r10Hash(i+vec2(1.,1.)),f.x),f.y);}`);
 shader.fragmentShader=shader.fragmentShader.replace('#include <map_fragment>',`#include <map_fragment>
 #ifdef USE_MAP
 vec2 uv2=vec2(vMapUv.x*.71+vMapUv.y*.29,-vMapUv.x*.29+vMapUv.y*.71)+vec2(.31,.73);
 vec3 tex2=texture2D(map,uv2).rgb;
 // The secondary sample is normalized toward a neutral detail factor to avoid replacing RGB turf colors.
 diffuseColor.rgb*=mix(vec3(1.),clamp(tex2/vec3(.67),vec3(.82),vec3(1.15)),.36);
 #endif
 diffuseColor.rgb*=.93+.14*r10Noise(r10Ground*.041)+.05*r10Noise(r10Ground*.13);`);};m.customProgramCacheKey=()=> 'r10-range-terrain-v022';return m;}
class SceneRenderer{
 constructor(original,owner,T=root.R10Three){this.T=T;this.owner=owner;this.original=original;this.canvas=root.document.createElement('canvas');this.canvas.className='threeSceneCanvas';this.canvas.setAttribute('aria-hidden','true');this.canvas.style.pointerEvents='none';this.canvas.style.position='absolute';this.canvas.style.inset='0';this.canvas.style.width='100%';this.canvas.style.height='100%';original.parentNode.insertBefore(this.canvas,original);try{
  this.renderer=new T.WebGLRenderer({canvas:this.canvas,alpha:true,antialias:true,powerPreference:'high-performance'});this.renderer.setClearColor(0,0);this.renderer.outputColorSpace=T.SRGBColorSpace;this.renderer.toneMapping=T.ACESFilmicToneMapping;this.renderer.toneMappingExposure=1.08;
  this.scene=new T.Scene();this.scene.fog=new T.FogExp2(0xb6c9ce,.0032);this.camera=new T.PerspectiveCamera(60,1,.15,1800);this.static=new T.Group();this.dynamic=new T.Group();this.scene.add(this.static,this.dynamic);
  this.scene.add(new T.HemisphereLight(0xc7e2ff,0x66774a,1.55));this.sun=new T.DirectionalLight(0xffe8bb,2.85);this.sun.position.set(85,85,-55);this.scene.add(this.sun,this.sun.target);this.sun.castShadow=true;this.sun.shadow.mapSize.set(1024,1024);Object.assign(this.sun.shadow.camera,{left:-85,right:85,top:85,bottom:-85,near:1,far:340});this.sun.shadow.normalBias=.12;this.sun.shadow.bias=-.0004;this.renderer.shadowMap.type=T.PCFSoftShadowMap;this.renderer.shadowMap.autoUpdate=false;
  this.sky=this.makeSky();this.scene.add(this.sky);
  this.textures={};this.materials={};this.assetsReady=false;this.pendingAssets=0;
  const lit=(opts={})=>new T.MeshStandardMaterial({roughness:1,side:T.DoubleSide,...opts});
  for(const kind of surfaceKinds){this.materials[kind]=lit({vertexColors:true,roughness:kind==='water'?.19:1,metalness:kind==='water'?.12:0});}
  this.materials.solid=lit({vertexColors:true,roughness:.9});
  for(const kind of propKinds){const m=lit({vertexColors:true,roughness:kind==='window'||kind==='windscreen'?.24:kind==='metal'?.38:.92,metalness:kind==='metal'?.18:0});if(kind==='windscreen'){m.transparent=true;m.opacity=.38;m.depthWrite=false;}if(['stone','roof','timber','path'].includes(kind)){const tex=new T.DataTexture(propTextureData(kind),128,128,T.RGBAFormat);tex.colorSpace=T.SRGBColorSpace;tex.wrapS=tex.wrapT=T.RepeatWrapping;tex.magFilter=T.LinearFilter;tex.minFilter=T.LinearMipmapLinearFilter;tex.generateMipmaps=true;tex.needsUpdate=true;this.textures['prop-'+kind]=tex;m.map=tex;m.bumpMap=tex;m.bumpScale=kind==='stone'?.028:kind==='roof'?.025:.009;}this.materials[kind]=m;}
  this.rangeWater=makeRangeWater(T);this.reflectionTarget=null;this.reflectionCamera=new T.PerspectiveCamera();this.waterKey=null;this.materials.bark=lit({side:T.FrontSide});this.materials.crown=lit({side:T.FrontSide});
  this.materials.overlay=new T.MeshBasicMaterial({vertexColors:true,side:T.DoubleSide,polygonOffset:true,polygonOffsetFactor:-1,polygonOffsetUnits:-1});this.materials.line=new T.LineBasicMaterial({vertexColors:true});
  const assets=root.R10VisualAssets||{};const mappings={rough:['rough','grass'],fairway:['fairway'],green:['green'],tee:['tee'],sand:['sand'],bark:['bark'],crown:['crown'],water:['water']};
  for(const [kind,targets] of Object.entries(mappings)){if(!assets[kind])continue;this.pendingAssets++;new T.TextureLoader().load(assets[kind],tex=>{if(this.disposed){tex.dispose();return;}tex.colorSpace=T.SRGBColorSpace;tex.wrapS=tex.wrapT=T.RepeatWrapping;tex.magFilter=T.LinearFilter;tex.minFilter=T.LinearMipmapLinearFilter;tex.anisotropy=Math.min(8,this.renderer.capabilities.getMaxAnisotropy());this.textures[kind]=tex;for(const k of targets){const m=this.materials[k];m.map=tex;if(['sand','bark','water','crown'].includes(k)){m.bumpMap=tex;m.bumpScale=k==='water'?.08:k==='sand'?.025:k==='bark'?.07:.035;}m.needsUpdate=true;this.real?.rememberBaseline(k,m);}this.pendingAssets--;this.assetsReady=this.pendingAssets===0&&!this.assetError;if(this.assetsReady){this.real?.apply(this.preset);this.key=null;}if(this.assetsReady&&owner.lastData&&original.isConnected)owner.draw(owner.lastData,root.performance.now());},undefined,()=>{this.pendingAssets--;this.assetError=kind;});}
  // Existing alpha-cutout foliage atlas: reuse detailed foliage in the new range only.
  if(root.R10FoliageImage){new T.TextureLoader().load(root.R10FoliageImage,tex=>{if(this.disposed){tex.dispose();return;}tex.colorSpace=T.SRGBColorSpace;tex.anisotropy=Math.min(4,this.renderer.capabilities.getMaxAnisotropy());this.textures.foliage=tex;this.materials.foliage=new T.MeshStandardMaterial({map:tex,vertexColors:true,side:T.DoubleSide,alphaTest:.52,roughness:1,metalness:0});this.key=null;if(owner.lastData&&original.isConnected)owner.draw(owner.lastData,root.performance.now());},undefined,()=>{this.foliageError=true;});}
  this.canvas.addEventListener('webglcontextlost',e=>{e.preventDefault();this.lost=true;});original.style.opacity='0';if(root.R10RealAssets&&root.R10ThreeLoaders&&root.R10RealScene){this.real=new root.R10RealScene.RealScene(this,root.R10RealAssets,root.R10ThreeLoaders);this.real.load().catch(e=>{this.real.errors.push(String(e));this.real.complete=true;});}
 }catch(e){this.dispose();throw e;}}
 makeSky(){const T=this.T,m=new T.ShaderMaterial({side:T.BackSide,depthWrite:false,fog:false,toneMapped:false,uniforms:{rangeStyle:{value:0}},vertexShader:`varying vec3 vDir;void main(){vDir=position;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}`,fragmentShader:`varying vec3 vDir;uniform float rangeStyle;
 float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
 float noise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(hash(i),hash(i+vec2(1.,0.)),f.x),mix(hash(i+vec2(0.,1.)),hash(i+vec2(1.,1.)),f.x),f.y);}
 void main(){vec3 d=normalize(vDir);float h=max(0.,d.y);vec3 col=mix(vec3(.68,.79,.84),vec3(.085,.35,.66),pow(h,.57));vec2 p=d.xz/(.22+h)*2.5;float n=.53*noise(p)+.28*noise(p*2.03)+.13*noise(p*4.1)+.06*noise(p*8.2);float cloud=smoothstep(.49,.68,n)*smoothstep(.025,.17,h);col=mix(col,vec3(.90,.93,.96),cloud*.93);if(rangeStyle>.5){vec3 blue=mix(vec3(.63,.76,.82),vec3(.065,.29,.60),pow(h,.57));float detail=smoothstep(.48,.65,n)*smoothstep(.035,.16,h);col=mix(blue,mix(vec3(.81,.86,.90),vec3(.97,.98,1.),smoothstep(.54,.72,n)),detail*.96);}float sun=max(0.,dot(d,normalize(vec3(.65,.69,-.42))));col+=vec3(.18,.12,.045)*pow(sun,18.);col=mix(col,vec3(1.,.91,.67),smoothstep(.9993,.9998,sun));gl_FragColor=vec4(col,1.);
 #include <colorspace_fragment>
 }`});const mesh=new T.Mesh(new T.SphereGeometry(1200,32,16),m);mesh.frustumCulled=false;mesh.renderOrder=-100;return mesh;}
 addRangeForest(group,trees,quality){
  if(this.rangeAerial){this.addForest(group,trees,'low');return;}
  if(!this.materials.foliage){this.addForest(group,trees,quality);return;}
  // Preserve volumetric silhouettes near the tee; atlas cards fill the middle and distant forest.
  const T=this.T,near=[],b=bucket(),limit=quality==='high'?62:quality==='medium'?48:35;
  for(const t of trees){if(Math.hypot(t.x,t.z)<limit){near.push(t);continue;}
   const tone=.83+.17*rand(t.seed),species=t.species===1?1:0;
   for(const angle of [Math.PI/4,-Math.PI/4])for(const [u,v] of [[0,0],[1,0],[1,1],[0,0],[1,1],[0,1]]){
    const dx=(u-.5)*t.width;vertex(b,[-t.x+dx*Math.cos(angle),t.base+v*t.height,t.z+dx*Math.sin(angle)],[tone,tone,tone],[(u*.996+.002+species)*.5,v*.4995+.5005]);
   }
  }
  this.addForest(group,near,quality);
  if(b.position.length){const mesh=new T.Mesh(this.meshGeometry(b,true),this.materials.foliage);mesh.userData.rangeFoliage=true;mesh.receiveShadow=true;mesh.castShadow=quality!=='low';group.add(mesh);}
 }
 addForest(group,trees,quality){if(!trees.length)return;if(this.preset==='experimental'&&this.real)trees=this.real.trees(group,trees,quality,this.camera.position);if(!trees.length)return;const T=this.T,high=quality==='high',low=quality==='low',branches=[],crowns=[],pines=[];
  function part(list,x,y,z,sx,sy,sz,color,seed,angle=0){list.push({x,y,z,sx,sy,sz,color,seed,angle});}
  for(const t of trees){const h=t.height,w=Math.max(.7,t.width*.46),x=t.x,z=t.z,y=t.base,k=t.seed,needle=t.species===1;const bark=new T.Color(0x786344).multiplyScalar(.8+.35*rand(k));part(branches,x,y+h*.28,z,Math.max(.10,h*.022),h*.56,Math.max(.10,h*.022),bark,k);
   const color=new T.Color(needle?0x3c6238:0x557f35).multiplyScalar(.78+.40*rand(k+6));if(needle){for(let j=0;j<(low?3:5);j++){const n=low?3:5,f=j/(n-1),r=w*(.94-f*.68);part(pines,x,y+h*(.36+f*.43),z,r,h*(.42-f*.15),r,color.clone().multiplyScalar(.83+f*.20),k+j);}}
   else{part(crowns,x,y+h*.71,z,w*.77,h*.29,w*.76,color,k);const n=low?3:high?9:6;for(let j=0;j<n;j++){const a=j*2.399+k,rad=w*(.42+.17*rand(k+j+9)),yy=h*(.59+.19*rand(k+j+17)),rr=w*(.38+.15*rand(k+j+31));const cx=x+Math.cos(a)*rad,cz=z+Math.sin(a)*rad;part(crowns,cx,y+yy,cz,rr,h*(.16+.08*rand(k+j+3)),rr*.92,color.clone().multiplyScalar(.80+.36*rand(k+j+41)),k+j,a);if(!low&&j<3){const from=new T.Vector3(x,y+h*.28,z),to=new T.Vector3(cx,y+yy*.92,cz),mid=from.clone().lerp(to,.5),v=to.clone().sub(from),q=new T.Quaternion().setFromUnitVectors(new T.Vector3(0,1,0),v.clone().normalize());branches.push({x:mid.x,y:mid.y,z:mid.z,sx:h*.011,sy:v.length(),sz:h*.011,color:bark,quaternion:q});}}}
  }
  const canopy=new T.SphereGeometry(1,high?14:10,high?10:7),pos=canopy.attributes.position;for(let i=0;i<pos.count;i++){const x=pos.getX(i),y=pos.getY(i),z=pos.getZ(i),s=1+.105*Math.sin(x*13+y*8)*Math.cos(z*11-y*7)+.06*Math.sin(x*21+z*15);pos.setXYZ(i,x*s,y*s,z*s);}canopy.computeVertexNormals();
  const batches=[[branches,new T.CylinderGeometry(.47,1,1,low?5:8),this.materials.bark],[crowns,canopy,this.materials.crown],[pines,new T.ConeGeometry(1,1,high?12:8,3),this.materials.crown]];
  const dummy=new T.Object3D();for(const [parts,geo,mat] of batches){if(!parts.length){geo.dispose();continue;}const mesh=new T.InstancedMesh(geo,mat,parts.length);for(let i=0;i<parts.length;i++){const p=parts[i];dummy.position.set(p.x,p.y,p.z);dummy.scale.set(p.sx,p.sy,p.sz);dummy.quaternion.identity();if(p.quaternion)dummy.quaternion.copy(p.quaternion);else dummy.rotation.y=p.angle||0;dummy.updateMatrix();mesh.setMatrixAt(i,dummy.matrix);mesh.setColorAt(i,p.color);}mesh.instanceMatrix.needsUpdate=true;mesh.instanceColor.needsUpdate=true;mesh.castShadow=true;mesh.receiveShadow=true;mesh.computeBoundingSphere();group.add(mesh);}
 }
 meshGeometry(b,normals=true){const T=this.T,g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(b.position,3));g.setAttribute('color',new T.Float32BufferAttribute(b.color,3));g.setAttribute('uv',new T.Float32BufferAttribute(b.uv,2));if(normals){g.computeVertexNormals();const n=g.attributes.normal;if(normals==='terrain'){const sum=new Map(),keys=[];for(let i=0;i<n.count;i++){const p=g.attributes.position,k=[p.getX(i),p.getY(i),p.getZ(i)].map(x=>Math.round(x*1000)).join('/');keys.push(k);const sign=n.getY(i)<0?-1:1,v=sum.get(k)||[0,0,0];v[0]+=n.getX(i)*sign;v[1]+=n.getY(i)*sign;v[2]+=n.getZ(i)*sign;sum.set(k,v);}for(let i=0;i<n.count;i++){const v=sum.get(keys[i]),l=Math.hypot(...v)||1;n.setXYZ(i,v[0]/l,v[1]/l,v[2]/l);}}}return g;}
 clear(group){for(const obj of group.children.slice()){group.remove(obj);obj.geometry?.dispose();if(obj.isInstancedMesh)obj.dispose();if(obj.userData.ownMaterial)obj.material.dispose();}}
 addTriangles(group,geo,isDynamic,quality='medium'){const T=this.T,converted=convert(geo);for(const [kind,b] of Object.entries(converted)){if(!b.position.length||kind==='leaves')continue;let material=isDynamic&&kind==='solid'?this.materials.overlay:this.materials[kind];const rangeSurface=!isDynamic&&geo.naturalRange;let owned=false;if(rangeSurface&&['fairway','grass','rough'].includes(kind)){material=rangeTerrainMaterial(material);owned=true;}if(rangeSurface&&kind==='water'){material=this.rangeWater;}const mesh=new T.Mesh(this.meshGeometry(b,surfaceKinds.includes(kind)?'terrain':true),material);if(owned)mesh.userData.ownMaterial=true;if(rangeSurface&&kind==='water')mesh.userData.rangeWater=true;if(rangeSurface&&propKinds.includes(kind))mesh.userData.facilityProp=kind;mesh.receiveShadow=!isDynamic;mesh.castShadow=!isDynamic&&(kind==='solid'||propKinds.includes(kind)&&kind!=='path'&&kind!=='windscreen');if(!isDynamic&&['fairway','rough','tee','grass'].includes(kind))mesh.userData.grassSurface=kind==='grass'?'rough':kind;group.add(mesh);}if(!isDynamic){if(geo.naturalRange)this.addRangeForest(group,converted.trees,quality);else this.addForest(group,converted.trees,quality);group.updateMatrixWorld(true);if(this.preset==='experimental')this.real?.grass(group,quality,this.camera.position);}}
 addLines(group,arr){if(!arr.length)return;group.add(new this.T.LineSegments(this.meshGeometry(convertLinear(arr),false),this.materials.line));}
 addDots(group,arr,ratio){const T=this.T; // Fixed pixel-size circular points, matching the existing HUD marker sizes.
  if(!arr.length)return;const b=convertLinear(arr),g=this.meshGeometry(b,false),sizes=[];for(let i=6;i<arr.length;i+=7)sizes.push(arr[i]*ratio);g.setAttribute('size',new T.Float32BufferAttribute(sizes,1));const m=new T.ShaderMaterial({vertexShader:'attribute float size; attribute vec3 color; varying vec3 col; void main(){col=color;gl_PointSize=size;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',fragmentShader:'varying vec3 col; void main(){float d=length(gl_PointCoord-.5);if(d>.5)discard;gl_FragColor=vec4(col,1.); #include <colorspace_fragment>\n}'.replace('; #include',';\n#include')});const p=new T.Points(g,m);p.userData.ownMaterial=true;group.add(p);}
 updateReflection(cam,quality,w,h){const T=this.T,r=this.renderer,water=this.static.children.filter(o=>o.userData.rangeWater);if(!water.length)return;const uniforms=this.rangeWater.uniforms;
  if(quality==='low'||cam.eye[1]<=WATER_Y){uniforms.hasReflection.value=0;return;}
  const max=quality==='high'?768:384,scale=Math.min(1,max/Math.max(w,h)),rw=Math.max(64,Math.round(w*scale)),rh=Math.max(64,Math.round(h*scale));
  if(!this.reflectionTarget){this.reflectionTarget=new T.WebGLRenderTarget(rw,rh,{depthBuffer:true});}else if(this.reflectionTarget.width!==rw||this.reflectionTarget.height!==rh){this.reflectionTarget.setSize(rw,rh);this.waterKey=null;}
  const key=[this.key,...cam.eye,...cam.at,w,h,quality].map(v=>typeof v==='number'?v.toFixed(3):v).join('/');if(this.waterKey===key)return;
  const c=this.reflectionCamera;c.copy(this.camera,false);c.position.set(...mirrorPoint(xyz(...cam.eye)));const up=xyz(...cam.u);c.up.set(up[0],-up[1],up[2]);c.lookAt(...mirrorPoint(xyz(...cam.at)));c.updateMatrixWorld(true);uniforms.reflectionMatrix.value.multiplyMatrices(c.projectionMatrix,c.matrixWorldInverse);
  const target=r.getRenderTarget(),clip=r.clippingPlanes,shadow=r.shadowMap.needsUpdate,sky=this.sky.position.clone(),dynamic=this.dynamic.visible;for(const mesh of water)mesh.visible=false;this.dynamic.visible=false;
  try{r.clippingPlanes=[new T.Plane(new T.Vector3(0,1,0),-WATER_Y)];r.shadowMap.needsUpdate=false;this.sky.position.copy(c.position);r.setRenderTarget(this.reflectionTarget);r.clear();r.render(this.scene,c);uniforms.reflection.value=this.reflectionTarget.texture;uniforms.hasReflection.value=1;this.waterKey=key;this.reflectionPasses=(this.reflectionPasses||0)+1;}
  finally{r.setRenderTarget(target);r.clippingPlanes=clip;r.shadowMap.needsUpdate=shadow;this.sky.position.copy(sky);this.dynamic.visible=dynamic;for(const mesh of water)mesh.visible=true;}
 }
 pauseWater(){if(this.waterRAF!=null){root.cancelAnimationFrame?.(this.waterRAF);this.waterRAF=null;}}
 animateWater(){if(this.waterRAF!=null||!root.requestAnimationFrame)return;const tick=t=>{this.waterRAF=null;if(this.disposed||this.lost||!this.naturalRange||this.waterQuality!=='high'||!this.canvas.isConnected||!this.canvas.getClientRects().length||root.document.hidden)return;if(t-(this.waterFrame||0)>=100){this.waterFrame=t;this.rangeWater.uniforms.time.value=t*.001;this.renderer.render(this.scene,this.camera);}this.waterRAF=root.requestAnimationFrame(tick);};this.waterRAF=root.requestAnimationFrame(tick);}
 draw({key,ground,dynamic,cam,quality,w,h,ratio}){if(this.lost)throw Error('Three.js GPU context lost');const r=this.renderer; if(this.w!==w||this.h!==h){r.setSize(w,h,false);this.w=w;this.h=h;}
  const shadows=quality!=='low';r.shadowMap.enabled=shadows;this.camera.aspect=w/h;this.camera.updateProjectionMatrix();this.camera.position.set(...xyz(...cam.eye));this.camera.up.set(...xyz(...cam.u));this.camera.lookAt(...xyz(...cam.at));this.sky.position.copy(this.camera.position);
  const preset=resolvePreset(this.owner.lastData?.preset||root.R10GraphicsPreset),rangeStyle=preset==='hybrid'&&!this.owner.lastData?.scene;if(this.preset!==preset||this.rangeStyle!==rangeStyle){this.preset=preset;this.rangeStyle=rangeStyle;this.real?.apply(preset);this.key=null;this.shadowCenter=null;}const aerial=rangeStyle&&cam.eye[1]>35;if(aerial!==this.rangeAerial)this.shadowCenter=null;this.rangeAerial=aerial;const fullKey=key+'/'+preset+(this.rangeAerial?'/aerial':'');if(this.key!==fullKey){this.clear(this.static);const geo=ground(true,preset);this.addTriangles(this.static,geo,false,quality);this.addLines(this.static,geo.lines);this.naturalRange=!!geo.naturalRange;this.key=fullKey;this.waterKey=null;r.shadowMap.needsUpdate=true;}
  this.sky.material.uniforms.rangeStyle.value=this.naturalRange?1:0;this.scene.fog.density=this.naturalRange?(this.rangeAerial?.00058:.00175):.0032;this.sun.intensity=this.naturalRange?2.55:2.85;r.toneMappingExposure=this.naturalRange?1.02:1.08;const shadowSpan=this.naturalRange?(this.rangeAerial?235:100):85;Object.assign(this.sun.shadow.camera,{left:-shadowSpan,right:shadowSpan,top:shadowSpan,bottom:-shadowSpan});const center=this.rangeAerial?[-cam.at[0],0,cam.at[2]]:[-cam.eye[0],0,cam.eye[2]];if(shadows&&(!this.shadowCenter||Math.hypot(center[0]-this.shadowCenter[0],center[2]-this.shadowCenter[2])>45)){this.shadowCenter=center;this.sun.position.set(center[0]+85,(this.rangeAerial?190:85)+cam.eye[1]*.12,center[2]-55);this.sun.target.position.set(...center);this.sun.shadow.camera.far=this.rangeAerial?720:340;this.sun.shadow.camera.updateProjectionMatrix();r.shadowMap.needsUpdate=true;}
  this.clear(this.dynamic);this.addTriangles(this.dynamic,dynamic,true);this.addLines(this.dynamic,dynamic.lines);this.addDots(this.dynamic,dynamic.dots,ratio);if(this.naturalRange){this.waterQuality=quality;this.rangeWater.uniforms.time.value=(root.performance?.now()||0)*.001;this.updateReflection(cam,quality,w,h);}else this.pauseWater();r.render(this.scene,this.camera);if(this.naturalRange&&quality==='high')this.animateWater();else this.pauseWater();}
 dispose(){this.disposed=true;this.pauseWater();this.reflectionTarget?.dispose();this.rangeWater?.dispose();if(this.static)this.clear(this.static);if(this.dynamic)this.clear(this.dynamic);this.real?.dispose();this.sky?.geometry.dispose();this.sky?.material.dispose();for(const m of Object.values(this.materials||{}))m.dispose();for(const t of Object.values(this.textures||{}))t.dispose();this.renderer?.dispose();this.renderer?.forceContextLoss();this.canvas?.remove();if(this.original?.style)this.original.style.opacity='';}
}
function resolvePreset(p){return ['classic','hybrid','experimental'].includes(p)?p:'hybrid';}
const api={propTextureData,mirrorPoint,resolvePreset,SceneRenderer,xyz,srgb,convert,convertLinear,textureData};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.R10ThreeScene=api;
})(typeof globalThis!=='undefined'?globalThis:this);
