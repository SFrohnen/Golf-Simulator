/* Offline, rule-based personal coaching. Descriptive and hypothesis-based, not a swing diagnosis. */
(function(root){'use strict';
const A=typeof module!=='undefined'&&module.exports?require('./club-analytics.js'):root.ClubAnalytics;
const P=typeof module!=='undefined'&&module.exports?require('./practice.js'):root.R10Practice;
const VERSION='coach-0.6.0';
const modes=['off','brief','detailed'];const mode=v=>modes.includes(v)?v:'brief';
const f=A.finite, mean=xs=>xs.length?xs.reduce((a,b)=>a+b,0)/xs.length:null;
const fmt=n=>Number(n).toLocaleString(undefined,{minimumFractionDigits:1,maximumFractionDigits:1});
const side=v=>v<0?'left':'right';
const valid=s=>s&&A.confirmed(s)&&A.isClub(s.club)&&['R10','DEMO'].includes(s.source)&&f(s.carry)&&Number(s.carry)>0;
function comparable(a,b){
 if(!valid(a)||!valid(b)||a.club!==b.club||a.source!==b.source||!a.model||a.model!==b.model)return false;
 // Do not mix different atmospheres, or full/unspecified practice with target/partial shots.
 if(!['temperatureC','altitudeM'].every(k=>f(a[k])&&f(b[k])&&Math.abs(Number(a[k])-Number(b[k]))<.01))return false;
 const ta=f(a.practiceTarget)&&Number(a.practiceTarget)>0,tb=f(b.practiceTarget)&&Number(b.practiceTarget)>0;
 if(ta!==tb)return false;
 return !ta||Math.abs(Number(a.practiceTarget)-Number(b.practiceTarget))<=Math.max(5,Number(a.practiceTarget)*.05);
}
function stats(rows){const carries=rows.map(s=>Number(s.carry));const carry=mean(carries);const off=rows.filter(s=>f(s.offline)).map(s=>Number(s.offline));const sd=carry===null?null:Math.sqrt(mean(carries.map(x=>(x-carry)**2)));const sm=rows.map(A.smash).filter(v=>v!==null&&Number.isFinite(v)&&v>0&&v<=1.65);return {n:rows.length,carry,sd,offline:mean(off.map(Math.abs)),offN:off.length,L:off.filter(x=>x< -1).length,R:off.filter(x=>x>1).length,C:off.filter(x=>Math.abs(x)<=1).length,smash:mean(sm),smashN:sm.length};}
function analyze(s,history=[],hand='right'){
 if(!valid(s))return null;
 const sign=hand==='left'?-1:1, shape=A.shape(s,hand), delivery=A.swing(s,hand), q=P.score(s), targeted=!!q;
 const idx=history.indexOf(s);const earlier=idx>=0?history.slice(idx+1):history.filter(x=>Date.parse(x.time)<Date.parse(s.time));
 const peers=earlier.filter(x=>comparable(s,x)).slice(0,30), baseline=stats(peers), sameSession=peers.filter(x=>s.sessionId&&x.sessionId===s.sessionId), prior=peers.filter(x=>s.sessionId&&x.sessionId&&x.sessionId!==s.sessionId);
 const now=stats([s,...sameSession]), before=stats(prior);
 let observations=[], recommendations=[];
 const add=(id,priority,title,detail,drill)=>recommendations.push({id,priority,title,detail,drill});
 const offline=f(s.offline)?Number(s.offline):null, start=f(s.direction)?Number(s.direction):null;
 const tolerance=Math.max(3,Number(s.carry)*.05);
 if(q){observations.push('Target '+fmt(s.practiceTarget)+' m: '+fmt(Math.abs(q.depth))+' m '+(q.depth<0?'short':'long')+', '+fmt(Math.abs(q.offline))+' m '+(Math.abs(q.offline)<.05?'centered':side(q.offline))+'.');
  if(Math.abs(q.depth)>q.tolerance&&Math.abs(q.depth)>=Math.abs(q.offline))add('distance',85,q.depth<0?'Control carry: short':'Control carry: long','Landing depth missed the target by '+fmt(Math.abs(q.depth))+' m. Change swing length or club only if that fits the intended shot.','Hit five balls to the same target with one repeatable swing length; adjust only one variable.');
 }
 if(shape)observations.push('Modeled shape: '+shape.label+'.');
 if(delivery?.opposite){observations.push('Delivery and modeled curve disagree; spin estimate or measurement may be unreliable.');add('conflict',100,'Check the shot data','Face-to-path and modeled curvature point in opposite directions. Do not infer a swing fault from this shot.','Check R10 alignment and compare three more shots before changing your swing.');}
 if(f(s.path)&&f(s.face)){
  const path=Number(s.path)*sign, face=Number(s.face)*sign, diff=(Number(s.face)-Number(s.path))*sign;
  observations.push('Path '+fmt(Math.abs(path))+'° '+(Math.abs(path)<.05?'neutral':path>0?'in-to-out':'out-to-in')+'; face '+fmt(Math.abs(face))+'° '+(Math.abs(face)<.05?'square':face>0?'open':'closed')+' to target; face-to-path '+fmt(Math.abs(diff))+'° '+(Math.abs(diff)<.05?'square':diff>0?'open':'closed')+'.');
  if(!delivery?.opposite&&Math.abs(diff)>=2&&((offline!==null&&Math.abs(offline)>tolerance)||(shape&&Math.abs(shape.curveDegrees)>=5))){const open=diff>0;add('curve',80,open?'Manage fade / slice curvature':'Manage draw / hook curvature','Face is '+fmt(Math.abs(diff))+'° '+(open?'open':'closed')+' relative to path. This is consistent with a '+(open?'fade or slice':'draw or hook')+' tendency, not proof of the swing cause.','Use half swings and aim for a smaller face-to-path difference. Check start direction and curve after each of five shots.');}
  else if(!delivery?.opposite&&start!==null&&Math.abs(start)>=2&&offline!==null&&Math.abs(offline)>tolerance){add('start',70,'Improve start direction','Ball started '+side(start)+'. Face orientation contributes to start direction, but strike location and club delivery also matter.','Use a safe intermediate alignment mark and hit five controlled shots starting near the target line.');}
 }else observations.push('Club delivery is incomplete; no face/path diagnosis.');
 const smash=A.smash(s);if(smash!==null&&Number.isFinite(smash)){
  if(smash<=0||smash>1.65)observations.push('Smash factor appears implausible; check speed readings.');
  else{observations.push('Smash factor '+fmt(smash)+'.');if(!targeted&&baseline.smashN>=5&&baseline.smash-smash>=.10)add('strike',60,'Check strike consistency','Smash factor is below your comparable club baseline. This may reflect strike, delivered loft or swing intent.','Use impact tape or face spray if appropriate and compare five controlled strikes.');}
 }
 if(offline!==null&&Math.abs(offline)>tolerance&&!recommendations.some(r=>['curve','start','conflict'].includes(r.id)))add('offline',65,'Improve directional consistency','Modeled landing is '+fmt(Math.abs(offline))+' m '+side(offline)+'. No reliable single swing cause established.','Check alignment and hit five controlled shots to a single target; review the dispersion.');
 if(!targeted&&baseline.n>=5&&baseline.carry>0&&Math.abs(Number(s.carry)-baseline.carry)>Math.max(8,baseline.carry*.1))add('carry',45,'Check distance consistency','Carry differs from your recent comparable '+s.club+' mean. Swing intent is not recorded, so this is not automatically a bad strike.','Repeat the same intended swing before changing your technique.');
 if(baseline.offN>=5&&Math.max(baseline.L,baseline.R)/baseline.offN>=.7)add('pattern',50,'Recurring '+(baseline.L>baseline.R?'left':'right')+' miss','In '+baseline.offN+' prior comparable shots, '+Math.max(baseline.L,baseline.R)+' landed on the same side (outside a 1 m center band).','Set an intermediate target and review five-shot dispersion before adjusting aim or delivery.');
 if(!recommendations.length)add('repeat',10,q?.hit?'On target — repeat the feel':'Build a repeatable pattern',q?.hit?'Landing is within the target radius.':'No major actionable miss flagged by the available measurements.','Repeat five shots with the same intent and check the resulting pattern.');
 recommendations.sort((a,b)=>b.priority-a.priority);
 const trend=now.offN>=5&&before.offN>=5?{current:now.offline,prior:before.offline,currentN:now.offN,priorN:before.offN}:null;
 return {version:VERSION,source:s.source,club:s.club,shape:shape?.label||null,observations,recommendations,baseline,trend,spinEstimated:/ESTIMAT/i.test(s.spinSource||''),targeted};
}
const api={VERSION,mode,analyze,comparable,stats};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.R10Coach=api;
})(typeof globalThis!=='undefined'?globalThis:this);
