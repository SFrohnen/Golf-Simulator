/* Offline, rule-based personal coaching. Descriptive and hypothesis-based, not a swing diagnosis. */
(function(root){'use strict';
const A=typeof module!=='undefined'&&module.exports?require('./club-analytics.js'):root.ClubAnalytics;
const P=typeof module!=='undefined'&&module.exports?require('./practice.js'):root.R10Practice;
const VERSION='coach-0.7.4';
const modes=['off','brief','detailed'];const mode=v=>modes.includes(v)?v:'brief';
const f=A.finite, mean=xs=>xs.length?xs.reduce((a,b)=>a+b,0)/xs.length:null;
const fmt=n=>Number(n).toLocaleString(undefined,{minimumFractionDigits:1,maximumFractionDigits:1});
const side=v=>v<0?'left':'right';
const valid=s=>s&&A.confirmed(s)&&A.isClub(s.club)&&['R10','DEMO'].includes(s.source)&&f(s.carry)&&Number(s.carry)>0;
function comparable(a,b){
 if(!valid(a)||!valid(b)||A.swingLength(a.club,a.swingLength)!==A.swingLength(b.club,b.swingLength)||a.club!==b.club||a.source!==b.source||!a.model||a.model!==b.model)return false;
 // Do not mix different atmospheres, or full/unspecified practice with target/partial shots.
 if(!['temperatureC','altitudeM'].every(k=>f(a[k])&&f(b[k])&&Math.abs(Number(a[k])-Number(b[k]))<.01))return false;
 const ta=f(a.practiceTarget)&&Number(a.practiceTarget)>0,tb=f(b.practiceTarget)&&Number(b.practiceTarget)>0;
 if(ta!==tb)return false;
 return !ta||Math.abs(Number(a.practiceTarget)-Number(b.practiceTarget))<=Math.max(5,Number(a.practiceTarget)*.05);
}
function stats(rows){const carries=rows.map(s=>Number(s.carry));const carry=mean(carries);const off=rows.filter(s=>f(s.offline)).map(s=>Number(s.offline));const sd=carry===null?null:Math.sqrt(mean(carries.map(x=>(x-carry)**2)));const sm=rows.map(A.smash).filter(v=>v!==null&&Number.isFinite(v)&&v>0&&v<=1.65);return {n:rows.length,carry,sd,offline:mean(off.map(Math.abs)),offN:off.length,L:off.filter(x=>x< -1).length,R:off.filter(x=>x>1).length,C:off.filter(x=>Math.abs(x)<=1).length,smash:mean(sm),smashN:sm.length};}
function analyze(s,history=[],hand='right'){
 if(!valid(s))return null;
 const sign=hand==='left'?-1:1, shape=A.shape(s,hand), delivery=A.swing(s,hand), q=P.score(s), targeted=!!q;
 const idx=history.indexOf(s);const earlier=idx>=0?history.slice(idx+1):history.filter(x=>Date.parse(x.time)<Date.parse(s.time));
 const peers=earlier.filter(x=>comparable(s,x)).slice(0,30), baseline=stats(peers), sameSession=peers.filter(x=>s.sessionId&&x.sessionId===s.sessionId), prior=peers.filter(x=>s.sessionId&&x.sessionId&&x.sessionId!==s.sessionId);
 const now=stats([s,...sameSession]), before=stats(prior);
 let observations=[], recommendations=[];
 const add=(id,priority,title,detail,drill)=>recommendations.push({id,priority,title,detail,drill});
 const offline=f(s.offline)?Number(s.offline):null, start=f(s.direction)?Number(s.direction):null;
 const tolerance=Math.max(3,Number(s.carry)*.05);
 if(q){observations.push('Target '+fmt(s.practiceTarget)+' m: '+fmt(Math.abs(q.depth))+' m '+(q.depth<0?'short':'long')+', '+fmt(Math.abs(q.offline))+' m '+(Math.abs(q.offline)<.05?'centered':side(q.offline))+'.');
  if(Math.abs(q.depth)>q.tolerance&&Math.abs(q.depth)>=Math.abs(q.offline))add('distance',85,q.depth<0?'Control carry: short':'Control carry: long','Landing depth missed the target by '+fmt(Math.abs(q.depth))+' m. Change swing length or club only if that fits the intended shot.','If strike efficiency and launch are normal, adjust swing length or choose a different club. Aim to bring landing depth within ±3 m; do not change the swing path solely to fix distance.');
 }
 if(shape)observations.push('Modeled shape: '+shape.label+'.');
 if(delivery?.opposite){observations.push('Delivery and modeled curve disagree; spin estimate or measurement may be unreliable.');add('conflict',100,'Check the shot data','Face-to-path and modeled curvature point in opposite directions. Do not infer a swing fault from this shot.','Check R10 alignment and compare three more shots before changing your swing.');}
 if(f(s.path)&&f(s.face)){
  const path=Number(s.path)*sign, face=Number(s.face)*sign, diff=(Number(s.face)-Number(s.path))*sign;
  observations.push('Path '+fmt(Math.abs(path))+'° '+(Math.abs(path)<.05?'neutral':path>0?'in-to-out':'out-to-in')+'; face '+fmt(Math.abs(face))+'° '+(Math.abs(face)<.05?'square':face>0?'open':'closed')+' to target; face-to-path '+fmt(Math.abs(diff))+'° '+(Math.abs(diff)<.05?'square':diff>0?'open':'closed')+'.');
  if(!delivery?.opposite&&Math.abs(diff)>=2&&((offline!==null&&Math.abs(offline)>tolerance)||(shape&&Math.abs(shape.curveDegrees)>=5))){const open=diff>0;add('curve',80,open?'Manage fade / slice curvature':'Manage draw / hook curvature','Face is '+fmt(Math.abs(diff))+'° '+(open?'open':'closed')+' relative to path. This is consistent with a '+(open?'fade or slice':'draw or hook')+' tendency, not proof of the swing cause.',(Math.abs(path)<2?'Keep your nearly neutral path; check clubface alignment at address and return it nearer square at impact.':'Check alignment; work on bringing path and face closer together without forcing an extreme path.')+' For a straight shot, aim for face-to-path within ±2° and monitor offline distance.');}
  else if(!delivery?.opposite&&start!==null&&Math.abs(start)>=2&&offline!==null&&Math.abs(offline)>tolerance){add('start',70,'Improve start direction','Ball started '+side(start)+'. Face orientation contributes to start direction, but strike location and club delivery also matter.','Check the clubface points at an intermediate target at address. For a straight shot, aim for horizontal launch within ±2°; avoid changing path unless the path data also supports it.');}
 }else observations.push('Club delivery is incomplete; no face/path diagnosis.');
 if(f(s.launch)){const launch=Number(s.launch);observations.push('Vertical launch '+fmt(launch)+'°'+(f(s.attack)?'; attack '+fmt(s.attack)+'°':'')+'.');
 const priorLaunch=mean(peers.filter(x=>f(x.launch)).map(x=>Number(x.launch)));const ranges={'Driver':[10,19],'5 Wood':[11,20],'7 Wood':[13,23],'5 Iron':[13,22],'6 Iron':[15,24],'7 Iron':[17,26],'8 Iron':[19,30],'9 Iron':[22,34],'Pitching Wedge':[24,36],'52° Wedge':[27,43],'56° Wedge':[30,48],'60° Wedge':[32,52]};const band=ranges[s.club];
 if(!targeted&&band&&(launch<band[0]||launch>band[1])){const low=launch<band[0],goal=low?band[0]:band[1];add('launch',72,low?'Launch is unusually low':'Launch is unusually high','Launch '+fmt(launch)+'° versus a broad illustrative '+s.club+' full-shot band '+band.join('–')+'°. '+(f(s.attack)?'Attack angle '+fmt(s.attack)+'°. ':'')+'Delivered loft and strike position are not directly measured here.','Check ball position and face contact first. '+(s.club==='Driver'?'Check tee height and strike location. ':'Avoid forcing additional shaft lean or scooping. ')+'If a normal full shot is intended, move toward '+fmt(goal)+'° and compare carry and strike efficiency.');}
 if(priorLaunch!==null&&peers.length>=5)observations.push('Comparable launch baseline '+fmt(priorLaunch)+'°; difference '+fmt(launch-priorLaunch)+'°.');}
 if(f(s.spin)){const rpm=Number(s.spin),spinPrior=mean(peers.filter(x=>f(x.spin)).map(x=>Number(x.spin)));observations.push('Spin '+fmt(rpm)+' RPM'+(/ESTIMAT/i.test(s.spinSource||'')?' (estimated)':'')+(f(s.spinAxis)?'; axis '+fmt(s.spinAxis)+'° (positive = right)':'')+'.');if(!targeted&&s.club==='Driver'&&rpm>0&&(rpm<1500||rpm>3500)){const low=rpm<1500;add('spin',55,low?'Low driver spin':'High driver spin','Driver spin '+fmt(rpm)+' RPM '+(low?'may reduce lift':'may increase height and reduce rollout')+'. '+(/ESTIMAT/i.test(s.spinSource||'')?'Spin is estimated, so confirm with multiple shots. ':'')+'Strike location and delivered loft are not known.','Check strike location on the face and tee height. Compare shots of similar ball speed; aim toward a broad 1,800–3,000 RPM starting band if appropriate for your launch and speed.');}if(spinPrior!==null&&peers.length>=5)observations.push('Comparable mean spin '+fmt(spinPrior)+' RPM.');}
 const smash=A.smash(s);if(smash!==null&&Number.isFinite(smash)){
  if(smash<=0||smash>1.65)observations.push('Smash factor appears implausible; check speed readings.');
  else{observations.push('Smash factor '+fmt(smash)+'.');if(!targeted&&baseline.smashN>=5&&baseline.smash-smash>=.10)add('strike',60,'Check strike consistency','Smash factor is below your comparable club baseline. This may reflect strike, delivered loft or swing intent.','Use impact tape or face spray to check centered contact; compare ball speed at similar club speed. Aim to recover your baseline smash factor of '+fmt(baseline.smash)+'.');}
 }
 if(offline!==null&&Math.abs(offline)>tolerance&&!recommendations.some(r=>['curve','start','conflict'].includes(r.id)))add('offline',65,'Improve directional consistency','Modeled landing is '+fmt(Math.abs(offline))+' m '+side(offline)+'. No reliable single swing cause established.','Check target alignment and compare initial launch with final offline. If start is straight but the ball curves, inspect face-to-path and spin axis rather than changing aim.');
 if(!targeted&&baseline.n>=5&&baseline.carry>0&&Math.abs(Number(s.carry)-baseline.carry)>Math.max(8,baseline.carry*.1))add('carry',45,'Check distance consistency','Carry differs from your recent comparable '+s.club+' mean. Swing intent is not recorded, so this is not automatically a bad strike.','Repeat the same intended swing before changing your technique.');
 if(baseline.offN>=5&&Math.max(baseline.L,baseline.R)/baseline.offN>=.7)add('pattern',50,'Recurring '+(baseline.L>baseline.R?'left':'right')+' miss','In '+baseline.offN+' prior comparable shots, '+Math.max(baseline.L,baseline.R)+' landed on the same side (outside a 1 m center band).','Set an intermediate target and review five-shot dispersion before adjusting aim or delivery.');
 if(!recommendations.length)add('repeat',10,q?.hit?'On target — repeat the feel':'Build a repeatable pattern',q?.hit?'Landing is within the target radius.':'No major actionable miss flagged by the available measurements.','Repeat five shots with the same intent and check the resulting pattern.');
 recommendations.sort((a,b)=>b.priority-a.priority);
 const trend=now.offN>=5&&before.offN>=5?{current:now.offline,prior:before.offline,currentN:now.offN,priorN:before.offN}:null;
 return {version:VERSION,source:s.source,club:s.club,shape:shape?.label||null,observations,recommendations,baseline,trend,spinEstimated:/ESTIMAT/i.test(s.spinSource||''),targeted};
}
function sessionFeedback(rows,hand='right'){const validRows=rows.filter(valid),groups=new Map();for(const s of validRows){const key=s.club+'|'+s.source;if(!groups.has(key))groups.set(key,[]);groups.get(key).push(s);}const out=[];for(const ss of groups.values()){const b=stats(ss),n=ss.length;const average=k=>mean(ss.filter(s=>f(s[k])).map(s=>Number(s[k])));const path=average('path'),face=average('face'),launch=average('launch'),diff=mean(ss.map(A.faceToPath).filter(x=>x!==null));const q=ss.map(P.score).filter(Boolean);const misses=b.offN?Math.max(b.L,b.R)/b.offN:0;let detail=n+' shots; mean absolute offline '+(b.offline===null?'unavailable':fmt(b.offline)+' m')+'; '+b.L+' L / '+b.R+' R / '+b.C+' C (±1 m).';if(face!==null&&path!==null&&diff!==null)detail+=' Mean face '+fmt(face)+'°, path '+fmt(path)+'°, face-to-path '+fmt(diff)+'° (positive = right).';if(launch!==null)detail+=' Mean launch '+fmt(launch)+'°.';let action=n<3?'More comparable shots are needed before diagnosing a recurring pattern.':misses>=.7&&face!==null&&Math.abs(face)>2?'Check face alignment and start direction before changing path; aim for face and horizontal launch within ±2° for straight shots.': 'Compare start direction and curvature; keep a stable intended swing and address the dominant measurable miss.';if(q.length){const depth=mean(q.map(x=>x.depth));detail+=' Mean depth error '+fmt(depth)+' m.';if(Math.abs(depth)>3)action+=' Adjust swing length or club for the '+(depth<0?'short':'long')+' tendency; target ±3 m depth.';}out.push({title:ss[0].club+' technical review',detail,action});}return out;}
function spoken(shot,history,hand,level,impact){
 if(level==='off'||!valid(shot))return '';
 if(impact)return 'Check your clearance to the trees.';
 const cue=analyze(shot,history,hand)?.recommendations[0];
 return cue ? cue.title.replace(/[:/]/g,' ').trim()+'.' : '';
}

// Freeze the target and the comparison group when the golfer starts the drill.
function suggestDrill(history,club,source,hand,model){
 const eligible=s=>valid(s)&&A.swingLength(s.club,s.swingLength)==='full'&&s.club===club&&s.source===source&&s.model===model&&!s.mishit&&!s.practiceId&&f(s.offline);
 const last=history.find(eligible);
 if(!last)return null;
 const peers=history.filter(s=>eligible(s)&&(s===last||comparable(last,s))).slice(0,10);
 const target=Math.min(300,Math.max(10,Math.round(mean(peers.map(s=>Number(s.carry))))));
 const base={club,source,target,count:peers.length,metric:'offline',unit:'m',label:'Mean distance from centre',instruction:'Pick an intermediate target and start each ball along that line.'};
 if(peers.length<5){
   const prior=history.find(s=>s.smartBaseline&&s.source===source&&s.club===club&&s.model===model&&f(s.practiceTarget)&&Math.abs(s.practiceTarget-target)<=Math.max(5,target*.05));
   if(prior){
     const scored=history.filter(s=>s.practiceId===prior.practiceId&&valid(s)&&!s.mishit&&s.club===club&&s.source===source&&f(s.offline));
     if(scored.length===5)return {...base,title:'Tighten your landing pattern',before:mean(scored.map(s=>Math.abs(Number(s.offline)))),count:5};
   }
   return {...base,title:'Build your five-shot baseline',before:null};
 }
 const cue=analyze(last,history,hand).recommendations[0];
 const sideMiss=peers.filter(s=>Number(s.offline)>1).length>=peers.length*.7?'right':
    peers.filter(s=>Number(s.offline)<-1).length>=peers.length*.7?'left':null;
 const drill={...base,title:sideMiss?'Reduce the '+sideMiss+' miss':'Tighten your landing pattern'};
 if(cue.id==='conflict'){
   drill.title='Check alignment and repeat';drill.instruction=cue.drill;
 }else if(cue.id==='start'){
   Object.assign(drill,{title:cue.title,metric:'direction',unit:'°',label:'Mean start-line error',instruction:cue.drill});
 }else if(cue.id==='carry'||cue.id==='distance'){
   Object.assign(drill,{title:'Repeat your carry distance',metric:'carry',label:'Mean carry error',instruction:cue.drill});
 }else if(['launch','spin','strike'].includes(cue.id)){
   const metric={launch:'launch',spin:'spin',strike:'smash'}[cue.id];
   const reference=cue.id==='strike'?analyze(last,history,hand).baseline.smash:null;
   Object.assign(drill,{title:cue.title,metric,reference,unit:{launch:'°',spin:'rpm',strike:''}[cue.id],label:{launch:'Mean launch',spin:'Mean spin',strike:'Mean smash factor'}[cue.id],instruction:cue.drill});
 }else if(cue.id==='curve'||cue.id==='offline')drill.instruction=cue.drill;
 const values=peers.map(s=>drillValue(drill,s)).filter(v=>v!==null);
 return {...drill,before:values.length>=5?mean(values):null,count:values.length};
}
function drillValue(d,s){
 const value=d.metric==='smash'?A.smash(s):s[d.metric];
 if(!f(value))return null;
 if(d.metric==='carry')return Math.abs(Number(value)-d.target);
 if(d.metric==='offline'||d.metric==='direction')return Math.abs(Number(value));
 return Number(value);
}
const api={VERSION,mode,analyze,spoken,suggestDrill,drillValue,comparable,stats,sessionFeedback};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.R10Coach=api;
})(typeof globalThis!=='undefined'?globalThis:this);
