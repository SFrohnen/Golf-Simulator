/* Course screen, separate from personal range history (multiple players). */
(function(root){'use strict';
function init(env){const {$,A,F,fmt,esc,options,renderCoach,settings,isCourse}=env,E=root.R10Course,M=root.R10CourseMap,STORE='r10-course-round-v1',PACK='r10-course-packs-v1';let packs=[],round=null,aim=null,armed=false,last=null,notice='',projection=null,baseProjection=null,viewKey='',detailsOpen=false,renderer=null,framePending=false;const C=root.R10Course3D;let cameraZoom=1,recommendation=null,recommendationKey='',customAim=null,landingPattern=[];let view='3d';try{view=localStorage.getItem('r10-course-view')||'3d';}catch(e){}$('courseView').value=view;$('courseCamera').value='follow';$('courseQuality').value='medium';
const courseSettings=()=>({...settings(),temperatureC:round?.config?.temperatureC??settings().temperatureC});
const revision=c=>Number(c.mapRevision)||0; const preferred=(a,b)=>revision(a)>revision(b)||(revision(a)===revision(b)&&!!a.terrain&&!b.terrain);
try{packs=JSON.parse(localStorage.getItem(PACK)||'[]').map(E.validate).filter(c=>c.id!=='demo');}catch(e){packs=[];notice='Saved course packs could not be loaded.';}try{const r=JSON.parse(localStorage.getItem(STORE)||'null');if(r&&r.version===1){E.validate(r.course);round=r;round.config.reviewHoles=true;if(r.reviewShot)last={...r.reviewShot,started:performance.now()};aim=E.defaultAim(r);}}catch(e){notice='Saved round could not be loaded.';}
const bundled=[];for(const p of root.R10BundledCourses?.packs||[]){try{const c=E.validate(p);if(c.kind==='osm'&&c.id!=='demo')bundled.push(c);}catch(e){notice='A bundled pack failed validation.';}}
const courses=()=>[E.demo(),...bundled.filter(b=>!packs.some(p=>p.id===b.id&&!preferred(b,p))),...packs.filter(p=>!bundled.some(b=>b.id===p.id&&preferred(b,p)))];
$('courseDataStatus').innerHTML=(root.R10BundledCourses?.status||[]).map(s=>'<p><strong>'+esc(s.name)+'</strong>: '+esc(s.state==='available'?'Available (mapped, provisional)':s.state)+' — '+esc(s.detail)+'</p>').join('')||'No build-time course report. Imported course packs may still be used.';
function save(){try{localStorage.setItem(STORE,JSON.stringify(round));if(round?.done){const rows=JSON.parse(localStorage.getItem('r10-completed-rounds')||'[]');if(!rows.some(r=>r.id===round.id)){const t=E.totals(round)[0];localStorage.setItem('r10-completed-rounds',JSON.stringify([{id:round.id,date:new Date().toISOString(),course:round.course.name,holes:round.numbers.length,gross:t.strokes,par:t.par,differential:null,kind:'simulator',scorecards:round.scorecards,shots:round.log},...rows]));}}}catch(e){notice='Round save failed: '+e.message;}}
// Each venue illustration uses the actual local coordinates of its opening hole.
function holePreview(h){
    const coords=[...h.route,...h.surfaces.filter(s=>['green','fairway','bunker'].includes(s.type)).flatMap(s=>s.ring)];
    const xs=coords.map(p=>p[0]),ys=coords.map(p=>p[1]);
    const x=Math.min(...xs),y=Math.min(...ys);
    // Rotate the tee-to-green bearing onto the wide axis for the card.
    const angle=Math.atan2(h.pin[1]-h.tee[1],h.pin[0]-h.tee[0]);
    const rotate=p=>[(p[0]-x)*Math.cos(angle)+(p[1]-y)*Math.sin(angle),-(p[0]-x)*Math.sin(angle)+(p[1]-y)*Math.cos(angle)];
    const rot=coords.map(rotate),minX=Math.min(...rot.map(p=>p[0])),maxX=Math.max(...rot.map(p=>p[0])),minY=Math.min(...rot.map(p=>p[1])),maxY=Math.max(...rot.map(p=>p[1]));
    const scale=Math.min(272/Math.max(1,maxX-minX),80/Math.max(1,maxY-minY));
    const xy=p=>{const [u,v]=rotate(p);return [150+(u-(minX+maxX)/2)*scale,52-(v-(minY+maxY)/2)*scale];};
    const path=ring=>ring.map((p,i)=>(i?'L':'M')+xy(p).map(v=>v.toFixed(1)).join(',')).join('');
    const colors={fairway:'#849c69',bunker:'#ead9ae',green:'#c8df97',tee:'#b1ca84'};
    const shapes=h.surfaces.filter(s=>colors[s.type]).map(s=>'<path fill-rule="evenodd" fill="'+colors[s.type]+'" d="'+[s.ring,...(s.holes||[])].map(r=>path(r)+'Z').join('')+'"/>').join('');
    const [u,v]=xy(h.pin);
    return '<svg aria-hidden="true" viewBox="0 0 300 106">'+shapes+'<path d="'+path(h.route)+'" fill="none" stroke="#fff" opacity=".7" stroke-dasharray="3 4"/><path d="M'+u+' '+v+'v-15l10 4-10 3" stroke="#fbead0" fill="#e87651"/></svg>';
}
function refreshVenues(){
    const ordered=courses().slice().sort((a,b)=>Number(a.kind==='fictional')-Number(b.kind==='fictional'));
    $('venueDeck').innerHTML=ordered.map(c=>'<button class="venue" data-venue="'+esc(c.id)+'"><div class="venueMap">'+holePreview(c.holes[0])+'</div><small>'+ (c.kind==='fictional'?'FICTIONAL COURSE':c.terrain?'MAPPED · ELEVATION':'MAPPED COURSE')+'</small><strong>'+esc(c.name)+'</strong><span>18 holes · Par '+c.holes.reduce((sum,h)=>sum+h.par,0)+' <b>→</b></span></button>').join('');
}
function openLobby(mode){
    if(round)return;
    $('courseMode').value=mode||'casual';
    $('courseLobby').classList.toggle('hidden',false);$('roundOptions').classList.toggle('hidden',true);
    $('coursePageHeading').textContent='Select course';refreshVenues();refresh();
}
function chooseVenue(id){
    const course=courses().find(c=>c.id===id);if(!course)return;
    $('courseSelect').value=id;$('selectedVenue').textContent=course.name;
    $('coursePageHeading').textContent=careerSetup()?'Tournament setup':'Round setup';
    $('courseLobby').classList.toggle('hidden',true);$('roundOptions').classList.toggle('hidden',false);refresh();
}
$('venueDeck').onclick=e=>{const id=e.target.closest('[data-venue]')?.dataset.venue;if(id)chooseVenue(id);};
$('changeVenue').onclick=()=>openLobby($('courseMode').value);
$('courseGames').onclick=e=>{const mode=e.target.closest('[data-game]')?.dataset.game;if(mode)openLobby(mode);};

function fillCourses(){const selected=$('courseSelect').value;$('courseSelect').innerHTML=courses().map(c=>`<option value="${esc(c.id)}">${esc(c.name)}${c.terrain?" · elevation":c.kind!=='fictional'?" · flat terrain":""}</option>`).join('');$('courseSelect').value=courses().some(c=>c.id===selected)?selected:(courses().find(c=>c.kind!=='fictional')?.id||'demo');}
fillCourses();refreshVenues();$('courseClub').innerHTML=options('7 Iron');$('courseClub').value='7 Iron';
function selectCourse(text){try{if(text.length>1024*1024)throw Error('Course pack exceeds 1 MB');const c=E.validate(JSON.parse(text));if(c.id==='demo'||c.kind==='fictional')throw Error('Imported pack must be mapped or surveyed, with a unique ID');const next=[...packs.filter(p=>p.id!==c.id),c];localStorage.setItem(PACK,JSON.stringify(next));packs=next;fillCourses();refreshVenues();chooseVenue(c.id);notice='Imported '+c.name+'. Geometry is not independently verified by this app.';refresh();}catch(e){notice='Course import failed: '+e.message;refresh();}}
root.importR10Course=selectCourse;
const tour=root.R10Career;
function historyKey(source,difficulty){return 'r10-tour-v1-'+source+'-'+difficulty;}
function tourHistory(source,difficulty){
    const history=JSON.parse(localStorage.getItem(historyKey(source,difficulty))||'[]');
    if(!Array.isArray(history))throw Error('Career history could not be read.');
    return history;
}
function careerSetup(){return $('courseMode').value==='career';}
function showCareer(){
    const playing=!!round?.career;
    const visible=round?playing:careerSetup();
    $('careerBoard').classList.toggle('hidden',!visible||(playing&&!round.done));
    $('careerPreview').classList.toggle('hidden',!visible);
    if(!visible || (playing&&!round.done))return;
    const source=round?.config.source||$('courseSource').value,difficulty=round?.config.difficulty||$('courseDifficulty').value;
    const prior=tourHistory(source,difficulty);
    const history=playing?tour.record(prior,round):prior;
    if(history!==prior)localStorage.setItem(historyKey(source,difficulty),JSON.stringify(history));
    const next=tour.stage(history),season=playing?round.career.season:next.season;
    const latest=history.at(-1);
    const target=tour.targets[difficulty];
    $('careerPreview').textContent='Season '+next.season+' · '+next.name+' · Winning pace about '+(target>0?'+':'')+target+' over 18 holes. Short rounds scale proportionally.';
    const table=(rows,metric)=>'<table class="practiceTable"><thead><tr><th>Place</th><th>Golfer</th><th>'+metric+'</th></tr></thead><tbody>'+rows.map(r=>'<tr><td>'+r.place+'</td><td>'+esc(r.name)+'</td><td>'+r[metric.toLowerCase()]+'</td></tr>').join('')+'</tbody></table>';
    const earned=tour.achievements(history);
    const champions=history.filter(e=>e.final).map(e=>{
        const winners=tour.standings(history,e.season).filter(r=>r.place===1);
        return '<li>Season '+e.season+' · '+winners.map(r=>esc(r.name)).join(' / ')+' · '+winners[0].points+' points</li>';
    });
    const archive=champions.length?'<details><summary>Season champions</summary><ul>'+champions.join('')+'</ul></details>':'';

    const lastResult=latest?'<details'+(playing?' open':'')+'><summary>Season '+latest.season+' · '+esc(latest.name)+' results</summary><p>'+esc(latest.course)+' · '+latest.holes+' holes · Par '+latest.par+'</p>'+table(latest.results,'Strokes')+'</details>':'';
    $('careerBoard').innerHTML='<h2>Season '+season+' standings</h2><p>'+(source==='DEMO'?'Demo':'Live R10')+' · '+esc(difficulty)+' · Seven recurring opponents · Double points in the final</p>'+table(tour.standings(history,season),'Points')+lastResult+archive+(earned.length?'<p>Achievements · '+earned.map(esc).join(' · ')+'</p>':'');
}
if(round?.career){
    $('courseMode').value='career';
    $('courseSource').value=round.config.source;
    $('courseDifficulty').value=round.config.difficulty;
}
for(const id of ['courseMode','courseDifficulty','courseSource'])$(id).onchange=refresh;
function choiceButtons(id,selectId,choices){
    const value=$(selectId).value;
    $(id).innerHTML=choices.map(([key,label])=>'<button type="button" data-value="'+key+'" aria-pressed="'+(value===key)+'">'+label+'</button>').join('');
    $(id).onclick=e=>{
        const picked=e.target.closest('[data-value]');if(!picked)return;
        $(selectId).value=picked.dataset.value;refresh();
    };
}
function updateSetup(){if(!round){$('puttingRule').classList.toggle('hidden',$('coursePutting').value==='manual');
choiceButtons('holeChoices','courseHoles',[3,6,9,12,15,18].map(n=>[String(n),String(n)]));
choiceButtons('sourceChoices','courseSource',[['DEMO','Demo'],['R10','Live R10']]);
$('courseGames').innerHTML=['casual','career'].map(mode=>'<button data-game="'+mode+'" aria-pressed="'+(careerSetup()===(mode==='career'))+'">'+(mode==='career'?'Tour career':'Casual round')+'</button>').join('');}const career=careerSetup();for(const id of ['courseFormat','courseHumans','courseBots']){$(id).disabled=career;$(id).closest?.('label')?.classList.toggle('hidden',career);}$('courseStart').textContent=career?'Start tournament':'Start round';$('courseSide').disabled=Number($('courseHoles').value)>9;$('courseSideLabel').classList.toggle('hidden',$('courseSide').disabled);$('courseFormatHelp').textContent=career?'Solo stroke play. Opponents post their scores when you finish.':$('courseFormat').value==='scramble'?'Two golfers per team; choose the preferred ball after both shots. Solo scramble adds a bot partner. Opponents are two-bot teams.':'Individual stroke play; each golfer has a separate score.';}
$('courseHoles').onchange=updateSetup;$('courseFormat').onchange=updateSetup;$('courseImport').onclick=()=>{if(root.R10Native?.importCourse)root.R10Native.importCourse();else $('courseFile').click();};$('courseFile').onchange=async e=>{const f=e.target.files[0];if(!f)return;try{if(f.size>1024*1024)throw Error('Course pack exceeds 1 MB');selectCourse(await f.text());}catch(err){notice=err.message;refresh();}finally{e.target.value='';}};
$('coursePackExport').onclick=()=>{const c=courses().find(p=>p.id===$('courseSelect').value);if(!c||c.kind==='fictional'){notice='Select a real course to export.';refresh();return;}const data=JSON.stringify(c),name=c.id+'-course.json';if(root.R10Native?.exportCourse)root.R10Native.exportCourse(name,data);else{const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([data],{type:'application/json'}));a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),3000);}notice='Course export requested.';refresh();};
$('courseStart').onclick=()=>{try{const c=courses().find(x=>x.id===$('courseSelect').value);const career=careerSetup(),difficulty=$('courseDifficulty').value,source=$('courseSource').value;const event=career?tour.stage(tourHistory(source,difficulty)):null;const base=bundled.find(p=>p.id===c.id);
const sameLayout=base && c.origin?.lat===base.origin?.lat && c.origin?.lon===base.origin?.lon && c.holes.every((h,i)=>E.dist(h.pin,base.holes[i].pin)<1);
const trees=sameLayout && root.R10Canopy?.[c.id];
const gameCourse=trees?{...c,holes:c.holes.map((h,i)=>({...h,surfaces:[...h.surfaces,...trees[i]]}))}:c;
round=E.create(gameCourse,{reviewHoles:true,holes:Number($('courseHoles').value),side:$('courseSide').value,humans:career?1:Number($('courseHumans').value),bots:career?0:Number($('courseBots').value),difficulty:$('courseDifficulty').value,format:career?'stroke':$('courseFormat').value,source:$('courseSource').value,putting:$('coursePutting').value});if(event)round.career=event;aim=E.defaultAim(round);armed=false;last=null;projection=null;viewKey='';detailsOpen=false;customAim=null;recommendationKey='';round.config.temperatureC=courseSettings().temperatureC;notice='Round started. Live shots count automatically; select your club or tap to aim.';save();advanceBots();refresh();}catch(e){notice=e.message;refresh();}};
function advanceBots(){if(!round||round.done||round.reviewHole)return;let limit=0;while(!round.done&&!round.reviewHole&&limit++<200){const a=E.active(round),ready=a.state.candidates.length===a.team.members.length;if(ready){if(a.team.members.some(p=>!p.bot))break;E.choose(round,E.best(round));continue;}if(a.state.awaitPutt||!a.player.bot)break;E.botShot(round);}aim=E.defaultAim(round);save();}
function afterAction(){customAim=null;if(inspect&&round.reviewHole){clearInspection();$('courseCamera').value='follow';}armed=false;advanceBots();if(round.reviewHole)round.reviewShot=last;save();refresh();}
$('courseContinue').onclick=()=>{
    if(!round?.reviewHole)return;
    clearInspection();if($('courseCamera').value==='explore')$('courseCamera').value='follow';E.continueHole(round);customAim=null;delete round.reviewShot;aim=E.defaultAim(round);projection=null;cameraZoom=1;
    notice=round.done?'Round complete':'Next tee';advanceBots();save();refresh();
};
$('coursePutting').onchange=refresh;
$('mapEnd').onclick=()=>$('courseEnd').onclick();
$('courseArm').onclick=()=>{const a=round&&E.active(round);if(!a||round.reviewHole||a.player.bot||a.state.awaitPutt||a.state.candidates.length>=a.team.members.length||!A.isClub($('courseClub').value)||!aim)return;armed=true;notice='Ready for '+a.player.name+' · '+$('courseClub').value;refresh();};$('courseLength').onchange=()=>{armed=false;refresh();};$('courseClub').onchange=()=>{env.syncCourseLength();armed=false;notice='Club selected. Live shots count automatically.';recommendation=null;refresh();};$('courseAimPin').onclick=()=>{if(round&&!round.done){aim=E.hole(round).pin.slice();customAim=aim.slice();recommendationKey='';armed=false;refresh();}};
function shotResult(entry){
    if(entry.impact)return 'Tree hit at '+fmt(entry.impact.distance)+' m · OB';
    return 'Carry '+fmt(entry.shot.carry)+' m · Rollout '+fmt(entry.rollout||0)+' m · '+entry.surface;
}
function capture(raw){if(!round||round.done||round.reviewHole){notice='Shot not counted: start or resume an active round first.';refresh();return false;}const a=E.active(round);if(a.state.awaitPutt||a.state.candidates.length>=a.team.members.length||!A.isClub($('courseClub').value)||!aim){notice='Shot not counted: finish scoring or select a club and target.';refresh();return false;}if(raw.source!==round.config.source||a.player.bot){notice='Shot not counted: wrong source or not a human turn.';refresh();return false;}try{const {points,...flight}=F.simulate(raw,{...courseSettings(),altitudeM:a.hole.terrain?E.height(a.hole,a.state.pos):courseSettings().altitudeM,groundAt:E.groundAt(a.hole,a.state.pos,aim)});const s={...raw,...flight,club:$('courseClub').value,swingLength:A.swingLength($('courseClub').value,$('courseLength').value),clubConfirmed:true,id:Date.now()+Math.random(),time:new Date().toISOString(),sessionId:round.id,practiceTarget:E.dist(a.state.pos,aim),player:a.player.id};const entry=E.shoot(round,aim,s,points);if(inspect){clearInspection();$('courseCamera').value='auto';}last={entry,shot:s,points,started:performance.now()};notice='Shot recorded for '+a.player.name+' · '+shotResult(entry)+(entry.penalty?' · penalty / replay from previous position if selected':'');afterAction();env.announceShot(s,round.log.filter(e=>e.player===entry.player&&e.shot.source===s.source).map(e=>e.shot).reverse(),entry.impact);return true;}catch(e){notice='Shot not counted: '+e.message;armed=false;refresh();return false;}}
$('courseDemo').onclick=()=>{if(!round||round.config.source!=='DEMO')return;if(!armed)$('courseArm').onclick();if(!armed)return;const a=E.active(round),club=$('courseClub').value,b=A.CLUBS.find(c=>c.name===club).base,d=E.dist(a.state.pos,aim);let speed=b[0]*(({half:.68,threeQuarter:.85})[A.swingLength(club,$('courseLength').value)]||1),raw={source:'DEMO',club,ballSpeed:speed,launch:b[1],spin:b[2],direction:(Math.random()-.5)*8,spinAxis:(Math.random()-.5)*12,clubSpeed:speed/1.4,face:2,path:3,attack:-3,spinSource:'DEMO'};try{const full=F.simulate(raw,courseSettings()).carry;if(d<full*.75){let lo=1,hi=speed;for(let i=0;i<12;i++){const m=(lo+hi)/2;if(F.simulate({...raw,ballSpeed:m},courseSettings()).carry<d)lo=m;else hi=m;}speed=(lo+hi)/2;}speed*=.94+Math.random()*.12;raw.ballSpeed=speed;raw.clubSpeed=speed/1.4;capture(raw);}catch(e){notice='Demo error: '+e.message;refresh();}};
$('courseChoices').onclick=e=>{const i=e.target.dataset?.choice;if(i===undefined)return;try{E.choose(round,Number(i));notice='Preferred scramble ball selected.';afterAction();}catch(err){notice=err.message;refresh();}};
$('coursePutt').onclick=()=>{try{E.finishPutt(round,Number($('coursePuttCount').value));notice='Putts recorded.';afterAction();}catch(e){notice=e.message;refresh();}};
let ending=false;
function setEnding(open){
    ending=open;
    $('endRoundPrompt').classList.toggle('hidden',!open);
    $('courseActive').inert=open;
    $('careerBoard').inert=open;
    if(open){armed=false;$('keepPlaying').focus?.();}
}
$('courseEnd').onclick=()=>{if(round){setEnding(true);refresh();}};
$('keepPlaying').onclick=()=>setEnding(false);
$('confirmEnd').onclick=()=>{
    if(!ending||!round)return;
    if(round.career&&round.done){
        try{showCareer();}catch(e){setEnding(false);notice='Career save failed: '+e.message;refresh();return;}
    }
    try{localStorage.removeItem(STORE);}catch(e){setEnding(false);notice='Could not end saved round: '+e.message;refresh();return;}
    closeLastReplay();clearInspection();if($('courseCamera').value==='explore')$('courseCamera').value='tee';setEnding(false);round=null;armed=false;last=null;aim=null;
    projection=null;viewKey='';detailsOpen=false;notice='Round ended.';openLobby($('courseMode').value);
};
function back(){
    if(!round)return;
    if(ending){setEnding(false);return;}
    if(!$('lastReplayShell').classList.contains('hidden')){closeLastReplay();return;}
    if(detailsOpen){detailsOpen=false;refresh();}
}
$('courseExport').onclick=()=>{if(!round)return;const quote=x=>'"'+String(x).replace(/"/g,'""')+'"';const data=[['Hole','Par',...round.teams.map(t=>t.name)],...round.scorecards.map(h=>[h.hole,h.par,...h.scores])].map(r=>r.map(quote).join(',')).join('\n');const filename='r10-round-scorecard-'+new Date().toISOString().slice(0,10)+'.csv';if(root.R10Native?.exportCsv)root.R10Native.exportCsv(filename,data);else{const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([data],{type:'text/csv'}));a.download=filename;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),3000);}};
const colors={fairway:'#65a85f',green:'#a1d47f',bunker:'#ffe4b0',water:'#2ca9e5',ob:'#9d5652',rough:'#718a55',tee:'#a5c990',woodland:'#123c25',tree_row:'#17492c',tree:'#15432a'};
const outlines={bunker:'#8b6842',water:'#9edbff',ob:'#eb938a',woodland:'#7da76f',tree_row:'#a1b985',tree:'#b2ca91',fairway:'#a4c78b',green:'#d1edaf'};
function draw(t=performance.now()){if(!isCourse()||!round||round.done||detailsOpen)return; if(view==='3d'&&C){draw3d(t);return;}const cv=$('courseCanvas'),box=cv.getBoundingClientRect(),w=box.width,h=box.height;if(w<10||h<10)return;const dpr=Math.min(2,root.devicePixelRatio||1);cv.width=Math.round(w*dpr);cv.height=Math.round(h*dpr);const ctx=cv.getContext('2d');ctx.setTransform(dpr,0,0,dpr,0,0);ctx.fillStyle='#53674a';ctx.fillRect(0,0,w,h);const a=E.active(round),hole=a.hole,key=round.id+':'+hole.number;
const top=Math.min(h*.34,$('courseMapTop').getBoundingClientRect().height),bottom=Math.min(h*.46,$('courseMapBottom').getBoundingClientRect().height);
if(!projection||viewKey!==key||projection.w!==w||projection.h!==h){baseProjection=M.fit([...hole.route,...round.states.map(s=>s.pos)],w,h,top,bottom);projection={...baseProjection};viewKey=key;}
const k=projection.k,project=p=>M.project(projection,p);
function line(p,q,color,dashed=false){ctx.strokeStyle=color;ctx.lineWidth=1.8;ctx.setLineDash(dashed?[5,4]:[]);ctx.beginPath();ctx.moveTo(...project(p));ctx.lineTo(...project(q));ctx.stroke();ctx.setLineDash([]);}
function dot(p,color,r){ctx.fillStyle=color;ctx.beginPath();ctx.arc(...project(p),r,0,Math.PI*2);ctx.fill();}
function path(r){ctx.moveTo(...project(r[0]));for(const p of r.slice(1))ctx.lineTo(...project(p));ctx.closePath();}
const layers=['rough','fairway','tee','green','bunker','water','woodland','tree_row','tree','ob'];
for(const s of hole.surfaces.slice().sort((a,b)=>layers.indexOf(a.type)-layers.indexOf(b.type))){ctx.fillStyle=colors[s.type];ctx.beginPath();path(s.ring);for(const r of s.holes||[])path(r);ctx.fill('evenodd');if(outlines[s.type]){ctx.strokeStyle=outlines[s.type];ctx.lineWidth=['bunker','water','tree_row','tree'].includes(s.type)?1.3:.75;ctx.stroke();}if(['woodland','tree_row','ob'].includes(s.type)){ctx.save();ctx.clip('evenodd');ctx.strokeStyle='#b5d7a333';ctx.lineWidth=1;for(let i=-h;i<w;i+=16){ctx.beginPath();ctx.moveTo(i,0);ctx.lineTo(i+h,h);ctx.stroke();}ctx.restore();}}
for(let i=1;i<hole.route.length;i++)line(hole.route[i-1],hole.route[i],'#d6ebc9',true);
if(last?.entry.hole===hole.number&&last.entry.trace){const full=last.entry.trace;
const progress=Math.min(1,Math.max(0,(t-(last.started??(t-1800)))/1800));
const tr=full.slice(0,Math.max(1,Math.ceil(full.length*Math.min(1,progress/.8))));
$('scoreMoment').classList.toggle('flightPlaying',progress<1);
if(progress<1)scheduleDraw();
for(let i=1;i<tr.length;i++)line(tr[i-1],tr[i],'#ffbc6c');let groundStart=last.entry.carryPos;const steps=last.entry.groundPath||[];for(const step of steps.slice(0,Math.max(0,Math.ceil(steps.length*(progress-.8)/.2)))){line(groundStart,step.pos,'#ffffff');groundStart=step.pos;}dot(progress<1?(progress<=.8?tr.at(-1):groundStart||tr.at(-1)):last.entry.pos,last.entry.impact?'#ff5252':'#ffbc6c',last.entry.impact?6:4);if(last.entry.impact){const [ix,iy]=project(last.entry.pos);ctx.fillStyle='#ffb4a4';ctx.fillText('TREE HIT',ix+8,iy-8);}}
dot(hole.tee,'#fff',4);dot(hole.pin,'#f9ed5f',5);const [px,py]=project(hole.pin);ctx.fillStyle='#fff';ctx.font='12px system-ui';ctx.fillStyle='#e98068';ctx.beginPath();ctx.moveTo(px,py);ctx.lineTo(px,py-12);ctx.lineTo(px+8,py-9);ctx.lineTo(px,py-6);ctx.fill();
round.states.forEach((s,i)=>{dot(s.pos,['#fff','#f9a8d4','#93c5fd','#facc15'][i%4],i===round.turn?6:4);for(const [j,c] of s.candidates.entries()){dot(c.pos,'#ffbc6c',5);const [x,y]=project(c.pos);ctx.fillText(String(j+1),x+6,y-3);}});for(const ring of root.R10Caddie.dispersionRings(landingPattern)){const p=project(ring.center);ctx.beginPath();ctx.arc(p[0],p[1],ring.radius*k,0,Math.PI*2);ctx.fillStyle='#f9d38422';ctx.fill();ctx.strokeStyle='#f9d384';ctx.stroke();}for(const p of landingPattern)dot(p,'#ffe493',2.4);if(aim){line(a.state.pos,aim,'#fff',true);dot(aim,'#fff',3);const [ax,ay]=project(aim);placeAimTag(ax,ay); }
const sy=h-bottom-14,scale=[5,10,20,50,100,200].reduce((n,d)=>d*k<=100?d:n,5);ctx.fillStyle='#fff';ctx.fillText('N ↑',8,top+15);ctx.fillText(scale+' m',10,sy-5);ctx.strokeStyle='#fff';ctx.beginPath();ctx.moveTo(10,sy);ctx.lineTo(10+scale*k,sy);ctx.stroke();}
// Anchor the only target readout beside the aim marker. If it is outside the
// camera frustum or covered by the HUD, use its marker on the inset instead.
function placeAimTag(x,y,visible=true){
    const tag=$('aimTag'),play=$('coursePlay');
    if(!tag.style)return;
    const rect=play.getBoundingClientRect();
    play.style.setProperty('--dock-height',$('courseMapBottom').offsetHeight+'px');
    const inset=$('holeInset').getBoundingClientRect();
    const top=$('courseMapTop').getBoundingClientRect().bottom-rect.top;
    const bottom=$('courseMapBottom').getBoundingClientRect().top-rect.top;
    const width=tag.offsetWidth,height=tag.offsetHeight;
    let left=x+10,upper=y-height-5;
    const overInset=left+width>inset.left-rect.left&&upper+height>inset.top-rect.top;
    if(!visible||x<0||x>rect.width||y<top||y>bottom||overInset){
        const marker=$('holeInsetPlot').querySelector(inspect?.lastLanding?'[data-finish]':'[data-aim]');
        if(!marker)return;
        const box=marker.getBoundingClientRect();
        left=box.left-rect.left-width-8;upper=box.top-rect.top-height/2;
    }
    tag.style.left=Math.max(4,Math.min(rect.width-width-4,left))+'px';
    tag.style.top=Math.max(top,Math.min(bottom-height,upper))+'px';
}
function refreshInset(a){
    const h=a.hole,ball=a.state.pos,target=aim||h.pin;
    const entry=last?.entry.hole===h.number?last.entry:null;
    const weather={...courseSettings(),altitudeM:h.terrain?E.height(h,ball):courseSettings().altitudeM};const key=A.profileKey($('courseClub').value,$('courseLength').value);const sample=root.R10Caddie.plan(h,ball,root.R10Caddie.clubSamples(env.shotHistory?.()||[],F.VERSION,weather),true,key,target,weather);landingPattern=sample?.pattern||[];$('holeInsetPlot').innerHTML=M.holeInset(h,ball,target,entry,landingPattern);
    $('holeInsetCaption').textContent=inspect?.lastLanding&&entry?'Last landing':'Scout target · landing pattern';
    $('aimReading').textContent='◎ '+E.aimLabel(h,ball,target,fmt);
    if(inspect?.lastLanding&&entry){
        $('aimReading').textContent='Finish · '+E.aimLabel(h,entry.from,entry.pos,fmt);
        $('fairwayRoom').textContent=shotResult(entry);return;
    }
    const room=M.fairwayRoom(h,ball,target);
    $('fairwayRoom').textContent=room?'← '+fmt(room.left)+' m   Fairway   '+fmt(room.right)+' m →':'Fairway edges unavailable';
}
function scheduleDraw(){if(framePending)return;framePending=true;requestAnimationFrame(t=>{framePending=false;draw(t);});}
// North-up inspection camera. Centre is in course metres, distance is the
// horizontal setback. Mouse and one-finger drags translate over the terrain.
let inspect=null;
const contacts=new Map();
let suppressAim=false,turnAim=null;
function markInspection(id){for(const name of ['courseBall','inspectTarget','courseLanding','courseGreen'])$(name).setAttribute?.('aria-pressed',String(name===id));}
function clearInspection(){
    markInspection(null);
    inspect=null;contacts.clear();if(round&&!round.done)refreshInset(E.active(round));
    $('coursePlay').classList.toggle('inspecting',false);
    $('courseScoreBack').classList.toggle('hidden',true);
}
function inspectPoint(point,setback=12){
    if(!round||round.done)return;
    const h=E.hole(round);
    inspect={centre:point.slice(),setback,hole:h.number};
    refreshInset(E.active(round));
    view='3d';$('courseView').value=view;$('courseCamera').value='explore';
    $('coursePlay').classList.toggle('inspecting',true);
    $('courseScoreBack').classList.toggle('hidden',!round.reviewHole);
    updateView();scheduleDraw();
}
function inspectBall(){const active=round&&E.active(round);if(active){inspectPoint(active.state.pos,4);markInspection('courseBall');}}
$('courseBall').onclick=inspectBall;
function scoutTarget(){
    if(!round||round.done)return;
    inspectPoint(aim||E.hole(round).pin,8);
    inspect.scouting=true;markInspection('inspectTarget');
}
$('inspectTarget').onclick=()=>{if(inspect?.scouting){clearInspection();view='2d';$('courseView').value='2d';updateView();projection=null;draw();notice='Tap anywhere on the 2D map to set the target.';refresh();}else scoutTarget();};
$('holeInset').onclick=()=>{if(last?.entry.hole===E.hole(round).number)$('courseLanding').onclick();else scoutTarget();};

$('courseLanding').onclick=()=>{
    const h=round&&!round.done&&E.hole(round),e=last?.entry;
    if(!h)return;if(!e||e.hole!==h.number){scoutTarget();return;}
    const contact=e.carryPos||e.pos;
    inspectPoint([(contact[0]+e.pos[0])/2,(contact[1]+e.pos[1])/2],Math.max(8,E.dist(contact,e.pos)*1.55));inspect.lastLanding=true;refreshInset(E.active(round));markInspection('courseLanding');
};
$('courseScoreBack').onclick=()=>{clearInspection();$('courseCamera').value='follow';refresh();};
const shell=$('course3dShell');
shell.onpointerdown=e=>{
    if(!contacts.size){
        suppressAim=false;turnAim=null;
        if(!inspect&&aim&&round&&!round.done&&!round.reviewHole&&!renderer?.replay){
            const a=E.active(round);
            if(!a.state.awaitPutt&&a.state.candidates.length<a.team.members.length)
                turnAim={origin:a.state.pos.slice(),start:aim.slice()};
        }
    }else turnAim=null;
    contacts.set(e.pointerId,{x:e.clientX,y:e.clientY,startX:e.clientX,startY:e.clientY});
    if(contacts.size>1)suppressAim=true;
    shell.setPointerCapture?.(e.pointerId);
};
shell.onpointermove=e=>{
    const finger=contacts.get(e.pointerId);if(!finger)return;
    const dx=e.clientX-finger.x,dy=e.clientY-finger.y;
    finger.x=e.clientX;finger.y=e.clientY;
    if(Math.hypot(finger.x-finger.startX,finger.y-finger.startY)>4)suppressAim=true;
    if(!inspect||contacts.size!==1||!suppressAim)return;
    const metres=2*inspect.setback/Math.max(1,shell.getBoundingClientRect().height);
    inspect.centre[0]-=dx*metres;inspect.centre[1]+=dy*metres*1.45;
    scheduleDraw();
};
shell.onpointerup=e=>{
    const finger=contacts.get(e.pointerId);
    if(turnAim&&finger&&contacts.size===1&&suppressAim){
        const dx=e.clientX-finger.startX,dy=e.clientY-finger.startY;
        if(Math.abs(dx)>6&&Math.abs(dx)>Math.abs(dy)){
            const {origin,start}=turnAim,angle=dx/Math.max(1,shell.getBoundingClientRect().width)*Math.PI/2;
            const east=start[0]-origin[0],north=start[1]-origin[1];
            aim=[origin[0]+east*Math.cos(angle)+north*Math.sin(angle),origin[1]+north*Math.cos(angle)-east*Math.sin(angle)];
            customAim=aim.slice();recommendationKey='';armed=false;notice='';refresh();
        }
    }
    contacts.delete(e.pointerId);turnAim=null;
};
shell.onpointercancel=e=>{contacts.delete(e.pointerId);suppressAim=true;};
function updateView(){
    const h=round&&!round.done&&E.hole(round);
    $('inspectTarget').classList.toggle('hidden',!h);
    const use=view==='3d'&&!!C;$('courseCanvas').classList.toggle('hidden',use);$('course3dShell').classList.toggle('hidden',!use);for(const id of ['courseCamera','courseQuality'])$(id).classList.toggle('hidden',!use);$('courseReplay').disabled=!last||!round||round.done||last.entry.hole!==E.hole(round).number;$('course3dStatus').textContent=use?'3D · '+(round?.course?.terrain?.source||'flat terrain (no DEM)')+' · mapped features / estimated trees · tap ground or switch to 2D to aim':'';}
$('courseView').onchange=()=>{view=$('courseView').value;clearInspection();if($('courseCamera').value==='explore')$('courseCamera').value='tee';try{localStorage.setItem('r10-course-view',view);}catch(e){}renderer?.stop();updateView();scheduleDraw();};$('courseCamera').onchange=()=>{if($('courseCamera').value==='explore'){inspectBall();return;}clearInspection();scheduleDraw();};$('courseQuality').onchange=scheduleDraw;$('courseReplay').onclick=()=>{if(!last||!round||round.done||last.entry.hole!==E.hole(round).number)return;if(inspect){clearInspection();$('courseCamera').value='follow';}last.started=performance.now();renderer?.restart(performance.now());scheduleDraw();};
function draw3d(t){const a=E.active(round),h=a.hole,entry=last?.entry.hole===h.number?last.entry:null,pts=entry?C.shotPoints(h,entry,last.points):[],shot=entry?{...last.shot,points:pts}:null;try{if(!renderer)renderer=new root.Range3D.Renderer($('course3dCanvas'),$('course3dHud'));const scene=C.make({hole:h,inspect,externalAim:true,key:round.id+':'+h.number,position:a.state.pos,aim:aim||h.pin,states:round.states,entry,color:entry?(round.config.humans>1?(last.entry.player==='p0'?'#ffda35':last.entry.player==='p1'?'#68c8ff':'#f6a7e4'):'#ffda35'):null});const playing=renderer.draw({shots:shot?[shot]:[],groups:[],target:null,A:{color:A.color},mode:$('courseCamera').value,quality:$('courseQuality').value||'medium',animate:true,zoom:inspect?1:cameraZoom,scene},t);
    if(renderer.lastCamera){
        const tgt=inspect?.lastLanding&&entry?entry.pos:aim||h.pin,box=$('course3dCanvas').getBoundingClientRect();
        const q=root.Range3D.project([tgt[0]-h.tee[0],E.height(h,tgt)-E.height(h,h.tee)+.65,tgt[1]-h.tee[1]],renderer.lastCamera,box.width/box.height);
        placeAimTag((q.x+1)*box.width/2,(1-q.y)*box.height/2,q.z>.15);
    }
    $('course3dStatus').textContent=(renderer.three?'Three.js':renderer.software?'Software 3D':'Legacy WebGL 2 · fallback')+' · '+(h.terrain?h.terrain.source:'flat terrain (no DEM)')+' · estimated trees · tap ground or switch to 2D to aim';$('scoreMoment').classList.toggle('flightPlaying',playing);if(playing)scheduleDraw();}catch(err){console.warn('Course renderer fallback',err);view='2d';$('courseView').value='2d';updateView();$('course3dStatus').textContent='3D unavailable; switched to 2D map.';draw();}}
$('course3dShell').onclick=e=>{if((inspect&&!inspect.scouting)||suppressAim||!round||round.done||!renderer?.lastCamera||(renderer.replay&&!inspect?.scouting))return;const a=E.active(round);if(round.reviewHole||a.state.awaitPutt||a.state.candidates.length>=a.team.members.length)return;const b=$('course3dCanvas').getBoundingClientRect(),p=C.groundPick(renderer.lastCamera,2*(e.clientX-b.left)/b.width-1,1-2*(e.clientY-b.top)/b.height,b.width/b.height,a.hole);if(!p)return;const next=[p[0]+a.hole.tee[0],p[1]+a.hole.tee[1]];if(E.dist(next,a.state.pos)<1)return;aim=next;customAim=next.slice();recommendationKey='';if(inspect?.scouting)inspect.centre=next.slice();armed=false;notice='Aim updated.';refresh();};
const cv=$('courseCanvas'),pointers=new Map();let dragged=false,gestureStart=null;
function local(e){const b=cv.getBoundingClientRect();return [e.clientX-b.left,e.clientY-b.top];}
function aimAt(p){if(!round||round.done||!projection)return;const a=E.active(round);if(round.reviewHole||a.state.awaitPutt||a.state.candidates.length>=a.team.members.length)return;const pos=M.unproject(projection,p);if(E.dist(pos,a.state.pos)<1)return;aim=pos;customAim=pos.slice();recommendationKey='';armed=false;notice='Aim updated.';refresh();}
function zoomBy(f,p){if(!projection||!baseProjection)return;projection=M.zoom(projection,f,p||[projection.ox,projection.oy],baseProjection.k);draw();}
cv.onpointerdown=e=>{if(!projection)return;e.preventDefault();const p=local(e);if(!pointers.size){dragged=false;gestureStart=p;}else dragged=true;pointers.set(e.pointerId,p);cv.setPointerCapture?.(e.pointerId);};
cv.onpointermove=e=>{if(!pointers.has(e.pointerId)||!projection)return;e.preventDefault();const before=[...pointers.values()],p=local(e),old=pointers.get(e.pointerId);pointers.set(e.pointerId,p);const after=[...pointers.values()];if(after.length>=2){dragged=true;const mid=q=>[(q[0][0]+q[1][0])/2,(q[0][1]+q[1][1])/2],d=q=>Math.hypot(q[0][0]-q[1][0],q[0][1]-q[1][1]),m=mid(before),n=mid(after);if(d(before)>2){projection=M.zoom(projection,d(after)/d(before),m,baseProjection.k);projection=M.pan(projection,n[0]-m[0],n[1]-m[1]);draw();}}else if(dragged||Math.hypot(p[0]-gestureStart[0],p[1]-gestureStart[1])>5){dragged=true;projection=M.pan(projection,p[0]-old[0],p[1]-old[1]);draw();}};
cv.onpointerup=e=>{if(!pointers.has(e.pointerId))return;const p=local(e);pointers.delete(e.pointerId);if(!pointers.size&&!dragged&&gestureStart&&Math.hypot(p[0]-gestureStart[0],p[1]-gestureStart[1])<=5)aimAt(p);};cv.onpointercancel=e=>{pointers.delete(e.pointerId);dragged=true;};cv.onwheel=e=>{if(!projection)return;e.preventDefault();zoomBy(Math.exp(-e.deltaY*.002),local(e));};
function courseZoom(f){
    if(view==='2d'){zoomBy(f);return;}
    if(inspect){inspect.setback=Math.max(2,Math.min(220,inspect.setback/f));scheduleDraw();return;}
    cameraZoom=Math.max(.55,Math.min(4,cameraZoom*f));scheduleDraw();
}
root.Range3D.bindZoom($('course3dShell'),courseZoom);
$('courseZoomIn').onclick=()=>courseZoom(1.4);
$('courseZoomOut').onclick=()=>courseZoom(1/1.4);
$('courseZoomReset').onclick=()=>{clearInspection();cameraZoom=1;projection=null;$('courseCamera').value='aerial';draw();};
$('courseGreen').onclick=()=>{
    if(!round||round.done)return;
    clearInspection();markInspection('courseGreen');if($('courseCamera').value==='explore')$('courseCamera').value='tee';view='2d';$('courseView').value=view;updateView();draw();
    if(!projection)return;
    const pin=E.hole(round).pin,ring=E.hole(round).surfaces.find(s=>s.type==='green'&&s.ring.some(p=>E.dist(p,pin)<30))?.ring||[pin];
    const radius=Math.max(16,...ring.map(p=>E.dist(p,pin)));
    projection={...projection,cx:pin[0],cy:pin[1],k:Math.min(projection.w*.43,Math.max(30,projection.h-$('courseMapTop').getBoundingClientRect().height-$('courseMapBottom').getBoundingClientRect().height)*.43)/radius};
    draw();
};
$('courseDetailsToggle').onclick=()=>{detailsOpen=true;armed=false;refresh();};$('courseDetailsClose').onclick=()=>{detailsOpen=false;refresh();};
let shownScore='';
function renderHoleScore(){
    const card=round?.reviewHole && round.scorecards.at(-1);
    $('scoreMoment').classList.toggle('hidden',!card);
    if(!card){shownScore='';return;}
    const key=round.id+'-'+card.hole;
    if(shownScore===key)return;
    shownScore=key;$('scoreMoment').classList.toggle('flightPlaying',!!last&&last.entry.hole===card.hole&&performance.now()-last.started<1800);
    const names={'-3':'Albatross','-2':'Eagle','-1':'Birdie',0:'Par',1:'Bogey',2:'Double bogey',3:'Triple bogey'};
    const name=strokes=>strokes===1?'Hole in one':names[strokes-card.par]||((strokes-card.par>0?'+':'')+(strokes-card.par)+' to par');
    const totals=E.totals(round);
    const rows=round.teams.map((team,i)=>{
        const state=round.states[i],strokes=card.scores[i],total=totals[i].strokes-totals[i].par;
        const result=state.pickedUp?'Picked up':name(strokes);
        const putts=state.manualPutts??state.last?.putts;
        const finish=putts===0?'Holed · 0 putts':Number.isInteger(putts)&&state.last?.pos?
            'Finished '+fmt(E.dist(state.last.pos,E.hole(round).pin))+' m from the pin · '+putts+(state.manualPutts?' putt':' auto-putt')+(putts===1?'':'s'):'';
        return '<div class="scoreLine"><small>'+esc(team.name)+'</small><strong>'+esc(result)+'</strong><span>'+strokes+' stroke'+(strokes===1?'':'s')+(finish?' · '+finish:'')+' · Round '+(total===0?'E':total>0?'+'+total:total)+'</span></div>';
    });
    $('scoreMomentContent').innerHTML='<p>HOLE '+card.hole+' <i> / </i> PAR '+card.par+'</p>'+rows.join('');
}
try{$('courseHudPreset').value=localStorage.getItem('r10-course-hud')==='technical'?'technical':'playing';}catch(e){}$('courseHudPreset').onchange=()=>{try{localStorage.setItem('r10-course-hud',$('courseHudPreset').value);}catch(e){}refresh();};
function refresh(){renderHoleScore();env.setRoundSession(!!round);$('lastCourseReplay').classList.toggle('hidden',!round||!last);updateSetup();try{showCareer();}catch(e){notice='Career could not be saved or loaded: '+e.message;}$('courseStatus').textContent=notice;$('courseMapNotice').textContent=/^(Shot recorded for |Round started|Ready for |Aim updated)/.test(notice)?'':notice;$('courseSetup').classList.toggle('hidden',!!round);$('courseActive').classList.toggle('hidden',!round);if(!round){renderer?.stop();renderCoach('courseCoach',null);return;}const done=round.done,a=E.active(round);
if(!done&&a&&aim&&!round.reviewHole&&!a.player.bot&&!a.state.awaitPutt&&a.state.candidates.length<a.team.members.length){
 const key=[round.id,round.index,round.turn,a.state.strokes,a.state.candidates.length].join('/');
 if(key!==recommendationKey){recommendationKey=key;const weather={...courseSettings(),altitudeM:a.hole.terrain?E.height(a.hole,a.state.pos):courseSettings().altitudeM};const groups=root.R10Caddie.clubSamples(env.shotHistory?.()||[],F.VERSION,weather);recommendation=root.R10Caddie.plan(a.hole,a.state.pos,groups,true,'',customAim,weather);if(recommendation){const [club,length]=recommendation.club.split(' · ');$('courseClub').value=club;env.syncCourseLength();$('courseLength').value=length==='Half'?'half':length==='¾'?'threeQuarter':'full';aim=recommendation.target.slice();}}
 }
 if(document.activeElement!==$('courseTemp'))$('courseTemp').value=courseSettings().temperatureC;
 $('courseBagHint').textContent=!done&&a&&aim?(recommendation?'Caddie: '+recommendation.club+(recommendation.estimated?' (generic estimate)':'')+' · '+recommendation.hazards+'/'+recommendation.n+' modeled hazard landings · ':'')+env.distanceHint(E.dist(a.state.pos,aim)):'';
if(root.R10GameHud){$('courseCaddieCue').textContent=recommendation&&!done&&!round.reviewHole?'Caddie · '+recommendation.club+(recommendation.estimated?' · estimate':'')+' · '+recommendation.hazards+'/'+recommendation.n+' hazard samples':'';$('courseCaddieCue').classList.toggle('hidden',!$('courseCaddieCue').textContent);}
$('courseContinue').classList.toggle('hidden',!round.reviewHole);
$('courseContinue').textContent=round.index===round.numbers.length-1?'Finish round':'Next tee';
if(a){
    refreshInset(a);
    const e=last?.entry;
    if(root.R10GameHud){const t=E.totals(round)[round.turn],shot=e&&e.hole===a.hole.number?last.shot:null;root.R10GameHud.update($('courseHud'),shot,{course:true,pin:E.dist(a.state.pos,a.hole.pin),strokes:a.state.strokes,score:t.strokes-t.par,total:shot&&!e.impact?shot.carry+(e.rollout||0):null,target:shot?.practiceTarget,shape:shot?A.shape(shot,env.hand())?.label:null},$('courseHudPreset').value);$('courseLie').textContent=e&&e.hole===a.hole.number?(e.impact?'Tree hit · OB':(e.penalty?'Penalty · ':'')+e.surface):'';$('courseLie').classList.toggle('hidden',!$('courseLie').textContent);const status=round.config.source==='DEMO'?'Demo mode':$('headerStatusText').textContent==='Demo mode'?'R10 disconnected':$('headerStatusText').textContent;root.R10GameHud.status($('courseReady'),status==='R10 ready',status||'R10 waiting');}
    $('courseResultHud').textContent=e&&e.hole===a.hole.number&&!round.reviewHole?(e.impact?'Tree hit':(e.penalty?'Penalty · ':'')+e.surface+' · Carry '+fmt(last.shot.carry)+' m · Offline '+fmt(Math.abs(last.shot.offline))+' m '+(last.shot.offline<0?'L':'R')):'';

}
const ready=a&&a.state.candidates.length===a.team.members.length; $('courseTitle').textContent=(round.career?'Season '+round.career.season+' · '+round.career.name+' · ':'')+round.course.name+' · '+(round.config.source==='DEMO'?'Demo':'Live R10');$('courseAttribution').textContent=round.course.attribution+' · Estimated bounce and rollout; unmapped turf uses a default resistance. Trees / woodland: simulator lost-ball OB, not official OB. Airborne collisions use estimated canopy heights. Terrain: '+(round.course.terrain?.source||'flat (no DEM)')+'.'+(a?.hole.approximatePuttingTarget?' · Green unmapped; 10 m gameplay-only putting target.':'')+(round.course.id==='trier'&&a?.hole.number===10?' · Hole 10: fairway bunker reported missing; exact outline pending verification.':'');$('courseDetailsAttribution').textContent=$('courseAttribution').textContent;$('coursePlay').classList.toggle('hidden',done);$('courseDetailPanel').classList.toggle('courseDetailsOpen',!done&&detailsOpen);$('courseDetailPanel').classList.toggle('courseDetailsClosed',!done&&!detailsOpen);$('courseMapTitle').textContent=done?'':round.course.name+' · Hole '+a.hole.number+' · Par '+a.hole.par+' · '+fmt(courseSettings().temperatureC)+'°C';$('courseHole').textContent=done?'Round complete':'Hole '+a.hole.number+' · Par '+a.hole.par+' · '+(round.index+1)+'/'+round.numbers.length;$('courseTurn').textContent=done?'':(a.team.name===a.player.name?'':a.team.name+' · ')+(ready?'Select scramble ball':a.state.awaitPutt?'Enter putts':a.player.name)+' · '+a.state.strokes+(a.state.strokes===1?' stroke':' strokes');$('courseArm').disabled=done||round.reviewHole||armed||ready||a?.state.awaitPutt||a?.player.bot;$('courseArm').textContent=armed?'Ready':'Live shots auto-count';$('courseDemo').classList.toggle('hidden',round.config.source!=='DEMO'||done);$('courseArm').classList.toggle('hidden',round.config.source==='DEMO');$('courseDemo').disabled=done||round.reviewHole||ready||a?.state.awaitPutt||a?.player.bot;$('courseChoices').innerHTML=ready?a.state.candidates.map((c,i)=>`<button class="secondary wideBtn" data-choice="${i}">Ball ${i+1} · ${esc(a.team.members[i].name)} · ${esc(c.impact?'Tree collision':c.surface)} · ${fmt(E.dist(c.penalty?c.from:c.pos,a.hole.pin))} m to pin${c.penalty?' · +1 penalty / replay':''}</button>`).join(''):'';$('coursePuttBox').classList.toggle('hidden',!a?.state.awaitPutt);$('courseScore').innerHTML='<table class="practiceTable"><thead><tr><th>Hole / Par</th>'+round.teams.map(t=>'<th>'+esc(t.name)+'</th>').join('')+'</tr></thead><tbody>'+round.scorecards.map(h=>'<tr><td>'+h.hole+' / '+h.par+'</td>'+h.scores.map(s=>'<td>'+s+'</td>').join('')+'</tr>').join('')+'<tr><th>Total</th>'+E.totals(round).map(t=>'<th>'+t.strokes+' ('+(t.strokes-t.par>0?'+':'')+(t.strokes-t.par)+')</th>').join('')+'</tr></tbody></table>';$('courseLast').innerHTML=last?`<div class="clubCard"><strong>${esc(last.shot.club)} · ${esc(last.entry.player==='p0'?'Player 1':'Player 2')}</strong><p><strong>${esc(shotResult(last.entry))} · Offline ${fmt(Math.abs(last.shot.offline))} m ${last.shot.offline<0?'L':'R'} · Launch ${fmt(last.shot.launch)}°</strong></p><p>${esc(A.shape(last.shot,env.hand())?.label||'Shape unavailable')} · ${esc(last.entry.impact?'Tree collision at '+fmt(last.entry.impact.distance)+' m (height '+fmt(last.entry.impact.height)+' m)':last.entry.surface)}</p></div>`:'';const peers=last?round.log.filter(e=>e.player===last.entry.player&&e.shot.source===last.shot.source).map(e=>e.shot).reverse():[];renderCoach('courseCoach',last?.shot||null,peers);const feedback=$('courseCoach').innerHTML;const title=feedback.match(/<h3>(.*?)<\/h3>/)?.[1];$('courseMapCoach').innerHTML=title?'Coach: '+title+' · Round details for full advice':'';updateView();if(isCourse())scheduleDraw();}
let detailRenderer=null, replayFrame=null;
function closeLastReplay(){
    if(replayFrame!==null)cancelAnimationFrame(replayFrame);
    replayFrame=null;detailRenderer?.stop();$('lastReplayShell').classList.toggle('hidden',true);
}
$('closeLastReplay').onclick=closeLastReplay;
$('lastCourseReplay').onclick=()=>{
    if(!round||!last)return;
    closeLastReplay();
    const e=last.entry,h={...round.course.holes.find(h=>h.number===e.hole),terrain:round.course.terrain};
    const scene=C.make({hole:h,key:round.id+':'+e.hole,position:e.from,aim:e.aim,states:[],entry:e,color:A.color(last.shot.club)});
    const shot={...last.shot,points:C.shotPoints(h,e,last.points)};
    $('lastReplayShell').classList.toggle('hidden',false);
    try{
        if(!detailRenderer)detailRenderer=new root.Range3D.Renderer($('lastReplayCanvas'),$('lastReplayHud'));
        detailRenderer.restart(performance.now());
        const drawFrame=t=>{
            replayFrame=null;
            try{
                if(detailRenderer.draw({shots:[shot],groups:[],target:null,A:{color:A.color},mode:'follow',
                    quality:$('courseQuality').value||'medium',animate:true,scene},t))
                    replayFrame=requestAnimationFrame(drawFrame);
            }catch(err){closeLastReplay();notice='Replay unavailable: '+err.message;refresh();}
        };
        replayFrame=requestAnimationFrame(drawFrame);
    }catch(err){closeLastReplay();notice='Replay unavailable: '+err.message;refresh();}
};
function setCourseTemperature(t){if(!round||round.done||!Number.isFinite(t)||t< -30||t>50)return;round.config.temperatureC=t;recommendationKey='';save();refresh();}
$('courseTemp').onchange=()=>{const raw=$('courseTemp').value,t=Number(raw);if(raw===''||!Number.isFinite(t)||t< -30||t>50){$('courseTemp').value=courseSettings().temperatureC;return;}$('courseWeatherStatus').textContent='Manual temperature';setCourseTemperature(t);};
$('courseWeather').onclick=()=>{if(!round||round.done)return;const id=round.id;$('courseWeatherStatus').textContent='Fetching course temperature…';env.requestCourseWeather(round.course.origin,(t,error)=>{if(round?.id!==id)return;if(error||!Number.isFinite(t)){$('courseWeatherStatus').textContent=error||'No weather value received.';return;}$('courseWeatherStatus').textContent='Open-Meteo · current model temperature';setCourseTemperature(t);});};
function leave(){closeLastReplay();armed=false;pointers.clear();renderer?.stop();}
updateSetup();refresh();return {capture,refresh,draw,leave,back,openLobby};}
root.R10CourseUI={init};
})(typeof globalThis!=='undefined'?globalThis:this);
