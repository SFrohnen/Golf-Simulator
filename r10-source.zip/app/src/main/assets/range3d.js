/* Offline WebGL2 practice range. Presentation only: never changes recorded shots. */
(function(root){'use strict';
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v)), mix=(a,b,t)=>a+(b-a)*t;
const valid=p=>p&&['x','y','z','t'].every(k=>typeof p[k]==='number'&&Number.isFinite(p[k]));
function trajectory(s){return Array.isArray(s?.points)?s.points.filter(valid).filter((p,i,a)=>!i||p.t>a[i-1].t):[];}
function sample(points,t){if(!points.length)return null;if(t<=points[0].t)return {...points[0]};for(let i=1;i<points.length;i++)if(t<=points[i].t){let a=points[i-1],b=points[i],k=clamp((t-a.t)/(b.t-a.t),0,1);return {x:mix(a.x,b.x,k),y:mix(a.y,b.y,k),z:mix(a.z,b.z,k),t};}return {...points.at(-1)};}
function world(p){return [p.y,p.z+.12,p.x];}
function hex(s){const n=parseInt(String(s).replace('#',''),16);return Number.isFinite(n)?[(n>>16&255)/255,(n>>8&255)/255,(n&255)/255]:[1,1,1];}
const sub=(a,b)=>a.map((v,i)=>v-b[i]),dot=(a,b)=>a.reduce((s,v,i)=>s+v*b[i],0),cross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]],norm=a=>{let l=Math.hypot(...a)||1;return a.map(v=>v/l)};
function camera(eye,at){let f=norm(sub(at,eye)),r=norm(cross([0,1,0],f)),u=cross(f,r);return {eye,at,f,r,u};}
function project(v,c,aspect,fov=60){const p=sub(v,c.eye),z=dot(p,c.f),s=1/Math.tan(fov*Math.PI/360);return {x:dot(p,c.r)*s/(z*aspect),y:dot(p,c.u)*s/z,z};}
function extent(shots,target,groups=[]){let depth=Math.max(100,(target||0)+25),half=45,apex=0;for(const s of shots){depth=Math.max(depth,s.downrange+20);half=Math.max(half,Math.abs(s.offline)+15);apex=Math.max(apex,Number(s.apex)||0);}for(const g of groups){depth=Math.max(depth,g.center.y+g.radius+10);half=Math.max(half,Math.abs(g.center.x)+g.radius+10);}return {depth:Math.max(100,Math.ceil(depth/25)*25),half,apex};}
function chooseCamera(mode,e,ball,aspect){if(mode==='follow'&&ball){return camera([ball.y*.85,Math.max(3.8,ball.z+5),ball.x-17],[ball.y,Math.max(1,ball.z*.8),ball.x+22]);}if(mode==='aerial'){const d=Math.max(e.depth,e.half*2/Math.max(.5,aspect));return camera([0,d*1.05,-d*.42],[0,0,e.depth*.46]);}return camera([0,3.3,-9],[0,Math.max(5,e.apex*.34),Math.max(60,e.depth*.42)]);}
const VERT=`#version 300 es
in vec3 pos;in vec3 color;in float size;uniform vec3 eye, right, up, forward;uniform float aspect, focal, pixelRatio;out vec3 vColor;out float depth;out vec3 vWorld;out float material;
void main(){vec3 p=pos-eye;float z=dot(p,forward);float near=.15,far=1800.;gl_Position=vec4(dot(p,right)*focal/aspect,dot(p,up)*focal,(far+near)/(far-near)*z-2.*far*near/(far-near),z);gl_PointSize=max(1.,size)*pixelRatio;vColor=color;depth=z;vWorld=pos;material=size;}`;
const FRAG=`#version 300 es
precision highp float;in vec3 vColor;in float depth;in vec3 vWorld;in float material;uniform bool pointMode;out vec4 outColor;
float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
float noise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(hash(i),hash(i+vec2(1,0)),f.x),mix(hash(i+vec2(0,1)),hash(i+vec2(1,1)),f.x),f.y);}
void main(){vec3 c=vColor;if(pointMode){float r=distance(gl_PointCoord,vec2(.5));if(r>.5)discard;c*=1.-.32*smoothstep(.21,.5,r);}else if(material<-.5){vec2 p=vWorld.xz;float coarse=noise(p*.25)-.5;float detail=(noise(p*11.)-.5)*(1.-smoothstep(.045,.30,length(fwidth(p))));float fine=(hash(floor(p*55.))-.5)*(1.-smoothstep(.01,.07,length(fwidth(p))));c*=1.+.15*coarse+.22*detail+.12*fine;}
float fog=smoothstep(80.,650.,depth)*.75;outColor=vec4(mix(c,vec3(.62,.75,.76),fog),1.);}`;
function rollVisual(land,roll,p){let k=1-(1-p)*(1-p);return {x:mix(land.x,roll.finalDownrange,k),y:mix(land.y,roll.finalOffline,k),z:Math.max(0,Math.sin(p*3*Math.PI)*Math.max(0,1-p)*Math.min(.65,roll.rollout*.04)),t:land.t};}
function blendCamera(a,b,k){let eye=a.eye.map((v,i)=>mix(v,b.eye[i],k)),f=norm(a.f.map((v,i)=>mix(v,b.f[i],k)));return camera(eye,eye.map((v,i)=>v+f[i]));}
function program(gl){function shader(type,src){const s=gl.createShader(type);gl.shaderSource(s,src);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS)){const err=gl.getShaderInfoLog(s);gl.deleteShader(s);throw Error(err);}return s;}let v=shader(gl.VERTEX_SHADER,VERT),f=shader(gl.FRAGMENT_SHADER,FRAG),p=gl.createProgram();gl.attachShader(p,v);gl.attachShader(p,f);gl.linkProgram(p);gl.deleteShader(v);gl.deleteShader(f);if(!gl.getProgramParameter(p,gl.LINK_STATUS))throw Error(gl.getProgramInfoLog(p));return p;}
function geometry(){const tris=[],lines=[],dots=[];const push=(a,p,c,size=1)=>a.push(...p,...c,size);const tri=(a,b,c,col,mat=1)=>{[a,b,c].forEach(p=>push(tris,p,col,mat));};const line=(a,b,c)=>{push(lines,a,c);push(lines,b,c);};const quad=(a,b,c,d,col,mat=1)=>{tri(a,b,c,col,mat);tri(a,c,d,col,mat);};const point=(a,col,size)=>push(dots,a,col,size);function ring(x,z,r,col,y=.09,n=64){for(let i=0;i<n;i++){let a=i*2*Math.PI/n,b=(i+1)*2*Math.PI/n;line([x+r*Math.cos(a),y,z+r*Math.sin(a)],[x+r*Math.cos(b),y,z+r*Math.sin(b)],col);}}function disc(x,z,r,col,y=.03,n=48,mat=1){for(let i=0;i<n;i++){let a=i*2*Math.PI/n,b=(i+1)*2*Math.PI/n;tri([x,y,z],[x+r*Math.cos(a),y,z+r*Math.sin(a)],[x+r*Math.cos(b),y,z+r*Math.sin(b)],col,mat);}}return {tris,lines,dots,tri,line,quad,point,ring,disc};}
// Deterministic scene assets: procedural colors, shadow patches, layered foliage and terrain silhouettes.
const shade=(c,k)=>c.map(v=>clamp(v*k,0,1));
const random=n=>{const x=Math.sin(n*127.1+311.7)*43758.5453;return x-Math.floor(x);};
function oval(g,x,z,rx,rz,col,y=.025,n=32,mat=1){for(let j=0;j<n;j++){let a=j*Math.PI*2/n,b=(j+1)*Math.PI*2/n;g.tri([x,y,z],[x+rx*Math.cos(a),y,z+rz*Math.sin(a)],[x+rx*Math.cos(b),y,z+rz*Math.sin(b)],col,mat);}}
function ellipsoid(g,x,y,z,rx,ry,rz,col,seed,segments=9,bands=5){
 const p=(a,b)=>[x+rx*Math.cos(a)*Math.sin(b),y+ry*Math.cos(b),z+rz*Math.sin(a)*Math.sin(b)];
 for(let i=0;i<bands;i++)for(let j=0;j<segments;j++){let a=j*Math.PI*2/segments,b=(j+1)*Math.PI*2/segments,t=i*Math.PI/bands,u=(i+1)*Math.PI/bands;let n=[Math.cos((a+b)/2)*Math.sin((t+u)/2),Math.cos((t+u)/2),Math.sin((a+b)/2)*Math.sin((t+u)/2)];let k=.69+.37*Math.max(0,dot(n,norm([-.65,.85,-.4])))+.12*random(seed+i*31+j);g.quad(p(a,t),p(b,t),p(b,u),p(a,u),shade(col,k));}}
function tree(g,x,z,h,seed,quality){let r=h*(.23+.09*random(seed+4)),tr=h*.48,base=[.23+.10*random(seed),.34+.14*random(seed+7),.11+.06*random(seed+3)];
 // Tapered trunk, lit faces rather than a flat billboard.
 for(let j=0;j<6;j++){let a=j*Math.PI/3,b=(j+1)*Math.PI/3;g.quad([x+.22*Math.cos(a),0,z+.22*Math.sin(a)],[x+.22*Math.cos(b),0,z+.22*Math.sin(b)],[x+.10*Math.cos(b),tr,z+.10*Math.sin(b)],[x+.10*Math.cos(a),tr,z+.10*Math.sin(a)],shade([.38,.29,.17],.72+.25*random(seed+j)));}
 const n=quality==='low'?6:quality==='high'?12:9,bands=quality==='high'?6:5;
 ellipsoid(g,x,h*.72,z,r,h*.32,r*.9,base,seed,n,bands);
 if(quality!=='low')for(let j=0;j<(quality==='high'?4:3);j++){let a=j*2.4+seed,rr=r*(.47+.19*random(seed+j+60));ellipsoid(g,x+Math.cos(a)*rr,h*(.60+.16*random(seed+j+17)),z+Math.sin(a)*rr,r*.67,h*.23,r*.64,shade(base,.9+.17*random(seed+j+21)),seed+j*37,n,bands);}}
function green(g,x,z,r=12,active=false){oval(g,x,z,r+1.2,r*.79+1.2,[.37,.53,.20],.018,40,-1);oval(g,x,z,r,r*.79,[.46,.66,.29],.025,40,-1);oval(g,x,z,r*.93,r*.73,[.48,.69,.32],.031,40,-1);if(active)return;g.line([x,.04,z],[x,2.8,z],[.97,.97,.90]);g.tri([x,2.8,z],[x+1.6,2.43,z],[x,2.06,z],[.93,.39,.19]);}
function ground(e,quality){const g=geometry(),{quad,tri}=g;const half=Math.max(40,e.half+7),end=Math.max(350,e.depth+70),stride=quality==='low'?24:quality==='high'?9:14;
 // Broad rough base, softly varied blocks and alternating mown fairway stripes.
 quad([-900,-.08,-100],[900,-.08,-100],[900,-.08,1000],[-900,-.08,1000],[.30,.43,.19],-1);
 for(let z=-24,i=0;z<end;z+=stride,i++){let x0=Math.min(half,21+Math.max(0,z)*.10),x1=Math.min(half,21+Math.max(0,z+stride)*.10);const band=i%2?[.37,.56,.21]:[.43,.62,.25];let cells=quality==='low'?4:quality==='high'?10:6;for(let k=0;k<cells;k++){let a=-1+2*k/cells,b=-1+2*(k+1)/cells;quad([a*x0,0,z],[b*x0,0,z],[b*x1,0,z+stride],[a*x1,0,z+stride],shade(band,.96+.075*random(i*17+k)),-1);}for(let side of [-1,1]){quad([side*x0,-.02,z],[side*(half+16),-.02,z],[side*(half+16),-.02,z+stride],[side*x1,-.02,z+stride],shade([.29,.45,.18],.91+.14*random(i+side*17)),-1);}}
 // A close-cut tee deck and a pair of tee markers.
 oval(g,0,0,5.2,4.6,[.37,.53,.24],.012,36,-1);quad([-3,.035,-2.8],[3,.035,-2.8],[3,.035,2.6],[-3,.035,2.6],[.50,.66,.31],-1);
 for(let z=-2.8;z<2.5;z+=.9)quad([-3,.038,z],[3,.038,z],[3,.038,z+.37],[-3,.038,z+.37],[.47,.63,.28],-1);
 for(let side of [-1,1]){let x=side*2.2;oval(g,x,.1,.32,.26,[.20,.33,.13],.045,12);quad([x-.22,.05,.0],[x+.22,.05,.0],[x+.22,.32,.0],[x-.22,.32,.0],[.94,.92,.77]);}
 // Ground-level target greens are separate from the active practice target overlay.
 for(let m=50;m<=Math.min(end-10,350);m+=50){let x=m%100===0?0:(m%150===0?-8:9);green(g,x,m,Math.min(12,8+m*.012));}
 const trees=[];const step=quality==='low'?27:quality==='high'?13:19;for(let side of [-1,1])for(let z=8,i=0;z<end+60;z+=step,i++){let seed=i+side*101, x=side*(Math.min(half,21+z*.10)+9+random(seed+2)*11),h=7+6*random(seed);trees.push([x,z,h,seed]);if(quality!=='low'&&i%2===0){trees.push([x+side*(9+random(seed+9)*8),z+step*.47,8+6*random(seed+8),seed+83]);if(i<8)trees.push([x+side*(22+random(seed+19)*16),z+step*.23,10+6*random(seed+28),seed+123]);}}
 for(let i=0;i<18;i++){let x=-135+i*16,z=end+42+18*random(i+555);trees.push([x,z,8+7*random(i+605),i+700]);}
 // Soft-looking overlapping ground shadow footprints, offset consistently away from sunlight.
 for(const [x,z,h] of trees){oval(g,x+h*.19,z+h*.12,h*.34,h*.23,[.25,.39,.16],.011,16);oval(g,x+h*.14,z+h*.08,h*.23,h*.16,[.21,.34,.14],.014,16);}
 g.groundTriangles=g.tris.length/21;
 // Distant decorative rolling hills, not playable elevation. Multiple depth layers.
 for(let layer=0;layer<3;layer++){let z=510+layer*150;for(let i=0;i<30;i++){let x=-900+i*60,b=x+60;let h=xx=>20+layer*12+18*Math.sin(xx*.006+layer*2)+10*Math.sin(xx*.013+layer);quad([x,-.07,z],[b,-.07,z],[b,h(b),z],[x,h(x),z],shade([.30,.48,.31],1+layer*.10));}}
 for(const [x,z,h,seed] of trees)tree(g,x,z,h,seed,quality);
 // Target marker boards, painted posts and sunlit faces.
 for(let m=50;m<=Math.min(e.depth,350);m+=50){let x=-14;g.line([x-.8,0,m],[x-.8,1.25,m],[.28,.23,.12]);g.line([x+.8,0,m],[x+.8,1.25,m],[.28,.23,.12]);quad([x-1.25,.65,m],[x+1.25,.65,m],[x+1.25,1.65,m],[x-1.25,1.65,m],[.94,.83,.40]);}
 return g;}
function dynamic(e,shots,target,groups,A,points,ball,playing,roll=null,rolling=false,cam=null){const g=geometry();for(let m=25;m<=e.depth;m+=25){g.line([-8,.05,m],[8,.05,m],[.66,.79,.52]);}for(let m=0;m<e.depth;m+=10)g.line([0,.06,m],[0,.06,m+4],[.74,.83,.59]);if(Number.isFinite(target)){g.disc(0,target,15.5,[.37,.56,.25],.042,64,-1);g.disc(0,target,14.8,[.49,.68,.32],.052,64,-1);for(let r=3;r<=15;r+=3)g.ring(0,target,r,r===3?[.98,1,.72]:[.76,.88,.60]);g.line([0,.08,target],[0,3,target],[.97,.97,.9]);g.tri([0,3,target],[1.8,2.65,target],[0,2.2,target],[.98,.81,.25]);}
for(const group of groups)g.ring(group.center.x,group.center.y,Math.max(.35,group.radius),hex(group.color),.13);
for(const s of shots){if(playing&&s===shots[0])continue;g.point([s.offline,.18,s.downrange],hex(A.color(s.club)),s===shots[0]?9:6);}
if(points.length){const col=hex(A.color(shots[0]?.club));let last=points[0];
 const tracer=(a,b)=>{g.line(a,b,col);if(!cam)return;let d=sub(b,a),view=sub(cam.eye,a),n=norm(cross(d,view));if(Math.hypot(...d)<1e-6)return;let mid=a.map((v,i)=>(v+b[i])/2),width=clamp(dot(sub(mid,cam.eye),cam.f)*.0016,.045,.35);let off=(p,k)=>p.map((v,i)=>v+n[i]*k);g.quad(off(a,width),off(b,width),off(b,-width),off(a,-width),shade(col,.82));g.quad(off(a,width*.38),off(b,width*.38),off(b,-width*.38),off(a,-width*.38),col.map(v=>mix(v,1,.22)));};for(let i=1;i<points.length;i++){let p=points[i];if(playing&&!rolling&&p.t>ball.t){if(last.t<ball.t)tracer(world(last),world(ball));break;}tracer(world(last),world(p));last=p;}if(roll&&(!playing||rolling)){const land=points.at(-1),finish=ball||land;g.ring(land.y,land.x,1.2,[.95,.93,.65],.11,24);const d=Math.hypot(finish.x-land.x,finish.y-land.y);for(let i=0;i<d;i+=1.8){const at=k=>[mix(land.y,finish.y,k/d),.13,mix(land.x,finish.x,k/d)];g.line(at(i),at(Math.min(d,i+.85)),shade(col,.85));}if(!playing)g.ring(finish.y,finish.x,.65,[1,1,.95],.14,24);}if(ball){g.point(world(ball),[1,1,.93],8);g.point([ball.y,.08,ball.x],[.12,.19,.12],5);}}
g.point([0,.15,0],[1,1,.94],7);return g;}
// Canvas fallback: same 3D coordinates, perspective, clipping and animation; no GPU requirement.
let grassTile=null;
function grain(ctx,w,h){
 if(!root.document?.createElement||!ctx.createPattern)return;
 if(!grassTile){let c=root.document.createElement('canvas');c.width=c.height=96;let q=c.getContext('2d');if(!q)return;let d=q.createImageData(96,96);for(let i=0;i<96*96;i++){let n=Math.round(105+random(i*1.7)*47+random(i%96*3+Math.floor(i/96)*.7)*40);d.data.set([n,n,n,255],i*4);}q.putImageData(d,0,0);grassTile=c;}
 const pat=ctx.createPattern(grassTile,'repeat');if(!pat)return;ctx.save();ctx.globalAlpha=.24;ctx.globalCompositeOperation='soft-light';ctx.fillStyle=pat;ctx.fillRect(0,0,w,h);ctx.restore();
}
function software(ctx,geo,dyn,cam,w,h){
 const near=.18,depth=p=>dot(sub(p,cam.eye),cam.f),css=c=>`rgb(${c.map(v=>Math.round(clamp(v,0,1)*255)).join(',')})`;
 const screen=p=>{const q=project(p,cam,w/h);return [(q.x+1)*w/2,(1-q.y)*h/2]};
 const intersection=(a,b)=>{let k=(near-depth(a))/(depth(b)-depth(a));return a.map((v,i)=>mix(v,b[i],k));};
 function clip(ps){let out=[];for(let i=0;i<ps.length;i++){let a=ps[i],b=ps[(i+1)%ps.length],inside=depth(a)>=near,next=depth(b)>=near;if(inside)out.push(a);if(inside!==next)out.push(intersection(a,b));}return out;}
 function colorAt(col,z){const k=clamp((z-100)/550,0,1)*.72;return css(col.map((v,i)=>mix(v,[.61,.75,.74][i],k)));}
 function triangles(arr){let out=[];for(let i=0;i<arr.length;i+=21){let ps=[arr.slice(i,i+3),arr.slice(i+7,i+10),arr.slice(i+14,i+17)];out.push({ps,col:arr.slice(i+3,i+6),z:ps.reduce((a,p)=>a+depth(p),0)/3});}return out;}
 function fill(t){let ps=clip(t.ps);if(ps.length<3)return;ctx.beginPath();ps.forEach((p,i)=>{let q=screen(p);i?ctx.lineTo(...q):ctx.moveTo(...q);});ctx.closePath();ctx.fillStyle=colorAt(t.col,t.z);ctx.fill();}
 // Sky is the shared offline CSS background behind both transparent render surfaces.
 const ts=triangles(geo.tris),n=geo.groundTriangles;ts.slice(0,n).forEach(fill);
 // Apply a subtle texture to projected ground only, not sky, trees or HUD.
 const groundPoly=clip(geo.groundBounds||[[-900,-.08,-100],[900,-.08,-100],[900,-.08,1000],[-900,-.08,1000]]);if(groundPoly.length>=3){ctx.save();ctx.beginPath();groundPoly.forEach((p,i)=>{let q=screen(p);i?ctx.lineTo(...q):ctx.moveTo(...q);});ctx.closePath();ctx.clip();grain(ctx,w,h);ctx.restore();}
 ts.slice(n).sort((a,b)=>b.z-a.z).forEach(fill);triangles(dyn.tris).forEach(fill);
 const allLines=geo.lines.concat(dyn.lines);for(let i=0;i<allLines.length;i+=14){let a=allLines.slice(i,i+3),b=allLines.slice(i+7,i+10);if(depth(a)<near&&depth(b)<near)continue;if(depth(a)<near)a=intersection(a,b);if(depth(b)<near)b=intersection(a,b);ctx.beginPath();ctx.moveTo(...screen(a));ctx.lineTo(...screen(b));ctx.strokeStyle=colorAt(allLines.slice(i+3,i+6),(depth(a)+depth(b))/2);ctx.lineWidth=1.5;ctx.stroke();}
 for(let i=0;i<dyn.dots.length;i+=7){let a=dyn.dots.slice(i,i+3);if(depth(a)<near)continue;let q=screen(a);ctx.beginPath();ctx.arc(...q,dyn.dots[i+6]/2,0,Math.PI*2);ctx.fillStyle=css(dyn.dots.slice(i+3,i+6));ctx.fill();}
}
class Renderer{
 constructor(canvas,hud){this.canvas=canvas;this.hud=hud;this.gl=null;this.failed=false;this.key=null;this.start=0;this.replay=false;this.groundKey='';this.onLost=e=>{e.preventDefault();this.failed=true;};canvas.addEventListener('webglcontextlost',this.onLost);canvas.addEventListener('webglcontextrestored',()=>{this.gl=null;this.failed=false;this.software=false;this.groundKey='';});}
 init(){if(this.failed){this.software=true;return;}if(this.gl||this.software)return;let gl=this.canvas.getContext('webgl2',{alpha:true,antialias:true,powerPreference:'low-power'});if(!gl||typeof gl.createShader!=='function'){this.software=true;return;}this.gl=gl;try{this.p=program(gl);}catch(e){this.gl=null;this.software=true;return;}this.buf=gl.createBuffer();this.groundBuf=gl.createBuffer();this.attrib=['pos','color','size'].map(n=>gl.getAttribLocation(this.p,n));this.u=Object.fromEntries(['eye','right','up','forward','aspect','focal','pixelRatio','pointMode'].map(n=>[n,gl.getUniformLocation(this.p,n)]));}
 draw(data,t){this.init();const {shots,target,groups,A,mode,quality,animate}=data,gl=this.gl,c=this.canvas,rect=c.getBoundingClientRect();if(rect.width<10||rect.height<10)return false;let ratio=Math.min(root.devicePixelRatio||1,quality==='low'?1:quality==='high'?2:1.5),w=Math.round(rect.width*ratio),h=Math.round(rect.height*ratio);if(c.width!==w||c.height!==h||this.hud.width!==w||this.hud.height!==h){c.width=w;c.height=h;this.hud.width=w;this.hud.height=h;}let latest=shots[0],points=trajectory(latest),key=latest?String(latest.id??latest.shotId??latest.time):null;if(key!==this.key){this.key=key;this.start=t;this.replay=!!animate;}if(!points.length)this.replay=false;const duration=points.length?points.at(-1).t:0,ms=clamp(duration*700,900,4300),roll=points.length&&latest&&typeof A.rollout==='function'?A.rollout(latest,data.surface||'medium'):null,rollMs=roll&&roll.rollout>.05?clamp(roll.rollout*65,350,1100):0,elapsed=this.replay?Math.max(0,t-this.start):ms+rollMs,playing=elapsed<ms+rollMs,rolling=elapsed>=ms&&rollMs>0;let ball=sample(points,Math.min(1,elapsed/ms)*duration);if(rolling&&ball){let p=clamp((elapsed-ms)/rollMs,0,1);ball=rollVisual(ball,roll,p);}if(!playing)this.replay=false;let e=extent(shots,target,groups);if(roll){e.depth=Math.max(e.depth,Math.ceil((roll.finalDownrange+20)/25)*25);e.half=Math.max(e.half,Math.abs(roll.finalOffline)+15);}let desired=data.scene?data.scene.camera(mode,ball,w/h,playing):chooseCamera(mode,e,ball,w/h),cam=desired;if(data.zoom && data.zoom!==1){const at=desired.at;desired=cam=camera(desired.eye.map((x,i)=>at[i]+(x-at[i])/data.zoom),at);}if(this.lastMode&&mode!==this.lastMode&&this.lastCamera){this.transition={from:this.lastCamera,start:t};}this.lastMode=mode;if(this.transition){let p=clamp((t-this.transition.start)/360,0,1),k=p*p*(3-2*p);cam=blendCamera(this.transition.from,desired,k);if(p===1)this.transition=null;}this.lastCamera=cam;const gkey=data.scene?data.scene.key+'/'+quality:[e.depth,Math.ceil(e.half),quality].join('/');const g=data.scene?data.scene.dynamic(points,ball,playing,cam):dynamic(e,shots,target,groups,A,points,ball,playing,roll,rolling,cam);if(c.style)c.style.visibility=this.software?'hidden':'visible';if(!this.software){gl.viewport(0,0,w,h);gl.clearColor(0,0,0,0);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);gl.enable(gl.DEPTH_TEST);gl.depthFunc(gl.LEQUAL);gl.useProgram(this.p);const u=this.u;gl.uniform3fv(u.eye,cam.eye);gl.uniform3fv(u.right,cam.r);gl.uniform3fv(u.up,cam.u);gl.uniform3fv(u.forward,cam.f);gl.uniform1f(u.aspect,w/h);gl.uniform1f(u.focal,1/Math.tan(Math.PI/6));gl.uniform1f(u.pixelRatio,ratio);
 const bind=buf=>{gl.bindBuffer(gl.ARRAY_BUFFER,buf);[0,12,24].forEach((off,i)=>{let a=this.attrib[i];if(a>=0){gl.enableVertexAttribArray(a);gl.vertexAttribPointer(a,i===2?1:3,gl.FLOAT,false,28,off);}});};
 bind(this.groundBuf);if(gkey!==this.groundKey){const geo=data.scene?data.scene.ground(quality):ground(e,quality);this.staticLines=geo.lines;const arr=new Float32Array(geo.tris);gl.bufferData(gl.ARRAY_BUFFER,arr,gl.STATIC_DRAW);this.groundCount=arr.length/7;this.groundKey=gkey;}gl.uniform1i(u.pointMode,0);gl.drawArrays(gl.TRIANGLES,0,this.groundCount);
 bind(this.buf);for(const [arr,type] of [[g.tris,gl.TRIANGLES],[(this.staticLines||[]).concat(g.lines),gl.LINES],[g.dots,gl.POINTS]])if(arr.length){gl.uniform1i(u.pointMode,type===gl.POINTS?1:0);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(arr),gl.DYNAMIC_DRAW);gl.drawArrays(type,0,arr.length/7);}}
 const ctx=this.hud.getContext('2d');ctx.setTransform(ratio,0,0,ratio,0,0);ctx.clearRect(0,0,rect.width,rect.height);if(this.software){if(this.cpuKey!==gkey){this.cpuGeometry=data.scene?data.scene.ground(quality):ground(e,quality);this.cpuKey=gkey;}software(ctx,this.cpuGeometry,g,cam,rect.width,rect.height);}ctx.font='600 11px system-ui';ctx.textAlign='center';const occupied=[];function label(p,text){let q=project(p,cam,w/h);if(q.z<.15||Math.abs(q.x)>.96||Math.abs(q.y)>.91)return;let x=(q.x+1)*rect.width/2,y=(1-q.y)*rect.height/2;let tw=ctx.measureText(text).width;let b=[x-tw/2-6,y-14,x+tw/2+6,y+6];if(occupied.some(a=>b[0]<a[2]&&b[2]>a[0]&&b[1]<a[3]&&b[3]>a[1]))return;occupied.push(b);ctx.fillStyle='#0a2328bb';ctx.fillRect(x-tw/2-4,y-12,tw+8,16);ctx.fillStyle='#f1f8ed';ctx.fillText(text,x,y);}
 if(data.scene){for(const [p,text] of data.scene.labels(playing))label(p,text);return playing||!!this.transition;}if(Number.isFinite(target))label([0,4,target],target+' m target');if(latest&&!playing){label([latest.offline,2,latest.downrange],latest.carry.toFixed(1)+' m carry');if(roll&&roll.rollout>2)label([roll.finalOffline,1.1,roll.finalDownrange],roll.total.toFixed(1)+' m total');}for(let m=50;m<=e.depth;m+=50)label([-14,1.45,m],m+' m');return playing||!!this.transition;}
 restart(t){this.start=t;this.replay=true;}
 stop(){this.replay=false;}
}
function bindZoom(el,change){
    const span=e=>Math.hypot(e.touches[0].clientX-e.touches[1].clientX,e.touches[0].clientY-e.touches[1].clientY);
    let previous=0;
    el.addEventListener('touchstart',e=>{if(e.touches.length===2)previous=span(e);},{passive:true});
    el.addEventListener('touchmove',e=>{
        if(e.touches.length!==2)return;
        e.preventDefault();const current=span(e);
        if(previous>2 && current>2)change(current/previous);
        previous=current;
    },{passive:false});
    el.addEventListener('touchend',()=>{previous=0;});
    el.addEventListener('wheel',e=>{e.preventDefault();change(Math.exp(-e.deltaY*.002));},{passive:false});
}
const api={bindZoom,trajectory,sample,world,project,camera,extent,chooseCamera,geometry,ground,dynamic,software,tree,oval,ellipsoid,random,shade,hex,rollVisual,blendCamera,Renderer};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.Range3D=api;
})(typeof globalThis!=='undefined'?globalThis:this);
