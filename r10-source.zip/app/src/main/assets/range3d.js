/* Offline WebGL2 practice range. Presentation only: never changes recorded shots. */
(function(root){'use strict';
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v)), mix=(a,b,t)=>a+(b-a)*t;
const valid=p=>p&&['x','y','z','t'].every(k=>typeof p[k]==='number'&&Number.isFinite(p[k]));
function trajectory(s){return Array.isArray(s?.points)?s.points.filter(valid).filter((p,i,a)=>!i||p.t>a[i-1].t):[];}
function sample(points,t){if(!points.length)return null;if(t<=points[0].t)return {...points[0]};for(let i=1;i<points.length;i++)if(t<=points[i].t){let a=points[i-1],b=points[i],k=clamp((t-a.t)/(b.t-a.t),0,1);return {x:mix(a.x,b.x,k),y:mix(a.y,b.y,k),z:mix(a.z,b.z,k),t};}return {...points.at(-1)};}
function world(p){return [p.y,p.z+.12,p.x];}
function hex(s){const n=parseInt(String(s).replace('#',''),16);return Number.isFinite(n)?[(n>>16&255)/255,(n>>8&255)/255,(n&255)/255]:[1,1,1];}
const sub=(a,b)=>a.map((v,i)=>v-b[i]),dot=(a,b)=>a.reduce((s,v,i)=>s+v*b[i],0),cross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]],norm=a=>{let l=Math.hypot(...a)||1;return a.map(v=>v/l)};
function camera(eye,at){let f=norm(sub(at,eye)),r=norm(cross([0,1,0],f)),u=cross(f,r);return {eye,at,f,r,u};}
function project(v,c,aspect,fov=60){const p=sub(v,c.eye),z=dot(p,c.f),s=1/Math.tan(fov*Math.PI/360);return {x:dot(p,c.r)*s/(z*aspect),y:dot(p,c.u)*s/z,z};}
function extent(shots,target,groups=[]){let depth=Math.max(100,(target||0)+25),half=45,apex=0;for(const s of shots){depth=Math.max(depth,s.downrange+20);half=Math.max(half,Math.abs(s.offline)+15);apex=Math.max(apex,Number(s.apex)||0);}for(const g of groups){depth=Math.max(depth,g.center.y+g.radius+10);half=Math.max(half,Math.abs(g.center.x)+g.radius+10);}return {depth:Math.max(100,Math.ceil(depth/25)*25),half,apex};}
function chooseCamera(mode,e,ball,aspect){if(mode==='follow'&&ball){return camera([ball.y*.85,Math.max(3.8,ball.z+5),ball.x-17],[ball.y,Math.max(1,ball.z*.8),ball.x+22]);}if(mode==='aerial'){const d=Math.max(e.depth,e.half*2/Math.max(.5,aspect));return camera([0,d*1.05,-d*.42],[0,0,e.depth*.46]);}return camera([0,1.85,-4.8],[0,Math.max(2.4,e.apex*.17),Math.max(60,e.depth*.42)]);}
function facilityCamera(e,aspect){const end=Math.max(355,e.depth),at=[0,0,(end-12)/2],half=Math.max(92,e.half+36),bounds=[[-half,0,-12],[half,0,-12],[-half,0,end],[half,0,end]],landscape=aspect>=1.3;const view=d=>camera(landscape?[d*.24,d,at[2]]:[0,d,at[2]-d*.24],at);let lo=80,hi=Math.max(1000,end*3);for(let i=0;i<30;i++){const d=(lo+hi)/2,c=view(d);if(bounds.every(p=>{const v=project(p,c,aspect);return v.z>0&&Math.abs(v.x)<.94&&Math.abs(v.y)<.94;}))hi=d;else lo=d;}return view(hi);}
const VERT=`#version 300 es
in vec3 pos;in vec3 color;in float size;uniform vec3 eye, right, up, forward;uniform float aspect, focal, pixelRatio;out vec3 vColor;out float depth;out vec3 vWorld;out float material;
void main(){vec3 p=pos-eye;if(size < -9.){vec2 side=right.xz/max(.001,length(right.xz));p.xz+=side*(color.x-.5)*(-size-10.); }float z=dot(p,forward);float near=.15,far=1800.;gl_Position=vec4(dot(p,right)*focal/aspect,dot(p,up)*focal,(far+near)/(far-near)*z-2.*far*near/(far-near),z);gl_PointSize=max(1.,size)*pixelRatio;vColor=color;depth=z;vWorld=pos;material=size;}`;
const FRAG=`#version 300 es
precision highp float;in vec3 vColor;in float depth;in vec3 vWorld;in float material;uniform sampler2D foliage;uniform bool texturedGround;uniform bool pointMode;out vec4 outColor;
float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
float noise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(hash(i),hash(i+vec2(1,0)),f.x),mix(hash(i+vec2(0,1)),hash(i+vec2(1,1)),f.x),f.y);}
void main(){vec3 c=vColor;if(material < -9.){
 vec4 leaf=texture(foliage,vec2((clamp(vColor.x,.002,.998)+floor(vColor.z))*.5,(1.-vColor.y)*.4995));
 if(leaf.a<.42)discard;
 c=leaf.rgb*(.92+fract(vColor.z)*.16);
 }else if(pointMode){float r=distance(gl_PointCoord,vec2(.5));if(r>.5)discard;c*=1.-.32*smoothstep(.21,.5,r);}else if(material<-.5){vec2 p=vWorld.xz;float coarse=noise(p*.25)-.5;float detail=(noise(p*11.)-.5)*(1.-smoothstep(.045,.30,length(fwidth(p))));float fine=(hash(floor(p*55.))-.5)*(1.-smoothstep(.01,.07,length(fwidth(p))));vec3 n=normalize(cross(dFdx(vWorld),dFdy(vWorld)));if(n.y<0.)n=-n;
 if(texturedGround && material != -2.){
   vec2 tile=p*.56;
   vec2 mirrorUV=1.-abs(2.*fract(tile*.5)-1.);
   vec2 uv=vec2(.001,.501)+mirrorUV*.498;
   vec3 cut=textureGrad(foliage,uv,dFdx(tile)*.498,dFdy(tile)*.498).rgb;
   float light=dot(cut,vec3(.299,.587,.114));
   c*=mix(1.,clamp(.56+light*1.18,.68,1.28),1.-smoothstep(14.,52.,depth));
 }
 float sun=clamp(dot(n,normalize(vec3(-.65,.85,-.4))),0.,1.);
 c*=(.81+.29*sun)*(1.+.13*coarse+.15*detail+.10*fine);}
float fog=smoothstep(80.,650.,depth)*.75;outColor=vec4(mix(c,vec3(.62,.75,.76),fog),1.);}`;
function rollVisual(land,roll,p){let k=1-(1-p)*(1-p);return {x:mix(land.x,roll.finalDownrange,k),y:mix(land.y,roll.finalOffline,k),z:Math.max(0,Math.sin(p*3*Math.PI)*Math.max(0,1-p)*Math.min(.65,roll.rollout*.04)),t:land.t};}
function blendCamera(a,b,k){let eye=a.eye.map((v,i)=>mix(v,b.eye[i],k)),f=norm(a.f.map((v,i)=>mix(v,b.f[i],k)));return camera(eye,eye.map((v,i)=>v+f[i]));}
function program(gl){function shader(type,src){const s=gl.createShader(type);gl.shaderSource(s,src);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS)){const err=gl.getShaderInfoLog(s);gl.deleteShader(s);throw Error(err);}return s;}let v=shader(gl.VERTEX_SHADER,VERT),f=shader(gl.FRAGMENT_SHADER,FRAG),p=gl.createProgram();gl.attachShader(p,v);gl.attachShader(p,f);gl.linkProgram(p);gl.deleteShader(v);gl.deleteShader(f);if(!gl.getProgramParameter(p,gl.LINK_STATUS))throw Error(gl.getProgramInfoLog(p));return p;}
function geometry(){const tris=[],lines=[],dots=[];const push=(a,p,c,size=1)=>a.push(...p,...c,size);const tri=(a,b,c,col,mat=1)=>{[a,b,c].forEach(p=>push(tris,p,col,mat));};const line=(a,b,c)=>{push(lines,a,c);push(lines,b,c);};const quad=(a,b,c,d,col,mat=1)=>{tri(a,b,c,col,mat);tri(a,c,d,col,mat);};const point=(a,col,size)=>push(dots,a,col,size);function ring(x,z,r,col,y=.09,n=64){for(let i=0;i<n;i++){let a=i*2*Math.PI/n,b=(i+1)*2*Math.PI/n;line([x+r*Math.cos(a),y,z+r*Math.sin(a)],[x+r*Math.cos(b),y,z+r*Math.sin(b)],col);}}function disc(x,z,r,col,y=.03,n=48,mat=1){for(let i=0;i<n;i++){let a=i*2*Math.PI/n,b=(i+1)*2*Math.PI/n;tri([x,y,z],[x+r*Math.cos(a),y,z+r*Math.sin(a)],[x+r*Math.cos(b),y,z+r*Math.sin(b)],col,mat);}}return {tris,lines,dots,tri,line,quad,point,ring,disc};}
// Deterministic scene assets: procedural colors, shadow patches, layered foliage and terrain silhouettes.
const shade=(c,k)=>c.map(v=>clamp(v*k,0,1));
const random=n=>{const x=Math.sin(n*127.1+311.7)*43758.5453;return x-Math.floor(x);};
function oval(g,x,z,rx,rz,col,y=.025,n=32,mat=1){for(let j=0;j<n;j++){let a=j*Math.PI*2/n,b=(j+1)*Math.PI*2/n;g.tri([x,y,z],[x+rx*Math.cos(a),y,z+rz*Math.sin(a)],[x+rx*Math.cos(b),y,z+rz*Math.sin(b)],col,mat);}}
function ellipsoid(g,x,y,z,rx,ry,rz,col,seed,segments=9,bands=5){
 const p=(a,b)=>[x+rx*Math.cos(a)*Math.sin(b),y+ry*Math.cos(b),z+rz*Math.sin(a)*Math.sin(b)];
 for(let i=0;i<bands;i++)for(let j=0;j<segments;j++){let a=j*Math.PI*2/segments,b=(j+1)*Math.PI*2/segments,t=i*Math.PI/bands,u=(i+1)*Math.PI/bands;let n=[Math.cos((a+b)/2)*Math.sin((t+u)/2),Math.cos((t+u)/2),Math.sin((a+b)/2)*Math.sin((t+u)/2)];let k=.69+.37*Math.max(0,dot(n,norm([-.65,.85,-.4])))+.12*random(seed+i*31+j);g.quad(p(a,t),p(b,t),p(b,u),p(a,u),shade(col,k));}}
function tree(g,x,z,h,seed,quality){let r=h*(.23+.09*random(seed+4)),tr=h*.48,base=[.23+.10*random(seed),.34+.14*random(seed+7),.11+.06*random(seed+3)];
 // Tapered trunk, lit faces rather than a flat billboard.
 for(let j=0;j<6;j++){let a=j*Math.PI/3,b=(j+1)*Math.PI/3;g.quad([x+.22*Math.cos(a),0,z+.22*Math.sin(a)],[x+.22*Math.cos(b),0,z+.22*Math.sin(b)],[x+.10*Math.cos(b),tr,z+.10*Math.sin(b)],[x+.10*Math.cos(a),tr,z+.10*Math.sin(a)],shade([.38,.29,.17],.72+.25*random(seed+j)));}
 const n=quality==='low'?6:quality==='high'?12:9,bands=quality==='high'?6:5;
 ellipsoid(g,x,h*.72,z,r,h*.32,r*.9,base,seed,n,bands);
 if(quality!=='low')for(let j=0;j<(quality==='high'?4:3);j++){let a=j*2.4+seed,rr=r*(.47+.19*random(seed+j+60));ellipsoid(g,x+Math.cos(a)*rr,h*(.60+.16*random(seed+j+17)),z+Math.sin(a)*rr,r*.67,h*.23,r*.64,shade(base,.9+.17*random(seed+j+21)),seed+j*37,n,bands);}}
// UV and species travel in the existing colour channel of each textured tree.
function foliageCard(g,x,z,h,width,seed,base=0){
 const species=random(seed+13)>.70?1:0, tone=species+.15+.68*random(seed+71);
 const mat=-10-width*(species?.77:1);
 for(const [u,v] of [[0,0],[1,0],[1,1],[0,0],[1,1],[0,1]])
   g.tris.push(x,base+v*h,z,u,v,tone,mat);
}
function grassClump(g,x,z,y,seed){
 const straw=random(seed+5)>.58, colour=straw?[.62,.56,.29]:[.43,.49,.22];
 for(let j=0;j<7;j++){
   const a=random(seed+j*3)*6.283, dx=Math.cos(a), dz=Math.sin(a);
   const h=.24+.44*random(seed+j*11), w=.025+.025*random(seed-j);
   const bx=x+dx*.13,bz=z+dz*.13;
   g.tri([bx-dz*w,y,bz+dx*w],[bx+dz*w,y,bz-dx*w],
         [bx+dx*.19+.08,y+h,bz+dz*.19],shade(colour,.82+.28*random(seed+j)));
 }
}
function green(g,x,z,r=12,active=false){oval(g,x,z,r+1.2,r*.79+1.2,[.37,.53,.20],.018,40,-3);oval(g,x,z,r,r*.79,[.46,.66,.29],.025,40,-4);oval(g,x,z,r*.93,r*.73,[.48,.69,.32],.031,40,-4);if(active)return;g.line([x,.04,z],[x,2.8,z],[.97,.97,.90]);g.tri([x,2.8,z],[x+1.6,2.43,z],[x,2.06,z],[.93,.39,.19]);}
function ground(e,quality,textured=false){const g=geometry(),{quad,tri}=g;const half=Math.max(40,e.half+7),end=Math.max(350,e.depth+70),stride=quality==='low'?24:quality==='high'?9:14;
 // Broad rough base, softly varied blocks and alternating mown fairway stripes.
 quad([-900,-.08,-100],[900,-.08,-100],[900,-.08,1000],[-900,-.08,1000],[.36,.48,.22],-5);
 for(let z=-24,i=0;z<end;z+=stride,i++){let x0=Math.min(half,21+Math.max(0,z)*.10),x1=Math.min(half,21+Math.max(0,z+stride)*.10);const band=i%2?[.36,.54,.19]:[.43,.62,.23];let cells=quality==='low'?4:quality==='high'?10:6;for(let k=0;k<cells;k++){let a=-1+2*k/cells,b=-1+2*(k+1)/cells;quad([a*x0,0,z],[b*x0,0,z],[b*x1,0,z+stride],[a*x1,0,z+stride],shade(band,.986+.025*random(i*17+k)),-3);}for(let side of [-1,1]){quad([side*x0,-.02,z],[side*(half+16),-.02,z],[side*(half+16),-.02,z+stride],[side*x1,-.02,z+stride],shade([.28,.48,.17],.91+.14*random(i+side*17)),-5);}}
 // A close-cut tee deck and a pair of tee markers.
 oval(g,0,0,5.2,4.6,[.37,.53,.24],.012,36,-1);quad([-1.55,.035,-1.15],[1.55,.035,-1.15],[1.55,.035,.85],[-1.55,.035,.85],[.18,.27,.17],-6);
 quad([-1.50,.038,-1.10],[1.50,.038,-1.10],[1.50,.038,.80],[-1.50,.038,.80],[.26,.36,.23],-6);
 for(let side of [-1,1]){let x=side*2.2;oval(g,x,.1,.32,.26,[.20,.33,.13],.045,12);quad([x-.22,.05,.0],[x+.22,.05,.0],[x+.22,.32,.0],[x-.22,.32,.0],[.94,.92,.77]);}
 // Ground-level target greens are separate from the active practice target overlay.
 for(let m=50;m<=Math.min(end-10,350);m+=50){let x=m%100===0?0:(m%150===0?-8:9);green(g,x,m,Math.min(12,8+m*.012));}
 const trees=[];const step=quality==='low'?27:quality==='high'?13:19;for(let side of [-1,1])for(let z=8,i=0;z<end+60;z+=step,i++){let seed=i+side*101, x=side*(Math.min(half,21+z*.10)+9+random(seed+2)*11),h=7+6*random(seed);trees.push([x,z,h,seed]);if(quality!=='low'&&i%2===0){trees.push([x+side*(9+random(seed+9)*8),z+step*.47,8+6*random(seed+8),seed+83]);if(i<8)trees.push([x+side*(22+random(seed+19)*16),z+step*.23,10+6*random(seed+28),seed+123]);}}
 for(let i=0;i<18;i++){let x=-135+i*16,z=end+42+18*random(i+555);trees.push([x,z,8+7*random(i+605),i+700]);}
 // Soft-looking overlapping ground shadow footprints, offset consistently away from sunlight.
 for(const [x,z,h] of trees){oval(g,x+h*.19,z+h*.12,h*.34,h*.23,[.25,.39,.16],.011,16);oval(g,x+h*.14,z+h*.08,h*.23,h*.16,[.21,.34,.14],.014,16);}
 g.groundTriangles=g.tris.length/21;
 // Distant decorative rolling hills, not playable elevation. Multiple depth layers.
 for(let layer=0;layer<3;layer++){let z=510+layer*150;for(let i=0;i<30;i++){let x=-900+i*60,b=x+60;let h=xx=>20+layer*12+18*Math.sin(xx*.006+layer*2)+10*Math.sin(xx*.013+layer);quad([x,-.07,z],[b,-.07,z],[b,h(b),z],[x,h(x),z],shade([.30,.48,.31],1+layer*.10));}}
 for(const [x,z,h,seed] of trees){
   if(textured)foliageCard(g,x,z,h,h*1.02,seed);else tree(g,x,z,h,seed,quality);
 }
 for(const side of [-1,1])for(let i=0;i<(quality==='low'?90:340);i++){
   const seed=i*9+side*117,z=-6+random(seed)*Math.min(end,210);
   const x=side*(Math.min(half,21+Math.max(0,z)*.10)+random(seed+2)*6);
   grassClump(g,x,z,-.015,seed);
 }
 // Target marker boards, painted posts and sunlit faces.
 for(let m=50;m<=Math.min(e.depth,350);m+=50){let x=-14;g.line([x-.8,0,m],[x-.8,1.25,m],[.28,.23,.12]);g.line([x+.8,0,m],[x+.8,1.25,m],[.28,.23,.12]);quad([x-1.25,.65,m],[x+1.25,.65,m],[x+1.25,1.65,m],[x-1.25,1.65,m],[.94,.83,.40]);}
 return g;}
// Fixed, irregular practice distances: the UI and the scene share this catalogue.
const rangeTargets=Object.freeze([42,65,97,128,150,183,212,248,271,303,337]);
const rangeGreens=Object.freeze(rangeTargets.map((z,i)=>Object.freeze({z,x:[-5,7,-8,8,0,-8,7,-9,8,-8,9][i],r:[8,9,10,11,12,11,10,12,11,12,13][i]})));
const rangeBunkers=Object.freeze([[ -22,62,6,3.8],[21,108,7,4.5],[-25,142,8,3.8],[-17,168,5,3],[28,225,9,4.3],[18,235,4.5,3.2],[-30,287,8.8,4.2],[25,327,6.3,3.3]]);
const rangePonds=Object.freeze([[36,51,14,20],[-53,199,19,27]]);
// v0.24 visual landscape relief in metres. Scoring/flight remain on the calibrated flat reference plane.
const BALL_RADIUS=.021335;
const smooth01=x=>{x=clamp(x,0,1);return x*x*(3-2*x);};
function rangeHeight(x,z){
 const front=smooth01((z-35)/35),lateral=smooth01((Math.abs(x)-36)/50);
 let h=front*(1.65*Math.sin((z-58)*.024)+.65*Math.cos(z*.039+x*.028)+.50*Math.sin(x*.055+z*.012));
 h+=lateral*front*(1.8+1.2*Math.sin(z*.019+x*.026)+.75*Math.cos(x*.043-z*.013));
 // Both ponds share the original planar reflection height. A broad smooth apron keeps triangulated ground below them.
 for(const [px,pz,rx,rz] of rangePonds){const q=Math.hypot((x-px)/(rx+9),(z-pz)/(rz+9));h*=smooth01((q-1)/.65);}
 return h*(1-smooth01((z-420)/85));
}
function rangeSurfaceOffset(x,z){if(Math.abs(x)<=1.54&&z>=-1.14&&z<=.8)return .04;for(const t of rangeGreens)if(((x-t.x)/t.r)**2+((z-t.z)/(t.r*.79))**2<=1)return .14;return 0;}
function rangeElevationLabel(distance){const h=rangeHeight(0,distance);return distance+' m · '+(Math.abs(h)<.05?'level':(h>0?'+':'')+h.toFixed(1)+' m visual elevation');}
function rangeGroundPick(cam,x,y,aspect){if(!cam)return null;const f=Math.tan(Math.PI/6),d=cam.f.map((v,i)=>v+cam.r[i]*x*aspect*f+cam.u[i]*y*f),p=k=>[cam.eye[0]+d[0]*k,cam.eye[2]+d[2]*k],delta=k=>{const q=p(k);return cam.eye[1]+d[1]*k-rangeHeight(...q);};let a=0;for(let b=1;b<=1100;b+=1){if(delta(b)<=0&&delta(a)>0){for(let i=0;i<18;i++){const m=(a+b)/2;if(delta(m)>0)a=m;else b=m;}return p((a+b)/2);}a=b;}return null;}
// Same point arrays serve old renderers. The Three.js adapter replaces only the tagged ball dots.
function golfBall(g,legacy,position,color=[1,1,.94],size=7,ground=null){(g.golfBalls||(g.golfBalls=[])).push({dot:g.dots.length,position,ground});g.point(legacy,color,size);}
function raiseRangeGeometry(g){for(const arr of [g.tris,g.lines,g.dots])for(let i=0;i<arr.length;i+=7)arr[i+1]+=rangeHeight(arr[i],arr[i+2]);for(const b of g.golfBalls||[]){b.position[1]+=rangeHeight(b.position[0],b.position[2]);if(b.ground!=null)b.ground+=rangeHeight(b.position[0],b.position[2]);}return g;}
// Reusable world-space model helpers. Props are low-poly original geometry, not downloaded assets.
function propTransform(x,z,angle){const c=Math.cos(angle),s=Math.sin(angle);return ([a,y,b])=>[x+a*c-b*s,y,z+a*s+b*c];}
function propBox(g,tf,x,y,z,w,h,d,col,mat=1){const a=x-w/2,b=x+w/2,c=z-d/2,e=z+d/2,lo=y-h/2,hi=y+h/2;const pts=[[a,lo,c],[b,lo,c],[b,lo,e],[a,lo,e],[a,hi,c],[b,hi,c],[b,hi,e],[a,hi,e]].map(tf);for(const [i,j,k,l,f] of [[0,1,5,4,.86],[1,2,6,5,.75],[2,3,7,6,.87],[3,0,4,7,.94],[4,5,6,7,1],[3,2,1,0,.7]])g.quad(pts[i],pts[j],pts[k],pts[l],shade(col,f),mat);}
function propWheel(g,tf,x,z){const n=14,y=.28,r=.28,col=[.085,.09,.085];for(let i=0;i<n;i++){const a=i*2*Math.PI/n,b=(i+1)*2*Math.PI/n;const v=(dx,t,rr=r)=>tf([x+dx,y+rr*Math.cos(t),z+rr*Math.sin(t)]);g.quad(v(-.12,a),v(.12,a),v(.12,b),v(-.12,b),col);for(const side of [-1,1]){g.tri(tf([x+side*.12,y,z]),v(side*.12,a),v(side*.12,b),col);g.tri(tf([x+side*.124,y,z]),v(side*.124,a,.14),v(side*.124,b,.14),[.54,.56,.53]);}}}
function propCylinder(g,tf,x,y,z,r,h,col,mat=1,n=12){for(let i=0;i<n;i++){const a=i*Math.PI*2/n,b=(i+1)*Math.PI*2/n,p=(t,Y)=>tf([x+r*Math.cos(t),Y,z+r*Math.sin(t)]);g.quad(p(a,y),p(b,y),p(b,y+h),p(a,y+h),col,mat);g.tri(tf([x,y+h,z]),p(a,y+h),p(b,y+h),col,mat);}}
function golfCart(g,x,z,angle,col){const t=propTransform(x,z,angle),box=(...a)=>propBox(g,t,...a);oval(g,x,z,1,1.55,[.22,.33,.15],.006,24,-5);for(const xx of [-.65,.65])for(const zz of [-.87,.87])propWheel(g,t,xx,zz);
 box(0,.48,0,1.35,.28,2.25,col,9);box(0,.76,.68,1.28,.34,.78,col,9);box(0,.87,.66,1.18,.08,.68,shade(col,1.12),9);box(0,.82,-.50,1.20,.20,.65,[.72,.62,.45],1);box(0,1.12,-.83,1.18,.48,.15,[.74,.65,.48]);box(0,.84,-1.05,1.22,.27,.42,col,9);box(0,.55,1.18,1.29,.11,.09,[.13,.15,.13],9);box(0,.52,-1.18,1.29,.11,.09,[.13,.15,.13],9);
 for(const xx of [-.59,.59])for(const zz of [-.78,.73])box(xx,1.48,zz,.055,1.4,.055,[.16,.17,.15],9);box(0,2.16,-.02,1.54,.10,2.09,[.90,.87,.72],9);box(0,2.23,-.02,1.43,.045,1.96,[.92,.89,.76],9);box(0,1.65,.78,1.12,.73,.025,[.52,.71,.76],7);box(0,1.28,.78,1.18,.05,.04,[.16,.19,.18],9);box(0,1.06,.39,.34,.045,.09,[.10,.11,.10]);
 for(let i=0;i<12;i++){const a=i*Math.PI/6,b=(i+1)*Math.PI/6;g.line(t([-.37+.13*Math.cos(a),1.28+.09*Math.sin(a),.37]),t([-.37+.13*Math.cos(b),1.28+.09*Math.sin(b),.37]),[.07,.08,.07]);}box(-.37,1.12,.40,.045,.28,.045,[.12,.13,.11]);
 box(0,.61,1.24,.75,.10,.035,[.20,.23,.22],9);for(const xx of [-.43,.43]){box(xx,.83,1.08,.26,.14,.045,[.95,.89,.68],9);box(xx,.76,-1.26,.18,.10,.04,[.73,.12,.07],9);}
 // Golf bags, straps, handles and visible club shafts on the rear rack.
 for(const xx of [-.36,.36]){propCylinder(g,t,xx,.59,-1.04,.17,.77,xx<0?[.18,.28,.18]:[.40,.17,.11],5);propCylinder(g,t,xx,1.34,-1.04,.18,.055,[.13,.14,.13],9);for(let k=0;k<4;k++){const px=xx+(k%2-.5)*.14,pz=-1.04+(Math.floor(k/2)-.5)*.13;g.line(t([px,1.31,pz]),t([px,1.60+k*.055,pz]),[.60,.63,.60]);box(px,1.60+k*.055,pz,.11,.045,.045,[.20,.22,.21],9);}}
}
function clubhouse(g,x,z){const t=propTransform(x,z,-.16),box=(...a)=>propBox(g,t,...a);const stone=[.76,.73,.60],wood=[.36,.24,.15],roof=[.43,.28,.21],glass=[.29,.42,.46];
 box(0,.14,0,16,.28,10,stone,3);box(0,1.95,0,14,3.5,8,stone,3);box(0,.45,-5.05,15,.25,2.4,[.61,.59,.49],8);box(0,.28,-6.55,12,.25,.7,stone,3);box(0,.12,-7.0,12,.15,.65,stone,3);
 const a=t([-7.7,3.7,-4.6]),b=t([7.7,3.7,-4.6]),c=t([7.7,3.7,4.6]),d=t([-7.7,3.7,4.6]),u=t([-7.7,5.65,0]),v=t([7.7,5.65,0]);g.quad(a,b,v,u,roof,4);g.quad(d,u,v,c,shade(roof,.84),4);g.tri(a,u,d,wood,5);g.tri(b,c,v,wood,5);box(0,5.67,0,15.7,.13,.20,roof,4);
 for(const zz of [-4.62,4.62]){box(0,3.72,zz,15.6,.18,.12,wood,5);box(0,3.57,zz,15.7,.10,.16,[.24,.27,.25],9);for(const xx of [-7.25,7.25])box(xx,1.92,zz,.08,3.25,.09,[.24,.27,.25],9);}
 for(const xx of [-6,-3,3,6]){box(xx,2,-4.03,1.85,1.55,.10,wood,5);box(xx,2,-4.10,1.60,1.32,.055,glass,6);box(xx,2,-4.15,.065,1.32,.065,stone,3);box(xx,2,-4.16,1.60,.045,.055,stone,3);box(xx,1.24,-4.18,1.9,.12,.27,stone,3);}
 box(0,1.35,-4.10,1.75,2.1,.12,wood,5);box(0,1.45,-4.19,1.48,1.87,.07,glass,6);box(0,1.45,-4.24,.075,1.87,.06,wood,5);box(.12,1.36,-4.28,.06,.14,.04,[.76,.67,.40],9);for(const xx of [-6.7,-2.3,2.3,6.7]){box(xx,1.77,-5.9,.22,2.7,.22,wood,5);box(xx,.53,-5.9,.38,.24,.38,stone,3);}box(0,3.20,-5.1,15,.18,2.65,roof,4);box(5.6,5.0,1.3,.64,1.7,.64,stone,3);box(5.6,5.89,1.3,.84,.12,.84,roof,4);for(let zz=-2.8;zz<=2.8;zz+=2.8){box(-7.06,2,zz,.1,1.5,1.55,wood,5);box(-7.13,2,zz,.04,1.28,1.3,glass,6);box(7.06,2,zz,.1,1.5,1.55,wood,5);box(7.13,2,zz,.04,1.28,1.3,glass,6);}
 // Terrace furniture and planters: only two sets, keeping the geometry budget bounded.
 for(const xx of [-4.4,4.4]){propCylinder(g,t,xx,.52,-5.25,.06,.62,wood,5,8);propCylinder(g,t,xx,1.13,-5.25,.54,.08,wood,5,12);for(const side of [-1,1]){box(xx+side*.84,.76,-5.25,.44,.11,.48,wood,5);box(xx+side*.84,1.02,-5.46,.44,.46,.08,wood,5);for(const ox of [-.16,.16])box(xx+side*.84+ox,.57,-5.25,.05,.37,.05,[.14,.16,.15],9);}}
 for(const xx of [-7.6,7.6]){box(xx,.42,-6.1,1.2,.55,.85,stone,3);for(let j=0;j<5;j++){const px=xx+(random(j+xx)-.5)*.9,pz=-6.1+(random(j+70+xx)-.5)*.6;g.tri(t([px-.12,.70,pz]),t([px+.12,.70,pz]),t([px,.95+random(j)*.32,pz]),[.26,.43,.13]);}}
}
function ribbon(g,points,width,col,mat,y=.029){for(let i=0;i<points.length-1;i++){const [x,z]=points[i],[nx,nz]=points[i+1],dx=nx-x,dz=nz-z,l=Math.hypot(dx,dz)||1,a=dz/l*width/2,b=-dx/l*width/2;g.quad([x-a,y,z-b],[x+a,y,z+b],[nx+a,y,nz+b],[nx-a,y,nz-b],col,mat);}}
function irregularOval(g,x,z,rx,rz,col,y,seed,mat){const n=mat===2?128:64,pt=i=>{const a=i*Math.PI*2/n,k=1+.10*Math.sin(a*3+seed)+.045*Math.sin(a*5-seed);return [x+rx*k*Math.cos(a),y,z+rz*k*Math.sin(a)];};for(let i=0;i<n;i++)g.tri([x,y,z],pt(i),pt(i+1),col,mat);}
// Hybrid-only surface patches: adjacent layers share the exact boundary, never stack full discs.
function surfaceRing(g,x,z,outer,inner,col,seed,mat,n=64,irregular=true){
 const pt=(r,i)=>{const a=i*2*Math.PI/n,k=irregular?1+.10*Math.sin(a*3+seed)+.045*Math.sin(a*5-seed):1;return [x+r[0]*k*Math.cos(a),r[2],z+r[1]*k*Math.sin(a)];};
 for(let i=0;i<n;i++){const a=pt(outer,i),b=pt(outer,i+1);if(inner)g.quad(a,b,pt(inner,i+1),pt(inner,i),col,mat);else g.tri([x,outer[2],z],a,b,col,mat);}
}
function rangeGreen(g,x,z,r){const edge=[r+1.2,r*.79+1.2,.085],rim=[r,r*.79,.13],core=[r*.93,r*.73,.14];surfaceRing(g,x,z,edge,rim,[.37,.53,.20],0,-5,32,false);surfaceRing(g,x,z,rim,core,[.46,.66,.29],0,-4,32,false);surfaceRing(g,x,z,core,null,[.48,.69,.32],0,-4,32,false);}
function rangeBench(g,x,z,angle){const t=propTransform(x,z,angle),box=(...args)=>propBox(g,t,...args);for(const dx of [-.74,.74]){box(dx,.25,0,.085,.50,.44,[.21,.24,.23],9);box(dx,.63,.20,.075,.76,.07,[.21,.24,.23],9);}for(let i=0;i<4;i++)box(0,.51,-.18+i*.115,1.85,.065,.105,[.53,.37,.22],5);for(let i=0;i<3;i++)box(0,.72+i*.115,.22,1.85,.095,.05,[.53,.37,.22],5);}
// v0.21: decorative facility. All playable flight and rollout remain on the existing flat plane.
function naturalGround(e,quality,textured=true,externalCart=false){
 const g=geometry(),half=Math.max(64,e.half+16),end=Math.max(390,e.depth+55),step=quality==='low'?9:quality==='high'?4.5:6;
 const edge=z=>Math.min(half-12,26+Math.max(0,z)*.12+5*Math.sin(z*.027)+3*Math.sin(z*.061));
 const bank=(x,z)=>{const d=Math.max(0,Math.abs(x)-half-4),f=Math.min(1,d/24);const mask=rangePonds.reduce((v,[px,pz,rx,rz])=>v*smooth01((Math.hypot((x-px)/(rx+9),(z-pz)/(rz+9))-1)/.65),1);return -.03+mask*f*f*(1.0+1.65*(.5+.5*Math.sin(z*.024+x*.055))+1.3*(.5+.5*Math.sin(z*.046-x*.04)))*Math.max(0,1-Math.max(0,d-90)/100);};
 const point=(x,z)=>[x,bank(x,z),z];
 // A continuous, graded green surround rather than flat white or grey margins.
 g.quad([-900,-4,-100],[900,-4,-100],[900,-4,1100],[-900,-4,1100],[.29,.43,.18],-5);
 for(let z=-24,i=0;z<end+80;z+=step,i++){
  const next=z+step,w0=edge(z),w1=edge(next),base=[.39,.58,.21];
  for(let k=0;k<16;k++){let a=-1+2*k/16,b=a+2/16;g.quad([a*w0,0,z],[b*w0,0,z],[b*w1,0,next],[a*w1,0,next],base,-3);}
  for(const side of [-1,1]){const a=side*w0,b=side*w1;for(let k=0;k<4;k++){const u=k/4,v=(k+1)/4;g.quad([mix(a,side*half,u),-.015,z],[mix(a,side*half,v),-.015,z],[mix(b,side*half,v),-.015,next],[mix(b,side*half,u),-.015,next],[.30,.47,.18],-5);}
   for(let x=half;x<half+84;x+=12){let l=side*x,r=side*(x+12);g.quad(point(l,z),point(r,z),point(r,next),point(l,next),[.28,.43,.16],-5);}for(let x=half+84;x<half+204;x+=40){let l=side*x,r=side*(x+40);g.quad(point(l,z),point(r,z),point(r,next),point(l,next),[.28,.43,.16],-5);}
  }
 }
 g.terrainTriangles=g.tris.length/21;
 // Tee deck and mat: dark, physically distinct materials; never photo tinted.
 oval(g,0,0,5.4,4.7,[.32,.49,.19],.012,48,-1);
 g.quad([-1.65,.036,-1.25],[1.65,.036,-1.25],[1.65,.036,.9],[-1.65,.036,.9],[.16,.23,.14],-6);
 g.quad([-1.54,.04,-1.14],[1.54,.04,-1.14],[1.54,.04,.80],[-1.54,.04,.80],[.22,.34,.18],-6);
 for(const side of [-1,1]){let x=side*2.25;g.quad([x-.20,.04,0],[x+.20,.04,0],[x+.20,.32,0],[x-.20,.32,0],[.95,.88,.67]);}
 // Irregularly spaced playable targets. Flag positions stay on the scoring centreline;
 // green outlines vary in shape and lateral offset without moving the scoring target.
 for(const {z:m,x,r} of rangeGreens){rangeGreen(g,x,m,r);g.line([0,.14,m],[0,2.8,m],[.97,.97,.90]);g.tri([0,2.8,m],[1.6,2.43,m],[0,2.06,m],[.93,.39,.19]);
  const sx=(m%3===0?-1:1)*Math.min(edge(m)-2,20+(m%7));
  g.line([sx-1.1,0,m],[sx-1.1,1.5,m],[.32,.25,.14]);g.line([sx+1.1,0,m],[sx+1.1,1.5,m],[.32,.25,.14]);g.quad([sx-1.55,.8,m],[sx+1.55,.8,m],[sx+1.55,1.85,m],[sx-1.55,1.85,m],[.97,.83,.25]);
  const glyphs=['abcdef','bc','abdeg','abcdg','bcfg','acdfg','acdefg','abc','abcdefg','abcdfg'],seg={a:[0,.66,.45,.08],b:[.37,.35,.08,.35],c:[.37,.03,.08,.35],d:[0,0,.45,.08],e:[0,.03,.08,.35],f:[0,.35,.08,.35],g:[0,.33,.45,.08]},digits=String(m);
  for(let j=0;j<digits.length;j++)for(const q of glyphs[Number(digits[j])]){const [dx,dy,w,h]=seg[q],lx=sx-(digits.length*.60-.15)/2+j*.60+dx,ly=.98+dy;g.quad([lx,ly,m-.015],[lx+w,ly,m-.015],[lx+w,ly+h,m-.015],[lx,ly+h,m-.015],[.09,.10,.045]);}
 }
 // Independently placed and irregularly shaped sand pockets and ponds. Visual only.
 for(const [x,z,rx,rz] of rangeBunkers){const outer=[rx+.8,rz+.7,.085],lip=[rx,rz,.16],floor=[rx*.81,rz*.79,.09];surfaceRing(g,x,z,outer,lip,[.35,.49,.20],z,-5,40);surfaceRing(g,x,z,lip,floor,[.78,.69,.48],z,-2,40);surfaceRing(g,x,z,floor,null,[.89,.80,.60],z,-2,40);}
 for(const [x,z,rx,rz] of rangePonds){const outer=[rx+2.2,rz+2.2,.10],bankEdge=[rx+.65,rz+.65,.20],waterEdge=[rx,rz,.048];surfaceRing(g,x,z,outer,bankEdge,[.32,.45,.20],z,-5,64);surfaceRing(g,x,z,bankEdge,waterEdge,[.37,.41,.24],z,-5,64);surfaceRing(g,x,z,waterEdge,null,[.15,.36,.41],z,2,64);for(let j=0;j<24;j++){const a=j*2.399+z,k=1+.10*Math.sin(a*3+z)+.045*Math.sin(a*5-z);const px=x+(rx+.85)*k*Math.cos(a),pz=z+(rz+.85)*k*Math.sin(a);if(random(j+z)>.44){grassClump(g,px,pz,.16,j+z);if(j%3===0)grassClump(g,px+.25,pz-.19,.16,j+z+55);}if(j%5===0){const r=.17+.20*random(j+z+12);ellipsoid(g,px,.16,pz,r,r*.55,r*.73,[.43,.43,.36],j+z,5,3);}}}
 // Clubhouse, two parked golf carts and a compact path near the practice area.
 irregularOval(g,-29,22,12,9,[.47,.44,.37],.025,4,8);ribbon(g,[[-33,27],[-28,19],[-21,15],[-12,10],[-7,4]],2.8,[.57,.55,.46],8);ribbon(g,[[-28,19],[-41,15],[-48,4],[-48,-12]],2.5,[.49,.48,.40],8);
 clubhouse(g,-33,34);if(!externalCart){golfCart(g,-13,12,.36,[.64,.71,.43]);golfCart(g,-17,15,-.28,[.85,.83,.69]);}g.externalCart=externalCart;rangeBench(g,-22,19,.42);rangeBench(g,-8,7,-.18);
 // Seeded irregular forest belts, varied setbacks, heights and overlapping crowns.
 const trees=[],spacing=quality==='low'?20:quality==='high'?10:14;
 for(const side of [-1,1])for(let row=0;row<(quality==='low'?2:3);row++)for(let z=6,i=0;z<end+55;z+=spacing,i++){
  const seed=side*701+row*137+i*19,z0=z+(random(seed+4)-.5)*spacing*.9;
  const x=side*(Math.max(edge(z0)+12,40)+row*14+random(seed+8)*13+5*Math.sin(z0*.035+side*2));
  if(rangePonds.some(([px,pz,rx,rz])=>((x-px)/(rx+5))**2+((z0-pz)/(rz+5))**2<1)||(side===-1&&z0<46&&x>-48))continue;
  const h=7+random(seed+13)*9,width=h*(.77+.32*random(seed+25));trees.push([x,z0,h,width,seed,Math.max(-.01,bank(x,z0))]);
 }
 for(let i=0;i<36;i++){const x=-180+i*10+(random(i+655)-.5)*7,z=end+25+random(i+633)*30,h=8+random(i+634)*8;trees.push([x,z,h,h*.95,i+800,Math.max(-.01,bank(x,z))]);}
 for(let i=0;i<(quality==='low'?26:54);i++){const side=i%2?1:-1,k=i*41+901,z=30+random(k)*340,x=side*(half+55+random(k+1)*60),h=8+random(k+2)*8;trees.push([x,z,h,h*.95,k,bank(x,z)]);}
 g.groundTriangles=g.tris.length/21;
 for(let layer=0;layer<3;layer++){let z=510+layer*150;for(let i=0;i<30;i++){let x=-900+i*60,b=x+60;let h=xx=>15+layer*9+14*Math.sin(xx*.006+layer*2)+7*Math.sin(xx*.013+layer);g.quad([x,-.07,z],[b,-.07,z],[b,h(b),z],[x,h(x),z],shade([.30,.47,.24],1+layer*.08));}}
 for(const [x,z,h,width,seed,y] of trees){if(textured)foliageCard(g,x,z,h,width,seed,y);else tree(g,x,z,h,seed,quality);}
 // Short foreground grass with modest blade heights; keep the mat completely clear.
 const count=quality==='low'?120:quality==='high'?780:600;
 for(let i=0;i<count;i++){const k=i*17+23,x=(random(k)-.5)*23,z=-2+random(k+2)*23;if(Math.abs(x)<1.75&&z<1.2)continue;
  const height=.018+.028*random(k+3),a=random(k+4)*6.283,dx=Math.cos(a),dz=Math.sin(a),w=.008+.010*random(k+5),y=(x*x/29+z*z/23<1)?.014:.002;
  const c=shade([.39,.57,.24],.94+.14*random(k+8));g.tri([x-dz*w,y,z+dx*w],[x+dz*w,y,z-dx*w],[x+dx*.03,y+height,z+dz*.03],c);
  g.tri([x-dx*w,y,z-dz*w],[x+dx*w,y,z+dz*w],[x-dz*.025,y+height*.85,z+dx*.025],c);
 }
 for(let i=0;i<g.tris.length;i+=7){const x=g.tris[i],z=g.tris[i+2];if(i>=42&&z<505)g.tris[i+1]+=rangeHeight(x,z);}for(let i=0;i<g.lines.length;i+=7)if(g.lines[i+2]<500)g.lines[i+1]+=rangeHeight(g.lines[i],g.lines[i+2]);
 g.naturalRange=true;g.facility={targets:rangeGreens,bunkers:rangeBunkers,ponds:rangePonds,carts:2,clubhouse:1};return g;
}
function dynamic(e,shots,target,groups,A,points,ball,playing,roll=null,rolling=false,cam=null,natural=false){const g=geometry();for(let m=25;!natural&&m<=e.depth;m+=25){g.line([-8,.05,m],[8,.05,m],[.66,.79,.52]);}for(let m=0;m<e.depth;m+=10)g.line([0,natural?.24:.06,m],[0,natural?.24:.06,m+4],[.74,.83,.59]);if(Number.isFinite(target)){if(!natural){g.disc(0,target,15.5,[.37,.56,.25],.042,64,-1);g.disc(0,target,14.8,[.49,.68,.32],.052,64,-1);}for(let r=3;r<=15;r+=3)g.ring(0,target,r,r===3?[.98,1,.72]:[.76,.88,.60],natural?.24:.09);g.line([0,natural?.24:.08,target],[0,3,target],[.97,.97,.9]);g.tri([0,3,target],[1.8,2.65,target],[0,2.2,target],[.98,.81,.25]);}
for(const group of groups)g.ring(group.center.x,group.center.y,Math.max(.35,group.radius),hex(group.color),.13);
for(const s of shots.slice(1,5)){const prior=trajectory(s);for(let i=1;i<prior.length;i+=3){g.line(world(prior[i-1]),world(prior[Math.min(i+2,prior.length-1)]),[.72,.80,.71]);}}
for(const s of shots){if(playing&&s===shots[0])continue;if(s===shots[0]&&ball)(g.legacyBallDots||(g.legacyBallDots=[])).push(g.dots.length);g.point([s.offline,.18,s.downrange],hex(A.color(s.club)),s===shots[0]?9:6);}
if(points.length){const col=[1,.85,.18];let last=points[0];
 const tracer=(a,b)=>{g.line(a,b,col);if(!cam)return;let d=sub(b,a),view=sub(cam.eye,a),n=norm(cross(d,view));if(Math.hypot(...d)<1e-6)return;let mid=a.map((v,i)=>(v+b[i])/2),width=clamp(dot(sub(mid,cam.eye),cam.f)*.0016,.045,.35);let off=(p,k)=>p.map((v,i)=>v+n[i]*k);g.quad(off(a,width),off(b,width),off(b,-width),off(a,-width),shade(col,.82));g.quad(off(a,width*.38),off(b,width*.38),off(b,-width*.38),off(a,-width*.38),col.map(v=>mix(v,1,.22)));};for(let i=1;i<points.length;i++){let p=points[i];if(playing&&!rolling&&p.t>ball.t){if(last.t<ball.t)tracer(world(last),world(ball));break;}tracer(world(last),world(p));last=p;}if(roll&&(!playing||rolling)){const land=points.at(-1),finish=ball||land;g.ring(land.y,land.x,1.2,[.95,.93,.65],.11,24);const d=Math.hypot(finish.x-land.x,finish.y-land.y);for(let i=0;i<d;i+=1.8){const at=k=>[mix(land.y,finish.y,k/d),.13,mix(land.x,finish.x,k/d)];g.line(at(i),at(Math.min(d,i+.85)),shade(col,.85));}if(!playing)g.ring(finish.y,finish.x,.65,[1,1,.95],.14,24);}if(ball){golfBall(g,world(ball),[ball.y,Math.max(natural?rangeSurfaceOffset(ball.y,ball.x):0,ball.z)+BALL_RADIUS,ball.x],[1,1,.93],8,ball.z<.05?(natural?rangeSurfaceOffset(ball.y,ball.x):0):null);(g.legacyBallDots||(g.legacyBallDots=[])).push(g.dots.length);g.point([ball.y,.08,ball.x],[.12,.19,.12],5);}}
const legacyShadow=g.tris.length;oval(g,.045,.025,.10,.055,[.12,.19,.11],.043,12);g.legacyBallShadow=legacyShadow;golfBall(g,[0,.15,0],[0,.04+BALL_RADIUS,0],[1,1,.94],7,.04);if(playing)g.golfBalls.at(-1).hidden=true;return natural?raiseRangeGeometry(g):g;}
// Canvas fallback: same 3D coordinates, perspective, clipping and animation; no GPU requirement.
let grassTile=null;
function grain(ctx,w,h){
 if(!root.document?.createElement||!ctx.createPattern)return;
 if(!grassTile){let c=root.document.createElement('canvas');c.width=c.height=96;let q=c.getContext('2d');if(!q)return;let d=q.createImageData(96,96);for(let i=0;i<96*96;i++){let n=Math.round(105+random(i*1.7)*47+random(i%96*3+Math.floor(i/96)*.7)*40);d.data.set([n,n,n,255],i*4);}q.putImageData(d,0,0);grassTile=c;}
 const pat=ctx.createPattern(grassTile,'repeat');if(!pat)return;ctx.save();ctx.globalAlpha=.24;ctx.globalCompositeOperation='soft-light';ctx.fillStyle=pat;ctx.fillRect(0,0,w,h);ctx.restore();
}
function software(ctx,geo,dyn,cam,w,h){
 const near=.18,depth=p=>dot(sub(p,cam.eye),cam.f),css=c=>`rgb(${c.map(v=>Math.round(clamp(v,0,1)*255)).join(',')})`;
 const screen=p=>{const q=project(p,cam,w/h);return [(q.x+1)*w/2,(1-q.y)*h/2]};
 const intersection=(a,b)=>{let k=(near-depth(a))/(depth(b)-depth(a));return a.map((v,i)=>mix(v,b[i],k));};
 function clip(ps){let out=[];for(let i=0;i<ps.length;i++){let a=ps[i],b=ps[(i+1)%ps.length],inside=depth(a)>=near,next=depth(b)>=near;if(inside)out.push(a);if(inside!==next)out.push(intersection(a,b));}return out;}
 function colorAt(col,z){const k=clamp((z-100)/550,0,1)*.72;return css(col.map((v,i)=>mix(v,[.61,.75,.74][i],k)));}
 function triangles(arr){let out=[];for(let i=0;i<arr.length;i+=21){let ps=[arr.slice(i,i+3),arr.slice(i+7,i+10),arr.slice(i+14,i+17)];out.push({ps,col:arr.slice(i+3,i+6),z:ps.reduce((a,p)=>a+depth(p),0)/3});}return out;}
 function fill(t){let ps=clip(t.ps);if(ps.length<3)return;ctx.beginPath();ps.forEach((p,i)=>{let q=screen(p);i?ctx.lineTo(...q):ctx.moveTo(...q);});ctx.closePath();ctx.fillStyle=colorAt(t.col,t.z);ctx.fill();}
 // Sky is the shared offline CSS background behind both transparent render surfaces.
 const ts=triangles(geo.tris),n=geo.groundTriangles;ts.slice(0,n).forEach(fill);
 // Apply a subtle texture to projected ground only, not sky, trees or HUD.
 const groundPoly=clip(geo.groundBounds||[[-900,-.08,-100],[900,-.08,-100],[900,-.08,1000],[-900,-.08,1000]]);if(groundPoly.length>=3){ctx.save();ctx.beginPath();groundPoly.forEach((p,i)=>{let q=screen(p);i?ctx.lineTo(...q):ctx.moveTo(...q);});ctx.closePath();ctx.clip();grain(ctx,w,h);ctx.restore();}
 ts.slice(n).sort((a,b)=>b.z-a.z).forEach(fill);triangles(dyn.tris).forEach(fill);
 const allLines=geo.lines.concat(dyn.lines);for(let i=0;i<allLines.length;i+=14){let a=allLines.slice(i,i+3),b=allLines.slice(i+7,i+10);if(depth(a)<near&&depth(b)<near)continue;if(depth(a)<near)a=intersection(a,b);if(depth(b)<near)b=intersection(a,b);ctx.beginPath();ctx.moveTo(...screen(a));ctx.lineTo(...screen(b));ctx.strokeStyle=colorAt(allLines.slice(i+3,i+6),(depth(a)+depth(b))/2);ctx.lineWidth=1.5;ctx.stroke();}
 for(let i=0;i<dyn.dots.length;i+=7){let a=dyn.dots.slice(i,i+3);if(depth(a)<near)continue;let q=screen(a);ctx.beginPath();ctx.arc(...q,dyn.dots[i+6]/2,0,Math.PI*2);ctx.fillStyle=css(dyn.dots.slice(i+3,i+6));ctx.fill();}
}
class Renderer{
 constructor(canvas,hud){this.canvas=canvas;this.hud=hud;this.gl=null;this.failed=false;this.key=null;this.start=0;this.replay=false;this.groundKey='';this.onLost=e=>{e.preventDefault();this.failed=true;};canvas.addEventListener('webglcontextlost',this.onLost);canvas.addEventListener('webglcontextrestored',()=>{this.gl=null;this.failed=false;this.software=false;this.leaves=null;this.foliageReady=false;this.groundKey='';});}
 init(){if(this.failed){this.software=true;return;}if(this.gl||this.software)return;let gl=this.canvas.getContext('webgl2',{alpha:true,antialias:true,powerPreference:'low-power'});if(!gl||typeof gl.createShader!=='function'){this.software=true;return;}this.gl=gl;try{this.p=program(gl);}catch(e){this.gl=null;this.software=true;return;}this.buf=gl.createBuffer();this.groundBuf=gl.createBuffer();this.attrib=['pos','color','size'].map(n=>gl.getAttribLocation(this.p,n));this.u=Object.fromEntries(['eye','right','up','forward','aspect','focal','pixelRatio','pointMode','texturedGround'].map(n=>[n,gl.getUniformLocation(this.p,n)]));}
 loadFoliage(){
   if(this.leaves||!root.R10FoliageImage||!root.Image)return;
   const gl=this.gl,img=this.leaves=new root.Image();
   const texture=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,texture);
   gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,1,1,0,gl.RGBA,gl.UNSIGNED_BYTE,new Uint8Array([255,255,255,255]));
   gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR);
   img.onload=()=>{
     if(this.gl!==gl||this.failed)return;
     gl.bindTexture(gl.TEXTURE_2D,texture);
     gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,img);
     gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR_MIPMAP_LINEAR);
     gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);
     gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);
     gl.generateMipmap(gl.TEXTURE_2D);this.foliageReady=true;this.groundKey='';
     if(this.lastData&&this.canvas.isConnected)this.draw(this.lastData,performance.now());
   };
   img.src=root.R10FoliageImage;
 }
 draw(data,t){this.lastData=data;if(!this.three&&!this.threeTried){this.threeTried=true;if(root.R10Three&&root.R10ThreeScene&&this.canvas.parentNode){try{this.three=new root.R10ThreeScene.SceneRenderer(this.canvas,this); }catch(e){this.threeError=String(e.message||e);}}}if(!this.three){this.init();if(this.gl&&!this.software)this.loadFoliage();}const {shots,target,groups,A,mode,quality,animate}=data,gl=this.gl,c=this.canvas,rect=c.getBoundingClientRect();if(rect.width<10||rect.height<10)return false;let ratio=Math.min(root.devicePixelRatio||1,quality==='low'?1:quality==='high'?2:1.5),w=Math.round(rect.width*ratio),h=Math.round(rect.height*ratio);if(c.width!==w||c.height!==h||this.hud.width!==w||this.hud.height!==h){c.width=w;c.height=h;this.hud.width=w;this.hud.height=h;}let latest=shots[0],points=trajectory(latest),key=latest?String(latest.id??latest.shotId??latest.time):null;if(key!==this.key){this.key=key;this.start=t;this.replay=!!animate;}if(!points.length)this.replay=false;const duration=points.length?points.at(-1).t:0,ms=clamp(duration*700,900,4300),roll=points.length&&latest&&typeof A.rollout==='function'?A.rollout(latest,data.surface||'medium'):null,rollMs=roll&&roll.rollout>.05?clamp(roll.rollout*65,350,1100):0,elapsed=this.replay?Math.max(0,t-this.start):ms+rollMs,playing=elapsed<ms+rollMs,rolling=elapsed>=ms&&rollMs>0;let ball=sample(points,Math.min(1,elapsed/ms)*duration);if(rolling&&ball){let p=clamp((elapsed-ms)/rollMs,0,1);ball=rollVisual(ball,roll,p);}if(!playing){if(this.replay&&mode==='auto')this.landingUntil=t+950;this.replay=false;}if(key!==this.autoKey){this.autoKey=key;this.landingUntil=0;}const hold=mode==='auto'&&!playing&&!!ball&&t<(this.landingUntil||0);const cameraMode=mode==='auto'?(playing&&elapsed>650||hold?'follow':'tee'):mode;let e=extent(shots,target,groups);if(roll){e.depth=Math.max(e.depth,Math.ceil((roll.finalDownrange+20)/25)*25);e.half=Math.max(e.half,Math.abs(roll.finalOffline)+15);}let desired=data.inspect?camera([data.inspect.east,data.inspect.setback*.95,data.inspect.north-data.inspect.setback],[data.inspect.east,.15,data.inspect.north]):data.scene?data.scene.camera(cameraMode,ball,w/h,playing):hold?camera([ball.y-3,5,ball.x-10],[ball.y,.15,ball.x]):(cameraMode==='aerial'&&(data.preset||root.R10GraphicsPreset||'hybrid')==='hybrid'&&this.three?facilityCamera(e,w/h):chooseCamera(cameraMode,e,ball,w/h)),cam=desired;const raisedRange=!data.scene&&!!this.three&&(data.preset||root.R10GraphicsPreset||'hybrid')==='hybrid';if(raisedRange&&cameraMode!=='aerial'){const eye=desired.eye.slice(),at=desired.at.slice();eye[1]+=rangeHeight(eye[0],eye[2]);at[1]+=rangeHeight(at[0],at[2]);desired=cam=camera(eye,at);}if(data.zoom && data.zoom!==1){const at=desired.at;desired=cam=camera(desired.eye.map((x,i)=>at[i]+(x-at[i])/data.zoom),at);}if(this.lastMode&&cameraMode!==this.lastMode&&this.lastCamera){this.transition={from:this.lastCamera,start:t};}this.lastMode=cameraMode;if(this.transition){let p=clamp((t-this.transition.start)/360,0,1),k=p*p*(3-2*p);cam=blendCamera(this.transition.from,desired,k);if(p===1)this.transition=null;}this.lastCamera=cam;const gkey=data.scene?data.scene.key+'/'+quality:[e.depth,Math.ceil(e.half),quality].join('/');const g=data.scene?data.scene.dynamic(points,ball,playing,cam):dynamic(e,shots,target,groups,A,points,ball,playing,roll,rolling,cam,!!this.three&&(data.preset||root.R10GraphicsPreset||'hybrid')==='hybrid');if(this.three){try{this.three.draw({key:gkey,ground:(textured,preset)=>data.scene?data.scene.ground(quality,textured):preset==='hybrid'?naturalGround(e,quality,textured,!!this.three?.real?.facilityModels?.cart):ground(e,quality,textured),dynamic:g,cam,quality,w,h,ratio});}catch(err){this.threeError=String(err.message||err);this.three.dispose();this.three=null;return this.draw(data,t);}}if(c.style)c.style.visibility=this.software?'hidden':'visible';if(!this.three&&!this.software){gl.viewport(0,0,w,h);gl.clearColor(0,0,0,0);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);gl.enable(gl.DEPTH_TEST);gl.depthFunc(gl.LEQUAL);gl.useProgram(this.p);const u=this.u;gl.uniform1i(u.texturedGround,this.foliageReady?1:0);gl.uniform3fv(u.eye,cam.eye);gl.uniform3fv(u.right,cam.r);gl.uniform3fv(u.up,cam.u);gl.uniform3fv(u.forward,cam.f);gl.uniform1f(u.aspect,w/h);gl.uniform1f(u.focal,1/Math.tan(Math.PI/6));gl.uniform1f(u.pixelRatio,ratio);
 const bind=buf=>{gl.bindBuffer(gl.ARRAY_BUFFER,buf);[0,12,24].forEach((off,i)=>{let a=this.attrib[i];if(a>=0){gl.enableVertexAttribArray(a);gl.vertexAttribPointer(a,i===2?1:3,gl.FLOAT,false,28,off);}});};
 bind(this.groundBuf);if(gkey!==this.groundKey){const geo=data.scene?data.scene.ground(quality,this.foliageReady):ground(e,quality,this.foliageReady);this.staticLines=geo.lines;const arr=new Float32Array(geo.tris);gl.bufferData(gl.ARRAY_BUFFER,arr,gl.STATIC_DRAW);this.groundCount=arr.length/7;this.groundKey=gkey;}gl.uniform1i(u.pointMode,0);gl.drawArrays(gl.TRIANGLES,0,this.groundCount);
 bind(this.buf);for(const [arr,type] of [[g.tris,gl.TRIANGLES],[(this.staticLines||[]).concat(g.lines),gl.LINES],[g.dots,gl.POINTS]])if(arr.length){gl.uniform1i(u.pointMode,type===gl.POINTS?1:0);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(arr),gl.DYNAMIC_DRAW);gl.drawArrays(type,0,arr.length/7);}}
 const ctx=this.hud.getContext('2d');ctx.setTransform(ratio,0,0,ratio,0,0);ctx.clearRect(0,0,rect.width,rect.height);if(this.software){if(this.cpuKey!==gkey){this.cpuGeometry=data.scene?data.scene.ground(quality):ground(e,quality);this.cpuKey=gkey;}software(ctx,this.cpuGeometry,g,cam,rect.width,rect.height);}ctx.font='600 11px system-ui';ctx.textAlign='center';const occupied=[];function label(p,text){let q=project(p,cam,w/h);if(q.z<.15||Math.abs(q.x)>.96||Math.abs(q.y)>.91)return;let x=(q.x+1)*rect.width/2,y=(1-q.y)*rect.height/2;let tw=ctx.measureText(text).width;let b=[x-tw/2-6,y-14,x+tw/2+6,y+6];if(occupied.some(a=>b[0]<a[2]&&b[2]>a[0]&&b[1]<a[3]&&b[3]>a[1]))return;occupied.push(b);ctx.fillStyle='#0a2328bb';ctx.fillRect(x-tw/2-4,y-12,tw+8,16);ctx.fillStyle='#f1f8ed';ctx.fillText(text,x,y);}
 if(data.scene){for(const [p,text] of data.scene.labels(playing))label(p,text);return playing||hold||!!this.transition;}if(Number.isFinite(target))label([0,4+(raisedRange?rangeHeight(0,target):0),target],raisedRange?rangeElevationLabel(target):target+' m · level');if(latest&&!playing){label([latest.offline,2+(raisedRange?rangeHeight(latest.offline,latest.downrange):0),latest.downrange],latest.carry.toFixed(1)+' m carry');if(roll&&roll.rollout>2)label([roll.finalOffline,1.1+(raisedRange?rangeHeight(roll.finalOffline,roll.finalDownrange):0),roll.finalDownrange],roll.total.toFixed(1)+' m total');}for(let m=50;m<=e.depth;m+=50)if(m!==target)if(!this.three?.naturalRange)label([-14,1.45,m],m+' m');return playing||hold||!!this.transition;}
 restart(t){this.start=t;this.replay=true;this.landingUntil=0;}
 stop(){this.replay=false;this.landingUntil=0;this.three?.pauseWater();}
}
function bindZoom(el,change){
    const span=e=>Math.hypot(e.touches[0].clientX-e.touches[1].clientX,e.touches[0].clientY-e.touches[1].clientY);
    let previous=0;
    el.addEventListener('touchstart',e=>{if(e.touches.length===2)previous=span(e);},{passive:true});
    el.addEventListener('touchmove',e=>{
        if(e.touches.length!==2)return;
        e.preventDefault();const current=span(e);
        if(previous>2 && current>2)change(current/previous);
        previous=current;
    },{passive:false});
    el.addEventListener('touchend',()=>{previous=0;});
    el.addEventListener('wheel',e=>{e.preventDefault();change(Math.exp(-e.deltaY*.002));},{passive:false});
}
const api={BALL_RADIUS,rangeHeight,rangeElevationLabel,rangeGroundPick,golfBall,surfaceRing,facilityCamera,rangeTargets,rangeGreens,rangeBunkers,rangePonds,foliageCard,grassClump,bindZoom,trajectory,sample,world,project,camera,extent,chooseCamera,geometry,ground,naturalGround,dynamic,software,tree,oval,ellipsoid,random,shade,hex,rollVisual,blendCamera,Renderer};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.Range3D=api;
})(typeof globalThis!=='undefined'?globalThis:this);
