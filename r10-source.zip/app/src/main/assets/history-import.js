(function(root){'use strict';
const numeric=['ballSpeed','launch','direction','spin','spinAxis','clubSpeed','face','path','attack','carry','offline','downrange','apex','flightTime','landingSpeed','landingAngle','temperatureC','altitudeM','faceToPath','previousCarry','previousModelCarry','rollout','total','finalDownrange','finalOffline','practiceTarget','practiceIndex'];
function parse(text){
 const rows=[];let row=[],field='',quoted=false; text=String(text).replace(/^\uFEFF/,'');
 for(let i=0;i<text.length;i++){const c=text[i];if(c==='"'){if(quoted&&text[i+1]==='"'){field+='"';i++;}else if(quoted)quoted=false;else if(!field)quoted=true;else throw Error('Invalid CSV quoting');}else if(!quoted&&c===','){row.push(field);field='';}else if(!quoted&&(c==='\n'||c==='\r')){if(c==='\r'&&text[i+1]==='\n')i++;row.push(field);if(row.some(v=>v!==''))rows.push(row);row=[];field='';}else field+=c;}
 if(quoted)throw Error('Unclosed CSV quote');if(field||row.length){row.push(field);if(row.some(v=>v!==''))rows.push(row);}
 const keys=(rows.shift()||[]).map(k=>k.trim());if(!['time','club','source','ballSpeed','launch','carry'].every(k=>keys.includes(k))||new Set(keys).size!==keys.length)throw Error('Select a CSV exported by R10 Private Range.');
 if(rows.length>1000)throw Error('CSV exceeds the 1000-shot history limit.');
 return rows.map((values,i)=>{if(values.length!==keys.length)throw Error('Invalid column count on row '+(i+2));const record=Object.fromEntries(keys.map((k,j)=>[k,values[j]]));const s={};for(const k of ['time','shotId','club','source','spinSource','carryBasis','model','previousModel','originalClub','swingLength','captureMode','sessionId','rolloutSurface','rolloutBasis','practiceId','practiceMode','practiceConfig'])if(Object.hasOwn(record,k))s[k]=record[k];for(const k of numeric){if(!Object.hasOwn(record,k)||record[k].trim()==='')continue;const n=Number(record[k]);if(!Number.isFinite(n))throw Error('Invalid '+k+' on row '+(i+2));s[k]=n;}if(record.mishit==='true')s.mishit=true;else if(record.mishit==='false')s.mishit=false;if(record.clubConfirmed==='true')s.clubConfirmed=true;else if(record.clubConfirmed==='false')s.clubConfirmed=false;if(!Number.isFinite(Date.parse(s.time))||!Number.isFinite(s.carry)||s.carry<0||!Number.isFinite(s.ballSpeed)||s.ballSpeed<=0||!Number.isFinite(s.launch)||!s.club||!s.source)throw Error('Invalid shot on row '+(i+2));return s;});
}
const key=s=>JSON.stringify([new Date(s.time).toISOString(),String(s.shotId??''),s.source,...(!s.shotId?[s.ballSpeed,s.launch,s.direction??null,s.spin??null]:[])]);
function merge(text,existing,simulate,settings){const seen=new Set(existing.map(key)),added=[];let duplicates=0,recalculated=0,legacy=0;
 for(const raw of parse(text)){const k=key(raw);if(seen.has(k)){duplicates++;continue;}seen.add(k);const s={...raw,id:'import:'+k};if(!s.model&&typeof simulate==='function'){try{const f=simulate(s,settings);Object.assign(s,{previousCarry:s.previousCarry??s.carry,carryBasis:'MODELED_UNVALIDATED',...f});recalculated++;}catch(e){legacy++;}}if(s.faceToPath==null&&s.face!=null&&s.path!=null)s.faceToPath=s.face-s.path;added.push(s);}
 if(existing.length+added.length>1000)throw Error('Import would exceed the 1000-shot history limit. Nothing imported.');return {shots:[...existing,...added].sort((a,b)=>Date.parse(b.time)-Date.parse(a.time)),added:added.length,duplicates,recalculated,legacy};}
function recalculate(shots,simulate,settings,modelVersion){
 let updated=0,unchanged=0,skipped=0;
 const result=shots.map(s=>{
  if(s.source!=='R10'){skipped++;return s;}
  if(s.model===modelVersion&&s.temperatureC===Number(settings.temperatureC)&&s.altitudeM===Number(settings.altitudeM)){unchanged++;return s;}
  try{
   const f=simulate(s,settings);
   const changedModel=s.model!==f.model;
   const prior=changedModel&&s.model?{previousModel:s.model,previousModelCarry:s.carry}:{};
   updated++;return {...s,previousCarry:s.previousCarry??s.carry,...prior,...f,carryBasis:'MODELED_UNVALIDATED'};
  }catch(e){skipped++;return s;}
 });return {shots:result,updated,unchanged,skipped};
}
const api={parse,merge,recalculate};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.R10History=api;
})(typeof globalThis!=='undefined'?globalThis:this);
