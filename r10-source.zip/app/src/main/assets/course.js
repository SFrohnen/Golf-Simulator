/* Offline 2D course engine. Local metric coordinates: x east, y north. Carry-only placements. */
(function(root){'use strict';
const VERSION=1, lengths=[3,6,9,12,15,18], difficulties={easy:{max:165,spread:17,depth:.16},medium:{max:200,spread:10,depth:.10},hard:{max:235,spread:5,depth:.055},expert:{max:255,spread:3,depth:.03}};
const dist=(a,b)=>Math.hypot(a[0]-b[0],a[1]-b[1]), point=p=>Array.isArray(p)&&p.length===2&&p.every(x=>typeof x==='number'&&Number.isFinite(x)&&Math.abs(x)<1000000);
function terrainValidate(t){if(!t||t.version!==1||![t.x0,t.y0,t.step].every(Number.isFinite)||t.step<2||t.step>100||!Number.isInteger(t.nx)||!Number.isInteger(t.ny)||t.nx<2||t.ny<2||t.nx*t.ny>100000||!Array.isArray(t.values)||t.values.length!==t.nx*t.ny||!t.values.every(v=>Number.isFinite(v)&&v>=-500&&v<=5000)||typeof t.source!=='string'||!t.source.trim()||typeof t.attribution!=='string'||!t.attribution.trim())throw Error('Invalid terrain grid');}
function height(h,p){const t=h.terrain;if(!t)return 0;const x=Math.max(0,Math.min(t.nx-1,(p[0]-t.x0)/t.step)),y=Math.max(0,Math.min(t.ny-1,(p[1]-t.y0)/t.step)),i=Math.min(t.nx-2,Math.floor(x)),j=Math.min(t.ny-2,Math.floor(y)),a=x-i,b=y-j,v=t.values,k=j*t.nx+i;return (1-b)*((1-a)*v[k]+a*v[k+1])+b*((1-a)*v[k+t.nx]+a*v[k+t.nx+1]);}
function elevationDelta(h,from,to){const t=h.terrain;if(!t)return null;const inside=p=>point(p)&&p[0]>=t.x0&&p[0]<=t.x0+(t.nx-1)*t.step&&p[1]>=t.y0&&p[1]<=t.y0+(t.ny-1)*t.step;if(!inside(from)||!inside(to))return null;return height(h,to)-height(h,from);}
function aimLabel(h,from,to,format=v=>v.toFixed(1)){const d=elevationDelta(h,from,to),v=d===null?null:Math.round(d*10)/10;return format(dist(from,to))+' m'+(v===null?' · elevation unavailable':v>0?' · +'+format(v)+' m ↑':v<0?' · −'+format(Math.abs(v))+' m ↓':' · '+format(0)+' m level');}
function groundAt(h,from,aim){if(!h.terrain)return null;const base=height(h,from);return (x,y)=>height(h,landing(from,aim,x,y))-base;}
function validate(c){if(!c||c.version!==1||typeof c.id!=='string'||!/^[-a-zA-Z0-9_]{1,80}$/.test(c.id)||typeof c.name!=='string'||!c.name.trim()||c.name.length>120||!Array.isArray(c.holes)||c.holes.length!==18)throw Error('Expected version 1 course with exactly 18 holes and a valid ID/name');if(!['fictional','osm','survey'].includes(c.kind)||typeof c.attribution!=='string'||!c.attribution.trim())throw Error('Course source and attribution required');if(c.terrain)terrainValidate(c.terrain);let numbers=new Set();for(const h of c.holes){if(!Number.isInteger(h.number)||h.number<1||h.number>18||numbers.has(h.number)||!Number.isInteger(h.par)||h.par<3||h.par>6||!point(h.tee)||!point(h.pin)||dist(h.tee,h.pin)<40||dist(h.tee,h.pin)>1000||!Array.isArray(h.route)||h.route.length<2||h.route.length>500||!h.route.every(point)||dist(h.route[0],h.tee)>2||dist(h.route.at(-1),h.pin)>2||!Array.isArray(h.surfaces)||h.surfaces.length>300)throw Error('Invalid or duplicate hole '+h.number);if(h.approximatePuttingTarget!==undefined&&(c.kind!=='osm'||h.approximatePuttingTarget!==10||h.surfaces.some(s=>s.type==='green')))throw Error('Invalid approximate putting target');numbers.add(h.number);for(const p of h.surfaces){if(!['fairway','green','bunker','water','ob','rough','tee','woodland','tree_row','tree'].includes(p.type)||!Array.isArray(p.ring)||p.ring.length<3||p.ring.length>3000||!p.ring.every(point)||(p.holes!==undefined&&(!Array.isArray(p.holes)||p.holes.length>100||p.holes.some(r=>!Array.isArray(r)||r.length<3||r.length>3000||!r.every(point)))))throw Error('Invalid polygon on hole '+h.number);}}return {...c,holes:c.holes.slice().sort((a,b)=>a.number-b.number)};}
function poly(p,ring){let inside=false;for(let i=0,j=ring.length-1;i<ring.length;j=i++){const a=ring[i],b=ring[j];if((a[1]>p[1])!==(b[1]>p[1])&&p[0]<(b[0]-a[0])*(p[1]-a[1])/(b[1]-a[1])+a[0])inside=!inside;}return inside;}
const contains=(p,s)=>poly(p,s.ring)&&!(s.holes||[]).some(r=>poly(p,r));
function lie(h,p){if(dist(p,h.pin)<=.054)return 'holed';for(const type of ['ob','woodland','tree_row','tree','water','green','bunker'])if(h.surfaces.some(s=>s.type===type&&contains(p,s))){if(type==='green'&&h.worldId&&!h.surfaces.some(s=>s.type==='green'&&contains(p,s)&&contains(h.pin,s)))continue;return ['woodland','tree_row','tree'].includes(type)?'ob':type;}if(h.approximatePuttingTarget===10&&dist(p,h.pin)<=10)return 'approximate target';for(const type of ['tee','fairway','rough'])if(h.surfaces.some(s=>s.type===type&&contains(p,s)))return type;return 'unmapped';}
function ellipse(x,y,rx,ry){return Array.from({length:32},(_,i)=>[x+rx*Math.cos(i*Math.PI/16),y+ry*Math.sin(i*Math.PI/16)]);}
function demo(){const pars=[4,5,4,3,4,4,4,3,5,4,3,4,4,3,5,4,4,5];return validate({version:1,id:'demo',name:'Practice Valley (fictional)',kind:'fictional',attribution:'Procedurally designed fictional layout; not Trier, Kikuoka or Weiherhof.',holes:pars.map((par,i)=>{const d=par===3?125+i%4*16:par===4?305+i%5*17:465+i%4*16,bend=par===3?0:(i%3-1)*55;const tee=[0,0],pin=[bend,d],mid=[bend*.25,d*.52];const surfaces=[{type:'fairway',ring:[[-22,10],[-36,d*.48],[bend-28,d-12],[bend+28,d-12],[40,d*.48],[22,10]]},{type:'green',ring:ellipse(bend,d,16,19)},{type:'tee',ring:ellipse(0,0,9,10)},{type:'bunker',ring:ellipse(bend-22,d-18,10,14)},{type:'bunker',ring:ellipse(bend+22,d+5,9,10)}];if(i%3===1)surfaces.push({type:'water',ring:ellipse(50,d*.60,20,40)});return {number:i+1,par,tee,pin,route:[tee,mid,pin],surfaces};})});}
function holeNumbers(n,side){if(!lengths.includes(n))throw Error('Invalid round length');const start=n<=9&&side==='back'?10:1;return Array.from({length:n},(_,i)=>i+start);}
function create(c,opts={}){c=validate(c);const n=Number(opts.holes), humans=Number(opts.humans), bots=Number(opts.bots), format=opts.format;if(![1,2].includes(humans)||![0,1,2].includes(bots)||!['stroke','scramble'].includes(format)||!difficulties[opts.difficulty]||!['R10','DEMO'].includes(opts.source)||!['auto','manual'].includes(opts.putting))throw Error('Invalid round settings');const people=Array.from({length:humans},(_,i)=>({id:'p'+i,name:'Player '+(i+1),bot:false}));const teams=[];if(format==='scramble'){if(humans===1)people.push({id:'partner',name:'Bot partner',bot:true});teams.push({name:'Your scramble team',members:people});for(let i=0;i<bots;i++)teams.push({name:'Bot team '+(i+1),members:[{id:'b'+i+'a',name:'Bot '+(i+1)+'A',bot:true},{id:'b'+i+'b',name:'Bot '+(i+1)+'B',bot:true}]});}else{for(const p of people)teams.push({name:p.name,members:[p]});for(let i=0;i<bots;i++)teams.push({name:'Bot '+(i+1),members:[{id:'b'+i,name:'Bot '+(i+1),bot:true}]});}const r={version:1,id:'round-'+Date.now()+'-'+Math.random().toString(36).slice(2),course:c,config:{...opts,holes:n,humans,bots},numbers:holeNumbers(n,opts.side),index:0,turn:0,teams,scorecards:[],log:[],done:false};resetHole(r);return r;}
function hole(r){const h=r.course.holes[r.numbers[r.index]-1];if(r.course.worldEnabled){const W=root.R10CourseWorld||(typeof require==='function'?require('./course-world.js'):null);if(W?.has(r.course))return W.attach(r.course,h);}return r.course.terrain?{...h,terrain:r.course.terrain}:h;}
function resetHole(r){const h=hole(r);r.turn=0;r.states=r.teams.map(()=>({pos:h.tee.slice(),strokes:0,candidates:[],done:false,last:null,awaitPutt:false}));}
function active(r){if(r.done)return null;const team=r.teams[r.turn],state=r.states[r.turn];return {team,state,player:team.members[state.candidates.length]||team.members[0],hole:hole(r)};}
function next(r){if(r.states.every(s=>s.done)){r.scorecards.push({hole:hole(r).number,par:hole(r).par,scores:r.states.map(s=>s.strokes)});r.reviewHole=true;if(!r.config.reviewHoles)continueHole(r);return;}for(let i=1;i<=r.teams.length;i++){const j=(r.turn+i)%r.teams.length;if(!r.states[j].done){r.turn=j;return;}}}
function landing(pos,aim,forward,right){const d=dist(pos,aim);if(d<.01)throw Error('Aim must differ from ball position');if(!Number.isFinite(forward)||!Number.isFinite(right))throw Error('Missing landing coordinates');const ux=(aim[0]-pos[0])/d,uy=(aim[1]-pos[1])/d;return [pos[0]+ux*forward+uy*right,pos[1]+uy*forward-ux*right];}
// Approximate vertical obstacles on flat terrain, in metres above launch level.
// A canopy strike is a lost ball under the player's house rules; low shots can clear the canopy.
const treeHeights={tree:[3,12],tree_row:[2.5,14],woodland:[2,18]};
function treeObstacles(h){const out=[];for(const s of h.surfaces){if(!treeHeights[s.type])continue;const [bottom,top]=treeHeights[s.type];out.push({surface:s,low:bottom,high:top,type:s.type});if(s.type==='tree'){const center=s.ring.reduce((a,p)=>[a[0]+p[0]/s.ring.length,a[1]+p[1]/s.ring.length],[0,0]);out.push({surface:{ring:ellipse(center[0],center[1],.35,.35)},low:0,high:bottom,type:'trunk'});}}return out.map(o=>({...o,bounds:o.surface.ring.reduce((b,p)=>[Math.min(b[0],p[0]),Math.min(b[1],p[1]),Math.max(b[2],p[0]),Math.max(b[3],p[1])],[Infinity,Infinity,-Infinity,-Infinity])}));}
function segmentHit(a,b,o){const [xmin,ymin,xmax,ymax]=o.bounds;if(Math.max(a[0],b[0])<xmin||Math.min(a[0],b[0])>xmax||Math.max(a[1],b[1])<ymin||Math.min(a[1],b[1])>ymax)return null;const dz=b[2]-a[2],dx=b[0]-a[0],dy=b[1]-a[1];let lo=0,hi=1;if(Math.abs(dz)<1e-9){if(a[2]<o.low||a[2]>o.high)return null;}else{const t1=(o.low-a[2])/dz,t2=(o.high-a[2])/dz;lo=Math.max(0,Math.min(t1,t2));hi=Math.min(1,Math.max(t1,t2));if(lo>hi)return null;}const at=t=>[a[0]+dx*t,a[1]+dy*t];if(contains(at(lo),o.surface))return lo;const ts=[lo,hi];for(const ring of [o.surface.ring,...(o.surface.holes||[])])for(let i=0;i<ring.length;i++){const u=ring[i],v=ring[(i+1)%ring.length],ex=v[0]-u[0],ey=v[1]-u[1],den=dx*ey-dy*ex;if(Math.abs(den)<1e-10)continue;const rx=u[0]-a[0],ry=u[1]-a[1],t=(rx*ey-ry*ex)/den,k=(rx*dy-ry*dx)/den;if(t>=lo&&t<=hi&&k>=0&&k<=1)ts.push(t);}ts.sort((x,y)=>x-y);for(let i=0;i<ts.length-1;i++)if(contains(at((ts[i]+ts[i+1])/2),o.surface))return ts[i];return null;}
function traceFlight(h,from,aim,points){if(!Array.isArray(points)||points.length<2||!points.every(p=>p&&[p.x,p.y,p.z].every(Number.isFinite)))return null;const obs=treeObstacles(h),world=points.map(p=>{const q=landing(from,aim,p.x,p.y);return [...q,p.z+height(h,from)-height(h,q)];});const trace=[world[0].slice(0,2)];for(let i=1;i<world.length;i++){const a=world[i-1],b=world[i];let first=null;for(const o of obs){const t=segmentHit(a,b,o);if(t!==null&&(!first||t<first.t))first={t,type:o.type};}if(first){const p=a.map((v,j)=>v+(b[j]-v)*first.t);trace.push(p.slice(0,2));return {trace,impact:{type:first.type,pos:p.slice(0,2),height:p[2],flightHeight:p[2]+height(h,p)-height(h,from),distance:dist(from,p)}};}if(i%3===0||i===world.length-1)trace.push(b.slice(0,2));}return {trace,impact:null};}
// Start with the range model's flat, medium-firmness estimate. Integrate the
// remaining energy over the mapped turf and local DEM gradient after impact.
const turfResistance={fairway:1,tee:1,green:.65,'approximate target':.65,rough:2.4,unmapped:1.6};
function groundRun(h,from,aim,carryPos,shot,points){
    const analytics=root.ClubAnalytics||(typeof require==='function'?require('./club-analytics.js'):null);
    const estimate=analytics?.rollout({...shot,points},'medium');
    let pos=carryPos, surface=lie(h,pos), distance=0;
    const path=[];
    if(!estimate || estimate.rollout<=.01 || !(surface in turfResistance))
        return {pos,surface,distance,path};
    const finish=landing(from,aim,estimate.finalDownrange,estimate.finalOffline);
    let dx=finish[0]-pos[0],dy=finish[1]-pos[1];
    const len=Math.hypot(dx,dy);
    if(len<.001)return {pos,surface,distance,path};
    const drag=1.8, gravity=9.81;
    let speed=Math.sqrt(2*drag*estimate.rollout),vx=speed*dx/len,vy=speed*dy/len,time=0;
    // A low first hop models the initial bounce. The remaining track hugs the turf.
    const hopLength=Math.min(4,estimate.rollout*.22)/turfResistance[surface];
    const hopHeight=Math.min(.55,hopLength*.12);
    while(speed>.12 && distance<85 && time<18){
        const dt=Math.min(.08,.35/speed);
        const slopeX=(height(h,[pos[0]+1,pos[1]])-height(h,[pos[0]-1,pos[1]]))/2;
        const slopeY=(height(h,[pos[0],pos[1]+1])-height(h,[pos[0],pos[1]-1]))/2;
        const friction=drag*turfResistance[surface];
        const downX=vx-gravity*slopeX*dt, downY=vy-gravity*slopeY*dt;
        const v=Math.hypot(downX,downY),factor=v?Math.max(0,1-friction*dt/v):0;
        const nextX=downX*factor,nextY=downY*factor;
        const next=[pos[0]+(vx+nextX)*dt/2,pos[1]+(vy+nextY)*dt/2];
        distance+=dist(pos,next);pos=next;time+=dt;
        surface=lie(h,pos);
        const phase=Math.min(1,distance/hopLength);
        const stopped=!(surface in turfResistance);
        const z=stopped?0:4*hopHeight*phase*(1-phase);
        speed=Math.hypot(nextX,nextY);vx=nextX;vy=nextY;
        if(stopped || !path.length || time-path.at(-1).t>=.15 || speed<=.12)
            path.push({pos,z,t:time});
        if(stopped)break;
    }
    if(time && path.at(-1)?.t!==time)path.push({pos,z:0,t:time});
    if(path.length)path.at(-1).z=0;
    return {pos,surface,distance,path};
}
function shoot(r,aim,shot,points){
    const a=active(r);
    if(!a||r.reviewHole||a.state.awaitPutt||a.state.candidates.length>=a.team.members.length||!point(aim))
        throw Error('Not ready for another shot');
    const from=a.state.pos.slice(),carryPos=landing(from,aim,Number(shot.downrange),Number(shot.offline));
    const flight=traceFlight(a.hole,from,aim,points),impact=flight?.impact;
    const run=impact?null:groundRun(a.hole,from,aim,carryPos,shot,points);
    const pos=impact?impact.pos:run.pos,surface=impact?'ob':run.surface;
    const entry={hole:a.hole.number,team:r.turn,player:a.player.id,from,aim:aim.slice(),pos,surface,
        penalty:['water','ob'].includes(surface)?1:0,shot};
    if(flight)entry.trace=flight.trace;
    if(impact){entry.impact=impact;entry.intendedPos=carryPos;}
    else{entry.carryPos=carryPos;entry.rollout=run.distance;entry.groundPath=run.path;}
    r.log.push(entry);a.state.candidates.push(entry);
    if(a.team.members.length===1)choose(r,0);
    return entry;
}
function autoPutts(metres){
    if(metres<=2)return 1;
    return metres<=15?2:3;
}
function continueHole(r){
    if(!r.reviewHole)return;
    r.reviewHole=false;
    if(r.index===r.numbers.length-1){r.done=true;return;}
    r.index++;resetHole(r);
}
function choose(r,i){const a=active(r);if(!a||a.state.candidates.length!==a.team.members.length||!Number.isInteger(i)||!a.state.candidates[i])throw Error('Complete all team shots first');const s=a.state,e=s.candidates[i];s.strokes+=1+e.penalty;s.last={...e,chosen:true};e.chosen=true;s.candidates=[];if(!e.penalty)s.pos=e.pos.slice();const surface=lie(a.hole,s.pos);if(surface==='holed'){e.putts=0;s.last.putts=0;s.done=true;next(r);}else if(surface==='green'||surface==='approximate target'){if(r.config.putting==='manual'&&a.team.members.some(p=>!p.bot))s.awaitPutt=true;else{e.putts=autoPutts(dist(s.pos,a.hole.pin));s.last.putts=e.putts;s.strokes+=e.putts;s.done=true;next(r);}}else if(s.strokes>=15){s.strokes+=1;s.done=true;s.pickedUp=true;next(r);}else next(r);return e;}
function finishPutt(r,n){const a=active(r);if(!a||!a.state.awaitPutt||!Number.isInteger(n)||n<1||n>10)throw Error('Enter 1–10 putts');a.state.manualPutts=n;a.state.strokes+=n;a.state.awaitPutt=false;a.state.done=true;next(r);}
function defaultAim(r){const a=active(r);if(!a)return null;const {pos}=a.state,h=a.hole;const mid=h.route.length>2?h.route[Math.floor(h.route.length/2)]:h.pin;return dist(pos,h.pin)>220&&dist(pos,mid)>50&&dist(mid,h.pin)<dist(pos,h.pin)?mid.slice():h.pin.slice();}
function botShot(r,random=Math.random){const a=active(r);if(!a||!a.player.bot||a.state.awaitPutt||a.state.candidates.length>=a.team.members.length)throw Error('Not bot turn');const d=difficulties[r.config.difficulty],aim=defaultAim(r),distance=Math.min(d.max,dist(a.state.pos,aim)),noise=()=>random()+random()+random()+random()-2;let forward=Math.max(1,distance*(1+d.depth*noise())),right=d.spread*noise()*Math.max(.12,Math.min(1,distance/150));const apex=Math.min(28,Math.max(.5,forward*.12)),points=[{x:0,y:0,z:0,t:0}],ground=groundAt(a.hole,a.state.pos,aim);for(let i=1;i<=180;i++){const f=i/60,p={x:forward*f,y:right*f,z:4*apex*f*(1-f),t:f*4};const level=ground?ground(p.x,p.y):0;if(p.z<=level){const q=points.at(-1),old=q.z-(ground?ground(q.x,q.y):0),k=Math.max(0,Math.min(1,old/(old+level-p.z||1)));const end={x:q.x+(p.x-q.x)*k,y:q.y+(p.y-q.y)*k,z:q.z+(p.z-q.z)*k,t:q.t+(p.t-q.t)*k};points.push(end);forward=end.x;right=end.y;break;}points.push(p);}const end=points.at(-1),prev=points.at(-2),dt=Math.max(.00001,end.t-prev.t),horizontal=Math.hypot(end.x-prev.x,end.y-prev.y)/dt,vertical=(prev.z-end.z)/dt;return shoot(r,aim,{landingSpeed:Math.hypot(horizontal,vertical),landingAngle:Math.max(0,Math.atan2(vertical,horizontal)*180/Math.PI),spin:4000,source:'BOT',club:'Bot',carry:Math.hypot(forward,right),downrange:forward,offline:right},points);}
function best(r){const a=active(r);if(!a||!a.state.candidates.length)return -1;let i=0;const score=e=>dist(e.penalty?e.from:e.pos,a.hole.pin)+e.penalty*300+(e.surface==='bunker'?10:0);for(let j=1;j<a.state.candidates.length;j++)if(score(a.state.candidates[j])<score(a.state.candidates[i]))i=j;return i;}
function totals(r){return r.teams.map((t,i)=>({name:t.name,strokes:r.scorecards.reduce((n,h)=>n+h.scores[i],0),par:r.scorecards.reduce((n,h)=>n+h.par,0)}));}
const api={VERSION,lengths,difficulties,validate,terrainValidate,height,elevationDelta,aimLabel,groundAt,demo,dist,lie,holeNumbers,create,hole,active,landing,traceFlight,shoot,choose,finishPutt,continueHole,defaultAim,botShot,best,totals};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.R10Course=api;
})(typeof globalThis!=='undefined'?globalThis:this);
