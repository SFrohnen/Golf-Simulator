/* Club analytics and provisional flat-ground rollout. Does not modify GolfFlight. */
(function(root){'use strict';
const CLUBS=Object.freeze([
 ['60° Wedge','#f9a8d4',[19,39,10000]],['56° Wedge','#fb7185',[23,35,9800]],['52° Wedge','#fb923c',[27,32,9500]],['Pitching Wedge','#facc15',[30,29,9200]],['9 Iron','#bef264',[34,25,8200]],['8 Iron','#4ade80',[38,23,7300]],['7 Iron','#2dd4bf',[42,20,6500]],['6 Iron','#22d3ee',[46,18,5600]],['5 Iron','#60a5fa',[49,16,4600]],['5 Wood','#a78bfa',[56,15,3700]],['7 Wood','#e879f9',[53,18,4300]],['Driver','#f1f5f9',[65,13,2500]]
].map(([name,color,base])=>Object.freeze({name,color,base:Object.freeze(base)})));
const SURFACES=Object.freeze({soft:{retention:.25,deceleration:4.0},medium:{retention:.36,deceleration:3.0},firm:{retention:.46,deceleration:2.2}});
const finite=v=>v!==null&&v!==undefined&&v!==''&&Number.isFinite(Number(v));
const isClub=name=>CLUBS.some(c=>c.name===name);
const color=name=>CLUBS.find(c=>c.name===name)?.color||'#91a8b5';
function rollout(s,surface='medium'){
 const ground=SURFACES[surface];if(!ground||!['carry','landingSpeed','landingAngle','spin','downrange','offline'].every(k=>finite(s[k])))return null;
 const v=Number(s.landingSpeed),angle=Number(s.landingAngle),spin=Number(s.spin),x=Number(s.downrange),y=Number(s.offline);
 if(v<0||v>110||angle<0||angle>90||spin<0||spin>20000)return null;
 // Effective post-impact horizontal speed after bounce losses; reduced by steep impact and backspin.
 // Heuristic only: no slope, turf interaction or check-back model; not calibrated against real rollout.
 const rad=angle*Math.PI/180,axis=finite(s.spinAxis)?Number(s.spinAxis)*Math.PI/180:0;
 const backspin=Math.max(0,spin*Math.cos(axis))*Math.exp(-Math.max(0,Number(s.flightTime)||0)/25);
 const effective=v*Math.cos(rad)*ground.retention*Math.exp(-angle/65)/(1+backspin/7500);
 const distance=effective*effective/(2*ground.deceleration);
 // Use terminal trajectory heading if available; otherwise landing bearing (CSV may lack points).
 const p=s.points;let dx=x,dy=y;
 if(Array.isArray(p)&&p.length>=2){const a=p[p.length-2],b=p[p.length-1];if([a.x,a.y,b.x,b.y].every(finite)&&Math.hypot(b.x-a.x,b.y-a.y)>1e-6){dx=b.x-a.x;dy=b.y-a.y;}}
 const len=Math.hypot(dx,dy);if(len<1e-6&&distance>0)return null;
 const finalDownrange=x+(len?dx/len*distance:0),finalOffline=y+(len?dy/len*distance:0);
 return {rollout:distance,total:Number(s.carry)+distance,finalDownrange,finalOffline,rolloutSurface:surface,rolloutBasis:'ESTIMATED_FLAT_GROUND'};
}
function confirmed(s){return s.clubConfirmed===true||s.clubConfirmed==='true';}
function eligible(s,version,includeDemo=false){return s.model===version&&(s.source==='R10'||(includeDemo&&s.source==='DEMO'))&&confirmed(s)&&isClub(s.club)&&finite(s.carry);}
function mean(rows,fn){const nums=rows.map(fn).filter(finite).map(Number);return {value:nums.length?nums.reduce((a,b)=>a+b,0)/nums.length:null,n:nums.length};}
// Right is positive in the flight engine. Handedness changes golf terminology, not L/R.
function offlineSide(v){if(!finite(v))return null;return Math.abs(Number(v))<.05?'C':Number(v)<0?'L':'R';}
function directionalCounts(rows){const counts={L:0,R:0,C:0};for(const s of rows){const side=offlineSide(s.offline);if(side)counts[side]++;}return counts;}
function smash(s){return finite(s.ballSpeed)&&finite(s.clubSpeed)&&Number(s.ballSpeed)>0&&Number(s.clubSpeed)>0?Number(s.ballSpeed)/Number(s.clubSpeed):null;}
function shape(s,hand='right'){
 if(!['direction','offline','downrange'].every(k=>finite(s[k]))||Number(s.downrange)<=0)return null;
 const start=Number(s.direction),end=Math.atan2(Number(s.offline),Number(s.downrange))*180/Math.PI;
 const curve=((end-start+540)%360)-180, sign=hand==='left'?-1:1;
 // Configurable-in-code heuristic: bearing departure from initial line, not final offline alone.
 const launch=Math.abs(start)<1.5?'Straight':start*sign>0?'Push':'Pull';
 const bend=Math.abs(curve)<1.5?'Straight':curve*sign>0?(Math.abs(curve)>=5?'Slice':'Fade'):(Math.abs(curve)>=5?'Hook':'Draw');
 return {launch,bend,label:launch==='Straight'?bend:bend==='Straight'?launch:launch+' '+bend,curveDegrees:curve};
}
// R10 reports target-relative club angles. Positive is right; handedness changes terminology.
function faceToPath(s){return s&&finite(s.face)&&finite(s.path)?Number(s.face)-Number(s.path):null;}
function swing(s,hand='right'){
 if(!s)return null;const diff=faceToPath(s),sign=hand==='left'?-1:1;
 const bend=diff===null?null:Math.abs(diff)<2?'Near neutral':diff*sign>0?'Fade / slice tendency':'Draw / hook tendency';
 const flight=shape(s,hand);const opposite=diff!==null&&Math.abs(diff)>=2&&flight&&Math.abs(flight.curveDegrees)>=1.5&&Math.sign(diff)!==Math.sign(flight.curveDegrees);
 return {faceToPath:diff,bend,opposite:!!opposite};
}
function sessionRows(shots,id){return shots.filter(s=>s.sessionId===id);}
function summarize(shots,version,surface='medium',includeDemo=false){return CLUBS.map(c=>{const rows=shots.filter(s=>eligible(s,version,includeDemo)&&s.club===c.name);const rolls=rows.map(s=>rollout(s,surface));return {...c,count:rows.length,carry:mean(rows,s=>s.carry),rollout:mean(rolls,r=>r?.rollout),total:mean(rolls,r=>r?.total),offline:mean(rows,s=>finite(s.offline)?Math.abs(Number(s.offline)):null),finalOffline:mean(rolls,r=>r?Math.abs(r.finalOffline):null),spin:mean(rows,s=>s.spin),apex:mean(rows,s=>s.apex),launch:mean(rows,s=>s.launch),clubSpeed:mean(rows,s=>finite(s.clubSpeed)&&Number(s.clubSpeed)>0?Number(s.clubSpeed):null),smash:mean(rows,smash),path:mean(rows,s=>s.path),face:mean(rows,s=>s.face),faceToPath:mean(rows,faceToPath),attack:mean(rows,s=>s.attack),sides:directionalCounts(rows),estimatedSpin:rows.filter(s=>String(s.spinSource).toUpperCase().includes('ESTIMAT')).length};});}
function groups(shots,version,surface,includeDemo,mode='carry'){
 return CLUBS.map(c=>{const points=shots.filter(s=>eligible(s,version,includeDemo)&&s.club===c.name).map(s=>{if(mode==='finish'){const r=rollout(s,surface);return r?{x:r.finalOffline,y:r.finalDownrange}:null;}return finite(s.offline)&&finite(s.downrange)?{x:Number(s.offline),y:Number(s.downrange)}:null;}).filter(Boolean);
 if(!points.length)return {...c,points,center:null,radius:0};const center={x:mean(points,p=>p.x).value,y:mean(points,p=>p.y).value};const radius=Math.max(...points.map(p=>Math.hypot(p.x-center.x,p.y-center.y)));return {...c,points,center,radius};});
}
const api={CLUBS,SURFACES,finite,isClub,color,rollout,confirmed,eligible,summarize,groups,offlineSide,directionalCounts,smash,shape,faceToPath,swing,sessionRows};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.ClubAnalytics=api;
})(typeof globalThis!=='undefined'?globalThis:this);
