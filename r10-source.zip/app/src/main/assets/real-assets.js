/* Replaced by tools/fetch-real-assets.py in the release build. */
globalThis.R10RealAssets=null;
