(function(root){'use strict';
// Gross-score estimate only: no net-double-bogey adjustment, PCC or nine-hole expected score.
function differential(gross,rating,slope,holes){return holes===18&&Number.isFinite(gross)&&gross>=18&&Number.isFinite(rating)&&rating>=50&&rating<=90&&Number.isFinite(slope)&&slope>=55&&slope<=155?Math.round((gross-rating)*113/slope*10)/10:null;}
// WHS Rule 5.2a / 5.2b base calculation. Imported official differentials only;
// exceptional-score reductions and low-index caps require additional history.
function index(values){const a=values.slice(0,20),n=a.length;if(n<3||!a.every(Number.isFinite))return null;const count=n<=5?1:n<=8?2:n<=11?3:n<=14?4:n<=16?5:n<=18?6:n===19?7:8;const adj=n===3?-2:n===4||n===6?-1:0;return Math.min(54,Math.round((a.sort((x,y)=>x-y).slice(0,count).reduce((sum,v)=>sum+v,0)/count+adj)*10)/10);}
// User-supplied CSV of actual differentials. Expect most recent rows first unless ISO dates provided.
function parseDifferentials(text){const raw=String(text).replace(/^\uFEFF/,'').trim();if(!raw)return [];const lines=raw.split(/\r?\n/).filter(x=>x.trim());const delim=lines[0].includes('\t')?'\t':lines[0].includes(';')?';':',';const split=line=>line.split(delim).map(x=>x.trim().replace(/^"|"$/g,''));const header=split(lines[0]).map(x=>x.toLowerCase().replace(/[^a-z]/g,''));const col=header.findIndex(x=>['differential','scoredifferential','handicapdifferential'].includes(x));let vals;if(col>=0){const date=header.findIndex(x=>['date','rounddate','scoredate','playeddate'].includes(x));let rows=lines.slice(1).map(split);if(date>=0&&rows.every(r=>/^\d{4}-\d{2}-\d{2}/.test(r[date]||'')))rows=rows.sort((a,b)=>b[date].localeCompare(a[date]));vals=rows.map(r=>r[col]);}else vals=raw.split(/[,;\t\n]/).map(x=>x.trim()).filter(Boolean);if(!vals.length||vals.some(x=>x===''||!Number.isFinite(Number(x))||Number(x)<-20||Number(x)>100))throw Error('Use numeric score differentials or a CSV with a Score Differential column.');return vals.map(Number).slice(0,20);}

const api={differential,index,parseDifferentials};if(typeof module==='object')module.exports=api;else root.R10RoundStats=api;
})(globalThis);
