/* Offline experimental golf flight model, SI units. Generic coefficients, not calibrated to R10/Awesome Golf. */
(function(root){'use strict';
const VERSION='aero-0.3.0', R=.021335, MASS=.04593, AREA=Math.PI*R*R, G=9.80665;
const rad=d=>d*Math.PI/180, clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const finite=v=>v!==null&&v!==undefined&&v!==''&&Number.isFinite(Number(v));
function simulate(input, settings={}){
 const keys=['ballSpeed','launch','direction','spin','spinAxis'];
 if(!keys.every(k=>finite(input[k])))throw Error('Missing launch, speed, direction, spin or spin axis');
 const [speed,launch,heading,spin,axis]=keys.map(k=>Number(input[k]));
 if(speed<=0||speed>110||launch< -10||launch>85||Math.abs(heading)>90||spin<0||spin>20000||Math.abs(axis)>180)throw Error('Implausible launch data');
 const temp=Number(settings.temperatureC??15), altitude=Number(settings.altitudeM??0), dt=Number(settings.dt??.01);
 if(!Number.isFinite(temp)||temp< -30||temp>50||!Number.isFinite(altitude)||altitude< -500||altitude>5000||!Number.isFinite(dt)||dt<=0||dt>.05)throw Error('Invalid flight settings');
 const rho=101325*Math.pow(1-2.25577e-5*altitude,5.25588)/(287.05*(temp+273.15));
 const h=rad(heading), l=rad(launch), a=rad(axis), c=Math.cos(h), s=Math.sin(h);
 // x forward, y right, z up. Positive normalized R10 axis curves right.
 const omega=[Math.sin(h)*Math.cos(a),-Math.cos(h)*Math.cos(a),Math.sin(a)];
 let q=[0,0,.021335,speed*Math.cos(l)*c,speed*Math.cos(l)*s,speed*Math.sin(l)], t=0, apex=0;
 const points=[{x:0,y:0,z:0,t:0}];
 function deriv(state,time){
  const [vx,vy,vz]=state.slice(3), v=Math.hypot(vx,vy,vz);
  if(v<1e-8)return [vx,vy,vz,0,0,-G];
  const mu=1.81e-5, re=rho*v*2*R/mu;
  const w=spin*2*Math.PI/60*Math.exp(-time/25), S=R*w/v;
  // Smooth generic dimpled-ball drag crisis + spin-dependent drag and lift.
  // Coefficients are engineering approximations, not digitized experimental fits.
  const cd=.22+.22/(1+Math.exp(clamp((re-65000)/10000,-50,50)))+.12*clamp(S,0,.8);
  const cl=clamp(1.5*S/(1+1.8*S),0,.35);
  const f=.5*rho*AREA*v/MASS;
  const cross=[omega[1]*vz-omega[2]*vy,omega[2]*vx-omega[0]*vz,omega[0]*vy-omega[1]*vx];
  return [vx,vy,vz,f*(-cd*vx+cl*cross[0]),f*(-cd*vy+cl*cross[1]),f*(-cd*vz+cl*cross[2])-G];
 }
 const add=(a,b,f)=>a.map((v,i)=>v+b[i]*f);
 for(let n=0;n<Math.ceil(30/dt);n++){
  const prev=q,k1=deriv(q,t),k2=deriv(add(q,k1,dt/2),t+dt/2),k3=deriv(add(q,k2,dt/2),t+dt/2),k4=deriv(add(q,k3,dt),t+dt);
  q=q.map((v,i)=>v+dt*(k1[i]+2*k2[i]+2*k3[i]+k4[i])/6);t+=dt;
  apex=Math.max(apex,q[2]-R);
  if(q[2]<=R&&q[5]<0){
   const f=clamp((prev[2]-R)/(prev[2]-q[2]),0,1); q=prev.map((v,i)=>v+(q[i]-v)*f);t-=dt*(1-f);
   points.push({x:q[0],y:q[1],z:0,t});
   return {model:VERSION,carry:Math.hypot(q[0],q[1]),downrange:q[0],offline:q[1],apex,flightTime:t,landingSpeed:Math.hypot(...q.slice(3)),landingAngle:Math.atan2(-q[5],Math.hypot(q[3],q[4]))*180/Math.PI,temperatureC:temp,altitudeM:altitude,points};
  }
  if(n%Math.max(1,Math.round(.1/dt))===0)points.push({x:q[0],y:q[1],z:q[2]-R,t});
 }
 throw Error('Flight integration did not reach ground');
}
const api={simulate,VERSION};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.GolfFlight=api;
})(typeof globalThis!=='undefined'?globalThis:this);
