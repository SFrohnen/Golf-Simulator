/* Pure projection functions for the course canvas. World x east/y north. */
(function(root){'use strict';
function fit(points,w,h,top=0,bottom=0){const xs=points.map(p=>p[0]),ys=points.map(p=>p[1]),minX=Math.min(...xs)-35,maxX=Math.max(...xs)+35,minY=Math.min(...ys)-35,maxY=Math.max(...ys)+35;const usable=Math.max(60,h-top-bottom);return {cx:(minX+maxX)/2,cy:(minY+maxY)/2,k:Math.min(Math.max(20,w-24)/(maxX-minX),Math.max(20,usable-20)/(maxY-minY)),w,h,ox:w/2,oy:top+usable/2};}
function project(v,p){return [v.ox+(p[0]-v.cx)*v.k,v.oy-(p[1]-v.cy)*v.k];}
function unproject(v,p){return [v.cx+(p[0]-v.ox)/v.k,v.cy-(p[1]-v.oy)/v.k];}
function zoom(v,factor,anchor,base){const before=unproject(v,anchor),k=Math.max(base*.7,Math.min(base*10,v.k*factor));const next={...v,k};const after=unproject(next,anchor);return {...next,cx:next.cx+before[0]-after[0],cy:next.cy+before[1]-after[1]};}
function pan(v,dx,dy){return {...v,cx:v.cx-dx/v.k,cy:v.cy+dy/v.k};}
const api={fit,project,unproject,zoom,pan};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.R10CourseMap=api;
})(typeof globalThis!=='undefined'?globalThis:this);
