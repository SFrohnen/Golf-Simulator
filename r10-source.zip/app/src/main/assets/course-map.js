/* Pure projection functions for the course canvas. World x east/y north. */
(function(root){'use strict';
function fit(points,w,h,top=0,bottom=0){const xs=points.map(p=>p[0]),ys=points.map(p=>p[1]),minX=Math.min(...xs)-35,maxX=Math.max(...xs)+35,minY=Math.min(...ys)-35,maxY=Math.max(...ys)+35;const usable=Math.max(60,h-top-bottom);return {cx:(minX+maxX)/2,cy:(minY+maxY)/2,k:Math.min(Math.max(20,w-24)/(maxX-minX),Math.max(20,usable-20)/(maxY-minY)),w,h,ox:w/2,oy:top+usable/2};}
function project(v,p){return [v.ox+(p[0]-v.cx)*v.k,v.oy-(p[1]-v.cy)*v.k];}
function unproject(v,p){return [v.cx+(p[0]-v.ox)/v.k,v.cy-(p[1]-v.oy)/v.k];}
function zoom(v,factor,anchor,base){const before=unproject(v,anchor),k=Math.max(base*.7,Math.min(base*10,v.k*factor));const next={...v,k};const after=unproject(next,anchor);return {...next,cx:next.cx+before[0]-after[0],cy:next.cy+before[1]-after[1]};}
function pan(v,dx,dy){return {...v,cx:v.cx-dx/v.k,cy:v.cy+dy/v.k};}
// Intersect a cross-fairway line with all mapped fairways, merging touching
// spans. Holes in a polygon are excluded by the same even/odd rule as the map.
function fairwayRoom(h,ball,target){
    const dx=target[0]-ball[0],dy=target[1]-ball[1],length=Math.hypot(dx,dy);
    if(length<.01)return null;
    const ux=dx/length,uy=dy/length,spans=[];
    for(const surface of h.surfaces){
        if(surface.type!=='fairway')continue;
        const crossings=[];
        for(const ring of [surface.ring,...(surface.holes||[])]){
            for(let i=0;i<ring.length;i++){
                const a=ring[i],b=ring[(i+1)%ring.length];
                const along=p=>(p[0]-target[0])*ux+(p[1]-target[1])*uy;
                const av=along(a),bv=along(b);
                if((av>0)===(bv>0))continue;
                const t=av/(av-bv),x=a[0]+t*(b[0]-a[0])-target[0],y=a[1]+t*(b[1]-a[1])-target[1];
                crossings.push(x*uy-y*ux);
            }
        }
        crossings.sort((a,b)=>a-b);
        for(let i=0;i+1<crossings.length;i+=2)spans.push([crossings[i],crossings[i+1]]);
    }
    spans.sort((a,b)=>a[0]-b[0]);
    const merged=[];
    for(const span of spans){
        const prev=merged.at(-1);
        if(prev&&span[0]<=prev[1]+.001)prev[1]=Math.max(prev[1],span[1]);
        else merged.push(span.slice());
    }
    const hit=merged.find(([a,b])=>a<=0&&b>=0);
    return hit?{left:-hit[0],right:hit[1]}:null;
}
// Orient the inset to the shot and keep the full hole and latest finish in frame.
function holeInset(h,ball,target,entry,spread=[]){
    const w=144,height=158,from=entry?.from||ball;
    let dx=target[0]-ball[0],dy=target[1]-ball[1];
    if(Math.hypot(dx,dy)<1){dx=h.pin[0]-h.tee[0];dy=h.pin[1]-h.tee[1];}
    const len=Math.hypot(dx,dy)||1;
    const rotate=p=>[(p[0]-from[0])*dy/len-(p[1]-from[1])*dx/len,-((p[0]-from[0])*dx+(p[1]-from[1])*dy)/len];
    const pts=[...h.route,ball,target,...spread,...[entry?.carryPos,entry?.pos].filter(Boolean)].map(rotate);
    if(spread.length>=3){
        const d=spread.map(rotate),cx=d.reduce((v,q)=>v+q[0],0)/d.length,cy=d.reduce((v,q)=>v+q[1],0)/d.length;
        const radii=d.map(q=>Math.hypot(q[0]-cx,q[1]-cy)).sort((a,b)=>a-b),r=radii[Math.ceil(radii.length*.8)-1];
        pts.push([cx-r,cy-r],[cx+r,cy+r]);
    }
    const xs=pts.map(p=>p[0]),ys=pts.map(p=>p[1]);
    const minX=Math.min(...xs),maxX=Math.max(...xs),minY=Math.min(...ys),maxY=Math.max(...ys);
    const scale=Math.min((w-18)/(maxX-minX+28),(height-18)/(maxY-minY+28));
    const xy=p=>{const [x,y]=rotate(p);return [(w/2+(x-(minX+maxX)/2)*scale).toFixed(1),(height/2+(y-(minY+maxY)/2)*scale).toFixed(1)];};
    const path=ring=>ring.map((p,i)=>(i?'L':'M')+xy(p).join(' ')).join('')+'Z';
    const palette={woodland:'#344c38',tree_row:'#344c38',fairway:'#85a95f',tee:'#abc276',green:'#c7dd92',water:'#6499b0',bunker:'#e6d3a0'};
    let svg='';
    for(const [type,fill] of Object.entries(palette))for(const s of h.surfaces){
        if(s.type===type)svg+='<path fill="'+fill+'" fill-rule="evenodd" d="'+[s.ring,...(s.holes||[])].map(path).join('')+'"/>';
    }
    const line=(a,b,style)=>'<path d="M'+xy(a).join(' ')+'L'+xy(b).join(' ')+'" '+style+'/>';
    const dot=(p,r,fill)=>{const [x,y]=xy(p);return '<circle cx="'+x+'" cy="'+y+'" r="'+r+'" fill="'+fill+'" stroke="#27372e" stroke-width="1"/>';};
    if(spread.length){
        const n=spread.length;
        const centre=spread.reduce((p,q)=>[p[0]+q[0]/n,p[1]+q[1]/n],[0,0]);
        const radii=spread.map(p=>Math.hypot(p[0]-centre[0],p[1]-centre[1])).sort((a,b)=>a-b);
        if(n>=3)for(const fraction of [.5,.8]){
            const radius=radii[Math.ceil(n*fraction)-1]*scale;
            svg+='<circle data-spread="'+fraction+'" cx="'+xy(centre)[0]+'" cy="'+xy(centre)[1]+'" r="'+radius.toFixed(2)+'" fill="none" stroke="#fff3a1" stroke-width="1"/>';
        }
        svg+=spread.map(p=>dot(p,1.7,'#ffe493')).join('');
    }
    svg+=line(ball,target,'stroke="white" stroke-dasharray="3 2"');
    const [px,py]=xy(h.pin);
    svg+='<path d="M'+px+' '+py+'v-8l6 2-6 2" fill="#ec6953" stroke="#4d302a" stroke-width=".7"/>';
    svg+=dot(ball,3,'white')+dot(target,4,'none').replace('<circle','<circle data-aim="true"');
    if(entry){if(entry.carryPos)svg+=line(entry.carryPos,entry.pos,'stroke="#fff0b3" stroke-width="2"')+dot(entry.carryPos,3,'#ffc95c');svg+=dot(entry.pos,2.8,'white').replace('<circle','<circle data-finish="true"');}
    return svg;
}

const api={fairwayRoom,holeInset,fit,project,unproject,zoom,pan};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.R10CourseMap=api;
})(typeof globalThis!=='undefined'?globalThis:this);
