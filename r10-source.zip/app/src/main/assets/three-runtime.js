/* Build placeholder. tools/build-three.mjs replaces this with the pinned local Three.js runtime. */
