# v0.4.0-alpha — Club analytics

- Added exact 12-club selection with stable colors, selected-club persistence, and manual history correction with original club retained.
- New Analytics tab: equal-scale carry/finish dispersion, circles enclosing each club's points, individual club toggles, real-only default and optional demo shots.
- Added per-club carry, rollout, total, absolute lateral deviation, spin and peak height means, with valid sample counts.
- Provisional flat-ground rollout/finish estimates with soft, medium and firm presets; no changes to calibrated flight engine.
- Added rollout/total/peak/dispersion metrics to Range and directional club path/face-to-path labels (right-handed convention). Decimal displays use one fractional digit.
- CSV import/export preserves club confirmation and original club; stable deduplication across corrected clubs. Earlier labels require confirmation before inclusion in analytics.
- Protocol, flight, history, calibration regression, and new club analytics tests pass. Original backup replay: all 33 real shots yield rollout estimates. Android build and on-device UI/accuracy validation pending.

# 0.3.0-alpha — Package 1: Accuracy and physics (2026-11-24)

- Replaced vacuum projectile carry formula with offline 3D RK4 aerodynamic model: gravity, speed-dependent drag, spin-dependent lift, spin decay and normalized spin axis. Generic coefficients are provisional, not a validated Garmin/Awesome Golf reproduction.
- New shot diagnostics: raw launch inputs in SI units, spin provenance, club metrics, face-to-path, modeled apex, time, landing angle/speed and lateral landing deviation. Temperature and altitude inputs, still air. Rollout deferred.
- Overhead line uses modeled trajectory, not an illustrative quadratic curve. Carry is horizontal radial distance to landing; separate downrange and signed offline are exported.
- Existing history is retained, tagged legacy in the latest-shot diagnostic, and excluded (with demo shots) from new-model live summary. CSV keeps full precision. Visible measurement numbers use one decimal place.
- Replay tool and reference comparison fixture for the eight observed shots. No raw shot CSV supplied; actual accuracy improvement cannot yet be quantified.
- No changes to BLE transport. New model unit tests and existing Java wire tests pass. Android APK build and hardware test still required.
- Known limitations: coefficients not fitted to measured ball-specific data, no wind or terrain; spin direction convention follows existing R10 decoder; missing protobuf scalar fields can still default to zero and must be audited. Carry, lateral distance and apex are modeled, not direct measured outputs. Club list, grouping circles, per-club averages and rollout remain Package 2; coaching and gameplay remain Package 3.

## v0.3.1-alpha — CSV recovery
- Native Android file picker and offline import of v0.2/v0.3 CSV exports.
- Merge and deduplicate by timestamp, shot ID, club and source; preserve timestamps and existing history.
- Recalculate legacy shots with complete launch inputs using current atmosphere settings, preserving previousCarry; otherwise retain original carry.
- Reject malformed CSV and imports exceeding the existing 1,000-shot history limit. Import tests included.
- Android APK build and physical device import still require verification.

## v0.3.2-alpha — Physics optimization (2026-11-24)
- Default atmosphere 20°C / 200 m to match Awesome Golf.
- Bounded coefficient grid search: base drag unchanged 0.22; spin drag coefficient 0.12 → 0.22; lift scale 1.5 → 1.95. Seven confirmed pairs used; probable pair excluded. No per-club or distance correction.
- At matching settings: confirmed MAE 10.15 → 2.33 m; max 17.92 → 5.34 m; bias +1.76 → −2.01 m. Leave-one-out selects identical coefficients on all seven folds; MAE 2.33 m, not independent validation. All spin inputs estimated, reference is not ground truth.
- History: explicit Recalculate history action updates real R10 shots in current atmosphere; original carry, prior model carry, raw data, timestamps and shot IDs preserved. Invalid and demo shots skipped. History rows show shot ID and original carry.
- CSV import/export remains supported, with prior model columns. Backup before installing; import then recalculate if needed. Native WebChromeClient enables confirmation dialogs.
- Calibration fixtures and reproducible calibration/replay scripts added. BLE transport unchanged. No hardware or APK build validation locally. Club inventory, rollout and analytics remain separate follow-up work.
