# v0.7.4-alpha — Consolidated beta fixes

- Matched 15 reference shots from the supplied 36-row CSV using shot ID, carry, ball speed and launch. The five PW, five 7I and five Driver reference shots were identified independently of the app's mislabeled club column. New smooth speed/spin-regime corrections to drag and lift use 15 beta shots plus seven older confirmed reference shots. New model `aero-0.7.4`. Fit-set MAE: carry 5.04→1.53 m, apex 2.73→1.26 m, lateral comparison 2.22→1.67 m. Maximum carry error 4.98 m. Earlier seven reference MAE rises from 2.33 to 3.14 m (max 6.90 m); explicitly retained regression bounds 3.5/7.5 m. New results are calibration, NOT independent validation. Reference lateral definitions may differ.
- Bounded medium-surface rollout model using landing speed, landing angle and spin, fit to reference simulator rollout: 10.16→0.63 m MAE; total 13.74→1.57 m. Soft/firm modifiers remain provisional. No claim of actual turf accuracy. Course gameplay still carry-only.
- BLE: up to five backoff reconnect attempts after unplanned disconnect, connection/initialization watchdog and write-failure recovery, cancel on manual disconnect, keep screen awake, short-term duplicate suppression across reconnects, longer exportable diagnostics. Device testing required; cannot recover physical shots hit while disconnected. No change to wire protocol.
- Practice: Random Numbers still confirms each target; Target Practice confirms once; Club Gapping auto-selects shortest-to-longest, automatically advances, optional native tone cue and on-screen club change, manual remaining-club override. Shared scaled Range canvas for all practice modes, true origin, latest trajectory, landing points, club dispersion circles from three shots and moving target. Cumulative 3 m accuracy bands replace score as primary display.
- Coach: practice feedback on demand during a session and technical summary at completion; range coaching collapsed by default; uses numerical delivery/launch/spin, target and historical evidence, actionable check and measurable target, with uncertainty. Existing course integration retained. Mishit tagging, exclusion from gapping means and optional exclusion from analytics; CSV preserves tag. Spin axis L/R/C and neutral-zero formatting; reduced metric wrapping.
- Tests: all JS regression suites, protocol Java tests, Python course fixtures, new beta fit regression and mocked UI flows passed. Native Android APK compilation, audio and Bluetooth recovery not tested here. No new course geometry. Keep CSV backups and run History → Recalculate history after update.

# v0.7.3-alpha — Airborne tree collisions

- Human R10 and demo flight trajectories are checked against mapped tree, tree-row and woodland volumes before landing; earliest collision stops the plotted flight. Bot trajectories use approximate arcs and the same collision rules.
- Estimated canopy height bands: single tree 3–12 m, tree row 2.5–14 m, woodland 2–18 m. Single tree trunk radius approximated at 0.35 m. Flat terrain only; these are not surveyed heights. A shot can fly below, around or above a canopy; landing inside a tree area or striking a tree results in one penalty and replay per house rules. No change to calibrated range physics.
- Trier hole 10 audit: original OSM XML has no mapped fairway bunker near the central tree; only four nearby green-side bunker polygons plus one distant bunker from a neighboring area in the pack. The club Birdiebook depicts fairway bunkers, but exact geometry is unverified. Flagged in round details; no invented polygon. Water features remain unchanged (none mapped on hole 10).
- Tests: canopy, trunk, clearance, polygon cutouts, trace truncation, penalty and scramble selection; existing JS and Java protocol regressions pass. Android device testing pending.

# v0.4.2-alpha — Swing delivery analysis

- Club path, clubface angle, face-to-path and attack angle prominently displayed above flight diagnostics; handedness-aware labels, signed angles and missing-value handling.
- Face-to-path = face minus path, with a qualitative curvature tendency and a warning when delivery and modeled curvature disagree. Ball-flight classification remains based on reported launch and modeled curvature; do not double-count impact effects in flight physics.
- Session and historical club means include path, face and face-to-path; demo includes synthetic delivery values. Carry engine and BLE unchanged.

# v0.4.1-alpha — Live session usability

- Range now has a persistent active practice session and a New session button (does not delete history). Live club-colored dispersion circles appear after three valid shots per club, with auto-scaled plot and separate real/demo data. Analytics remains available across history.
- Correct any shot’s club directly in Range or History; quick last-shot selector. Club averages and circles update immediately. CSV preserves session IDs and historical club corrections. Older imports without session IDs remain in History rather than mixing into a new session.
- Latest shot shows estimated shape (push/pull/straight with fade/slice/draw/hook), handedness, bold carry/offline/launch, and total, peak, spin, spin axis, ball speed, club head speed and smash factor above flight diagnostics. Shape uses initial heading and modeled bearing change; heuristic 1.5° straight and 5° severe curvature thresholds, not a measured classification.
- Offline is shown as L/R/C; mean absolute offline plus counts of left, right and center for the current club and all-history club analytics. Missing values excluded. Smash factor = ball speed / club speed; missing/zero club speed omitted.
- Removed standalone rollout display and finish dispersion; total distance still uses the previous provisional ground model because total remains requested.
- Carry flight engine unchanged. Protocol, flight, history, reference, club/session/shape and mocked-DOM UI tests pass. Browser smoke test timed out in this environment; Android build and actual device visual validation pending.

# v0.4.0-alpha — Club analytics

- Added exact 12-club selection with stable colors, selected-club persistence, and manual history correction with original club retained.
- New Analytics tab: equal-scale carry/finish dispersion, circles enclosing each club's points, individual club toggles, real-only default and optional demo shots.
- Added per-club carry, rollout, total, absolute lateral deviation, spin and peak height means, with valid sample counts.
- Provisional flat-ground rollout/finish estimates with soft, medium and firm presets; no changes to calibrated flight engine.
- Added rollout/total/peak/dispersion metrics to Range and directional club path/face-to-path labels (right-handed convention). Decimal displays use one fractional digit.
- CSV import/export preserves club confirmation and original club; stable deduplication across corrected clubs. Earlier labels require confirmation before inclusion in analytics.
- Protocol, flight, history, calibration regression, and new club analytics tests pass. Original backup replay: all 33 real shots yield rollout estimates. Android build and on-device UI/accuracy validation pending.

# 0.3.0-alpha — Package 1: Accuracy and physics (2026-11-24)

- Replaced vacuum projectile carry formula with offline 3D RK4 aerodynamic model: gravity, speed-dependent drag, spin-dependent lift, spin decay and normalized spin axis. Generic coefficients are provisional, not a validated Garmin/Awesome Golf reproduction.
- New shot diagnostics: raw launch inputs in SI units, spin provenance, club metrics, face-to-path, modeled apex, time, landing angle/speed and lateral landing deviation. Temperature and altitude inputs, still air. Rollout deferred.
- Overhead line uses modeled trajectory, not an illustrative quadratic curve. Carry is horizontal radial distance to landing; separate downrange and signed offline are exported.
- Existing history is retained, tagged legacy in the latest-shot diagnostic, and excluded (with demo shots) from new-model live summary. CSV keeps full precision. Visible measurement numbers use one decimal place.
- Replay tool and reference comparison fixture for the eight observed shots. No raw shot CSV supplied; actual accuracy improvement cannot yet be quantified.
- No changes to BLE transport. New model unit tests and existing Java wire tests pass. Android APK build and hardware test still required.
- Known limitations: coefficients not fitted to measured ball-specific data, no wind or terrain; spin direction convention follows existing R10 decoder; missing protobuf scalar fields can still default to zero and must be audited. Carry, lateral distance and apex are modeled, not direct measured outputs. Club list, grouping circles, per-club averages and rollout remain Package 2; coaching and gameplay remain Package 3.

## v0.3.1-alpha — CSV recovery
- Native Android file picker and offline import of v0.2/v0.3 CSV exports.
- Merge and deduplicate by timestamp, shot ID, club and source; preserve timestamps and existing history.
- Recalculate legacy shots with complete launch inputs using current atmosphere settings, preserving previousCarry; otherwise retain original carry.
- Reject malformed CSV and imports exceeding the existing 1,000-shot history limit. Import tests included.
- Android APK build and physical device import still require verification.

## v0.3.2-alpha — Physics optimization (2026-11-24)
- Default atmosphere 20°C / 200 m to match Awesome Golf.
- Bounded coefficient grid search: base drag unchanged 0.22; spin drag coefficient 0.12 → 0.22; lift scale 1.5 → 1.95. Seven confirmed pairs used; probable pair excluded. No per-club or distance correction.
- At matching settings: confirmed MAE 10.15 → 2.33 m; max 17.92 → 5.34 m; bias +1.76 → −2.01 m. Leave-one-out selects identical coefficients on all seven folds; MAE 2.33 m, not independent validation. All spin inputs estimated, reference is not ground truth.
- History: explicit Recalculate history action updates real R10 shots in current atmosphere; original carry, prior model carry, raw data, timestamps and shot IDs preserved. Invalid and demo shots skipped. History rows show shot ID and original carry.
- CSV import/export remains supported, with prior model columns. Backup before installing; import then recalculate if needed. Native WebChromeClient enables confirmation dialogs.
- Calibration fixtures and reproducible calibration/replay scripts added. BLE transport unchanged. No hardware or APK build validation locally. Club inventory, rollout and analytics remain separate follow-up work.

## v0.5.0-alpha — Structured practice (2026-11-24)
- Practice tab with Random Numbers, Target Practice, and guided Club Gapping for a selectable subset of the existing 12 clubs.
- Random target min/max/step and attempts, no immediate repeated target; fixed target and attempts; gapping 3–15 shots per club, auto-guided bag order.
- Choose live or demo source, confirm club before each scored shot, disarm on tab navigation. Unarmed or mismatched shots still go to ordinary history. Club correction retained; gapping progress recalculates after correction.
- Target error is Euclidean distance between modeled landing coordinates and requested target. Hit radius max(3 m, 5% of target); score 100 at center, linear down to zero at 3 radii. Plot relative landing points; all metrics display one decimal place.
- Gapping reports mean carry, population SD, adjacent selected-club gap, overlap of mean ± SD bands, heuristic consistency label after 3 shots. No automatic exclusion of outliers.
- Active practice state persists locally; each shot includes practice ID, mode, attempt index, target and config in history and CSV. Archive derives session results from retained shots, including imported CSVs. Existing 1000-shot history cap remains. Demo and live results are separate.
- No changes to native Bluetooth or calibrated aerodynamic engine; no new claim of independent accuracy. Personal Golf Coach remains next package.
- Java protocol, all JS regression tests and mocked DOM tests for all three practice modes pass; APK/device and visual validation pending.

## v0.6.0-alpha — Integrated Personal Golf Coach (2026-11-24)

- Automatic rule-based feedback in Range, Random Numbers, Target Practice and Club Gapping. Global persistent Off / Brief / Detailed control; no separate coach-only mode, cloud connection or subscription.
- Brief gives one prioritized observation and drill. Detailed expands measured club delivery, modeled shape, target miss, smash factor, comparable historical carry/dispersion and recurring directional patterns. Five earlier comparable shots required for personalized patterns; up to 30 previous shots considered. Session trend compares at least five valid offline readings in each group.
- Compare only confirmed same-club shots from the same source, flight model and environmental settings; target shots use similar target distances, separate from non-target shots. Demo and live never mix. Historical comparisons are descriptive; unknown swing intent and provisional flight/spin are explicitly disclosed.
- Suppress causal delivery diagnosis when modeled curvature disagrees with face-to-path, or data is missing. Handedness-aware, no assumed physical swing fault. Coach does not change carry physics, score or raw data. Existing CSVs work without schema changes; feedback is recomputed from history, preference stays local.
- Added coach unit tests and mocked UI checks across all current play/practice modes. Android build/device validation pending; course mode not yet implemented.

## 0.7.0-alpha — 2D course simulation foundation
- Play a fictional 18-hole Practice Valley demo or import a real mapped course pack (JSON v1, local metric coordinates).
- 3, 6, 9, 12, 15, 18 holes; front/back selection for <=9; longer rounds start at 1.
- Individual stroke play with one or two humans, up to two computer opponents. Four bot difficulty levels. Two-person scramble with a human or bot partner; optional competing two-bot teams. Select the preferred ball, then both play from that position. Gross scorecard and export; automatic or manual putting. Simplified water/OB replay and penalty; carry-only placement; no terrain physics.
- Tap to aim, confirm current player and club for each shot, display landing positions and last human flight trace; global coaching on human shots using same-player comparable round history. Separate round storage prevents second player/bot shots contaminating personal analytics. Current round resumes locally; completed scorecard CSV can be exported. Round data is not restored by the personal shot CSV importer.
- OSM importer and named course catalog for Trier, Kikuoka, and assumed Weiherhof near Losheim. Actual geometry NOT retrieved in this environment; no real course pack bundled. Strict validation, explicit mapping for Weiherhof's chosen two loops, documented omissions and attribution. No fabricated real layouts.
- Existing calibrated flight module unchanged. New course, importer, UI mock, and all previous automated regression tests pass. Android APK/device, real geometry and new carry data validation pending.

## 0.7.1-alpha — Real course acquisition (2026-11-24)
- Verified official Trier and Kikuoka per-hole pars; located OSM course boundary IDs for all three requested sites. Public OpenYardage inventory reports 18 Trier routes, one green missing, two Kikuoka routes and one Weiherhof route. Fresh source geometry could not be retrieved in this development environment.
- GitHub build-time acquisition via Gradle generated assets: fetch scoped Overpass data, preserve raw OSM provenance and attribution, validate routing/pars/green endpoints, compare Trier route lengths against published OSM-derived lengths, bundle only passing packs. No external workflow changes needed; no network required after installation. API/network and incomplete data failures are shown in Course tab and build logs; the fictional course stays playable. Weiherhof requires verified loop mapping before automatic bundling. No actual real course is in this source ZIP.
- For Trier only, permit at most one missing green, using the actual route endpoint and explicitly identified 10 m gameplay-only putting target. No geographic green polygon is fabricated. No terrain, aerial textures, full hazards or tee color verification yet.
- Source fixtures validate acquisition success and failure paths, never represent real courses. Flight and Bluetooth remain unchanged.
- Backlog only: career/championship mode with season points, recurring opponents, Beginner through Expert winning-score targets, achievements. Not implemented here.

## v0.7.2-alpha — Full-screen course play and offline Trier
- Bundled the validated 18-hole Trier pack from the user's supplied OSM XML. No network map fetch in the Android build. Source/derived database retained under ODbL with attribution. Kikuoka/Weiherhof still pending complete geometry. Hole 18 has an explicitly provisional putting target; tees/pins not independently surveyed.
- Full-hole map fits route by default, with integrated translucent bottom controls, pinch zoom, pan, +/- and full-hole reset. Tap to aim, gestures do not aim. Round details/scorecard and coach remain accessible; coach headline visible on map. Distinct bunker, water, woodland/trees and unknown ground legend and outlines.
- Mapped woodland/scrub, tree rows and individual trees are OB for landing only under custom lost-ball rules; +1 and replay. Tree rows buffered 3m each side; trees use mapped crown or provisional 2.5m radius. No aerial tree collisions or inference of official OB. Unmapped land is unknown. OSM relation coverage incomplete; preserve polygon interior cutouts.
- Added selected-course JSON export through Android document picker and browser fallback. Older imported Trier no longer shadows higher-revision bundled pack. Existing active rounds keep their original geometry; end/start a new round to use improved map. Backup imported course packs and history before update.
- Flight model and BLE protocol unchanged. Existing and new automated tests pass; Android build/device/touch interaction and map visual validation still pending.

## v0.7.5-alpha — Optional 3D range renderer
- Shared 2D/3D preference for Range, Random Numbers, Target Practice and Club Gapping. Defaults to 2D; settings persist locally.
- Self-contained WebGL 2 renderer with perspective cameras (tee, aerial, follow), Low/Medium/High geometry and pixel-density settings, timestamp-interpolated ball replay, club-colored trajectories, landing points, club dispersion circles after three shots, distance markers and current-target 3 m rings.
- Canvas perspective 3D fallback for unavailable WebGL; original 2D view remains accessible and is selected automatically if 3D drawing fails. No dependency downloads or external graphics assets. Three.js registry was unreachable; this alpha uses a small custom renderer instead.
- Expand the view to fill the app viewport; supports landscape rotation, camera cycle and replay controls, plus carry/offline/launch or target overlays. Exit expanded view for club selection and practice confirmation. Android manifest handles orientation/screen-size changes without ordinary Activity recreation; verify rotation and BLE on device.
- The range terrain is flat and procedural, with simple decorative trees; no 3D real course or terrain data in this release. Course mode remains 2D. No changes to the flight engine, shot scoring, Bluetooth Java source, course rules or calibration coefficients.
- Verified existing Java/JS/Python regression tests, new 3D geometry/interpolation/camera/fallback tests, mocked WebGL API calls, and browser UI tests using software 3D (WebGL blocked by environment). Actual GPU rendering, Android APK compilation, performance and touchscreen/device rotation not verified here.
