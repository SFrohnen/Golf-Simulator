# 0.3.0-alpha — Package 1: Accuracy and physics (2026-11-24)

- Replaced vacuum projectile carry formula with offline 3D RK4 aerodynamic model: gravity, speed-dependent drag, spin-dependent lift, spin decay and normalized spin axis. Generic coefficients are provisional, not a validated Garmin/Awesome Golf reproduction.
- New shot diagnostics: raw launch inputs in SI units, spin provenance, club metrics, face-to-path, modeled apex, time, landing angle/speed and lateral landing deviation. Temperature and altitude inputs, still air. Rollout deferred.
- Overhead line uses modeled trajectory, not an illustrative quadratic curve. Carry is horizontal radial distance to landing; separate downrange and signed offline are exported.
- Existing history is retained, tagged legacy in the latest-shot diagnostic, and excluded (with demo shots) from new-model live summary. CSV keeps full precision. Visible measurement numbers use one decimal place.
- Replay tool and reference comparison fixture for the eight observed shots. No raw shot CSV supplied; actual accuracy improvement cannot yet be quantified.
- No changes to BLE transport. New model unit tests and existing Java wire tests pass. Android APK build and hardware test still required.
- Known limitations: coefficients not fitted to measured ball-specific data, no wind or terrain; spin direction convention follows existing R10 decoder; missing protobuf scalar fields can still default to zero and must be audited. Carry, lateral distance and apex are modeled, not direct measured outputs. Club list, grouping circles, per-club averages and rollout remain Package 2; coaching and gameplay remain Package 3.
