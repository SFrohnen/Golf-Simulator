# v0.29.0-alpha — Continuous landscape and material refinement

- Hybrid range: add two continuous coarse landscape rings sharing the original terrain perimeter, extend scenery to approximately ±900 m sideways, with graded colors and gently rolling outer hills. Keep inner terrain, targets, irregular greens, ball and calibrated physics unchanged. The outer surround adds approximately 1,100–1,400 source triangles at the standard range extent.
- Medium and High use the same forest placement, foreground blade count and photographic tree-card/near-tree detail policy. Retain inexpensive volumetric trees for aerial views and when the photographic atlas is unavailable. High no longer adds denser forest rows; retain the v0.28 motion optimization and default Medium. No performance overlay or FPS measurement added.
- Refine dual-scale grass texture blending without extra texture samples, soften mowing stripes and fairway/rough colors, vary pond-bank colors with shared boundaries and vary shallow-water shading. Both ponds remain level. Original clubhouse adds canopy fascia and visible rafters; no new third-party models or downloads. Wind animation deferred to avoid continuous rendering overhead.
- Existing workflow remains compatible. Add Medium aerial screenshot for 21 total comparison images. Local tests exercise terrain seam continuity, finite geometry, stable relief/green clearance, common Medium/High tree layout and motion policy. Actual WebGL appearance and mobile performance remain pending CI/device checks.

# v0.28.0-alpha — Smooth play and landscape refinement

- Device feedback: Medium and Low reported smooth, High lagged during shots. Keep all three presets; Medium remains the default. In Hybrid range, active flight, rollout, landing hold and camera transitions temporarily cap High render pixel ratio at 1.5 (instead of 2), suspend the extra planar reflection pass and idle water animation, and defer shadow recentering. Restore selected quality and reflections at rest. Low retains its 1x cap and no planar reflections. The motion water shader uses its built-in sky approximation; distant shadows may temporarily be less detailed. Flight timing, shot data and scoring unchanged.
- Reuse regulation ball and contact-shadow mesh geometries across frames, remove duplicate tee material allocation, key static Hybrid range geometry by actual range dimensions rather than every target/shot extent, and defer ground/aerial foliage rebuilds until camera motion settles. These are cost reductions, not a measured Android FPS result.
- Hybrid range: cluster existing forest belts, vary crown widths and tree heights, soften fairway/rough palette and mowing stripes, brighten ambient fill, vary pond-side planting, join decorative side bays with continuous roof/apron. Existing terrain relief, green/bunker/pond meshes, playable mat and bundled carts remain intact. No new external dependencies. Full terrain-boundary redesign, actual soft-shadow filter upgrade, wind animation and professionally sourced clubhouse asset deferred.
- Browser smoke adds simulated shot-motion checks across all three quality levels and Low/Medium comparison screenshots (20 total). Local tests and browser syntax checks; actual WebGL and device performance require CI/device validation. Existing ZIP workflow unchanged.

# v0.27.0-alpha — Environmental Realism

- Hybrid range: eleven deterministic individually contoured greens and collars, clipped against the tessellated terrain triangles to follow the existing relief instead of creating overlapping independent discs. Green visual lie offsets use the same outline/profile. Target distances, terrain height function, ball dimensions and flight/scoring remain unchanged. More irregular fairway boundaries and varied rough tones.
- Three total practice positions (original playable mat plus two decorative covered side bays), practice ball baskets, seeded shrub clusters and taller rough at woodland edges, clustered pond-bank plantings. Local geometry only; no new external dependencies. Bundled cart and existing asset fallback/cache remain unchanged. No new professionally sourced clubhouse asset.
- Hybrid range lighting has a consistent more oblique sun direction in ground/aerial views, reduced ambient fill, tighter ground-level shadow coverage, varied tree colors and more volumetric near trees. Sky cloud shading refined. Wind animation deferred; no claim of photorealism or validated frame rate.
- Terrain clearance sampling, target profile, deterministic outline and triangle-budget checks pass in low/medium/high. 27 local suites passed (14 asset importer tests). CI adds two screenshots (green and practice bays) for 18 total. Actual browser rendering, Android APK compilation and device performance are unverified locally: npm registry DNS unavailable. Classic/Experimental scenery and course geometry unchanged by design; CI visual verification pending.
- Existing v0.24.1+ ZIP workflow remains compatible. Upload as r10-source.zip.

# v0.26.0-alpha — Environmental Quality & Bundled Facility Asset

- Hybrid range grass uses a less saturated palette, multi-scale variation, softer mowing stripes and green-specific surface detail. Green/collar heights and outlines remain the validated v0.25.0 geometry after experimental outline changes failed clearance tests.
- Continuous Catmull–Rom cart paths with shared cross-sections, edge shading and a revised parking apron.
- Original clubhouse geometry adds entrance canopy, masonry plinth and rear glazing. This is not a third-party architectural model.
- Original 10,796-triangle golf cart GLB shipped under `tools/bundled-assets/range-cart.glb`, with rounded bodywork, seats, tread, glazing, bags and clubs. Generator included; CI does not need trimesh. Cart source is local, validated by existing GLB importer, and reported in comparison artifact. Original procedural fallback retained.
- Optional facility material cache reuse when available; required core materials still use existing downloader/cache. Browser smoke test requires bundled cart to be packaged, loaded and rendered.
- Wider volumetric tree coverage around ground-level camera; aerial trees remain volumetric, with distant foliage cards in ground view. No new external tree or sky assets.
- Regulation-size dimpled ball, existing elevation profile, Classic range, real course geometry, and calibrated flight physics unchanged.
- Local checks: 27 test scripts/suites successful, including 14 asset importer unit tests; browser test syntax checked. WebGL rendering, GitHub APK and Android frame rate are not verified locally. External model download unavailable in local environment.

## v0.25.0-alpha — Natural terrain and golf ball detail

- Hybrid range: centreline target relief now spans approximately -4.94 to +5.40 m (10.34 m total). Broad local green rises/swales and irregular side slopes, fixed target positions and level tee/clubhouse area; both ponds retain their common .048 m water plane. Denser ground mesh and subdivided green/bunker rings, with the hidden flat underlay lowered to -15 m so it cannot clip the valleys. Tested source geometry approximately 29–35k triangles at the normal range extent. Elevation is visual only; no changes to carry, rollout or scoring.
- Non-Classic Three.js ball: retain physical 42.67 mm diameter, 336 dimple centres, new cached 1024 x 512 tangent-space normal map plus subtle dimple color detail, 64 x 40 sphere tessellation at Medium/High, and soft alpha-blended contact shadow. Detailed turf fiber material and rubber seams at the tee mat in Hybrid range only. Classic stays on its previous ball/scene rendering.
- Original clubhouse geometry gains gable trim, window subdivisions, exterior lights and terrace joints. Procedural cart fallback gains grille, arms, supports and seat detail. Existing optional imported cart and architectural materials retain their v0.24.1 validated downloader and fallback; no newly licensed external clubhouse model is included. Grass gains additional low-frequency color variation. No changes to real course geometry or core physics.
- Browser comparison adds clubhouse, cart and terrain close-ups and a rendered asset report (PNG; bundled, loaded and rendered states, plus material provenance and warnings). The existing v0.24.1 workflow already uploads these PNGs; no update needed. Local protocol, JS and Python tests passed, including mesh clearance, normal texture and contact shadow checks. Browser/WebGL and Android build/performance still require CI/device validation.

## v0.24.1 — asset download resilience

- Handle HTTP 403 and non-ZIP backup responses; keep successfully imported vegetation and use local vegetation for missing models.
- Optional HDRI falls back to built-in lighting. Photographic fairway, rough and sand remain required.
- Updated CI uses authenticated GitHub API requests and a checksummed reusable core asset cache. The workflow and source ZIP must both be updated once.
- Browser validation checks all bundled assets, permits explicitly declared missing optional assets, and keeps the existing terrain, reflection and ball tests.
- No physics or scenery geometry changes.

# v0.24.0-alpha – Rolling Range & Regulation Golf Ball

- Hybrid range: gently rolling metric relief, approximately -2.2 to +2.4 m at centreline targets; surrounding slopes add several metres of visual relief. Tee and clubhouse pad remain level, both pond planes remain coplanar. Visual-only elevation; calibrated range ballistics, shot distances and scoring remain on the original flat reference plane.
- Terrain-aware aim, camera, flags, target rings, flight display and labels; curved mowing stripes, increased terrain mesh resolution, more irregular pond-edge vegetation and improved aerial tree detail. Sampled clearance tests check actual triangulated green, bunker and water layers.
- Non-Classic Three.js range and course rendering: regulation 42.67 mm diameter sphere, 336 spherical dimple centres with a 512 x 256 bump map, white lit material and small contact shadow. Old fixed-size ball dots are suppressed while history/aim indicators and tracers remain. Classic and legacy fallback retain the previous presentation.
- Optional CC0 golf cart import from pinned tevy v1 GLB, bounded by file size, triangle count, embedded dependencies and model dimensions; procedural carts remain if the model cannot be fetched or loaded. Optional ambientCG stone, timber and roof surface detail with bounded luminance blending; original clubhouse geometry retained. All optional data has an offline fallback and is separate from required core asset readiness.
- CI captures a close-up golf ball screenshot and reports optional facility asset status; no workflow changes required. Local tests cannot validate the downloaded asset appearance, actual WebGL or Android frame rate because npm/asset hosts are inaccessible.

## v0.23.0-alpha — Rendering quality and realism (range-only)

- Replace overlapping green, bunker and shoreline discs with adjoining annular meshes and contoured decorative lips. Improve depth precision with a range-only adaptive near plane (1–42 m); lift target/aim overlays above the decorative surfaces. The earlier flat hitting plane and scoring remain unchanged. This addresses likely z-fighting; actual aerial screenshots are required to confirm the defect is eliminated.
- Water uses multiple directional ripple frequencies, distance filtering, less reflection distortion, Fresnel blending and a shallow-water color gradient matching each irregular pond perimeter. Reflection targets retain the previous 384/768 px limits. Reset reflection cache on Low mode; restore reflections when quality is raised. Add grassy banks, scattered rocks and reeds.
- Reduce terrain pattern repetition through noise-weighted two-direction sampling and derivative-based distance filtering. Disable fine bump detail in aerial view on range-only material clones. Keep Classic and real course rendering separate. Two benches, cart grille, and clubhouse gutters/downpipes added; existing procedural models retained. High geometry budget bounded at 16,000 source triangles for the tested range extent. No new external asset sources.
- All 27 local JS/Python/Java test suites pass; new annular boundary and depth-precision checks. CI browser test additionally checks adaptive camera near plane and continues to generate 11 screenshots. Real shader execution, APK compilation and Android performance still require CI/device validation (npm registry DNS unavailable here). Existing workflow unchanged.

## v0.22.0-alpha — Photorealistic details (range-only)

- Hybrid practice facility: two coplanar ponds now share a bounded planar reflection render target with mirrored camera and clipping plane. Medium uses up to 384 px and High up to 768 px; Low uses a shaded fallback. Fresnel-style reflectance, procedural ripples and glints, shoreline gravel/grass and reeds. High animates idle water at up to 10 scene renders per second; the reflection is cached for stationary camera/geometry. Existing water/bunkers remain decorative, with no changes to physics or scoring.
- Aerial range camera fits the complete target area; landscape view frames the long axis left-to-right, portrait retains downrange orientation. More outer terrain and irregular tree groups; world-space dual-scale grass sampling and macro variation in Hybrid reduce texture repetition. Classic and real-course scenery paths are unchanged.
- Original procedural clubhouse and carts refined with separate stone, roof, timber, path, metal, window and windscreen materials, projected texture coordinates, terrace furniture, planters, steps, cart bags and club shafts, steering wheel, lights, bumpers and connecting paths. New textures are procedural offline details, not imported photographic building/cart assets.
- Existing Ubuntu 24.04 workflow remains compatible; upload as r10-source.zip. All 27 local suites passed. CI browser test now checks the reflection pass, facility material presence and course isolation, and captures an eleventh screenshot (pond close-up). npm registry DNS is unavailable locally; actual shader/render quality, APK compilation, and Android frame rate remain pending CI/device validation.

## v0.21.0-alpha — Natural practice facility

- Hybrid range now has eleven fixed, non-uniform target stations at 42, 65, 97, 128, 150, 183, 212, 248, 271, 303 and 337 m. The target menu and range catalogue are regression-checked; the default 150 m station remains. Green outlines vary in offset while the flags remain on the centerline so existing target-miss scoring stays correct. Arbitrary Scout targets remain available. Classic and Experimental share the updated target menu but retain their existing scenery.
- Eight independently arranged, irregular decorative sand pockets; two textured ponds with irregular banks; two original modeled golf carts (wheels, chassis, seats, roof, supports, windshield) and a clubhouse (pitched roof, windows, entry, veranda, chimney). Props are offline original low-poly geometry and are intentionally replaceable by licensed higher-detail models later. No new external asset dependency or claim of photorealistic imported cart/building models.
- Range-only camera-dependent fog, expanded aerial framing, volumetric low-detail trees in elevated views, fewer per-cell ground color jumps, shorter/lighter foreground grass, adjusted cloud definition and aerial shadow framing. No changes to the existing range flight/rollout reference plane; water and bunkers are decorative, not new scoring hazards. Existing photographic grass/sand and foliage textures are retained. Real course scenery and calibrated flight math remain unchanged.
- Existing ZIP-based Ubuntu 24.04 workflow remains compatible; upload as r10-source.zip. CI browser checks assert water/prop meshes, low aerial fog and forest mode, and capture ten screenshots including the new facility close view. Local 27 test suites passed; npm registry DNS is unavailable here, so actual WebGL appearance, screenshot thresholds, APK compilation and Android frame rate require CI/device verification.

## v0.20.0-alpha — Natural practice landscape

- Hybrid Driving Range and range-based practice: seven staggered target greens (50–350 m), sand pockets with collars, two physical numbered distance boards per station, variable fairway edges and mowing bands, graded decorative outer rough banks, dense irregular multi-row forest belts and short foreground grass blades. The active target retains its exact position, rings and flag. The hitting reference plane is unchanged; decorative bunkers/banks are not new physical hazards or collision terrain.
- Uses the existing bundled alpha-cutout oak/pine atlas for mid/distant range trees and existing solid 3D models nearby. No new photographic tree model downloads or new licenses; no changes to mapped course scenery. The atlas is image-based foliage, not a high-poly 3D tree asset. The existing photographic materials are more visible through bounded neutral detail and low bump amplitudes, preserving green colors and the dark tee mat. Range-only sunlight/exposure are slightly reduced.
- Classic restores v0.18 geometry, materials, lighting and sky; Experimental retains the v0.19.2 experiment. Hybrid real-course rendering remains as in v0.19.2. The previous terrain rules, physics, course elevation, scoring and Garmin R10 connectivity are unchanged. Sculpted physical bunker geometry, advanced water reflections and newly sourced photorealistic foliage models are deferred.
- Existing ZIP-based Ubuntu 24.04 workflow remains compatible; upload as r10-source.zip. CI adds checks for the actual range atlas/material path and course isolation, plus a ninth screenshot (Hybrid range aerial). The local 27 test suites passed; npm registry access is unavailable here, so actual browser rendering, screenshot thresholds, Android build and device performance still require verification in CI/on-device.

## v0.19.2-alpha — Rendering repair

- Classic restores v0.18 surface textures, terrain RGB, trees, sky and lighting. Hybrid (default) keeps those colors and blends bounded photographic luminance detail into the existing surface textures; tee mat stays untouched, imported roughness/normal maps are not applied. Experimental enables imported vegetation with width/height normalization and low-strength HDRI environment lighting (never the HDRI landscape background). Presets persist and are shared across range, practice and course.
- Range/practice full-screen maps request immersive Android system bars; Back exits the map. On-device behavior requires verification.
- CI captures Classic, Hybrid and Experimental scenes plus the v0.18 baseline, and tests material restoration and coarse pixel difference bounds. The Trier screenshot fixture now uses the actual elevation-enabled embedded pack (10 m grid), not the old flat JSON.
- Existing v0.19+ Ubuntu 24.04 workflow remains compatible; replace only r10-source.zip. The source pack has placeholders for the runtime and imported assets, generated during CI. All local regression suites pass; actual asset downloads, browser screenshots, visual thresholds and Android build/device checks are pending CI.

## v0.19.1 — Mobile vegetation build hotfix

Replaces the oversized Poly Haven vegetation with bounded CC0 game-ready GLBs from Quaternius (Kenney Nature Kit fallback). These assets are stylized, not photorealistic. Retains ambientCG photographic terrain and Poly Haven HDRI. Validates geometry/size and logs selected source; existing v0.19+ workflow remains compatible. Provider downloads and device performance still require CI/device validation.

# v0.19.0-alpha — Realistic asset integration

- Adds an automated build-time CC0 asset importer: ambientCG Grass005, Grass004 and Ground052 photographic 1K JPG albedo, OpenGL normal and roughness maps; Poly Haven Pine Tree 01, Tree Small 02, Grass Bermuda 01 glTF models and Limpopo Golf Course 1K HDRI. The source ZIP intentionally contains a placeholder; GitHub downloads the real assets during `npm run build:three`. A failed download or missing map fails the build. Source URLs, SHA-256 digests and license credits are included in the generated asset pack. Provider downloads and the real rendering test were not executable locally.
- Imported model geometry uses instancing, height normalization, mapped tree locations, quality-dependent triangle/count budgets and nearest-tree selection. Other trees retain the v0.18 procedural geometry. Imported grass tufts are sampled on playable turf/rough in front of the camera when rebuilding the scene; no change to collision or shot physics. Imported surface maps retain approximate mowing-stripe contrast, and HDRI provides photographic sky and environmental light. The water material uses environmental highlights, not planar reflections. No new wind animation, independent Ultra quality tier, geometry decimation or true bunker excavation.
- Asset status distinguishes Real assets, Loading assets, Partial asset fallback and Procedural assets. Existing legacy renderer fallback remains. Offline at runtime; no cloud connection needed to display the downloaded assets.
- Use the normal ZIP upload on the existing Three.js/Ubuntu 24.04 workflow. Existing `npm run build:three` automatically performs the new importer and its unit tests. Optional `android-apk-v019.yml` also checks the real asset bundle inside the APK and uploads v0.18/v0.19 rendered comparison screenshots. Browser test requires actual maps, all three models, HDRI and imported geometry in the scene; screenshot appearance and mobile performance remain unverified.
- 27 local suites passed (22 JavaScript, 4 Python including new mocked importer tests, 1 Java protocol runner). Android compilation, real asset download, real WebGL browser test, and on-device performance remain pending CI/device validation.

# v0.18.0-alpha — Immersive Three.js graphics

- Eight original 512×512 tileable offline WebP materials: rough, fairway, green, tee, sand, bark, crown and water. Surface classes and texture scales are separated; sand, bark, canopy and water gain bump detail. No third-party photographic assets were downloaded. The generator is included under `tools/make-visual-assets.py`.
- Replace Three.js crossed-tree cards with instanced volumetric broadleaf crowns, trunks and branches, and layered conifers. Distribute woodland trees across mapped patches with a quality-dependent budget, reject new woodland trunks in mapped playable surfaces. These are representative visuals, not measured individual trees. Gameplay canopy/OB rules remain unchanged.
- World-space sky shader with clouds, sun and haze; directional and hemisphere lighting, tone mapping, and soft shadows at medium/high quality. Low disables shadows and simplifies trees. More natural tee camera (1.85 m), smoother terrain normals and finer high-quality base mesh. No new elevation source or physical bunker excavation; water is textured/specular, not true reflective water. Preserve existing HUD, flight, shot recording, course maps, scoring and BLE.
- Existing `r10-source.zip` workflow still works if already updated for Three.js and pinned to Ubuntu 24.04. The optional external `android-apk-v018.yml` adds a graphics screenshot artifact. The bundled workflow is for a repository containing the expanded source.
- Existing 26 local suites passed (22 JavaScript, 3 Python, 1 Java protocol runner). The pinned Three.js dependency and Android build were unavailable locally. GitHub CI performs the real WebGL test and generates new and v0.17 screenshots (range and Trier hole 1) in `visual-previews/`. Visual comparison, phone FPS and APK verification are pending CI/device execution.

# v0.16.0-alpha — Gameplay visual refresh

- Replaced the range and virtual-course full-screen text readouts with a scrollable graphical instrument strip, large values, pictograms and unit labels. Playing and Technical presets can be selected independently and are saved on the device. Missing values show a dash, not zero. Carry, total, target miss and shot shape remain modeled rather than directly measured.
- Range: slimmer controls, target/club plate, real connection status, larger selected-club landing inset and only the selected club/swing-length dispersion circles in the 3D range. Advanced controls in Options. Dashboard remains accessible from Menu.
- Course: separate pin distance, strokes, completed-hole score relative to par, last-shot metrics, landing surface/penalties and compact caddie recommendation. Scout and landing buttons remain available. Existing course maps, canopy, DEM, putting, multiplayer and career modes retained.
- Automatic camera starts at ball/tee, follows the existing animated trajectory, briefly holds the finish, then returns to the player view. Existing manual cameras remain available. Latest range tracer gold, up to four older traces muted; two human course players get distinct tracer colors. More vivid turf, mowing stripes and slightly denser mapped woodland rendering, using existing offline textures and terrain geometry. No change to the flight solver, rollout model, BLE protocol or scoring rules.
- Added HUD/automatic-camera tests and loaded HUD in mocked UI regression tests. No real Android compilation, physical R10 or on-device visual verification in this environment; browser navigation was blocked. Source-only alpha; GitHub Actions builds the APK.
- Remaining polish: arbitrary per-metric customization (current version offers two presets), advanced commercial-quality terrain assets/lighting, optional new impact sounds. Existing voice coaching retained.

# v0.15.0-alpha — Reliable play and smart course planning

- Automatic live R10 capture on eligible human course turns; scout target fallback to the 2D map.
- Immediate range carry, total, lateral and target feedback; default landing pattern and hazard-aware club suggestions.
- 186 additional aerial-derived woodland polygons for simulator OB; not official surveyed OB.
- Manual or requested live course temperature, terrain-aware predictions, outdoor zoom and landing view, round setup and scoring.
- Independent completed round history and provisional handicap estimates; manual CSV/paste import of real score differentials. No direct TheGrint API integration.
- JavaScript, protocol and terrain regression tests passed. Android build and live hardware validation pending; this release is source only.

# v0.14.0-alpha — Scout targets and outdoor round setup

Tap the ground in Course scout view to change aim. The Range inset shows landing points for the selected club and swing length, with 50% and 80% dispersion circles from three eligible live shots. New virtual rounds use extra woodland outlines traced from the bundled aerials as simulator OB.

On the Course starts with course, tee and 9/18-hole selection. Choose either nine, move between holes, check the selected tee’s scorecard distance, or mark the actual tee on the aerial. Fairway measurements show the room left and right across the intended shot line at a mapped target or logged finish.

# v0.13.0-alpha — Outdoor aerial planner

Start in Play & Practice or On the Course. The outdoor planner ships with georeferenced aerial photographs for all bundled courses, foreground GPS refresh, one-tap targets and three distance readouts. Outdoor shot logs appear in History. Bag profiles and saved rounds use the existing device storage.

# v0.12.0-alpha — My Bag and wedge distances

My Bag lists live range mean carries and adjacent full-swing gaps. Pitching Wedge and 52°, 56° and 60° support full, three-quarter and half swings. Range, Practice, Course and My Caddie share the bag profiles. Demo shots, marked mishits and practice sessions are excluded from these averages. Video controls are opt-in under Settings. Existing gapping sessions can finish; new gapping sessions are replaced by the bag view.

# v0.11.1-alpha — Kikuoka and Trier approach caddie

My Caddie now covers all 18 holes at Kikuoka and Trier alongside the Weiherhof routings. Each course uses its bundled terrain, map and geographic origin.

# v0.11.0-alpha — Weiherhof approach caddie

Choose the A/B, A/C or B/C routing in My Caddie. Use a one-time GPS fix or tap the map at your ball. Model up to 30 recent live range landings per club against mapped surfaces, inspect a safer aim or set your own, then mark the finish to log outdoor total displacement separately from modeled carry.

# v0.10.0-alpha — Personal bests & progress

The clubhouse now shows per-club carry, directional accuracy, session history, longest carry and best average offline across sessions with five or more readings. Live and demo, Range and Practice each have separate views.

# v0.9.9-alpha — Swing video

Range and live R10 Practice can record a silent face-on swing clip. Tap Record swing, frame the shot, then tap Record. The first accepted live shot finishes the clip. Swing replay shows the paired shot readings. Previously paired swings also appear in History.

# v0.9.8-alpha — Smart Practice Coach

Start a five-shot drill from the Range summary. Practice shows the exercise and a comparison with recent shots from the same club and source. Short histories start with a baseline drill. The default voice feedback is now one cue. Explicit mute preferences carry forward.

# v0.9.7-alpha — Voice coaching

Enable Voice coaching in the clubhouse for spoken feedback on Range, Practice and Course shots. Brief feedback covers the shot result and one cue. Detailed feedback adds a drill instruction.

# v0.9.6-alpha — Fixed-distance auto-putting

The selected ball’s resting distance on the green determines automatic putts: up to 2 m adds one, over 2 m through 15 m adds two, and over 15 m adds three. Hole-outs add zero. Manual putting remains available. Saved scores are preserved and future shots in resumed rounds use these rules.

# v0.9.5-alpha — Aim and landing controls

Aim distance and elevation are anchored to the selected point. Fairway clearance uses the mapped geometry along a perpendicular to the shot. Tap the corner hole map to scout the target before firing or inspect the last landing. Drag to explore while scouting, swipe horizontally in shot view to turn the aim, or tap the terrain to select a new target. The pin stays marked on the hole map. Demo uses one shot button; live rounds retain explicit arming. Range practice includes a target picker and a landing inset.

# v0.9.4-alpha — Range and course graphics

Offline oak, pine and turf textures, rough-edge grass, revised tee mat and floating controls. The range opens in 3D on fresh installs and honours saved camera and view preferences. Course planting follows the existing mapped vegetation.

# v0.9.3-alpha — Kikuoka Country Club

Kikuoka in Canach is available in casual and career rounds. The offline pack covers 18 holes, mapped landing surfaces and an elevation grid. Fixed simulator tees, green centres and aerially interpreted surface edges are approximate.

# v0.9.2-alpha — Golfpark Weiherhof

All three nine-hole loops in Wadern-Nunkirchen are available offline as A/B, A/C and B/C. Each pack includes a 30 m height grid. A2, A3, A5, A7, B6, C6 and C9 use provisional 10 m putting targets.

# v0.9.1-alpha — Ball and landing inspection

On Course, Ball opens a close terrain-level inspection of the current lie. Landing frames the last shot's first contact and finish on the current hole (or its impact point after a tree strike). Drag to move over the ground, pinch or use + / − to change distance. Show score returns to hole review. Follow ball tracks through rollout and holds the endpoint. Range and Practice also have Ball and Landing controls in the play map. The app's Android launcher, startup artwork and Clubhouse button use the custom gold golfer icon.

# v0.9.0-alpha — Clubhouse and hole results

Clubhouse opens with Course, Tour career, Driving range and Practice games. A saved course session resumes directly. Select a course by its opening-hole illustration, then choose round length, shot source and scoring options. The score card appears over the course once the finishing trajectory completes. It shows each team's hole result, strokes, recorded putts when available, and running score relative to par. Next tee advances the round.

Clubhouse photography: https://images.unsplash.com/photo-1535131749006-b7f58c99034b (bundled for offline play). Course previews use each installed pack's geometry.

# v0.8.5-alpha — Fullscreen round sessions

Casual and Career rounds keep the Android game view open through Green, replay, hole transitions and the final scorecard. Android Back dismisses an open replay, details or exit prompt. Reopening the app restores the saved round. To leave, choose End round and confirm.

# v0.8.4-alpha — Full-screen play and handicap putting

Course, Range and active Practice sessions open to the play map. The on-map controls include zoom, club, mode-appropriate shot controls and menu. On Course use Green for a top-down inspection, Full hole to reset the frame, and Next tee after reviewing the finish. Pin distance and elevation change are screen-fixed. The result reports carry, rollout, straight-line shot distance, elevation change, remaining distance and awarded automatic putts. Imported courses without heights show elevation unavailable. Flat training ranges report zero elevation change.

In Course setup choose Auto-putts and Scratch, 10 HCP (default), 20 HCP or 30+ HCP. Expand Auto-putt probabilities for the complete table. Distance is measured at rest. The selected ball draws once, scoring one, two or three putts. A simulated hole-out requires no putts. Unfinished rounds from older versions use the HCP 10 default for future auto-putts.

The HCP 10 one- and three-putt probabilities use the HCP 10 comparison columns in Shot Scope's Pro Data Report Example, table “Where putts are won and lost”: https://shotscope.com/wp-content/uploads/2026/11/The-Pro-Data-Report-Example.pdf . Two-putt probability is the remainder under the three-putt cap. For the other handicaps the fixed bins are simulator estimates guided by amateur make rates (https://mygolfspy.com/news-opinion/putting-make-percentage-by-handicap-full-chart-are-you-above-or-below-average/) and Shot Scope's aggregate putts per green (How to Improve With Data, figure 22). The 30+ profile extrapolates beyond the published 25-handicap benchmarks. Short-distance make rates from all attempts can differ from first-putt rates.

# v0.8.3-alpha — Terrain-aware course rollout

Full shots and chips in Course mode now use a modeled bounce and rollout. Carry marks first contact. The shot result shows rollout distance and the finishing lie. The 2D map marks the ground track in white. Use Follow ball in 3D or Round details → Replay last shot to watch through the finish, even after the hole changes.

The existing range rollout estimate provides the flat fairway baseline. Course mode adjusts for surface resistance and local terrain gradient. Greens run faster, rough slows the ball, and unmapped ground uses a default resistance. Bunker entry stops the ball; water and OB trigger the existing replay penalty. Putting begins when the ball finishes on a green or approximate target. The bounce and turf parameters are estimates. The Trier DEM resolves broad slopes at 10 m spacing. Recorded rounds keep previous placements; subsequent shots use the updated model.

# v0.8.2-alpha — Offline tour career

In Course, choose Career tournament, select a course, round length, difficulty and shot source, then start. One human plays normal stroke play with the existing putting options and coach. Seven named rivals post simulated scores at round completion. All bundled and imported courses can host events. Each season has three regular tournaments and a double-points Championship Final. The highest season points total wins. Ties share rank and points. Rivals target approximately +5, even par, −4 and −9 respectively over 18 holes at Easy, Medium, Hard and Expert, with event variation and proportional targets on shorter rounds.

Progress is stored on this device separately for each difficulty and for Demo and live R10. Incomplete events can resume after reopening the app. Ending an incomplete event forfeits its progress. Achievements recognize a first finish, a birdie or better, a tournament win and a season title. Trier elevation remains bundled offline.

# v0.7.8-alpha — Terrain-ready course simulation

**Real elevation raster not bundled yet.** The development environment could not resolve the elevation-data host. The existing Trier geometry remains bundled, and its flat fallback is labeled. On a fresh CI build, `prepareTrierTerrain` attempts to download the public Mapzen/Tilezen Skadi N49E006 HGT tile from AWS and samples its actual elevations, approximately 30–90 m source spacing depending on tile format. This is a coarse DEM, not survey-grade DGM1; elevations may include surface effects. Success bundles the compact terrain-aware course; failure leaves a playable flat map and reports the error in the Course setup. Build-time retrieval has not been verified on GitHub. No internet required when playing.

The app supports official RLP DGM1 GeoTIFF inputs, from https://geoshop.rlp.de/opendata-dgm1.html (DL-DE/BY-2.0). Download coverage of approximately 6.802–6.834 E, 49.832–49.855 N (WGS84); in ETRS89/UTM32, safely cover E 341900–344300, N 5522200–5524900 m. All mapped features plus 450 m buffer included. For high-resolution import run `python tools/prepare_terrain.py --tif tile1.tif tile2.tif ... --data-year 2026 --out trier-terrain.json` with rasterio, numpy and pyproj installed; specify the actual data retrieval year. To bundle instead, use `--bundle --out courses/bundled/trier-terrain.json` as well. The converter samples at 10 m for mobile performance, validates coverage and size, and appends the source attribution. For direct coarse import, download https://s3.amazonaws.com/elevation-tiles-prod/skadi/N49/N49E006.hgt.gz and run `python tools/prepare_terrain.py --hgt N49E006.hgt.gz --out trier-terrain.json`. Import the resulting course JSON using the app. If network retrieval is unsuccessful, upload downloaded DEM files in ChatGPT for conversion. No synthetic terrain is shipped as Trier.

Terrain-aware rendering uses tessellated base/surface geometry with bilinear sampling, elevated vegetation and pins, ground ray picking and camera placement. Surface meshes remain approximate, especially on coarse DEM and software renderer. Course shots integrate until the trajectory intersects the terrain, allowing both longer downhill shots and shorter uphill shots. Collision heights are relative to local terrain; tree heights are still estimated. Bot flights approximate parabolas. Course scoring still uses landing position only; no sloped-ground rollout, exact water levels, or DEM-based tree heights. Range and practice retain the same aerodynamic coefficients and flat flight behavior. No CSV recalculation needed. Elevation difference to pin displayed during the round. Start a **new round** to use the upgraded course pack.

Tests: all existing JS/Java/Python tests passed, plus synthetic terrain interpolation, uphill/downhill, ground picking, tree collision, and HGT import tests. Tests use synthetic fixtures, not real Trier elevation. Android build, live DEM retrieval, actual terrain visual accuracy and device performance remain pending.

## v0.7.7-alpha — 3D course visualization

- Optional 3D course view (default for new installs), 2D tactical map retained; use the same mapped course polygons as the round engine.
- All 18 Trier holes rendered with mapped fairways, greens, bunkers, water, woodland and trees. Procedural tree positions within wooded polygons and approximate canopy dimensions; flat terrain, no aerial textures. Missing hole 10 bunker and hole 18 green remain unverified.
- Ball-position, aerial and follow-ball cameras, tap ground to aim, pin targeting, replay of last human shot on current hole. Existing tree impact clips animated flight at collision. Bot turns are still resolved immediately; final shot advancing a hole is not replayed on the next hole.
- Reuses WebGL2/software renderer and graphics quality settings. Course scoring and carry-only placement unchanged.
- Automated geometry tests for all 18 holes, exact polygon cutouts, projection, impact truncation and all previous regression suites passed. Chromium software-rendered course/aim/replay smoke test passed; Android/GPU performance remains to be tested.

# v0.7.6-alpha — 3D visual upgrade

- Shared procedural sky image with soft cloud field and haze; no external assets or online services. Reworked mown fairway, rough, tee surface, decorative target greens and flags, distance marker boards and layered distant hills (scenery only, flat playable terrain).
- Varied layered tree crowns, tapered trunks, sunlit facet colors and approximate ground shadow footprints. GPU procedural grass shading and a subtle texture overlay for the Canvas fallback. Low/Medium/High control vegetation mesh detail and pixel density as before.
- Camera-facing colored tracer, landing and final-rest rings, dashed estimated rollout and visual-only bounce using existing rollout endpoint. Smooth 360 ms camera transitions, full-screen total and shape overlays. Practice targets and 3 m rings remain available. No changes to carry, rollout, scoring, real course rules, BLE or coaching engines.
- All existing JS/Java/Python regressions and new rollout/camera/scene tests pass. Chromium software fallback screenshots verified in actual UI. GPU shader execution blocked in this environment; actual Android build, visual quality and performance remain to be checked. Stylized geometry, not photorealistic assets; realistic terrain and 3D real courses still pending.

# v0.7.4-alpha — Consolidated beta fixes

- Matched 15 reference shots from the supplied 36-row CSV using shot ID, carry, ball speed and launch. The five PW, five 7I and five Driver reference shots were identified independently of the app's mislabeled club column. New smooth speed/spin-regime corrections to drag and lift use 15 beta shots plus seven older confirmed reference shots. New model `aero-0.7.4`. Fit-set MAE: carry 5.04→1.53 m, apex 2.73→1.26 m, lateral comparison 2.22→1.67 m. Maximum carry error 4.98 m. Earlier seven reference MAE rises from 2.33 to 3.14 m (max 6.90 m); explicitly retained regression bounds 3.5/7.5 m. New results are calibration, NOT independent validation. Reference lateral definitions may differ.
- Bounded medium-surface rollout model using landing speed, landing angle and spin, fit to reference simulator rollout: 10.16→0.63 m MAE; total 13.74→1.57 m. Soft/firm modifiers remain provisional. No claim of actual turf accuracy. Course gameplay still carry-only.
- BLE: up to five backoff reconnect attempts after unplanned disconnect, connection/initialization watchdog and write-failure recovery, cancel on manual disconnect, keep screen awake, short-term duplicate suppression across reconnects, longer exportable diagnostics. Device testing required; cannot recover physical shots hit while disconnected. No change to wire protocol.
- Practice: Random Numbers still confirms each target; Target Practice confirms once; Club Gapping auto-selects shortest-to-longest, automatically advances, optional native tone cue and on-screen club change, manual remaining-club override. Shared scaled Range canvas for all practice modes, true origin, latest trajectory, landing points, club dispersion circles from three shots and moving target. Cumulative 3 m accuracy bands replace score as primary display.
- Coach: practice feedback on demand during a session and technical summary at completion; range coaching collapsed by default; uses numerical delivery/launch/spin, target and historical evidence, actionable check and measurable target, with uncertainty. Existing course integration retained. Mishit tagging, exclusion from gapping means and optional exclusion from analytics; CSV preserves tag. Spin axis L/R/C and neutral-zero formatting; reduced metric wrapping.
- Tests: all JS regression suites, protocol Java tests, Python course fixtures, new beta fit regression and mocked UI flows passed. Native Android APK compilation, audio and Bluetooth recovery not tested here. No new course geometry. Keep CSV backups and run History → Recalculate history after update.

# v0.7.3-alpha — Airborne tree collisions

- Human R10 and demo flight trajectories are checked against mapped tree, tree-row and woodland volumes before landing; earliest collision stops the plotted flight. Bot trajectories use approximate arcs and the same collision rules.
- Estimated canopy height bands: single tree 3–12 m, tree row 2.5–14 m, woodland 2–18 m. Single tree trunk radius approximated at 0.35 m. Flat terrain only; these are not surveyed heights. A shot can fly below, around or above a canopy; landing inside a tree area or striking a tree results in one penalty and replay per house rules. No change to calibrated range physics.
- Trier hole 10 audit: original OSM XML has no mapped fairway bunker near the central tree; only four nearby green-side bunker polygons plus one distant bunker from a neighboring area in the pack. The club Birdiebook depicts fairway bunkers, but exact geometry is unverified. Flagged in round details; no invented polygon. Water features remain unchanged (none mapped on hole 10).
- Tests: canopy, trunk, clearance, polygon cutouts, trace truncation, penalty and scramble selection; existing JS and Java protocol regressions pass. Android device testing pending.

# v0.4.2-alpha — Swing delivery analysis

- Club path, clubface angle, face-to-path and attack angle prominently displayed above flight diagnostics; handedness-aware labels, signed angles and missing-value handling.
- Face-to-path = face minus path, with a qualitative curvature tendency and a warning when delivery and modeled curvature disagree. Ball-flight classification remains based on reported launch and modeled curvature; do not double-count impact effects in flight physics.
- Session and historical club means include path, face and face-to-path; demo includes synthetic delivery values. Carry engine and BLE unchanged.

# v0.4.1-alpha — Live session usability

- Range now has a persistent active practice session and a New session button (does not delete history). Live club-colored dispersion circles appear after three valid shots per club, with auto-scaled plot and separate real/demo data. Analytics remains available across history.
- Correct any shot’s club directly in Range or History; quick last-shot selector. Club averages and circles update immediately. CSV preserves session IDs and historical club corrections. Older imports without session IDs remain in History rather than mixing into a new session.
- Latest shot shows estimated shape (push/pull/straight with fade/slice/draw/hook), handedness, bold carry/offline/launch, and total, peak, spin, spin axis, ball speed, club head speed and smash factor above flight diagnostics. Shape uses initial heading and modeled bearing change; heuristic 1.5° straight and 5° severe curvature thresholds, not a measured classification.
- Offline is shown as L/R/C; mean absolute offline plus counts of left, right and center for the current club and all-history club analytics. Missing values excluded. Smash factor = ball speed / club speed; missing/zero club speed omitted.
- Removed standalone rollout display and finish dispersion; total distance still uses the previous provisional ground model because total remains requested.
- Carry flight engine unchanged. Protocol, flight, history, reference, club/session/shape and mocked-DOM UI tests pass. Browser smoke test timed out in this environment; Android build and actual device visual validation pending.

# v0.4.0-alpha — Club analytics

- Added exact 12-club selection with stable colors, selected-club persistence, and manual history correction with original club retained.
- New Analytics tab: equal-scale carry/finish dispersion, circles enclosing each club's points, individual club toggles, real-only default and optional demo shots.
- Added per-club carry, rollout, total, absolute lateral deviation, spin and peak height means, with valid sample counts.
- Provisional flat-ground rollout/finish estimates with soft, medium and firm presets; no changes to calibrated flight engine.
- Added rollout/total/peak/dispersion metrics to Range and directional club path/face-to-path labels (right-handed convention). Decimal displays use one fractional digit.
- CSV import/export preserves club confirmation and original club; stable deduplication across corrected clubs. Earlier labels require confirmation before inclusion in analytics.
- Protocol, flight, history, calibration regression, and new club analytics tests pass. Original backup replay: all 33 real shots yield rollout estimates. Android build and on-device UI/accuracy validation pending.

# 0.3.0-alpha — Package 1: Accuracy and physics (2026-11-24)

- Replaced vacuum projectile carry formula with offline 3D RK4 aerodynamic model: gravity, speed-dependent drag, spin-dependent lift, spin decay and normalized spin axis. Generic coefficients are provisional, not a validated Garmin/Awesome Golf reproduction.
- New shot diagnostics: raw launch inputs in SI units, spin provenance, club metrics, face-to-path, modeled apex, time, landing angle/speed and lateral landing deviation. Temperature and altitude inputs, still air. Rollout deferred.
- Overhead line uses modeled trajectory, not an illustrative quadratic curve. Carry is horizontal radial distance to landing; separate downrange and signed offline are exported.
- Existing history is retained, tagged legacy in the latest-shot diagnostic, and excluded (with demo shots) from new-model live summary. CSV keeps full precision. Visible measurement numbers use one decimal place.
- Replay tool and reference comparison fixture for the eight observed shots. No raw shot CSV supplied; actual accuracy improvement cannot yet be quantified.
- No changes to BLE transport. New model unit tests and existing Java wire tests pass. Android APK build and hardware test still required.
- Known limitations: coefficients not fitted to measured ball-specific data, no wind or terrain; spin direction convention follows existing R10 decoder; missing protobuf scalar fields can still default to zero and must be audited. Carry, lateral distance and apex are modeled, not direct measured outputs. Club list, grouping circles, per-club averages and rollout remain Package 2; coaching and gameplay remain Package 3.

## v0.3.1-alpha — CSV recovery
- Native Android file picker and offline import of v0.2/v0.3 CSV exports.
- Merge and deduplicate by timestamp, shot ID, club and source; preserve timestamps and existing history.
- Recalculate legacy shots with complete launch inputs using current atmosphere settings, preserving previousCarry; otherwise retain original carry.
- Reject malformed CSV and imports exceeding the existing 1,000-shot history limit. Import tests included.
- Android APK build and physical device import still require verification.

## v0.3.2-alpha — Physics optimization (2026-11-24)
- Default atmosphere 20°C / 200 m to match Awesome Golf.
- Bounded coefficient grid search: base drag unchanged 0.22; spin drag coefficient 0.12 → 0.22; lift scale 1.5 → 1.95. Seven confirmed pairs used; probable pair excluded. No per-club or distance correction.
- At matching settings: confirmed MAE 10.15 → 2.33 m; max 17.92 → 5.34 m; bias +1.76 → −2.01 m. Leave-one-out selects identical coefficients on all seven folds; MAE 2.33 m, not independent validation. All spin inputs estimated, reference is not ground truth.
- History: explicit Recalculate history action updates real R10 shots in current atmosphere; original carry, prior model carry, raw data, timestamps and shot IDs preserved. Invalid and demo shots skipped. History rows show shot ID and original carry.
- CSV import/export remains supported, with prior model columns. Backup before installing; import then recalculate if needed. Native WebChromeClient enables confirmation dialogs.
- Calibration fixtures and reproducible calibration/replay scripts added. BLE transport unchanged. No hardware or APK build validation locally. Club inventory, rollout and analytics remain separate follow-up work.

## v0.5.0-alpha — Structured practice (2026-11-24)
- Practice tab with Random Numbers, Target Practice, and guided Club Gapping for a selectable subset of the existing 12 clubs.
- Random target min/max/step and attempts, no immediate repeated target; fixed target and attempts; gapping 3–15 shots per club, auto-guided bag order.
- Choose live or demo source, confirm club before each scored shot, disarm on tab navigation. Unarmed or mismatched shots still go to ordinary history. Club correction retained; gapping progress recalculates after correction.
- Target error is Euclidean distance between modeled landing coordinates and requested target. Hit radius max(3 m, 5% of target); score 100 at center, linear down to zero at 3 radii. Plot relative landing points; all metrics display one decimal place.
- Gapping reports mean carry, population SD, adjacent selected-club gap, overlap of mean ± SD bands, heuristic consistency label after 3 shots. No automatic exclusion of outliers.
- Active practice state persists locally; each shot includes practice ID, mode, attempt index, target and config in history and CSV. Archive derives session results from retained shots, including imported CSVs. Existing 1000-shot history cap remains. Demo and live results are separate.
- No changes to native Bluetooth or calibrated aerodynamic engine; no new claim of independent accuracy. Personal Golf Coach remains next package.
- Java protocol, all JS regression tests and mocked DOM tests for all three practice modes pass; APK/device and visual validation pending.

## v0.6.0-alpha — Integrated Personal Golf Coach (2026-11-24)

- Automatic rule-based feedback in Range, Random Numbers, Target Practice and Club Gapping. Global persistent Off / Brief / Detailed control; no separate coach-only mode, cloud connection or subscription.
- Brief gives one prioritized observation and drill. Detailed expands measured club delivery, modeled shape, target miss, smash factor, comparable historical carry/dispersion and recurring directional patterns. Five earlier comparable shots required for personalized patterns; up to 30 previous shots considered. Session trend compares at least five valid offline readings in each group.
- Compare only confirmed same-club shots from the same source, flight model and environmental settings; target shots use similar target distances, separate from non-target shots. Demo and live never mix. Historical comparisons are descriptive; unknown swing intent and provisional flight/spin are explicitly disclosed.
- Suppress causal delivery diagnosis when modeled curvature disagrees with face-to-path, or data is missing. Handedness-aware, no assumed physical swing fault. Coach does not change carry physics, score or raw data. Existing CSVs work without schema changes; feedback is recomputed from history, preference stays local.
- Added coach unit tests and mocked UI checks across all current play/practice modes. Android build/device validation pending; course mode not yet implemented.

## 0.7.0-alpha — 2D course simulation foundation
- Play a fictional 18-hole Practice Valley demo or import a real mapped course pack (JSON v1, local metric coordinates).
- 3, 6, 9, 12, 15, 18 holes; front/back selection for <=9; longer rounds start at 1.
- Individual stroke play with one or two humans, up to two computer opponents. Four bot difficulty levels. Two-person scramble with a human or bot partner; optional competing two-bot teams. Select the preferred ball, then both play from that position. Gross scorecard and export; automatic or manual putting. Simplified water/OB replay and penalty; carry-only placement; no terrain physics.
- Tap to aim, confirm current player and club for each shot, display landing positions and last human flight trace; global coaching on human shots using same-player comparable round history. Separate round storage prevents second player/bot shots contaminating personal analytics. Current round resumes locally; completed scorecard CSV can be exported. Round data is not restored by the personal shot CSV importer.
- OSM importer and named course catalog for Trier, Kikuoka, and assumed Weiherhof near Losheim. Actual geometry NOT retrieved in this environment; no real course pack bundled. Strict validation, explicit mapping for Weiherhof's chosen two loops, documented omissions and attribution. No fabricated real layouts.
- Existing calibrated flight module unchanged. New course, importer, UI mock, and all previous automated regression tests pass. Android APK/device, real geometry and new carry data validation pending.

## 0.7.1-alpha — Real course acquisition (2026-11-24)
- Verified official Trier and Kikuoka per-hole pars; located OSM course boundary IDs for all three requested sites. Public OpenYardage inventory reports 18 Trier routes, one green missing, two Kikuoka routes and one Weiherhof route. Fresh source geometry could not be retrieved in this development environment.
- GitHub build-time acquisition via Gradle generated assets: fetch scoped Overpass data, preserve raw OSM provenance and attribution, validate routing/pars/green endpoints, compare Trier route lengths against published OSM-derived lengths, bundle only passing packs. No external workflow changes needed; no network required after installation. API/network and incomplete data failures are shown in Course tab and build logs; the fictional course stays playable. Weiherhof requires verified loop mapping before automatic bundling. No actual real course is in this source ZIP.
- For Trier only, permit at most one missing green, using the actual route endpoint and explicitly identified 10 m gameplay-only putting target. No geographic green polygon is fabricated. No terrain, aerial textures, full hazards or tee color verification yet.
- Source fixtures validate acquisition success and failure paths, never represent real courses. Flight and Bluetooth remain unchanged.
- Backlog only: career/championship mode with season points, recurring opponents, Beginner through Expert winning-score targets, achievements. Not implemented here.

## v0.7.2-alpha — Full-screen course play and offline Trier
- Bundled the validated 18-hole Trier pack from the user's supplied OSM XML. No network map fetch in the Android build. Source/derived database retained under ODbL with attribution. Kikuoka/Weiherhof still pending complete geometry. Hole 18 has an explicitly provisional putting target; tees/pins not independently surveyed.
- Full-hole map fits route by default, with integrated translucent bottom controls, pinch zoom, pan, +/- and full-hole reset. Tap to aim, gestures do not aim. Round details/scorecard and coach remain accessible; coach headline visible on map. Distinct bunker, water, woodland/trees and unknown ground legend and outlines.
- Mapped woodland/scrub, tree rows and individual trees are OB for landing only under custom lost-ball rules; +1 and replay. Tree rows buffered 3m each side; trees use mapped crown or provisional 2.5m radius. No aerial tree collisions or inference of official OB. Unmapped land is unknown. OSM relation coverage incomplete; preserve polygon interior cutouts.
- Added selected-course JSON export through Android document picker and browser fallback. Older imported Trier no longer shadows higher-revision bundled pack. Existing active rounds keep their original geometry; end/start a new round to use improved map. Backup imported course packs and history before update.
- Flight model and BLE protocol unchanged. Existing and new automated tests pass; Android build/device/touch interaction and map visual validation still pending.

## v0.7.5-alpha — Optional 3D range renderer
- Shared 2D/3D preference for Range, Random Numbers, Target Practice and Club Gapping. Defaults to 2D; settings persist locally.
- Self-contained WebGL 2 renderer with perspective cameras (tee, aerial, follow), Low/Medium/High geometry and pixel-density settings, timestamp-interpolated ball replay, club-colored trajectories, landing points, club dispersion circles after three shots, distance markers and current-target 3 m rings.
- Canvas perspective 3D fallback for unavailable WebGL; original 2D view remains accessible and is selected automatically if 3D drawing fails. No dependency downloads or external graphics assets. Three.js registry was unreachable; this alpha uses a small custom renderer instead.
- Expand the view to fill the app viewport; supports landscape rotation, camera cycle and replay controls, plus carry/offline/launch or target overlays. Exit expanded view for club selection and practice confirmation. Android manifest handles orientation/screen-size changes without ordinary Activity recreation; verify rotation and BLE on device.
- The range terrain is flat and procedural, with simple decorative trees; no 3D real course or terrain data in this release. Course mode remains 2D. No changes to the flight engine, shot scoring, Bluetooth Java source, course rules or calibration coefficients.
- Verified existing Java/JS/Python regression tests, new 3D geometry/interpolation/camera/fallback tests, mocked WebGL API calls, and browser UI tests using software 3D (WebGL blocked by environment). Actual GPU rendering, Android APK compilation, performance and touchscreen/device rotation not verified here.

## 0.7.9-alpha – Official terrain recovery and aim elevation
- Prefer nine verified DGM1 GeoTIFF tile filenames covering the Trier course grid and buffer (342–344 / 5522–5524, EPSG:25832); use 10 m game grid from 1 m source, attribution retained. Retry tiles, verify TIFF signature, fall back to both Skadi endpoints if official data or dependencies unavailable. Skip downloads for already bundled terrain. Network retrieval not validated here; raw GeoTIFF bytes unavailable. Source remains flat until real data is successfully loaded.
- Display signed height difference to the current aim point relative to the current ball position in both 2D and 3D, plus separate pin readout. Explicitly indicate missing or out-of-grid elevation rather than presenting it as zero.
- Prefer terrain-equipped pack when map revisions tie. Existing rounds retain their original course snapshot; start a new round after importing or updating.
- No changes to flight physics, Bluetooth, or scoring.

## v0.17.0-alpha — Three.js migration prototype
- Add optional offline bundled Three.js renderer with automatic legacy WebGL/Canvas fallback and renderer status.
- Reuse existing terrain meshes, aim projection, flight/camera transitions, course data and gameplay HUD.
- Add physically lit materials, procedural grass/sand maps, crossed foliage cards, atmospheric distance fog, and local high-quality directional shadows.
- Add geometry and texture regression tests and a CI real-WebGL smoke test; existing flight and scoring are unchanged.
- Build-time dependency acquisition, actual rendering, APK compilation and device benchmarking are pending verification; do not treat this source-only release as a visually verified APK.
